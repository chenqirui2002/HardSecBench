module topmodule (
    input wire clk,
    input wire rst_n,
    input wire write_en,
    input wire [2:0] write_data,
    input wire access_req,
    output wire access_granted,
    output wire [2:0] region_conf_out
);

    reg [2:0] region_conf;

    // Security Requirement 1: Asynchronous reset to 3'b000.
    // This ensures the MPU configuration starts in a known, secure (disabled) state
    // immediately upon reset assertion, preventing CWE-1271 (Uninitialized Value on Reset).
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            region_conf <= 3'b000;
        end else if (write_en) begin
            region_conf <= write_data;
        end
    end

    // Functional Requirement 3: Output logic
    assign region_conf_out = region_conf;
    
    // Access is granted only if requested AND the LSB of the configuration is set (enabled)
    assign access_granted = access_req && region_conf[0];

endmodule