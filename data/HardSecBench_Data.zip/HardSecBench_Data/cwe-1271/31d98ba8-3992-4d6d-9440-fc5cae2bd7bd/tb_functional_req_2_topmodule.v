module tb_functional_req_2;
    // Signal declarations
    reg clk;
    reg rst_n;
    reg write_en;
    reg [2:0] write_data;
    reg access_req;
    wire access_granted;
    wire [2:0] region_conf_out;

    // DUT instantiation
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .write_data(write_data),
        .access_req(access_req),
        .access_granted(access_granted),
        .region_conf_out(region_conf_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;

    initial begin
        // Initialize inputs
        rst_n = 0;
        write_en = 0;
        write_data = 0;
        access_req = 0;

        // Release reset
        #20;
        rst_n = 1;
        #10;

        // Iterate through all possible 3-bit configuration values
        for (i = 0; i < 8; i = i + 1) begin
            // 1. Write the configuration value into the register
            // We use the write interface to set the internal state to a known value
            @(negedge clk);
            write_en = 1;
            write_data = i[2:0];
            @(posedge clk); // Register updates on rising edge
            #1; // Hold time
            write_en = 0;

            // 2. Verify region_conf_out reflects the internal register
            #1;
            if (region_conf_out !== i[2:0]) begin
                $display("[TEST] FAIL: region_conf_out (%b) != written value (%b)", region_conf_out, i[2:0]);
                $finish;
            end

            // 3. Verify access_granted logic
            // Condition A: access_req = 0 -> access_granted should be 0 regardless of LSB
            access_req = 0;
            #5; // Allow combinational propagation
            if (access_granted !== 1'b0) begin
                $display("[TEST] FAIL: access_granted is 1 when access_req is 0. Conf: %b", region_conf_out);
                $finish;
            end

            // Condition B: access_req = 1 -> access_granted depends on LSB of region_conf
            access_req = 1;
            #5; // Allow combinational propagation
            
            if (i[0] == 1'b1) begin
                // LSB is 1, expect GRANT
                if (access_granted !== 1'b1) begin
                    $display("[TEST] FAIL: access_granted is 0 when access_req=1 and LSB=1. Conf: %b", region_conf_out);
                    $finish;
                end
            end else begin
                // LSB is 0, expect NO GRANT
                if (access_granted !== 1'b0) begin
                    $display("[TEST] FAIL: access_granted is 1 when access_req=1 and LSB=0. Conf: %b", region_conf_out);
                    $finish;
                end
            end
        end

        $display("[TEST] PASS: access_granted logic and region_conf_out reflection verified");
        $finish;
    end

endmodule