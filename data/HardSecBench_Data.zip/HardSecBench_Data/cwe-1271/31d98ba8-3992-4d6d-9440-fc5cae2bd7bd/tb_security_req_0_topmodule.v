module testbench;
    // Signal declarations
    reg clk;
    reg rst_n;
    reg write_en;
    reg [2:0] write_data;
    reg access_req;
    
    wire access_granted;
    wire [2:0] region_conf_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .write_data(write_data),
        .access_req(access_req),
        .access_granted(access_granted),
        .region_conf_out(region_conf_out)
    );

    initial begin
        // Initialize inputs
        clk = 0;
        rst_n = 0;
        write_en = 0;
        write_data = 3'b000;
        access_req = 0;

        // Release reset to start operation
        #10 rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Step 1: Setup - Write a non-zero value (3'b111) to region_conf
        // -------------------------------------------------------
        write_en = 1;
        write_data = 3'b111;
        access_req = 1; // Enable request to verify access is granted when conf is set
        
        // Clock edge to capture data
        #5 clk = 1;
        #5 clk = 0;
        write_en = 0;

        // Verify setup was successful
        if (region_conf_out !== 3'b111) begin
            $display("[TEST] FAIL: Setup failed. Could not write initial value to register.");
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Test Asynchronous Reset
        // -------------------------------------------------------
        // Assert reset (active low) while clock is low (asynchronous check)
        #5 rst_n = 0;
        #5; // Small delay for propagation, NO clock edge here

        // -------------------------------------------------------
        // Step 3: Verify Security Requirement
        // -------------------------------------------------------
        // Requirement: region_conf must be asynchronously reset to 3'b000
        if (region_conf_out === 3'b000) begin
            // Secondary check: verify access is actually denied
            if (access_granted === 0) begin
                $display("[TEST] PASS: Register asynchronously reset to 0 and access disabled.");
            end else begin
                $display("[TEST] FAIL: Register reset to 0, but access_granted is still high.");
            end
        end else begin
            $display("[TEST] FAIL: Register did not reset to 3'b000 asynchronously. Current value: %b", region_conf_out);
        end

        $finish;
    end
endmodule