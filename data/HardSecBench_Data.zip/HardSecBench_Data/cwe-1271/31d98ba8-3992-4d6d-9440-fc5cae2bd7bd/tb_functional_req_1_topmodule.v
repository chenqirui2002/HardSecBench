`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [2:0] write_data;
    reg access_req;

    // Outputs
    wire access_granted;
    wire [2:0] region_conf_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .write_data(write_data),
        .access_req(access_req),
        .access_granted(access_granted),
        .region_conf_out(region_conf_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        write_data = 0;
        access_req = 0;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // Test Case 1: Write 3'b101
        // Setup data and enable
        write_en = 1;
        write_data = 3'b101;
        
        // Check before clock edge (should hold previous value, likely 0 from reset)
        // This ensures it is not a combinational pass-through
        if (region_conf_out === 3'b101) begin
             $display("[TEST] FAIL: region_conf_out updated before clock edge (combinational logic detected).");
             $finish;
        end

        // Trigger Clock Edge
        @(posedge clk);
        #1; // Allow for propagation delay

        // Check after clock edge
        if (region_conf_out !== 3'b101) begin
            $display("[TEST] FAIL: region_conf_out did not update to 3'b101 after write cycle. Got: %b", region_conf_out);
            $finish;
        end else begin
            $display("[TEST] PASS: region_conf_out updated to 3'b101 correctly.");
        end

        // Test Case 2: Write 3'b010 (Verify value change)
        write_data = 3'b010;
        
        @(posedge clk);
        #1; // Allow for propagation delay

        if (region_conf_out !== 3'b010) begin
            $display("[TEST] FAIL: region_conf_out did not update to 3'b010 after write cycle. Got: %b", region_conf_out);
            $finish;
        end else begin
            $display("[TEST] PASS: region_conf_out updated to 3'b010 correctly.");
        end

        // Test Case 3: Verify write_en low prevents update
        // Although the requirement focuses on write_en high, functional correctness implies
        // it acts as an enable.
        write_en = 0;
        write_data = 3'b111;
        
        @(posedge clk);
        #1;

        if (region_conf_out === 3'b111) begin
            $display("[TEST] FAIL: region_conf_out updated when write_en was low.");
            $finish;
        end else if (region_conf_out !== 3'b010) begin
            $display("[TEST] FAIL: region_conf_out changed unexpectedly when write_en was low.");
            $finish;
        end else begin
            $display("[TEST] PASS: region_conf_out held value 3'b010 when write_en was low.");
        end

        $display("[TEST] PASS: Functional Requirement 1 Verified.");
        $finish;
    end

endmodule