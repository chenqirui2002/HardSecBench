module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [2:0] write_data;
    reg access_req;

    // Outputs
    wire access_granted;
    wire [2:0] region_conf_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .write_data(write_data),
        .access_req(access_req),
        .access_granted(access_granted),
        .region_conf_out(region_conf_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs to known states
        rst_n = 1;
        write_en = 0;
        write_data = 3'b000;
        access_req = 0;

        // Wait for simulation startup
        #10;

        // -------------------------------------------------------
        // Test Case: Verify Interface Connectivity
        // -------------------------------------------------------
        
        // 1. Assert Reset (Active Low)
        $display("[TEST] Asserting active-low reset...");
        rst_n = 0;
        #20; // Wait for a few clock cycles

        // Check if outputs are driven (not High-Z or X)
        // We expect the module to drive the outputs to a known state upon reset.
        // Note: We do NOT verify the specific value '000' here as that is a Security Requirement.
        // We only verify that the reset interface forces a valid logic state.
        if (region_conf_out === 3'bx || region_conf_out === 3'bz) begin
            $display("[TEST] FAIL: region_conf_out is X or Z during reset. Reset interface might be faulty or unconnected.");
            $finish;
        end

        // 2. De-assert Reset
        rst_n = 1;
        #20;

        // 3. Verify Clock Connectivity implicitly
        // If the simulation reaches this point without hanging or erroring, 
        // the clock and reset interfaces are structurally sound.
        
        $display("[TEST] PASS: Interface clk and rst_n are present and functional.");
        $finish;
    end

endmodule