#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declare the function under test
extern size_t module(int reset_cause, volatile uint32_t *ctrl_reg, const uint8_t *src_mem, uint8_t *dest_buf, size_t len);

int main(void) {
    // Common setup
    const uint8_t src_mem[] = {0x11, 0x22, 0x33, 0x44};
    uint8_t dest_buf[4];
    size_t len = sizeof(src_mem);
    volatile uint32_t ctrl_reg;
    size_t ret;
    int i;
    int fail;

    // Test Case 1: reset_cause = 0 (Cold Boot), ctrl_reg bit 0 is 1
    // Requirement: No copy, return 0
    {
        memset(dest_buf, 0xAA, sizeof(dest_buf));
        ctrl_reg = 0x01; // Bit 0 set
        
        ret = module(0, &ctrl_reg, src_mem, dest_buf, len);
        
        fail = 0;
        if (ret != 0) {
            fail = 1;
            printf("[CASE-1] FAIL: Expected return 0 for reset_cause=0, got %zu\n", ret);
        }
        
        // Verify no copy occurred
        for (i = 0; i < 4; i++) {
            if (dest_buf[i] != 0xAA) {
                fail = 1;
                printf("[CASE-1] FAIL: Memory copied despite reset_cause=0\n");
                break;
            }
        }
        
        if (!fail) {
            printf("[CASE-1] PASS: Correctly handled Cold Boot (reset_cause=0)\n");
        }
    }

    // Test Case 2: reset_cause = 1 (Warm Boot), ctrl_reg bit 0 is 0
    // Requirement: No copy, return 0
    {
        memset(dest_buf, 0xBB, sizeof(dest_buf));
        ctrl_reg = 0x02; // Bit 0 NOT set (bit 1 is set)
        
        ret = module(1, &ctrl_reg, src_mem, dest_buf, len);
        
        fail = 0;
        if (ret != 0) {
            fail = 1;
            printf("[CASE-2] FAIL: Expected return 0 for unset bit, got %zu\n", ret);
        }
        
        for (i = 0; i < 4; i++) {
            if (dest_buf[i] != 0xBB) {
                fail = 1;
                printf("[CASE-2] FAIL: Memory copied despite ctrl_reg bit 0 unset\n");
                break;
            }
        }
        
        if (!fail) {
            printf("[CASE-2] PASS: Correctly handled unset control bit\n");
        }
    }

    // Test Case 3: reset_cause = 2 (Other), ctrl_reg bit 0 is 1
    // Requirement: No copy, return 0
    {
        memset(dest_buf, 0xCC, sizeof(dest_buf));
        ctrl_reg = 0x01; // Bit 0 set
        
        ret = module(2, &ctrl_reg, src_mem, dest_buf, len);
        
        fail = 0;
        if (ret != 0) {
            fail = 1;
            printf("[CASE-3] FAIL: Expected return 0 for reset_cause=2, got %zu\n", ret);
        }
        
        for (i = 0; i < 4; i++) {
            if (dest_buf[i] != 0xCC) {
                fail = 1;
                printf("[CASE-3] FAIL: Memory copied despite reset_cause=2\n");
                break;
            }
        }
        
        if (!fail) {
            printf("[CASE-3] PASS: Correctly handled unknown reset_cause\n");
        }
    }

    return 0;
}