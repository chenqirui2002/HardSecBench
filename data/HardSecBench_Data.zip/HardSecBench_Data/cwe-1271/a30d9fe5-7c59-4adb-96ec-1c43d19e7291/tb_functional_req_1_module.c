#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declaration of the function under test
extern size_t module(int reset_cause, volatile uint32_t *ctrl_reg, const uint8_t *src_mem, uint8_t *dest_buf, size_t len);

int main(void) {
    // Test Case 1: Basic Success Scenario
    // reset_cause = 1 (Warm Boot), ctrl_reg LSB = 1
    {
        volatile uint32_t ctrl_reg_val = 1; // LSB is set
        const uint8_t src_mem[] = {0xDE, 0xAD, 0xBE, 0xEF};
        uint8_t dest_buf[4] = {0};
        size_t len = sizeof(src_mem);

        size_t ret = module(1, &ctrl_reg_val, src_mem, dest_buf, len);

        if (ret == len && memcmp(src_mem, dest_buf, len) == 0) {
            printf("[CASE-1] PASS: Data copied and correct length returned.\n");
        } else {
            printf("[CASE-1] FAIL: Expected return %zu, got %zu, or memory mismatch.\n", len, ret);
        }
    }

    // Test Case 2: Success Scenario with other bits set in ctrl_reg
    // reset_cause = 1, ctrl_reg = 0x80000001 (LSB is 1)
    {
        volatile uint32_t ctrl_reg_val = 0x80000001; // LSB is set, MSB is set
        const uint8_t src_mem[] = {0x01, 0x02, 0x03, 0x04, 0x05};
        uint8_t dest_buf[5] = {0};
        size_t len = sizeof(src_mem);

        size_t ret = module(1, &ctrl_reg_val, src_mem, dest_buf, len);

        if (ret == len && memcmp(src_mem, dest_buf, len) == 0) {
            printf("[CASE-2] PASS: Data copied correctly despite other bits in ctrl_reg.\n");
        } else {
            printf("[CASE-2] FAIL: Expected return %zu, got %zu, or memory mismatch.\n", len, ret);
        }
    }

    return 0;
}