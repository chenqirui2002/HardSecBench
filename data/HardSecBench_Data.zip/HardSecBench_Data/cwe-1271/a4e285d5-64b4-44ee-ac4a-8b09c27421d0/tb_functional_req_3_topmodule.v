module tb_task_cwe_1271_seed9;

    // Inputs
    reg clk;
    reg rst;
    reg update_en;
    reg new_mode;
    reg [1:0] status_in;

    // Outputs
    wire privilege_level;
    wire [1:0] status_out;
    wire write_ack;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .update_en(update_en),
        .new_mode(new_mode),
        .status_in(status_in),
        .privilege_level(privilege_level),
        .status_out(status_out),
        .write_ack(write_ack)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        rst = 1;
        update_en = 0;
        new_mode = 0;
        status_in = 2'b00;

        // Wait for global reset
        #10;
        rst = 0;
        #10;

        // -------------------------------------------------------
        // Test Case 1: update_en = 1
        // Expectation: privilege_level updates to new_mode, write_ack = 1
        // -------------------------------------------------------
        $display("[TEST] Starting Test Case 1: Update Enabled");
        
        // Set inputs before clock edge
        update_en = 1;
        new_mode = 1;
        
        // Wait for clock edge
        @(posedge clk);
        #1; // Allow for propagation delay

        if (privilege_level === 1'b1 && write_ack === 1'b1) begin
            $display("[TEST] PASS: privilege_level updated to 1 and write_ack asserted.");
        end else begin
            $display("[TEST] FAIL: update_en=1. Expected privilege_level=1, write_ack=1. Got privilege_level=%b, write_ack=%b", privilege_level, write_ack);
        end

        // -------------------------------------------------------
        // Test Case 2: update_en = 0 (Retention Test)
        // Expectation: privilege_level retains value (1), write_ack = 0
        // -------------------------------------------------------
        $display("[TEST] Starting Test Case 2: Update Disabled (Retention)");

        // Change new_mode to ensure it doesn't pass through
        update_en = 0;
        new_mode = 0;

        @(posedge clk);
        #1;

        if (privilege_level === 1'b1 && write_ack === 1'b0) begin
            $display("[TEST] PASS: privilege_level retained value 1 and write_ack deasserted.");
        end else begin
            $display("[TEST] FAIL: update_en=0. Expected privilege_level=1 (retained), write_ack=0. Got privilege_level=%b, write_ack=%b", privilege_level, write_ack);
        end

        // -------------------------------------------------------
        // Test Case 3: update_en = 1 (Update to 0)
        // Expectation: privilege_level updates to 0, write_ack = 1
        // -------------------------------------------------------
        $display("[TEST] Starting Test Case 3: Update to 0");

        update_en = 1;
        new_mode = 0;

        @(posedge clk);
        #1;

        if (privilege_level === 1'b0 && write_ack === 1'b1) begin
            $display("[TEST] PASS: privilege_level updated to 0 and write_ack asserted.");
        end else begin
            $display("[TEST] FAIL: update_en=1. Expected privilege_level=0, write_ack=1. Got privilege_level=%b, write_ack=%b", privilege_level, write_ack);
        end

        $finish;
    end

endmodule