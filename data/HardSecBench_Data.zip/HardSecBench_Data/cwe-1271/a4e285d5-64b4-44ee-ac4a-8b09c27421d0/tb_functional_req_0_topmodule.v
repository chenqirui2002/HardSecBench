module tb_functional_req_0;

    // Testbench signals
    reg clk;
    reg rst;
    reg update_en;
    reg new_mode;
    reg [1:0] status_in;

    // Outputs from UUT
    wire privilege_level;
    wire [1:0] status_out;
    wire write_ack;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .update_en(update_en),
        .new_mode(new_mode),
        .status_in(status_in),
        .privilege_level(privilege_level),
        .status_out(status_out),
        .write_ack(write_ack)
    );

    initial begin
        // Initialize Inputs
        clk = 0;
        rst = 0;
        update_en = 0;
        new_mode = 0;
        status_in = 2'b00;

        // Wait for global reset/stabilization
        #10;

        // Step 1: Set a non-zero state to verify reset capability.
        // We use status_in = 2'b11. Assuming standard operation (Req-2), 
        // status_out should capture this on the next clock edge.
        status_in = 2'b11;
        
        #10 clk = 1; 
        #10 clk = 0;

        // Verify pre-condition
        if (status_out !== 2'b11) begin
            $display("[TEST] FAIL: Pre-condition setup failed. status_out did not update to 2'b11 with rst=0.");
            $finish;
        end

        // Step 2: Assert active-high reset WITHOUT clocking
        rst = 1;
        #10; // Wait to see if asynchronous reset occurs

        // Check if output changed immediately (Asynchronous behavior check)
        if (status_out === 2'b00) begin
            $display("[TEST] FAIL: Reset appears to be Asynchronous (output cleared before clock edge).");
            $finish;
        end

        // Step 3: Apply Clock Edge to trigger Synchronous Reset
        #10 clk = 1;
        #10 clk = 0;

        // Step 4: Verify Reset occurred
        if (status_out === 2'b00) begin
            $display("[TEST] PASS: Reset is synchronous and active-high.");
        end else begin
            $display("[TEST] FAIL: Output did not reset to 0 after clock edge with rst=1 (status_out=%b).", status_out);
        end

        $finish;
    end

endmodule