module tb_functional_req_2;

    // Signal Declarations
    reg clk;
    reg rst;
    reg update_en;
    reg new_mode;
    reg [1:0] status_in;

    wire privilege_level;
    wire [1:0] status_out;
    wire write_ack;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .update_en(update_en),
        .new_mode(new_mode),
        .status_in(status_in),
        .privilege_level(privilege_level),
        .status_out(status_out),
        .write_ack(write_ack)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    integer i;
    reg [1:0] expected_status;

    initial begin
        // Initialize Inputs
        rst = 1;
        update_en = 0;
        new_mode = 0;
        status_in = 2'b00;

        // Apply Reset
        @(posedge clk);
        #1; // Hold time
        
        // Deassert reset to begin testing REQ-2
        rst = 0;

        // Test Loop
        for (i = 0; i < 20; i = i + 1) begin
            // Set inputs before the clock edge
            status_in = $random;
            
            // Randomize other inputs to ensure status_out logic is independent
            update_en = $random;
            new_mode = $random;
            
            // Store expected value
            expected_status = status_in;

            // Wait for active clock edge
            @(posedge clk);
            
            // Check output after propagation delay
            #1;
            if (status_out !== expected_status) begin
                $display("[TEST] FAIL: status_out mismatch. Expected %b, Got %b", expected_status, status_out);
                $finish;
            end
        end

        // If loop completes without failure
        $display("[TEST] PASS: status_out updates correctly on every cycle when rst is deasserted");
        $finish;
    end

endmodule