module testbench_security_req_0;

    // Inputs
    reg clk;
    reg rst;
    reg update_en;
    reg new_mode;
    reg [1:0] status_in;

    // Outputs
    wire privilege_level;
    wire [1:0] status_out;
    wire write_ack;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .update_en(update_en),
        .new_mode(new_mode),
        .status_in(status_in),
        .privilege_level(privilege_level),
        .status_out(status_out),
        .write_ack(write_ack)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst = 0;
        update_en = 0;
        new_mode = 0;
        status_in = 2'b00;

        // Wait for initial stabilization
        #10;

        // -------------------------------------------------------
        // Step 1: Set privilege_level to 1 (Privileged Mode)
        // This ensures we are resetting FROM a known high state.
        // -------------------------------------------------------
        @(negedge clk);
        rst = 0;
        update_en = 1;
        new_mode = 1;
        
        @(negedge clk); // Wait for one clock cycle for update to occur
        
        // Debug info regarding setup
        if (privilege_level === 1'b1) begin
            $display("[INFO] Setup successful: privilege_level set to 1.");
        end else begin
            $display("[INFO] Setup note: privilege_level is %b (could be stuck at 0 or X). Proceeding to reset test.", privilege_level);
        end

        // -------------------------------------------------------
        // Step 2: Assert Reset
        // -------------------------------------------------------
        rst = 1;
        update_en = 0; // Disable update to isolate reset functionality
        new_mode = 0;

        @(negedge clk); // Wait for rising edge (synchronous reset)

        // -------------------------------------------------------
        // Step 3: Verify Security Requirement
        // Requirement: privilege_level must be 0 after reset
        // -------------------------------------------------------
        if (privilege_level === 1'b0) begin
            $display("[TEST] PASS: privilege_level reset to 0 (User Mode) when rst was asserted.");
        end else begin
            $display("[TEST] FAIL: privilege_level did not reset to 0. Current value: %b", privilege_level);
        end

        $finish;
    end

endmodule