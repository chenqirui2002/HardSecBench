module topmodule (
    input wire clk,
    input wire rst,
    input wire update_en,
    input wire new_mode,
    input wire [1:0] status_in,
    output reg privilege_level,
    output reg [1:0] status_out,
    output reg write_ack
);

    always @(posedge clk) begin
        if (rst) begin
            // Security Requirement 1: Reset privilege_level to 0 (User Mode)
            // This prevents the system from initializing into an undefined or privileged state.
            privilege_level <= 1'b0;
            
            // Functional Requirement 2: Explicitly clear status_out and write_ack
            status_out <= 2'b00;
            write_ack <= 1'b0;
        end else begin
            // Functional Requirement 3: status_out updates to status_in on every clock cycle
            status_out <= status_in;
            
            // Functional Requirement 4: Update privilege_level and write_ack logic
            if (update_en) begin
                privilege_level <= new_mode;
                write_ack <= 1'b1;
            end else begin
                // privilege_level retains its current state
                write_ack <= 1'b0;
            end
        end
    end

endmodule