module tb_functional_req_1;
    // Signals
    reg clk;
    reg rst;
    reg update_en;
    reg new_mode;
    reg [1:0] status_in;

    wire privilege_level;
    wire [1:0] status_out;
    wire write_ack;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .update_en(update_en),
        .new_mode(new_mode),
        .status_in(status_in),
        .privilege_level(privilege_level),
        .status_out(status_out),
        .write_ack(write_ack)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize inputs
        rst = 0;
        update_en = 0;
        new_mode = 0;
        status_in = 2'b00;

        // Wait for global reset/startup
        #10;

        // -------------------------------------------------------
        // Test Case 1: Assert Reset and check outputs
        // -------------------------------------------------------
        // Set inputs to values that would produce non-zero outputs if reset were ignored
        // status_in = 2'b11 (would propagate to status_out if not reset)
        // update_en = 1 (would set write_ack to 1 if not reset)
        rst = 1;
        status_in = 2'b11;
        update_en = 1;
        new_mode = 1;

        // Wait for synchronous reset edge
        @(posedge clk);
        #1; // Small delay for output propagation

        // Check Requirement [FUNCTIONAL-REQ-1]
        if (status_out !== 2'b00) begin
            $display("[TEST] FAIL: status_out is %b, expected 00 when rst is asserted.", status_out);
        end else if (write_ack !== 1'b0) begin
            $display("[TEST] FAIL: write_ack is %b, expected 0 when rst is asserted.", write_ack);
        end else begin
            $display("[TEST] PASS: status_out and write_ack cleared correctly on reset.");
        end

        // -------------------------------------------------------
        // Test Case 2: Maintain Reset with different inputs
        // -------------------------------------------------------
        // Change inputs while keeping reset high to ensure it stays cleared
        status_in = 2'b10;
        update_en = 1;
        
        @(posedge clk);
        #1;

        if (status_out !== 2'b00) begin
            $display("[TEST] FAIL: status_out is %b, expected 00 during sustained reset.", status_out);
        end else if (write_ack !== 1'b0) begin
            $display("[TEST] FAIL: write_ack is %b, expected 0 during sustained reset.", write_ack);
        end else begin
            $display("[TEST] PASS: Outputs remained cleared during sustained reset.");
        end

        $finish;
    end

endmodule