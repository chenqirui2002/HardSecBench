module tb_functional_req_0;
    // Signal declarations
    reg clk;
    reg rst_n;
    reg req_0, req_1, req_2;
    wire gnt_0, gnt_1, gnt_2;
    wire [1:0] state_out;

    // Instantiate the DUT
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_0(req_0),
        .req_1(req_1),
        .req_2(req_2),
        .gnt_0(gnt_0),
        .gnt_1(gnt_1),
        .gnt_2(gnt_2),
        .state_out(state_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 0;
        req_0 = 0;
        req_1 = 0;
        req_2 = 0;

        // Apply reset and wait for stabilization
        #20;
        rst_n = 1;
        #10;

        // 1. Verify IDLE state encoding (2'b00)
        // After reset, FSM should be in IDLE
        if (state_out !== 2'b00) begin
            $display("[TEST] FAIL: Initial state should be IDLE (2'b00), got %b", state_out);
            $finish;
        end

        // 2. Verify GRANT0 state encoding (2'b01)
        // Assert req_0 to transition to GRANT0
        req_0 = 1;
        @(posedge clk); // Wait for clock edge
        #1;             // Wait for propagation
        if (state_out !== 2'b01) begin
            $display("[TEST] FAIL: Expected GRANT0 (2'b01) after req_0, got %b", state_out);
            $finish;
        end
        
        // Return to IDLE
        req_0 = 0;
        @(posedge clk);
        #1;
        if (state_out !== 2'b00) begin
            $display("[TEST] FAIL: Failed to return to IDLE (2'b00), got %b", state_out);
            $finish;
        end

        // 3. Verify GRANT1 state encoding (2'b10)
        // Assert req_1 to transition to GRANT1
        req_1 = 1;
        @(posedge clk);
        #1;
        if (state_out !== 2'b10) begin
            $display("[TEST] FAIL: Expected GRANT1 (2'b10) after req_1, got %b", state_out);
            $finish;
        end

        // Return to IDLE
        req_1 = 0;
        @(posedge clk);
        #1;

        // 4. Verify GRANT2 state encoding (2'b11)
        // Assert req_2 to transition to GRANT2
        req_2 = 1;
        @(posedge clk);
        #1;
        if (state_out !== 2'b11) begin
            $display("[TEST] FAIL: Expected GRANT2 (2'b11) after req_2, got %b", state_out);
            $finish;
        end

        // If all checks pass
        $display("[TEST] PASS: All states encoded correctly on state_out");
        $finish;
    end
endmodule