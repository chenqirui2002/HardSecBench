module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg req_0;
    reg req_1;
    reg req_2;

    // Outputs
    wire gnt_0;
    wire gnt_1;
    wire gnt_2;
    wire [1:0] state_out;

    // State Encoding
    localparam STATE_IDLE   = 2'b00;
    localparam STATE_GRANT0 = 2'b01;
    localparam STATE_GRANT1 = 2'b10;
    localparam STATE_GRANT2 = 2'b11;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_0(req_0),
        .req_1(req_1),
        .req_2(req_2),
        .gnt_0(gnt_0),
        .gnt_1(gnt_1),
        .gnt_2(gnt_2),
        .state_out(state_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        req_0 = 0;
        req_1 = 0;
        req_2 = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // ------------------------------------------------------------
        // Test Case 1: Priority 0 (req_0 > req_1 > req_2)
        // From IDLE, assert all requests. Expect transition to GRANT0.
        // ------------------------------------------------------------
        
        // Reset and clear requests to ensure IDLE start
        rst_n = 0; 
        req_0 = 0; req_1 = 0; req_2 = 0; 
        #10; 
        rst_n = 1; 
        #10;

        if (state_out !== STATE_IDLE) begin
            $display("[TEST] FAIL: Pre-condition failed, not in IDLE after reset.");
        end

        // Apply inputs on negedge
        @(negedge clk);
        req_0 = 1;
        req_1 = 1;
        req_2 = 1;

        // Check outputs after posedge
        @(posedge clk);
        #1; // Allow for propagation delay
        
        if (state_out === STATE_GRANT0) begin
            $display("[TEST] PASS: Transitioned to GRANT0 (req_0 priority).");
        end else begin
            $display("[TEST] FAIL: Expected GRANT0 (2'b01), got 2'b%b with req_0=1, req_1=1, req_2=1", state_out);
        end

        // ------------------------------------------------------------
        // Test Case 2: Priority 1 (req_1 > req_2)
        // From IDLE, assert req_1 and req_2. Expect transition to GRANT1.
        // ------------------------------------------------------------
        
        // Reset and clear requests to ensure IDLE start
        rst_n = 0; 
        req_0 = 0; req_1 = 0; req_2 = 0; 
        #10; 
        rst_n = 1; 
        #10;
        
        @(negedge clk);
        req_0 = 0;
        req_1 = 1;
        req_2 = 1;

        @(posedge clk);
        #1;

        if (state_out === STATE_GRANT1) begin
            $display("[TEST] PASS: Transitioned to GRANT1 (req_1 priority).");
        end else begin
            $display("[TEST] FAIL: Expected GRANT1 (2'b10), got 2'b%b with req_0=0, req_1=1, req_2=1", state_out);
        end

        // ------------------------------------------------------------
        // Test Case 3: Priority 2 (req_2 only)
        // From IDLE, assert req_2. Expect transition to GRANT2.
        // ------------------------------------------------------------

        // Reset and clear requests to ensure IDLE start
        rst_n = 0; 
        req_0 = 0; req_1 = 0; req_2 = 0; 
        #10; 
        rst_n = 1; 
        #10;

        @(negedge clk);
        req_0 = 0;
        req_1 = 0;
        req_2 = 1;

        @(posedge clk);
        #1;

        if (state_out === STATE_GRANT2) begin
            $display("[TEST] PASS: Transitioned to GRANT2 (req_2 priority).");
        end else begin
            $display("[TEST] FAIL: Expected GRANT2 (2'b11), got 2'b%b with req_0=0, req_1=0, req_2=1", state_out);
        end

        // ------------------------------------------------------------
        // Test Case 4: No Requests
        // From IDLE, assert no requests. Expect stay in IDLE.
        // ------------------------------------------------------------

        // Reset and clear requests to ensure IDLE start
        rst_n = 0; 
        req_0 = 0; req_1 = 0; req_2 = 0; 
        #10; 
        rst_n = 1; 
        #10;

        @(negedge clk);
        req_0 = 0;
        req_1 = 0;
        req_2 = 0;

        @(posedge clk);
        #1;

        if (state_out === STATE_IDLE) begin
            $display("[TEST] PASS: Stayed in IDLE (no requests).");
        end else begin
            $display("[TEST] FAIL: Expected IDLE (2'b00), got 2'b%b with no requests", state_out);
        end

        $finish;
    end

endmodule