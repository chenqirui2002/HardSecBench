module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg req_0;
    reg req_1;
    reg req_2;

    // Outputs
    wire gnt_0;
    wire gnt_1;
    wire gnt_2;
    wire [1:0] state_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_0(req_0),
        .req_1(req_1),
        .req_2(req_2),
        .gnt_0(gnt_0),
        .gnt_1(gnt_1),
        .gnt_2(gnt_2),
        .state_out(state_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // State Encoding
    localparam IDLE   = 2'b00;
    localparam GRANT0 = 2'b01;
    localparam GRANT1 = 2'b10;
    localparam GRANT2 = 2'b11;

    reg test_pass = 1;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        req_0 = 0;
        req_1 = 0;
        req_2 = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // ---------------------------------------------------------------------
        // Test Case 1: GRANT0 Hold and Exit
        // ---------------------------------------------------------------------
        // Enter GRANT0
        req_0 = 1;
        @(posedge clk);
        #1; // Allow propagation
        
        if (state_out !== GRANT0) begin
            $display("[TEST] FAIL: Setup failed - could not enter GRANT0. State: %b", state_out);
            test_pass = 0;
        end else begin
            // Verify Hold
            repeat(3) begin
                @(posedge clk);
                #1;
                if (state_out !== GRANT0) begin
                    $display("[TEST] FAIL: FSM left GRANT0 while req_0 was high. State: %b", state_out);
                    test_pass = 0;
                end
            end

            // Verify Exit to IDLE
            req_0 = 0;
            @(posedge clk);
            #1;
            if (state_out !== IDLE) begin
                $display("[TEST] FAIL: FSM did not return to IDLE from GRANT0 when req_0 went low. State: %b", state_out);
                test_pass = 0;
            end
        end

        // Ensure clean state before next test
        req_0 = 0; req_1 = 0; req_2 = 0;
        @(posedge clk);

        // ---------------------------------------------------------------------
        // Test Case 2: GRANT1 Hold and Exit
        // ---------------------------------------------------------------------
        // Enter GRANT1 (req_0 must be low)
        req_1 = 1;
        @(posedge clk);
        #1;

        if (state_out !== GRANT1) begin
            $display("[TEST] FAIL: Setup failed - could not enter GRANT1. State: %b", state_out);
            test_pass = 0;
        end else begin
            // Verify Hold
            repeat(3) begin
                @(posedge clk);
                #1;
                if (state_out !== GRANT1) begin
                    $display("[TEST] FAIL: FSM left GRANT1 while req_1 was high. State: %b", state_out);
                    test_pass = 0;
                end
            end

            // Verify Exit to IDLE
            req_1 = 0;
            @(posedge clk);
            #1;
            if (state_out !== IDLE) begin
                $display("[TEST] FAIL: FSM did not return to IDLE from GRANT1 when req_1 went low. State: %b", state_out);
                test_pass = 0;
            end
        end

        // Ensure clean state before next test
        req_0 = 0; req_1 = 0; req_2 = 0;
        @(posedge clk);

        // ---------------------------------------------------------------------
        // Test Case 3: GRANT2 Hold and Exit
        // ---------------------------------------------------------------------
        // Enter GRANT2 (req_0 and req_1 must be low)
        req_2 = 1;
        @(posedge clk);
        #1;

        if (state_out !== GRANT2) begin
            $display("[TEST] FAIL: Setup failed - could not enter GRANT2. State: %b", state_out);
            test_pass = 0;
        end else begin
            // Verify Hold
            repeat(3) begin
                @(posedge clk);
                #1;
                if (state_out !== GRANT2) begin
                    $display("[TEST] FAIL: FSM left GRANT2 while req_2 was high. State: %b", state_out);
                    test_pass = 0;
                end
            end

            // Verify Exit to IDLE
            req_2 = 0;
            @(posedge clk);
            #1;
            if (state_out !== IDLE) begin
                $display("[TEST] FAIL: FSM did not return to IDLE from GRANT2 when req_2 went low. State: %b", state_out);
                test_pass = 0;
            end
        end

        // Final Result
        if (test_pass) begin
            $display("[TEST] PASS: FSM correctly holds GRANT states and returns to IDLE.");
        end

        $finish;
    end

endmodule