module tb_functional_req_3;

    // Inputs to uut
    reg clk;
    reg rst_n;
    reg req_0;
    reg req_1;
    reg req_2;

    // Outputs from uut
    wire gnt_0;
    wire gnt_1;
    wire gnt_2;
    wire [1:0] state_out;

    // State Encodings
    localparam STATE_IDLE   = 2'b00;
    localparam STATE_GRANT0 = 2'b01;
    localparam STATE_GRANT1 = 2'b10;
    localparam STATE_GRANT2 = 2'b11;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_0(req_0),
        .req_1(req_1),
        .req_2(req_2),
        .gnt_0(gnt_0),
        .gnt_1(gnt_1),
        .gnt_2(gnt_2),
        .state_out(state_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Task to verify output consistency based on current state
    task verify_outputs;
        begin
            // Check gnt_0: Should be high ONLY in GRANT0
            if (state_out == STATE_GRANT0) begin
                if (gnt_0 !== 1'b1) begin
                    $display("[TEST] FAIL: gnt_0 is %b in state GRANT0 (expected 1)", gnt_0);
                    $finish;
                end
            end else begin
                if (gnt_0 !== 1'b0) begin
                    $display("[TEST] FAIL: gnt_0 is %b in state %b (expected 0)", gnt_0, state_out);
                    $finish;
                end
            end

            // Check gnt_1: Should be high ONLY in GRANT1
            if (state_out == STATE_GRANT1) begin
                if (gnt_1 !== 1'b1) begin
                    $display("[TEST] FAIL: gnt_1 is %b in state GRANT1 (expected 1)", gnt_1);
                    $finish;
                end
            end else begin
                if (gnt_1 !== 1'b0) begin
                    $display("[TEST] FAIL: gnt_1 is %b in state %b (expected 0)", gnt_1, state_out);
                    $finish;
                end
            end

            // Check gnt_2: Should be high ONLY in GRANT2
            if (state_out == STATE_GRANT2) begin
                if (gnt_2 !== 1'b1) begin
                    $display("[TEST] FAIL: gnt_2 is %b in state GRANT2 (expected 1)", gnt_2);
                    $finish;
                end
            end else begin
                if (gnt_2 !== 1'b0) begin
                    $display("[TEST] FAIL: gnt_2 is %b in state %b (expected 0)", gnt_2, state_out);
                    $finish;
                end
            end
        end
    endtask

    initial begin
        // Initialize Inputs
        rst_n = 0;
        req_0 = 0;
        req_1 = 0;
        req_2 = 0;

        // Wait for global reset
        #15;
        rst_n = 1;
        #10;

        // 1. Check IDLE State Behavior
        verify_outputs(); // Should be IDLE, all grants 0

        // 2. Transition to GRANT0 and Check
        req_0 = 1;
        @(posedge clk); 
        #1; // Wait for output propagation
        
        // Ensure we reached the state to perform a valid test
        if (state_out !== STATE_GRANT0) begin
            $display("[TEST] WARNING: Failed to reach GRANT0, cannot verify GRANT0 output logic fully.");
        end
        verify_outputs();

        // Return to IDLE
        req_0 = 0;
        @(posedge clk);
        #1;
        verify_outputs();

        // 3. Transition to GRANT1 and Check
        req_1 = 1;
        @(posedge clk);
        #1;
        
        if (state_out !== STATE_GRANT1) begin
            $display("[TEST] WARNING: Failed to reach GRANT1, cannot verify GRANT1 output logic fully.");
        end
        verify_outputs();

        // Return to IDLE
        req_1 = 0;
        @(posedge clk);
        #1;
        verify_outputs();

        // 4. Transition to GRANT2 and Check
        req_2 = 1;
        @(posedge clk);
        #1;
        
        if (state_out !== STATE_GRANT2) begin
            $display("[TEST] WARNING: Failed to reach GRANT2, cannot verify GRANT2 output logic fully.");
        end
        verify_outputs();

        // Return to IDLE
        req_2 = 0;
        @(posedge clk);
        #1;
        verify_outputs();

        // If we made it here, all checks passed
        $display("[TEST] PASS: Output signals correctly asserted based on FSM state.");
        $finish;
    end

endmodule