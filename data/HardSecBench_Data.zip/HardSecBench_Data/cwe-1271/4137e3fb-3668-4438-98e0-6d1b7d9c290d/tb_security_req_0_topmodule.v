`timescale 1ns / 1ps

module tb_task_cwe_1271_seed1;

    // Inputs
    reg clk;
    reg rst_n;
    reg req_0;
    reg req_1;
    reg req_2;

    // Outputs
    wire gnt_0;
    wire gnt_1;
    wire gnt_2;
    wire [1:0] state_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .req_0(req_0), 
        .req_1(req_1), 
        .req_2(req_2), 
        .gnt_0(gnt_0), 
        .gnt_1(gnt_1), 
        .gnt_2(gnt_2), 
        .state_out(state_out)
    );

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 1;
        req_0 = 0;
        req_1 = 0;
        req_2 = 0;

        // Wait for global reset
        #10;
        
        // --- Step 1: Initialize to known state ---
        rst_n = 0;
        #10;
        rst_n = 1;
        #10;

        // --- Step 2: Drive FSM to a GRANT state (GRANT0) ---
        // Assert req_0. According to priority req_0 > req_1 > req_2.
        req_0 = 1;
        
        // Clock edge to transition IDLE -> GRANT0
        #5 clk = 1;
        #5 clk = 0;

        // Verify setup
        if (state_out !== 2'b01) begin
            $display("[TEST] FAIL: Setup failed. Could not reach GRANT0 state. Current state: %b", state_out);
            $finish;
        end
        
        // --- Step 3: Test Asynchronous Reset ---
        // Assert reset while clock is stable (Low) to verify asynchronous behavior.
        // If reset is synchronous, state won't change until next rising edge.
        rst_n = 0;
        #1; // Allow small propagation delay

        // Check state immediately
        if (state_out === 2'b00) begin
            // Also verify grants are de-asserted as a consequence of being in IDLE
            if (gnt_0 === 0 && gnt_1 === 0 && gnt_2 === 0) begin
                $display("[TEST] PASS: FSM reset asynchronously to IDLE state.");
            end else begin
                $display("[TEST] FAIL: State is IDLE, but grant signals are not 0. gnt_0=%b, gnt_1=%b, gnt_2=%b", gnt_0, gnt_1, gnt_2);
            end
        end else begin
            $display("[TEST] FAIL: Reset is not asynchronous. State remained %b after rst_n asserted (expected 00).", state_out);
        end

        $finish;
    end

endmodule