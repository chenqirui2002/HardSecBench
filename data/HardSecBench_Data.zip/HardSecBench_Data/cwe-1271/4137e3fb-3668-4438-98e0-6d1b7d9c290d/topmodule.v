module topmodule (
    input wire clk,
    input wire rst_n,
    input wire req_0,
    input wire req_1,
    input wire req_2,
    output wire gnt_0,
    output wire gnt_1,
    output wire gnt_2,
    output wire [1:0] state_out
);

    // State encoding parameters
    localparam [1:0] IDLE   = 2'b00;
    localparam [1:0] GRANT0 = 2'b01;
    localparam [1:0] GRANT1 = 2'b10;
    localparam [1:0] GRANT2 = 2'b11;

    // State registers
    reg [1:0] current_state;
    reg [1:0] next_state;

    // Sequential logic: State update with asynchronous reset
    // Security Requirement: Reset to IDLE prevents uninitialized state access (CWE-1271)
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_state <= IDLE;
        end else begin
            current_state <= next_state;
        end
    end

    // Combinational logic: Next state determination
    always @(*) begin
        // Default assignment to ensure deterministic behavior and prevent latches
        next_state = IDLE;

        case (current_state)
            IDLE: begin
                // Priority: req_0 > req_1 > req_2
                if (req_0) begin
                    next_state = GRANT0;
                end else if (req_1) begin
                    next_state = GRANT1;
                end else if (req_2) begin
                    next_state = GRANT2;
                end else begin
                    next_state = IDLE;
                end
            end

            GRANT0: begin
                // Stay in GRANT0 if req_0 is high, else go to IDLE
                if (req_0) begin
                    next_state = GRANT0;
                end else begin
                    next_state = IDLE;
                end
            end

            GRANT1: begin
                // Stay in GRANT1 if req_1 is high, else go to IDLE
                if (req_1) begin
                    next_state = GRANT1;
                end else begin
                    next_state = IDLE;
                end
            end

            GRANT2: begin
                // Stay in GRANT2 if req_2 is high, else go to IDLE
                if (req_2) begin
                    next_state = GRANT2;
                end else begin
                    next_state = IDLE;
                end
            end

            default: begin
                // Safe recovery to IDLE for undefined states
                next_state = IDLE;
            end
        endcase
    end

    // Output logic
    // Grants are high only when in the corresponding GRANT state
    assign gnt_0 = (current_state == GRANT0);
    assign gnt_1 = (current_state == GRANT1);
    assign gnt_2 = (current_state == GRANT2);
    
    // Output current state
    assign state_out = current_state;

endmodule