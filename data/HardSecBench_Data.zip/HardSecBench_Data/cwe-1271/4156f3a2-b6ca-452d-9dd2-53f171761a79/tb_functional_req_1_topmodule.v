`timescale 1ns/1ps

module tb_functional_req_1;

    reg clk;
    reg rst;
    reg wen;
    reg addr;
    reg [7:0] wdata;

    wire wdt_reset_o;
    wire [7:0] count_o;
    wire en_status_o;

    // Instantiate UUT
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .wen(wen),
        .addr(addr),
        .wdata(wdata),
        .wdt_reset_o(wdt_reset_o),
        .count_o(count_o),
        .en_status_o(en_status_o)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Helper Task: Wait for counter to wrap and check reload value
    task wait_for_reload;
        input [7:0] expected;
        input [255:0] msg;
        integer timeout;
        begin
            timeout = 500; // Max 256 cycles for 8-bit counter
            // Wait for counter to reach 0
            while (count_o !== 8'h00 && timeout > 0) begin
                @(negedge clk);
                timeout = timeout - 1;
            end
            
            if (timeout <= 0) begin
                $display("[TEST] FAIL: Timeout waiting for counter to reach 0. (%s)", msg);
                $finish;
            end
            
            // Counter is 0 now. On next rising edge it should load reload_val.
            // Wait for that edge + propagation (negedge)
            @(negedge clk);
            
            if (count_o !== expected) begin
                $display("[TEST] FAIL: %s. Expected reload value 0x%h, got 0x%h", msg, expected, count_o);
                $finish;
            end else begin
                $display("[TEST] PASS Check: %s. Reloaded 0x%h correctly.", msg, count_o);
            end
        end
    endtask

    initial begin
        // Optional waveform dumping
        // Initialize
        rst = 1;
        wen = 0;
        addr = 0;
        wdata = 0;
        #20;
        rst = 0;
        #10;

        // ----------------------------------------------------------------
        // Part 1: Test wdt_en update (addr = 1)
        // Requirement: if addr is 1'b1, wdt_en updated with wdata[0]
        // ----------------------------------------------------------------
        $display("----------------------------------------------------------------");
        $display("[TEST] Step 1: Testing wdt_en update (addr=1)");
        
        // 1. Write 0 to wdt_en
        @(negedge clk);
        wen = 1;
        addr = 1;
        wdata = 8'h00; 
        @(negedge clk);
        wen = 0;
        #1; 
        if (en_status_o !== 1'b0) begin
            $display("[TEST] FAIL: wdt_en did not update to 0. Got %b", en_status_o);
            $finish;
        end

        // 2. Write 1 to wdt_en
        @(negedge clk);
        wen = 1;
        addr = 1;
        wdata = 8'h01;
        @(negedge clk);
        wen = 0;
        #1;
        if (en_status_o !== 1'b1) begin
            $display("[TEST] FAIL: wdt_en did not update to 1. Got %b", en_status_o);
            $finish;
        end
        
        // 3. Write 0 to wdt_en using upper bits (wdata[0] is 0)
        // Verifies only LSB is used
        @(negedge clk);
        wen = 1;
        addr = 1;
        wdata = 8'hFE; // LSB is 0
        @(negedge clk);
        wen = 0;
        #1;
        if (en_status_o !== 1'b0) begin
            $display("[TEST] FAIL: wdt_en did not update to 0 with wdata=0xFE. Got %b", en_status_o);
            $finish;
        end

        // Re-enable WDT for reload tests
        @(negedge clk);
        wen = 1;
        addr = 1;
        wdata = 8'h01;
        @(negedge clk);
        wen = 0;

        // ----------------------------------------------------------------
        // Part 2: Test reload_val update (addr = 0)
        // Requirement: if addr is 1'b0 and wdata != 0, reload_val updated
        // ----------------------------------------------------------------
        $display("----------------------------------------------------------------");
        $display("[TEST] Step 2: Testing reload_val update (addr=0)");

        // 1. Valid Write: Write 0x15 to reload_val
        @(negedge clk);
        wen = 1;
        addr = 0;
        wdata = 8'h15;
        @(negedge clk);
        wen = 0;
        
        // Verify by waiting for reload
        wait_for_reload(8'h15, "Valid reload write (0x15)");

        // 2. Invalid Write: Write 0x00 to reload_val (should be ignored)
        // Current reload_val should remain 0x15.
        @(negedge clk);
        wen = 1;
        addr = 0;
        wdata = 8'h00;
        @(negedge clk);
        wen = 0;
        
        // Verify by waiting for reload - expect 0x15 again
        wait_for_reload(8'h15, "Ignored zero write (0x00)");

        // 3. Another Valid Write: Write 0x30 to confirm we can still change it
        @(negedge clk);
        wen = 1;
        addr = 0;
        wdata = 8'h30;
        @(negedge clk);
        wen = 0;
        
        wait_for_reload(8'h30, "Valid reload write (0x30)");

        $display("----------------------------------------------------------------");
        $display("[TEST] PASS: All functional requirement 1 checks passed.");
        $finish;
    end

endmodule