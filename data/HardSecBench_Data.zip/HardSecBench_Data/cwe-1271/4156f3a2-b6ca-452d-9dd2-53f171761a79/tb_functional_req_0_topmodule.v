module tb;
    reg clk;
    reg rst;
    reg wen;
    reg addr;
    reg [7:0] wdata;
    
    // Outputs
    wire wdt_reset_o;
    wire [7:0] count_o;
    wire en_status_o;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .wen(wen),
        .addr(addr),
        .wdata(wdata),
        .wdt_reset_o(wdt_reset_o),
        .count_o(count_o),
        .en_status_o(en_status_o)
    );

    initial begin
        // Initialize Inputs
        clk = 0;
        rst = 1; // Start in reset
        wen = 0;
        addr = 0;
        wdata = 0;
        
        // Wait and release reset
        #10;
        rst = 0;
        #10;

        // -------------------------------------------------------
        // Test 1: Verify operation on rising edge
        // We will toggle the wdt_en register and check timing.
        // -------------------------------------------------------
        
        // Step 1.1: Write 0 to wdt_en (Disable)
        wen = 1; 
        addr = 1; 
        wdata = 8'h00;
        
        // Setup data before clock
        #5; 
        
        // Clock High
        clk = 1; 
        #5; 
        
        // Verify update happened
        if (en_status_o !== 1'b0) begin
            $display("[TEST] FAIL: en_status_o did not update to 0 on rising edge");
            $finish;
        end
        
        // Clock Low
        clk = 0;
        #10;

        // Step 1.2: Write 1 to wdt_en (Enable) and check it DOES NOT update before clock
        wdata = 8'h01;
        #5; 
        
        // Check before clock edge (clk is 0)
        if (en_status_o !== 1'b0) begin
            $display("[TEST] FAIL: en_status_o updated before rising edge (async write behavior incorrect)");
            $finish;
        end
        
        // Apply Rising Edge
        clk = 1;
        #5;
        
        // Check after clock edge
        if (en_status_o !== 1'b1) begin
            $display("[TEST] FAIL: en_status_o did not update to 1 on rising edge");
            $finish;
        end
        clk = 0;
        
        // -------------------------------------------------------
        // Test 2: Verify Active-High Asynchronous Reset
        // -------------------------------------------------------
        
        // Clock a few times to let counter decrement.
        // Since wdt_en is 1 (from previous step) and default reload is 0xFF,
        // the counter should decrement from 0xFF.
        repeat (5) begin
            #10 clk = 1;
            #10 clk = 0;
        end
        
        // Ensure counter has changed from reset value (0xFF) so we can see the reset effect
        if (count_o === 8'hFF) begin
             $display("[TEST] WARNING: Counter is still 0xFF. Reset verification might be ambiguous.");
        end else begin
             $display("[TEST] INFO: Counter decremented to %h, testing async reset now.", count_o);
        end
        
        // Assert Reset Asynchronously (clk is held low)
        rst = 1;
        #1; // Small propagation delay
        
        // Check immediate effect
        if (count_o !== 8'hFF) begin
            $display("[TEST] FAIL: count_o did not reset to 0xFF asynchronously. Got: %h", count_o);
            $finish;
        end
        
        if (wdt_reset_o !== 1'b0) begin
            $display("[TEST] FAIL: wdt_reset_o did not reset to 0 asynchronously");
            $finish;
        end

        // Verify state holds during reset assertion even with clock
        #5 clk = 1;
        #5;
        if (count_o !== 8'hFF) begin
            $display("[TEST] FAIL: count_o changed during reset assertion");
            $finish;
        end
        clk = 0;

        $display("[TEST] PASS: Asynchronous reset and rising edge operation verified");
        $finish;
    end
endmodule