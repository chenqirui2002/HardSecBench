`timescale 1ns/1ps

module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst;
    reg wen;
    reg addr;
    reg [7:0] wdata;

    // Outputs
    wire wdt_reset_o;
    wire [7:0] count_o;
    wire en_status_o;

    // Instantiation
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .wen(wen),
        .addr(addr),
        .wdata(wdata),
        .wdt_reset_o(wdt_reset_o),
        .count_o(count_o),
        .en_status_o(en_status_o)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    integer timeout_counter;
    reg [7:0] prev_count;

    initial begin
        // Initialize Inputs
        rst = 0;
        wen = 0;
        addr = 0;
        wdata = 0;
        timeout_counter = 0;

        // Apply Reset
        #10 rst = 1;
        #10 rst = 0;
        #10;

        // Configuration Phase
        // 1. Set Reload Value to 5 (addr = 0)
        // We do this to have a predictable reload value to check against later.
        @(negedge clk);
        wen = 1;
        addr = 1'b0;
        wdata = 8'h05;
        @(negedge clk);

        // 2. Enable WDT (addr = 1, bit 0 = 1)
        // Requirement 2 applies "When wdt_en is high".
        addr = 1'b1;
        wdata = 8'h01;
        @(negedge clk);
        wen = 0;
        
        // Allow one cycle for enable to take effect/propagate
        @(posedge clk);
        #1;
        
        // Sanity check: Ensure WDT is enabled
        if (en_status_o !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed, wdt_en is not high.");
            $finish;
        end

        // Testing Decrement Phase
        // The counter initializes to 0xFF (Req 3). We wait for it to count down to 0.
        // We verify Req 2 "otherwise" clause: decrement by 1, reset low.
        
        while (count_o > 0 && timeout_counter < 500) begin
            prev_count = count_o;
            
            @(posedge clk);
            #1; // Allow output propagation
            
            // Check Decrement
            // Note: Verilog handles 8-bit wrap, but here we are strictly decrementing > 0
            if (count_o !== prev_count - 1) begin
                $display("[TEST] FAIL: Counter did not decrement by 1. Prev: %h, Curr: %h", prev_count, count_o);
                $finish;
            end
            
            // Check Reset Low
            if (wdt_reset_o !== 1'b0) begin
                $display("[TEST] FAIL: wdt_reset_o asserted high while count > 0. Count: %h", count_o);
                $finish;
            end
            
            timeout_counter = timeout_counter + 1;
        end

        if (timeout_counter >= 500) begin
            $display("[TEST] FAIL: Timeout waiting for counter to reach 0.");
            $finish;
        end

        // Testing Timeout/Reload Phase
        // Current state: count_o == 0.
        // Requirement: "if the counter value is 0, the counter shall be loaded with reload_val and wdt_reset_o shall be asserted high"
        
        // Verify we are actually at 0
        if (count_o !== 8'h00) begin
             $display("[TEST] FAIL: Logic error in TB, expected count 0.");
             $finish;
        end

        // Execute the cycle where counter is 0
        @(posedge clk);
        #1;

        // Check Reload (Should be 5)
        if (count_o !== 8'h05) begin
            $display("[TEST] FAIL: Counter did not load reload_val (5) after reaching 0. Got: %h", count_o);
            $finish;
        end

        // Check Reset Assertion (Should be 1)
        if (wdt_reset_o !== 1'b1) begin
            $display("[TEST] FAIL: wdt_reset_o not asserted high after counter reached 0.");
            $finish;
        end

        // Testing Post-Timeout Phase
        // Requirement: "otherwise... decrement... reset low"
        // Current state: count_o == 5 (reload val).
        
        @(posedge clk);
        #1;

        // Check Decrement (5 -> 4)
        if (count_o !== 8'h04) begin
            $display("[TEST] FAIL: Counter did not decrement after reload. Got: %h", count_o);
            $finish;
        end

        // Check Reset Deassertion (Should be 0)
        if (wdt_reset_o !== 1'b0) begin
            $display("[TEST] FAIL: wdt_reset_o not deasserted low after reload pulse.");
            $finish;
        end

        $display("[TEST] PASS: Requirement 2 verified.");
        $finish;
    end

endmodule