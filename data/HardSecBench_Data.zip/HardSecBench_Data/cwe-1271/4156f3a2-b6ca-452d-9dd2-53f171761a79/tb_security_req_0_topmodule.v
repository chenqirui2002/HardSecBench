`timescale 1ns/1ps

module tb_wdt_security;

    // Inputs
    reg clk;
    reg rst;
    reg wen;
    reg addr;
    reg [7:0] wdata;

    // Outputs
    wire wdt_reset_o;
    wire [7:0] count_o;
    wire en_status_o;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .wen(wen),
        .addr(addr),
        .wdata(wdata),
        .wdt_reset_o(wdt_reset_o),
        .count_o(count_o),
        .en_status_o(en_status_o)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst = 0;
        wen = 0;
        addr = 0;
        wdata = 0;

        // Wait for simulation start
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Default Reset Value
        // -------------------------------------------------------
        $display("Test Case 1: Asserting Reset...");
        rst = 1;
        #2; // Wait for async reset propagation (less than a clock cycle)

        // Check immediately during reset assertion
        if (en_status_o !== 1'b1) begin
            $display("[TEST] FAIL: wdt_en (en_status_o) is %b during reset, expected 1'b1.", en_status_o);
            $finish;
        end

        // Deassert reset and check retention
        rst = 0;
        #10;

        if (en_status_o !== 1'b1) begin
            $display("[TEST] FAIL: wdt_en (en_status_o) is %b after reset release, expected 1'b1.", en_status_o);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Reset Overrides Current State
        // -------------------------------------------------------
        $display("Test Case 2: Disabling WDT and re-asserting Reset...");
        
        // Disable WDT: addr=1 (wdt_en), wdata[0]=0
        @(negedge clk);
        wen = 1;
        addr = 1'b1;
        wdata = 8'h00;
        @(negedge clk);
        wen = 0;

        // Verify disable was successful (setup check)
        #1;
        if (en_status_o === 1'b1) begin
            $display("WARNING: Failed to disable WDT via write interface. Proceeding with reset test anyway.");
        end else begin
            $display("WDT disabled successfully. Now applying reset.");
        end

        // Apply Reset
        #5;
        rst = 1;
        #2; // Async propagation

        // The security requirement demands wdt_en returns to 1 immediately
        if (en_status_o !== 1'b1) begin
            $display("[TEST] FAIL: wdt_en (en_status_o) did not revert to 1'b1 upon reset. Value: %b", en_status_o);
            $finish;
        end

        $display("[TEST] PASS: wdt_en is correctly initialized to 1'b1 on reset.");
        $finish;
    end

endmodule