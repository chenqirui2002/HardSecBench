`timescale 1ns/1ps

module tb_functional_req_3;

    // Inputs
    reg clk;
    reg rst;
    reg wen;
    reg addr;
    reg [7:0] wdata;

    // Outputs
    wire wdt_reset_o;
    wire [7:0] count_o;
    wire en_status_o;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .wen(wen),
        .addr(addr),
        .wdata(wdata),
        .wdt_reset_o(wdt_reset_o),
        .count_o(count_o),
        .en_status_o(en_status_o)
    );

    // Clock generation
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        // Initialize inputs
        rst = 0;
        wen = 0;
        addr = 0;
        wdata = 0;

        // Wait for global reset/startup
        #20;

        // -------------------------------------------------------
        // Test Sequence for [FUNCTIONAL-REQ-3]
        // -------------------------------------------------------
        
        // 1. Assert Asynchronous Reset
        $display("[TEST] Asserting Reset...");
        rst = 1;
        #10; // Wait for async reset to propagate

        // 2. Verify Immediate Reset States (Counter and Output)
        // Requirement: internal counter initialized to 8'hFF
        if (count_o !== 8'hFF) begin
            $display("[TEST] FAIL: count_o not initialized to 0xFF during reset. Got: 0x%h", count_o);
            $finish;
        end else begin
            $display("[TEST] Check 1: count_o is 0xFF during reset.");
        end

        // Requirement: wdt_reset_o initialized to 1'b0
        if (wdt_reset_o !== 1'b0) begin
            $display("[TEST] FAIL: wdt_reset_o not initialized to 0 during reset. Got: %b", wdt_reset_o);
            $finish;
        end else begin
            $display("[TEST] Check 2: wdt_reset_o is 0 during reset.");
        end

        // 3. Deassert Reset
        @(negedge clk);
        rst = 0;
        $display("[TEST] Reset Deasserted.");

        // 4. Verify reload_val initialization
        // To verify reload_val is 0xFF, we must let the counter underflow.
        // We explicitly enable the WDT to ensure it counts, regardless of default state.
        // Writing 1 to addr 1 enables WDT (per Req 1).
        
        @(negedge clk);
        wen = 1;
        addr = 1'b1; // Address for wdt_en
        wdata = 8'h01; // Enable bit
        @(negedge clk);
        wen = 0;

        // Wait for counter to reach 0
        // Counter starts at 0xFF, so it needs ~255 cycles.
        // We add a timeout to prevent infinite loops if logic is broken.
        fork : wait_for_zero
            begin
                wait (count_o == 8'h00);
                $display("[TEST] Counter reached 0.");
            end
            begin
                repeat (500) @(posedge clk);
                $display("[TEST] FAIL: Timeout waiting for counter to reach 0.");
                $finish;
            end
        join_any
        disable wait_for_zero;

        // 5. Check Reload Value
        // At the next rising edge, the counter should reload from reload_val.
        @(posedge clk); 
        #1; // Allow for propagation delay after clock edge

        // Requirement: reload_val register initialized to 8'hFF
        if (count_o === 8'hFF) begin
            $display("[TEST] PASS: Counter reloaded to 0xFF, confirming reload_val reset value.");
        end else begin
            $display("[TEST] FAIL: Counter reloaded to 0x%h instead of 0xFF. reload_val reset incorrect.", count_o);
        end

        $finish;
    end

endmodule