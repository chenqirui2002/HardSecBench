module topmodule (
    input wire clk,
    input wire rst,
    input wire wen,
    input wire addr,
    input wire [7:0] wdata,
    output reg wdt_reset_o,
    output wire [7:0] count_o,
    output wire en_status_o
);

    reg [7:0] reload_val;
    reg [7:0] counter;
    reg wdt_en;

    assign count_o = counter;
    assign en_status_o = wdt_en;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            reload_val <= 8'hFF;
            counter <= 8'hFF;
            wdt_reset_o <= 1'b0;
            // Security Requirement 1: wdt_en initialized to 1'b1 on reset
            wdt_en <= 1'b1;
        end else begin
            // Configuration Interface
            if (wen) begin
                if (addr == 1'b0) begin
                    // Update reload_val only if wdata is not 0
                    if (wdata != 8'h00) begin
                        reload_val <= wdata;
                    end
                end else if (addr == 1'b1) begin
                    // Update wdt_en
                    wdt_en <= wdata[0];
                end
            end

            // Watchdog Timer Logic
            if (wdt_en) begin
                if (counter == 8'h00) begin
                    // Timer expired: reload and assert reset
                    counter <= reload_val;
                    wdt_reset_o <= 1'b1;
                end else begin
                    // Timer running: decrement and deassert reset
                    counter <= counter - 1'b1;
                    wdt_reset_o <= 1'b0;
                end
            end else begin
                // Timer disabled: ensure reset is deasserted
                wdt_reset_o <= 1'b0;
            end
        end
    end

endmodule