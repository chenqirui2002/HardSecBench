module tb_task_cwe_1271_seed12;
    reg clk;
    reg rst;
    reg chip_en;
    reg write_en;
    reg data_in;
    reg irq_in;
    wire irq_out;
    wire mask_out;

    // Instantiate the module
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .chip_en(chip_en),
        .write_en(write_en),
        .data_in(data_in),
        .irq_in(irq_in),
        .irq_out(irq_out),
        .mask_out(mask_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst = 0;
        chip_en = 0;
        write_en = 0;
        data_in = 0;
        irq_in = 0;

        // Initial Reset (to ensure known state, though we will overwrite mask functionally)
        rst = 1;
        #20;
        rst = 0;
        #20;

        // ---------------------------------------------------------
        // Test Case 1: Mask = 0 (Interrupt Enabled)
        // Requirement: irq_out = 1 IFF (chip_en=1 AND irq_in=1 AND mask=0)
        // ---------------------------------------------------------
        
        // 1.1 Program Mask to 0
        @(negedge clk);
        chip_en = 1;
        write_en = 1;
        data_in = 0;
        @(negedge clk);
        write_en = 0; // Disable write
        
        // Verify Setup
        if (mask_out !== 0) begin
            $display("[TEST] FAIL: Setup failed, mask_out is not 0 after writing 0.");
            $finish;
        end

        // 1.2 Verify Positive Case: chip_en=1, irq_in=1, mask=0 -> irq_out=1
        chip_en = 1;
        irq_in = 1;
        #1; // Allow combinational propagation
        if (irq_out !== 1) begin
            $display("[TEST] FAIL: irq_out should be 1 when chip_en=1, irq_in=1, mask=0");
            $finish;
        end

        // 1.3 Verify Negative Case: chip_en=0 -> irq_out=0
        chip_en = 0;
        irq_in = 1;
        #1;
        if (irq_out !== 0) begin
            $display("[TEST] FAIL: irq_out should be 0 when chip_en=0");
            $finish;
        end

        // 1.4 Verify Negative Case: irq_in=0 -> irq_out=0
        chip_en = 1;
        irq_in = 0;
        #1;
        if (irq_out !== 0) begin
            $display("[TEST] FAIL: irq_out should be 0 when irq_in=0");
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 2: Mask = 1 (Interrupt Disabled)
        // Requirement: irq_out = 0 if mask=1
        // ---------------------------------------------------------

        // 2.1 Program Mask to 1
        @(negedge clk);
        chip_en = 1;
        write_en = 1;
        data_in = 1;
        @(negedge clk);
        write_en = 0;

        // Verify Setup
        if (mask_out !== 1) begin
            $display("[TEST] FAIL: Setup failed, mask_out is not 1 after writing 1.");
            $finish;
        end

        // 2.2 Verify Masked Case: chip_en=1, irq_in=1, mask=1 -> irq_out=0
        chip_en = 1;
        irq_in = 1;
        #1;
        if (irq_out !== 0) begin
            $display("[TEST] FAIL: irq_out should be 0 when mask=1 (masked), even if chip_en=1 and irq_in=1");
            $finish;
        end

        // Success
        $display("[TEST] PASS: irq_out logic verified correctly.");
        $finish;
    end

endmodule