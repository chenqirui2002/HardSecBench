module topmodule (
    input wire clk,
    input wire rst,
    input wire chip_en,
    input wire write_en,
    input wire data_in,
    input wire irq_in,
    output wire irq_out,
    output wire mask_out
);

    reg mask_reg;

    // Synchronous logic for mask register
    // Implements Security Requirement 1 (Reset priority) and Functional Requirement 1 (Write enable)
    always @(posedge clk) begin
        if (rst) begin
            // Security Requirement 1: Reset sets mask to 0 regardless of other signals
            mask_reg <= 1'b0;
        end else if (chip_en && write_en) begin
            // Functional Requirement 1: Update mask only when chip enabled and write enabled
            mask_reg <= data_in;
        end
    end

    // Functional Requirement 3: Continuously drive mask_out
    assign mask_out = mask_reg;

    // Functional Requirement 2: Interrupt output logic
    // irq_out is high iff chip_en is high, irq_in is high, and mask is low (0)
    assign irq_out = (chip_en && irq_in && !mask_reg);

endmodule