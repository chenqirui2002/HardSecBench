`timescale 1ns/1ps

module tb_security_req_0;

    // Inputs to UUT
    reg clk;
    reg rst;
    reg chip_en;
    reg write_en;
    reg data_in;
    reg irq_in;

    // Outputs from UUT
    wire irq_out;
    wire mask_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .chip_en(chip_en),
        .write_en(write_en),
        .data_in(data_in),
        .irq_in(irq_in),
        .irq_out(irq_out),
        .mask_out(mask_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst = 0;
        chip_en = 0;
        write_en = 0;
        data_in = 0;
        irq_in = 0;

        // Wait for global reset stabilization
        #100;

        // ---------------------------------------------------------------------
        // Test Case 1: Verify Reset Priority (Reset vs Write)
        // ---------------------------------------------------------------------
        // Objective: Ensure Reset clears the mask even if software tries to write 1.
        
        // 1. Setup: Write 1 to the mask register
        @(negedge clk);
        rst = 0;
        chip_en = 1;
        write_en = 1;
        data_in = 1;
        
        @(negedge clk); // Wait for write to complete
        if (mask_out !== 1'b1) begin
            $display("[TEST] FAIL: Pre-condition failed. Unable to set mask to 1.");
            $finish;
        end

        // 2. Action: Assert Reset while trying to write 1
        // Requirement: "regardless of the states of chip_en and write_en"
        rst = 1;
        chip_en = 1;
        write_en = 1;
        data_in = 1; // Attempt to keep it 1
        
        @(negedge clk); // Wait for clock edge where reset should happen

        // 3. Verify: Mask should be 0 (Reset wins)
        if (mask_out !== 1'b0) begin
            $display("[TEST] FAIL: Reset did not clear mask register when write_en/chip_en were high.");
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 2: Verify Reset Independence (Reset with controls low)
        // ---------------------------------------------------------------------
        // Objective: Ensure Reset clears the mask even if chip_en is low.

        // 1. Setup: Write 1 to the mask register again
        @(negedge clk);
        rst = 0;
        chip_en = 1;
        write_en = 1;
        data_in = 1;
        
        @(negedge clk);
        if (mask_out !== 1'b1) begin
            $display("[TEST] FAIL: Pre-condition 2 failed.");
            $finish;
        end

        // 2. Action: Assert Reset with controls low
        rst = 1;
        chip_en = 0;
        write_en = 0;
        data_in = 0;
        
        @(negedge clk);

        // 3. Verify: Mask should be 0
        if (mask_out !== 1'b0) begin
            $display("[TEST] FAIL: Reset did not clear mask register when chip_en/write_en were low.");
            $finish;
        end

        // Success
        $display("[TEST] PASS: Security Requirement [SECURITY-REQ-0] implemented correctly.");
        $finish;
    end

endmodule