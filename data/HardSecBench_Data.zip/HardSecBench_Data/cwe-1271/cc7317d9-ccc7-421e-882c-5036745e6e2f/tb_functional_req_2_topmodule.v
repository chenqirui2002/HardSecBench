module tb_task_cwe_1271_seed12;

    // Inputs to UUT
    reg clk;
    reg rst;
    reg chip_en;
    reg write_en;
    reg data_in;
    reg irq_in;

    // Outputs from UUT
    wire irq_out;
    wire mask_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .chip_en(chip_en),
        .write_en(write_en),
        .data_in(data_in),
        .irq_in(irq_in),
        .irq_out(irq_out),
        .mask_out(mask_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst = 1;
        chip_en = 0;
        write_en = 0;
        data_in = 0;
        irq_in = 0;

        // Wait for global reset
        #20;
        rst = 0;
        #10;

        // ---------------------------------------------------------------------
        // Test Case 1: Verify mask_out reflects writing a '1' to the register
        // ---------------------------------------------------------------------
        @(negedge clk);
        chip_en = 1;
        write_en = 1;
        data_in = 1; // Set mask bit to 1

        @(posedge clk); // Register should update here
        #1; // Allow for propagation delay

        if (mask_out !== 1'b1) begin
            $display("[TEST] FAIL: mask_out is %b, expected 1 after writing 1 to internal register.", mask_out);
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 2: Verify mask_out holds value (reflects register) when not writing
        // ---------------------------------------------------------------------
        @(negedge clk);
        write_en = 0;
        data_in = 0; // Change data_in to 0 to ensure mask_out isn't just a passthrough

        @(posedge clk);
        #1;

        if (mask_out !== 1'b1) begin
            $display("[TEST] FAIL: mask_out changed to %b when write_en was low. It should hold the register value (1).", mask_out);
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 3: Verify mask_out reflects writing a '0' to the register
        // ---------------------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        data_in = 0; // Set mask bit to 0

        @(posedge clk); // Register should update here
        #1;

        if (mask_out !== 1'b0) begin
            $display("[TEST] FAIL: mask_out is %b, expected 0 after writing 0 to internal register.", mask_out);
            $finish;
        end

        // Test Passed
        $display("[TEST] PASS: mask_out correctly reflects internal mask register state.");
        $finish;
    end

endmodule