`timescale 1ns/1ps

module tb;
    // Inputs
    reg clk;
    reg rst;
    reg chip_en;
    reg write_en;
    reg data_in;
    reg irq_in;

    // Outputs
    wire irq_out;
    wire mask_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst(rst),
        .chip_en(chip_en),
        .write_en(write_en),
        .data_in(data_in),
        .irq_in(irq_in),
        .irq_out(irq_out),
        .mask_out(mask_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst = 1;      // Assert reset initially to define state
        chip_en = 0;
        write_en = 0;
        data_in = 0;
        irq_in = 0;

        // Release reset
        #20;
        rst = 0;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Write '1' to mask register
        // Requirement: rst=0, chip_en=1, write_en=1 -> update mask
        // -------------------------------------------------------
        @(negedge clk);
        rst = 0;
        chip_en = 1;
        write_en = 1;
        data_in = 1;

        @(posedge clk); // Trigger update
        #1;             // Wait for propagation

        if (mask_out !== 1'b1) begin
            $display("[TEST] FAIL: mask_out did not update to 1. Got: %b", mask_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Write '0' to mask register
        // Requirement: rst=0, chip_en=1, write_en=1 -> update mask
        // -------------------------------------------------------
        @(negedge clk);
        data_in = 0;

        @(posedge clk); // Trigger update
        #1;             // Wait for propagation

        if (mask_out !== 1'b0) begin
            $display("[TEST] FAIL: mask_out did not update to 0. Got: %b", mask_out);
            $finish;
        end

        // Success
        $display("[TEST] PASS: Mask register updates correctly with data_in");
        $finish;
    end

endmodule