module tb_task_cwe_1271_seed17;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr_in;
    reg [7:0] data_in;
    reg config_we;
    reg [7:0] config_data;

    // Outputs
    wire [7:0] data_out;
    wire filter_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr_in(addr_in),
        .data_in(data_in),
        .config_we(config_we),
        .config_data(config_data),
        .data_out(data_out),
        .filter_status(filter_status)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        addr_in = 0;
        data_in = 0;
        config_we = 0;
        config_data = 0;

        // Apply Reset
        #10 rst_n = 1;
        #10;

        // ----------------------------------------------------------------
        // Test Case 1: Filter Inactive (filter_active = 0)
        // Requirement: data_out shall be updated with data_in
        // ----------------------------------------------------------------
        
        // Step 1.1: Explicitly disable filter
        @(negedge clk);
        config_we = 1;
        config_data = 8'h00; // Set bit 0 to 0
        @(negedge clk);
        config_we = 0;

        // Step 1.2: Test propagation with addr > 0xA0 (Should PASS because filter is off)
        addr_in = 8'hA5;
        data_in = 8'h55;
        @(negedge clk); // Setup inputs
        @(negedge clk); // Wait for posedge capture and next negedge to check
        
        if (data_out === 8'h55) begin
            $display("[TEST] PASS: Filter Disabled - Data propagated correctly for addr 0xA5");
        end else begin
            $display("[TEST] FAIL: Filter Disabled - Expected 0x55, got 0x%h for addr 0xA5", data_out);
        end

        // ----------------------------------------------------------------
        // Test Case 2: Filter Active (filter_active = 1)
        // Requirement: if filter_active=1 and addr_in > 0xA0, data_out = 0x00
        //              otherwise data_out = data_in
        // ----------------------------------------------------------------

        // Step 2.1: Enable filter
        @(negedge clk);
        config_we = 1;
        config_data = 8'h01; // Set bit 0 to 1
        @(negedge clk);
        config_we = 0;

        // Step 2.2: Test Boundary Condition (addr_in == 0xA0)
        // Should PASS data (Requirement says > 0xA0 blocks)
        addr_in = 8'hA0;
        data_in = 8'hAA;
        @(negedge clk);
        @(negedge clk);

        if (data_out === 8'hAA) begin
            $display("[TEST] PASS: Filter Enabled - Data propagated for boundary addr 0xA0");
        end else begin
            $display("[TEST] FAIL: Filter Enabled - Expected 0xAA, got 0x%h for addr 0xA0", data_out);
        end

        // Step 2.3: Test Blocking Condition (addr_in > 0xA0)
        // Should BLOCK data (data_out = 0x00)
        addr_in = 8'hA1;
        data_in = 8'hFF;
        @(negedge clk);
        @(negedge clk);

        if (data_out === 8'h00) begin
            $display("[TEST] PASS: Filter Enabled - Data blocked for addr 0xA1");
        end else begin
            $display("[TEST] FAIL: Filter Enabled - Expected 0x00, got 0x%h for addr 0xA1", data_out);
        end

        // Step 2.4: Test Blocking Condition with another address (addr_in = 0xFF)
        addr_in = 8'hFF;
        data_in = 8'hCC;
        @(negedge clk);
        @(negedge clk);

        if (data_out === 8'h00) begin
            $display("[TEST] PASS: Filter Enabled - Data blocked for addr 0xFF");
        end else begin
            $display("[TEST] FAIL: Filter Enabled - Expected 0x00, got 0x%h for addr 0xFF", data_out);
        end

        $finish;
    end

endmodule