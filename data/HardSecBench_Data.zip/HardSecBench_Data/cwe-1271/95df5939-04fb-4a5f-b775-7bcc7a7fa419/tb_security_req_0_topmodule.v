module tb_task_cwe_1271_seed17;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr_in;
    reg [7:0] data_in;
    reg config_we;
    reg [7:0] config_data;

    // Outputs
    wire [7:0] data_out;
    wire filter_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr_in(addr_in),
        .data_in(data_in),
        .config_we(config_we),
        .config_data(config_data),
        .data_out(data_out),
        .filter_status(filter_status)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 1;
        addr_in = 0;
        data_in = 0;
        config_we = 0;
        config_data = 0;

        // Wait for global reset
        #10;

        // -------------------------------------------------------
        // Test Case 1: Check Reset Initialization of filter_active
        // -------------------------------------------------------
        $display("[TEST] Asserting Reset...");
        rst_n = 0;
        #10; // Wait for async reset to take effect

        // Check if filter_status is 1 during reset (Asynchronous set expected)
        if (filter_status !== 1'b1) begin
            $display("[TEST] FAIL: filter_status is %b during reset assertion. Expected 1 (Secure Default).", filter_status);
            $finish;
        end

        // Release Reset
        rst_n = 1;
        #10;

        // Check if filter_status remains 1 after reset release
        if (filter_status !== 1'b1) begin
            $display("[TEST] FAIL: filter_status is %b after reset release. Expected 1.", filter_status);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Functional Verification of Default State
        // -------------------------------------------------------
        // Setup inputs to trigger the filter:
        // Filter is active (default), Addr > 0xA0 -> Data should be blocked (0x00)
        // If filter was inactive (0), Data would pass (0xFF)
        addr_in = 8'hA1; 
        data_in = 8'hFF;
        config_we = 0; // Ensure we are not writing to config

        // Wait for a clock edge to process inputs
        @(posedge clk);
        #1; // Allow for propagation delay

        if (data_out === 8'h00) begin
            $display("[TEST] PASS: Filter is active by default. Data blocked correctly (DataOut: 0x00).");
        end else if (data_out === 8'hFF) begin
            $display("[TEST] FAIL: Filter appears inactive by default. Data passed through (DataOut: 0xFF).");
        end else begin
            $display("[TEST] FAIL: Unexpected output data: 0x%h", data_out);
        end

        $finish;
    end

endmodule