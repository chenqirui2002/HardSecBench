module topmodule (
    input wire clk,
    input wire rst_n,
    input wire [7:0] addr_in,
    input wire [7:0] data_in,
    input wire config_we,
    input wire [7:0] config_data,
    output reg [7:0] data_out,
    output wire filter_status
);

    // Internal configuration register
    reg filter_active;

    // Output status continuously reflects the internal register state
    assign filter_status = filter_active;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Reset logic
            data_out <= 8'h00;
            // Security Requirement: The filter must be enabled (1) by default upon reset
            // to ensure secure state before any configuration takes place.
            filter_active <= 1'b1;
        end else begin
            // Configuration Logic
            if (config_we) begin
                filter_active <= config_data[0];
            end

            // Data Filtering Logic
            // Note: Uses the state of filter_active at the rising edge of clk
            if (filter_active && (addr_in > 8'hA0)) begin
                data_out <= 8'h00; // Block data in restricted range
            end else begin
                data_out <= data_in; // Pass data
            end
        end
    end

endmodule