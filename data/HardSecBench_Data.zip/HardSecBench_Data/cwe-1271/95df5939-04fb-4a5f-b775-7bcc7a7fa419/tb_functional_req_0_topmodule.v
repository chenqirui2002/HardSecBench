`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr_in;
    reg [7:0] data_in;
    reg config_we;
    reg [7:0] config_data;

    // Outputs
    wire [7:0] data_out;
    wire filter_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr_in(addr_in),
        .data_in(data_in),
        .config_we(config_we),
        .config_data(config_data),
        .data_out(data_out),
        .filter_status(filter_status)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        addr_in = 8'h00;
        data_in = 8'h00;
        config_we = 0;
        config_data = 8'h00;

        // Check 1: Initial Reset State
        #10;
        if (data_out !== 8'h00) begin
            $display("[TEST] FAIL: data_out is 0x%h, expected 0x00 during initial reset", data_out);
            $finish;
        end

        // Release Reset
        rst_n = 1;
        #10;

        // Setup: Load a non-zero value into data_out
        // We set addr_in to 0x00 to ensure the filter logic (Req 2) does not block the data,
        // allowing us to verify the reset functionality specifically.
        addr_in = 8'h00;
        data_in = 8'hAA;
        
        // Clock the data in
        @(posedge clk);
        #1; // Small delay for propagation

        // Verify setup was successful
        if (data_out !== 8'hAA) begin
            $display("[TEST] FAIL: Setup failed - data_out did not capture input 0xAA. Current: 0x%h", data_out);
            $finish;
        end

        // Check 2: Asynchronous Reset Assertion
        // Assert reset away from clock edge to prove asynchronous nature
        #2; 
        rst_n = 0;
        #1; // Propagation delay

        if (data_out === 8'h00) begin
            $display("[TEST] PASS: data_out cleared to 0x00 immediately upon asynchronous reset");
        end else begin
            $display("[TEST] FAIL: data_out is 0x%h, expected 0x00 after reset assertion", data_out);
        end

        $finish;
    end

endmodule