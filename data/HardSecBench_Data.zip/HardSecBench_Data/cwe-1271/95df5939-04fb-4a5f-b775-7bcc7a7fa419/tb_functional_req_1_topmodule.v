`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr_in;
    reg [7:0] data_in;
    reg config_we;
    reg [7:0] config_data;

    // Outputs
    wire [7:0] data_out;
    wire filter_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr_in(addr_in),
        .data_in(data_in),
        .config_we(config_we),
        .config_data(config_data),
        .data_out(data_out),
        .filter_status(filter_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr_in = 0;
        data_in = 0;
        config_we = 0;
        config_data = 0;

        // Wait for global reset
        #100;
        rst_n = 1;
        #10;

        // Test Case 1: Write 1 to filter_active
        // Requirement: filter_active updated with config_data[0] when config_we asserted
        $display("[TEST] Case 1: Write 1 to configuration");
        @(negedge clk);
        config_we = 1;
        config_data = 8'h01; // bit 0 is 1
        @(negedge clk); // Wait for clock edge to process write
        config_we = 0;
        
        if (filter_status !== 1'b1) begin
            $display("[TEST] FAIL: filter_status should be 1 after writing config_data[0]=1. Got: %b", filter_status);
            $finish;
        end

        // Test Case 2: Write 0 to filter_active
        $display("[TEST] Case 2: Write 0 to configuration");
        @(negedge clk);
        config_we = 1;
        config_data = 8'hFE; // bit 0 is 0 (LSB)
        @(negedge clk);
        config_we = 0;

        if (filter_status !== 1'b0) begin
            $display("[TEST] FAIL: filter_status should be 0 after writing config_data[0]=0. Got: %b", filter_status);
            $finish;
        end

        // Test Case 3: Verify config_we = 0 prevents update
        $display("[TEST] Case 3: Attempt write with config_we = 0");
        @(negedge clk);
        config_we = 0;
        config_data = 8'h01; // bit 0 is 1
        @(negedge clk);
        
        // Should still be 0 from Case 2
        if (filter_status !== 1'b0) begin
            $display("[TEST] FAIL: filter_status changed to %b despite config_we=0", filter_status);
            $finish;
        end

        // Test Case 4: Verify only bit 0 matters (using high bits)
        $display("[TEST] Case 4: Verify only LSB is used");
        @(negedge clk);
        config_we = 1;
        config_data = 8'hF1; // bit 0 is 1, others are 1
        @(negedge clk);
        config_we = 0;

        if (filter_status !== 1'b1) begin
            $display("[TEST] FAIL: filter_status should be 1 with config_data=0xF1. Got: %b", filter_status);
            $finish;
        end

        $display("[TEST] PASS: filter_active configuration logic verified");
        $finish;
    end

endmodule