module topmodule (
    input wire clk,
    input wire rst_n,
    input wire soft_rst,
    input wire cfg_write,
    input wire secure_val_in,
    input wire dma_prio_in,
    input wire dma_burst_in,
    output reg secure_en_out,
    output reg dma_prio_out,
    output reg dma_burst_out
);

    // Asynchronous reset logic for hard reset (rst_n)
    // Synchronous logic for soft reset (soft_rst) and configuration write (cfg_write)
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // SECURITY-REQ-0: Asynchronously reset secure_en_out to 0
            // Also reset other configuration registers to a known state
            secure_en_out <= 1'b0;
            dma_prio_out  <= 1'b0;
            dma_burst_out <= 1'b0;
        end else begin
            // FUNCTIONAL-REQ-1: If soft_rst is high, retain current values
            // This takes priority over cfg_write
            if (soft_rst) begin
                secure_en_out <= secure_en_out;
                dma_prio_out  <= dma_prio_out;
                dma_burst_out <= dma_burst_out;
            end 
            // If soft_rst is low and cfg_write is high, update values
            else if (cfg_write) begin
                secure_en_out <= secure_val_in;
                dma_prio_out  <= dma_prio_in;
                dma_burst_out <= dma_burst_in;
            end
        end
    end

endmodule