`timescale 1ns/1ps

module tb_module_task_cwe_1271_seed7;

    // Inputs
    reg clk;
    reg rst_n;
    reg soft_rst;
    reg cfg_write;
    reg secure_val_in;
    reg [2:0] dma_prio_in;
    reg [3:0] dma_burst_in;

    // Outputs
    wire secure_en_out;
    wire [2:0] dma_prio_out;
    wire [3:0] dma_burst_out;

    // Test Status
    reg test_pass = 1;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .soft_rst(soft_rst),
        .cfg_write(cfg_write),
        .secure_val_in(secure_val_in),
        .dma_prio_in(dma_prio_in),
        .dma_burst_in(dma_burst_in),
        .secure_en_out(secure_en_out),
        .dma_prio_out(dma_prio_out),
        .dma_burst_out(dma_burst_out)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Procedure
    initial begin
        // Initialize Inputs
        rst_n = 0;
        soft_rst = 0;
        cfg_write = 0;
        secure_val_in = 0;
        dma_prio_in = 0;
        dma_burst_in = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Asynchronous Reset from Valid State
        // -------------------------------------------------------
        
        // Step 1: Set secure_en_out to 1
        @(negedge clk);
        secure_val_in = 1;
        cfg_write = 1;
        @(posedge clk);
        #1; // Hold time
        cfg_write = 0;
        
        // Verify pre-condition
        if (secure_en_out !== 1'b1) begin
            $display("[TEST] FAIL: Unable to set secure_en_out to 1. Setup failed.");
            test_pass = 0;
        end else begin
            $display("[TEST] Setup: secure_en_out set to 1.");
        end

        // Step 2: Assert Hard Reset (rst_n) asynchronously (away from clock edge)
        #2; 
        rst_n = 0;
        #1; // Small delay for propagation, no clock edge here

        // Verify Reset Behavior
        if (secure_en_out !== 1'b0) begin
            $display("[TEST] FAIL: secure_en_out did not reset to 0 asynchronously when rst_n was asserted.");
            test_pass = 0;
        end else begin
            $display("[TEST] PASS: secure_en_out reset asynchronously.");
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Hard Reset Priority over Soft Reset
        // -------------------------------------------------------
        
        // Recover from reset
        rst_n = 1;
        #10;
        
        // Step 1: Set secure_en_out to 1 again
        @(negedge clk);
        secure_val_in = 1;
        cfg_write = 1;
        @(posedge clk);
        #1;
        cfg_write = 0;

        if (secure_en_out !== 1'b1) begin
            $display("[TEST] FAIL: Unable to set secure_en_out to 1 for Test Case 2.");
            test_pass = 0;
        end

        // Step 2: Assert Soft Reset AND Hard Reset
        // If the implementation prioritizes soft_rst (incorrectly) or checks it first, 
        // it might fail to clear if logic is flawed.
        soft_rst = 1;
        #2;
        rst_n = 0; // Hard reset asserted while soft_rst is high
        #1; // Async check

        if (secure_en_out !== 1'b0) begin
            $display("[TEST] FAIL: secure_en_out did not reset when rst_n=0 and soft_rst=1.");
            test_pass = 0;
        end else begin
            $display("[TEST] PASS: Hard reset overrides soft_rst.");
        end

        // Final Result
        if (test_pass) begin
            $display("[TEST] PASS: All security reset checks passed.");
        end else begin
            $display("[TEST] FAIL: Security reset checks failed.");
        end

        $finish;
    end

endmodule