`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg soft_rst;
    reg cfg_write;
    reg secure_val_in;
    reg dma_prio_in;   // Fixed: Changed to 1-bit
    reg dma_burst_in;  // Fixed: Changed to 1-bit

    // Outputs
    wire secure_en_out;
    wire dma_prio_out; // Fixed: Changed to 1-bit
    wire dma_burst_out; // Fixed: Changed to 1-bit

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .soft_rst(soft_rst),
        .cfg_write(cfg_write),
        .secure_val_in(secure_val_in),
        .dma_prio_in(dma_prio_in),
        .dma_burst_in(dma_burst_in),
        .secure_en_out(secure_en_out),
        .dma_prio_out(dma_prio_out),
        .dma_burst_out(dma_burst_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        soft_rst = 0;
        cfg_write = 0;
        secure_val_in = 0;
        dma_prio_in = 0;
        dma_burst_in = 0;

        // Apply Hard Reset to start in known state
        #20;
        rst_n = 1; // Release hard reset
        #20;

        $display("Starting Test for FUNCTIONAL-REQ-0...");

        // Test Loop
        for (i = 0; i < 20; i = i + 1) begin
            // Setup inputs on negedge to ensure stability at posedge
            @(negedge clk);
            soft_rst = 0;
            cfg_write = 1;
            
            // Randomize inputs (1-bit values)
            secure_val_in = $random % 2;
            dma_prio_in = $random % 2;
            dma_burst_in = $random % 2;

            // Wait for rising edge where update should happen
            @(posedge clk);
            
            // Check outputs after small propagation delay
            #1;
            
            // Verify secure_en_out
            if (secure_en_out !== secure_val_in) begin
                $display("[TEST] FAIL: secure_en_out mismatch at iter %0d. Expected %b, Got %b", i, secure_val_in, secure_en_out);
                $finish;
            end
            
            // Verify dma_prio_out
            if (dma_prio_out !== dma_prio_in) begin
                $display("[TEST] FAIL: dma_prio_out mismatch at iter %0d. Expected %b, Got %b", i, dma_prio_in, dma_prio_out);
                $finish;
            end
            
            // Verify dma_burst_out
            if (dma_burst_out !== dma_burst_in) begin
                $display("[TEST] FAIL: dma_burst_out mismatch at iter %0d. Expected %b, Got %b", i, dma_burst_in, dma_burst_out);
                $finish;
            end
        end

        $display("[TEST] PASS: Outputs updated correctly when cfg_write=1 and soft_rst=0.");
        $finish;
    end

endmodule