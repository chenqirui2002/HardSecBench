module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg soft_rst;
    reg cfg_write;
    reg secure_val_in;
    reg dma_prio_in;   // Fixed: Changed to 1-bit scalar
    reg dma_burst_in;  // Fixed: Changed to 1-bit scalar

    // Outputs
    wire secure_en_out;
    wire dma_prio_out;  // Fixed: Changed to 1-bit scalar
    wire dma_burst_out; // Fixed: Changed to 1-bit scalar

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .soft_rst(soft_rst),
        .cfg_write(cfg_write),
        .secure_val_in(secure_val_in),
        .dma_prio_in(dma_prio_in),
        .dma_burst_in(dma_burst_in),
        .secure_en_out(secure_en_out),
        .dma_prio_out(dma_prio_out),
        .dma_burst_out(dma_burst_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        soft_rst = 0;
        cfg_write = 0;
        secure_val_in = 0;
        dma_prio_in = 0;
        dma_burst_in = 0;

        // Apply Hard Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Step 1: Set initial values (Pre-condition)
        // We write Pattern A (all 1s) to the registers.
        // -------------------------------------------------------
        @(negedge clk);
        soft_rst = 0;
        cfg_write = 1;
        secure_val_in = 1;
        dma_prio_in = 1;
        dma_burst_in = 1;
        
        @(posedge clk);
        #1; // Allow propagation
        
        // Verify Pre-condition
        if (secure_en_out !== 1 || dma_prio_out !== 1 || dma_burst_out !== 1) begin
            $display("[TEST] FAIL: Pre-condition setup failed. Outputs did not update as expected.");
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Test Soft Reset Retention
        // Requirement: If soft_rst is high, outputs retain values.
        // We assert soft_rst and attempt to write Pattern B (all 0s)
        // with cfg_write=1. The write should be ignored.
        // -------------------------------------------------------
        @(negedge clk);
        soft_rst = 1;
        cfg_write = 1; 
        secure_val_in = 0;
        dma_prio_in = 0;
        dma_burst_in = 0;

        @(posedge clk);
        #1; // Allow propagation

        // -------------------------------------------------------
        // Step 3: Verify Outputs
        // Outputs should still match Step 1 values (Pattern A: all 1s).
        // -------------------------------------------------------
        if (secure_en_out === 1 && dma_prio_out === 1 && dma_burst_out === 1) begin
            $display("[TEST] PASS: Outputs retained values during soft reset.");
        end else begin
            $display("[TEST] FAIL: Outputs changed during soft reset.");
            $display("       Expected (Retained): secure=1, prio=1, burst=1");
            $display("       Got (New/Unknown):   secure=%b, prio=%b, burst=%b", 
                     secure_en_out, dma_prio_out, dma_burst_out);
        end

        $finish;
    end

endmodule