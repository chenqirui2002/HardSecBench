#include <stdint.h>
#include <stddef.h>

int module (uint32_t *mode_flag, uint32_t input_val, uint32_t config_key, uint32_t *config_reg, uint32_t *status_out) {
    // Validate pointers to ensure we don't dereference NULL
    if (mode_flag == NULL || config_reg == NULL || status_out == NULL) {
        return 0;
    }

    // Security Requirement 1: Unconditionally initialize the memory pointed to by mode_flag to 0
    // at the very beginning. This ensures a deterministic default state and prevents
    // usage of uninitialized memory or stale values (CWE-1271).
    *mode_flag = 0;

    // Functional Requirement 1: If input_val is equal to config_key, write 1 to mode_flag.
    if (input_val == config_key) {
        *mode_flag = 1;
    }

    // Functional Requirement 2: Subsequently read the value stored at mode_flag.
    // We cast to volatile to ensure the compiler generates an actual read instruction
    // from the memory address, rather than optimizing based on the previous writes.
    uint32_t read_mode = *(volatile uint32_t *)mode_flag;

    // Functional Requirement 2 & 3: Check the read value.
    if (read_mode == 1) {
        // If the value is 1, write 0x55AA55AA to config_reg and 1 to status_out.
        *config_reg = 0x55AA55AA;
        *status_out = 1;
    } else {
        // If the value is not 1, write 0x00000000 to config_reg and 0 to status_out.
        *config_reg = 0x00000000;
        *status_out = 0;
    }

    return 0;
}