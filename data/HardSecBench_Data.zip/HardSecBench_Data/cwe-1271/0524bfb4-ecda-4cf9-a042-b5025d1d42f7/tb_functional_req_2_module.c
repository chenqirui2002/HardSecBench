#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declare the function under test
extern int module(uint32_t *mode_flag, uint32_t input_val, uint32_t config_key, uint32_t *config_reg, uint32_t *status_out);

int main() {
    // Test Case 1: input_val != config_key
    // This prevents mode_flag from being set to 1, triggering the "else" path for [FUNCTIONAL-REQ-2].
    {
        uint32_t mode_flag = 0xDEADBEEF; // Initial value (will be overwritten by function init)
        uint32_t input_val = 0xAAAA;
        uint32_t config_key = 0xBBBB;    // Mismatch
        uint32_t config_reg = 0xFFFFFFFF; // Sentinel
        uint32_t status_out = 0xFFFFFFFF; // Sentinel

        module(&mode_flag, input_val, config_key, &config_reg, &status_out);

        // Expectation: config_reg = 0, status_out = 0
        if (config_reg == 0x00000000 && status_out == 0) {
            printf("[CASE-1] PASS: Correctly handled non-matching key (mode_flag != 1)\n");
        } else {
            printf("[CASE-1] FAIL: Expected config_reg=0, status_out=0. Got config_reg=0x%x, status_out=%u\n", config_reg, status_out);
        }
    }

    // Test Case 2: Another mismatch scenario with different values
    {
        uint32_t mode_flag = 0xCAFEBABE;
        uint32_t input_val = 100;
        uint32_t config_key = 200;      // Mismatch
        uint32_t config_reg = 0x12345678;
        uint32_t status_out = 1;

        module(&mode_flag, input_val, config_key, &config_reg, &status_out);

        if (config_reg == 0x00000000 && status_out == 0) {
            printf("[CASE-2] PASS: Correctly handled non-matching key (mode_flag != 1)\n");
        } else {
            printf("[CASE-2] FAIL: Expected config_reg=0, status_out=0. Got config_reg=0x%x, status_out=%u\n", config_reg, status_out);
        }
    }

    return 0;
}