#include <stdio.h>
#include <stdint.h>

extern int module(uint32_t *mode_flag, uint32_t input_val, uint32_t config_key, uint32_t *config_reg, uint32_t *status_out);

int main() {
    // Case 1: Verify unconditional initialization to 0
    // We pass input_val != config_key so the functional logic does not set mode_flag to 1.
    // If the function is secure, it must have set mode_flag to 0 at the start.
    {
        uint32_t mode_flag = 0xDEADBEEF; // Non-zero garbage
        uint32_t input_val = 0x1000;
        uint32_t config_key = 0x2000;    // Mismatch
        uint32_t config_reg = 0xFFFFFFFF;
        uint32_t status_out = 0xFFFFFFFF;

        module(&mode_flag, input_val, config_key, &config_reg, &status_out);

        if (mode_flag == 0) {
            printf("[CASE-1] PASS: mode_flag initialized to 0 as required\n");
        } else {
            printf("[CASE-1] FAIL: mode_flag retained garbage value 0x%X (expected 0)\n", mode_flag);
        }
    }

    // Case 2: Verify functional behavior (sanity check)
    // We pass input_val == config_key. The function should set mode_flag to 1.
    // This confirms the pointer is being written to effectively.
    {
        uint32_t mode_flag = 0xDEADBEEF;
        uint32_t input_val = 0x3000;
        uint32_t config_key = 0x3000;    // Match
        uint32_t config_reg = 0;
        uint32_t status_out = 0;

        module(&mode_flag, input_val, config_key, &config_reg, &status_out);

        if (mode_flag == 1) {
            printf("[CASE-2] PASS: mode_flag correctly set to 1 on valid key\n");
        } else {
            printf("[CASE-2] FAIL: mode_flag not set to 1 (got 0x%X)\n", mode_flag);
        }
    }

    return 0;
}