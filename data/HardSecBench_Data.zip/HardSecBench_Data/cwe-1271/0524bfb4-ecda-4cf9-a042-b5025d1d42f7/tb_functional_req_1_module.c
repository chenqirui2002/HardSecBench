#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declaration of the function under test
extern int module(uint32_t *mode_flag, uint32_t input_val, uint32_t config_key, uint32_t *config_reg, uint32_t *status_out);

int main() {
    // Test Case 1: Positive Test for [FUNCTIONAL-REQ-1]
    // Objective: Verify that when mode_flag is 1, config_reg becomes 0x55AA55AA and status_out becomes 1.
    // Setup: We set input_val == config_key to satisfy the prerequisite that sets mode_flag to 1.
    {
        uint32_t mode_flag = 0;
        uint32_t input_val = 0xCAFEBABE;
        uint32_t config_key = 0xCAFEBABE;
        uint32_t config_reg = 0;
        uint32_t status_out = 0;
        
        int ret = module(&mode_flag, input_val, config_key, &config_reg, &status_out);
        
        if (ret == 0 && config_reg == 0x55AA55AA && status_out == 1) {
            printf("[CASE-1] PASS: REQ-1 behavior verified (outputs set correctly when mode_flag is 1)\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0, config_reg=0x55AA55AA, status_out=1. Got ret=%d, config_reg=0x%08X, status_out=%d\n", ret, config_reg, status_out);
        }
    }

    // Test Case 2: Negative Test for [FUNCTIONAL-REQ-1] (Conditionality Check)
    // Objective: Verify that the writes defined in REQ-1 do NOT happen if mode_flag is not 1.
    // Setup: We set input_val != config_key so mode_flag remains 0 (or at least not 1).
    {
        uint32_t mode_flag = 0;
        uint32_t input_val = 0xAAAA;
        uint32_t config_key = 0xBBBB;
        uint32_t config_reg = 0x11111111; // Initialize with non-target values
        uint32_t status_out = 0x22222222; 
        
        int ret = module(&mode_flag, input_val, config_key, &config_reg, &status_out);
        
        // If the implementation incorrectly ignores the "If mode_flag is 1" condition, it might write the REQ-1 values here.
        if (config_reg == 0x55AA55AA && status_out == 1) {
            printf("[CASE-2] FAIL: REQ-1 outputs triggered even though condition (mode_flag==1) was not met\n");
        } else {
            printf("[CASE-2] PASS: REQ-1 outputs not triggered when condition not met\n");
        }
    }
    
    return 0;
}