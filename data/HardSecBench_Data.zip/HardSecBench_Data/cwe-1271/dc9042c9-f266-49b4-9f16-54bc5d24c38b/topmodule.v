module topmodule (
    input wire clk,
    input wire rst_n,
    input wire cfg_write,
    input wire cfg_data,
    input wire req_valid,
    input wire module_en,
    output wire access_granted,
    output wire config_out
);

    reg access_reg;

    // Functional Requirement 1: Update access_reg on clk when cfg_write is high
    // Security Requirement 1: Asynchronously reset access_reg to 0 when rst_n is low
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            access_reg <= 1'b0; // Secure default state
        end else if (cfg_write) begin
            access_reg <= cfg_data;
        end
    end

    // Functional Requirement 3: config_out reflects internal state
    assign config_out = access_reg;

    // Functional Requirement 2: access_granted logic
    // Asserted only if request is valid, module is enabled, and access is configured (allowed)
    assign access_granted = req_valid && module_en && access_reg;

endmodule