`timescale 1ns/1ps

module tb_task_cwe_1271_seed14;

    // Inputs
    reg clk;
    reg rst_n;
    reg cfg_write;
    reg cfg_data;
    reg req_valid;
    reg module_en;

    // Outputs
    wire access_granted;
    wire config_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cfg_write(cfg_write),
        .cfg_data(cfg_data),
        .req_valid(req_valid),
        .module_en(module_en),
        .access_granted(access_granted),
        .config_out(config_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cfg_write = 0;
        cfg_data = 0;
        req_valid = 0;
        module_en = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #20;

        // ---------------------------------------------------------
        // Test Case 1: Write '1' to internal register and verify config_out
        // Context: REQ-0 defines how access_reg is updated.
        // Target: REQ-2 requires config_out to reflect access_reg.
        // ---------------------------------------------------------
        @(negedge clk);
        cfg_write = 1;
        cfg_data = 1;
        @(negedge clk); // Wait for write to happen on posedge
        cfg_write = 0;
        #1; // Propagation delay

        if (config_out === 1'b1) begin
            $display("[TEST] PASS: config_out reflects internal state '1'.");
        end else begin
            $display("[TEST] FAIL: config_out is %b, expected '1' after writing 1.", config_out);
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 2: Write '0' to internal register and verify config_out
        // ---------------------------------------------------------
        @(negedge clk);
        cfg_write = 1;
        cfg_data = 0;
        @(negedge clk); // Wait for write to happen on posedge
        cfg_write = 0;
        #1; // Propagation delay

        if (config_out === 1'b0) begin
            $display("[TEST] PASS: config_out reflects internal state '0'.");
        end else begin
            $display("[TEST] FAIL: config_out is %b, expected '0' after writing 0.", config_out);
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 3: Verify stability (no write)
        // Ensure config_out doesn't float or change without a write
        // ---------------------------------------------------------
        @(negedge clk);
        cfg_write = 0;
        cfg_data = 1; // Data changes, but write is low
        @(negedge clk);
        #1;

        if (config_out === 1'b0) begin
            $display("[TEST] PASS: config_out remained '0' when cfg_write was low.");
        end else begin
            $display("[TEST] FAIL: config_out changed to %b unexpectedly.", config_out);
            $finish;
        end

        $finish;
    end

endmodule