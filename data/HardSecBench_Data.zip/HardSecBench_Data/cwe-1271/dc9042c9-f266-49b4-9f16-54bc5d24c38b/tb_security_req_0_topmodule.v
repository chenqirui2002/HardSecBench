module tb_security_req_0;
    // Inputs
    reg clk;
    reg rst_n;
    reg cfg_write;
    reg cfg_data;
    reg req_valid;
    reg module_en;

    // Outputs
    wire access_granted;
    wire config_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cfg_write(cfg_write),
        .cfg_data(cfg_data),
        .req_valid(req_valid),
        .module_en(module_en),
        .access_granted(access_granted),
        .config_out(config_out)
    );

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        cfg_write = 0;
        cfg_data = 0;
        req_valid = 0;
        module_en = 0;

        // Release reset
        #10 rst_n = 1;

        // Step 1: Write '1' to the internal access_reg
        #10;
        cfg_write = 1;
        cfg_data = 1;
        
        // Clock the data in
        #5 clk = 1;
        #5 clk = 0;
        cfg_write = 0;

        // Verify setup: config_out should be 1
        if (config_out !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed - unable to write 1 to access_reg.");
            $finish;
        end

        // Enable request signals to verify gating logic
        req_valid = 1;
        module_en = 1;
        #5; // Allow combinational logic to settle

        // Verify setup: access should be granted
        if (access_granted !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed - access_granted should be high when reg is 1.");
            $finish;
        end

        // Step 2: Assert Asynchronous Reset
        // We keep clk = 0 to ensure we are testing ASYNCHRONOUS behavior
        rst_n = 0;
        
        // Small delay for propagation, but NO clock edge
        #5;

        // Step 3: Check if register reset immediately
        if (config_out === 1'b0 && access_granted === 1'b0) begin
            $display("[TEST] PASS: access_reg reset asynchronously to 0.");
        end else begin
            $display("[TEST] FAIL: access_reg did not reset asynchronously. config_out=%b, access_granted=%b", config_out, access_granted);
        end

        $finish;
    end
endmodule