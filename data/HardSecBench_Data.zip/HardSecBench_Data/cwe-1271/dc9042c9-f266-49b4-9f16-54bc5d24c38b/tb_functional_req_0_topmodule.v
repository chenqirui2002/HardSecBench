`timescale 1ns/1ps

module tb_task_cwe_1271_seed14;

    // Inputs
    reg clk;
    reg rst_n;
    reg cfg_write;
    reg cfg_data;
    reg req_valid;
    reg module_en;

    // Outputs
    wire access_granted;
    wire config_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cfg_write(cfg_write),
        .cfg_data(cfg_data),
        .req_valid(req_valid),
        .module_en(module_en),
        .access_granted(access_granted),
        .config_out(config_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cfg_write = 0;
        cfg_data = 0;
        req_valid = 0;
        module_en = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Write 1 to access_reg
        // -------------------------------------------------------
        @(negedge clk);
        cfg_write = 1;
        cfg_data = 1;
        
        @(posedge clk); // Expect update on this edge
        #1; // Allow for propagation delay
        
        if (config_out !== 1'b1) begin
            $display("[TEST] FAIL: access_reg (config_out) did not update to 1 when cfg_write=1");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Write 0 to access_reg
        // -------------------------------------------------------
        @(negedge clk);
        cfg_write = 1;
        cfg_data = 0;
        
        @(posedge clk); // Expect update on this edge
        #1;
        
        if (config_out !== 1'b0) begin
            $display("[TEST] FAIL: access_reg (config_out) did not update to 0 when cfg_write=1");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Write 1 again to confirm toggle capability
        // -------------------------------------------------------
        @(negedge clk);
        cfg_write = 1;
        cfg_data = 1;
        
        @(posedge clk);
        #1;
        
        if (config_out !== 1'b1) begin
            $display("[TEST] FAIL: access_reg (config_out) did not update to 1 on second write");
            $finish;
        end

        // If we reached here, all checks passed
        $display("[TEST] PASS: access_reg updates correctly based on cfg_write");
        $finish;
    end

endmodule