`timescale 1ns/1ps

module tb_task_cwe_1271_seed14;

    // Inputs
    reg clk;
    reg rst_n;
    reg cfg_write;
    reg cfg_data;
    reg req_valid;
    reg module_en;

    // Outputs
    wire access_granted;
    wire config_out;

    // Instantiate the DUT
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cfg_write(cfg_write),
        .cfg_data(cfg_data),
        .req_valid(req_valid),
        .module_en(module_en),
        .access_granted(access_granted),
        .config_out(config_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    reg expected_val;
    integer i, j;
    reg current_access_reg;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cfg_write = 0;
        cfg_data = 0;
        req_valid = 0;
        module_en = 0;

        // Release Reset
        #20;
        rst_n = 1;
        #20;

        // Test Loop: Test with access_reg = 0 and then access_reg = 1
        for (i = 0; i < 2; i = i + 1) begin
            // 1. Set the internal access_reg using the config interface
            @(posedge clk);
            cfg_write = 1;
            cfg_data = i[0]; // First 0, then 1
            current_access_reg = i[0];
            @(posedge clk);
            cfg_write = 0;
            
            // Wait for value to latch
            #10;

            // 2. Iterate through all combinations of req_valid and module_en
            for (j = 0; j < 4; j = j + 1) begin
                req_valid = j[0];
                module_en = j[1];
                
                #10; // Allow combinational logic to settle

                // 3. Determine expected output based on REQ-1
                // Condition: access_granted = req_valid AND module_en AND access_reg
                expected_val = req_valid && module_en && current_access_reg;

                // 4. Verify Output
                if (access_granted !== expected_val) begin
                    $display("[TEST] FAIL: access_granted mismatch. access_reg=%b, req_valid=%b, module_en=%b. Got %b, Expected %b",
                             current_access_reg, req_valid, module_en, access_granted, expected_val);
                    $finish;
                end
            end
        end

        // If loop completes without error
        $display("[TEST] PASS: access_granted logic verified correctly.");
        $finish;
    end

endmodule