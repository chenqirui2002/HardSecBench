`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg load_key;
    reg [127:0] key_in;
    reg [1:0] key_type_in;

    // Outputs
    wire key_valid;
    wire [127:0] key_out;
    wire [1:0] key_type_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .load_key(load_key),
        .key_in(key_in),
        .key_type_in(key_type_in),
        .key_valid(key_valid),
        .key_out(key_out),
        .key_type_out(key_type_out)
    );

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        load_key = 0;
        key_in = 0;
        key_type_in = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify sensitivity to Rising Edge of clk
        // -------------------------------------------------------
        $display("[TEST] Starting Test Case 1: Rising Edge Sensitivity");
        
        // Setup inputs for a load operation
        load_key = 1;
        key_in = 128'hAABBCCDDEEFF00112233445566778899;
        key_type_in = 2'b10;
        
        // Check outputs BEFORE clock edge (should not have updated yet)
        #5;
        if (key_valid === 1'b1) begin
            $display("[TEST] FAIL: Output updated before clock rising edge (Combinatorial or Latch behavior detected)");
        end else begin
            // Trigger Rising Edge
            clk = 1;
            #5; // Wait for propagation
            
            // Check outputs AFTER clock edge
            if (key_valid === 1'b1 && key_out === 128'hAABBCCDDEEFF00112233445566778899) begin
                $display("[TEST] PASS: Logic updated on rising edge of clk");
            end else begin
                $display("[TEST] FAIL: Logic did not update on rising edge of clk");
            end
        end

        // -------------------------------------------------------
        // Test Case 2: Verify sensitivity to Falling Edge of rst_n (Asynchronous)
        // -------------------------------------------------------
        $display("[TEST] Starting Test Case 2: Falling Edge rst_n Sensitivity");

        // Ensure we are in a valid state first (from previous test)
        if (key_valid !== 1'b1) begin
            $display("[TEST] ABORT: Cannot test reset, pre-condition (valid state) failed.");
        end else begin
            // Hold clock steady (low) to ensure no synchronous events occur
            clk = 0;
            #10;
            
            // Assert Reset (Falling Edge of rst_n)
            rst_n = 0;
            #5; // Small delay to allow async propagation
            
            // Check if output reacted immediately without a clock edge
            if (key_valid === 1'b0) begin
                $display("[TEST] PASS: Logic reset asynchronously (sensitive to falling edge of rst_n)");
            end else begin
                $display("[TEST] FAIL: Logic did not reset asynchronously (likely synchronous reset or incorrect sensitivity list)");
            end
        end

        $finish;
    end

endmodule