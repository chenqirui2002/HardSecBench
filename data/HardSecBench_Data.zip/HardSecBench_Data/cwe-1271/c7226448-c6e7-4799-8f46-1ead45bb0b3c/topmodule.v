module topmodule (
    input wire clk,
    input wire rst_n,
    input wire load_key,
    input wire [127:0] key_in,
    input wire [1:0] key_type_in,
    output reg key_valid,
    output reg [127:0] key_out,
    output reg [1:0] key_type_out
);

    // Sequential logic sensitive to rising edge of clk and falling edge of rst_n
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Security Requirement: Asynchronously reset key_valid to 0
            key_valid <= 1'b0;
            
            // Secure Practice (CWE-1271): Clear sensitive key data and type on reset
            // to prevent uninitialized values or leakage of previous keys.
            key_out <= 128'd0;
            key_type_out <= 2'd0;
        end else begin
            // Functional Requirement: Load key on rising edge of clk if load_key is asserted
            if (load_key) begin
                key_valid <= 1'b1;
                key_out <= key_in;
                key_type_out <= key_type_in;
            end
            // Implicit else: Retain previous values
        end
    end

endmodule