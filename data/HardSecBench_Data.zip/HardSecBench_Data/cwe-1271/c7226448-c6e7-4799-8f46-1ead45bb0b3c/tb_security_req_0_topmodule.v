module testbench;

    // Inputs
    reg clk;
    reg rst_n;
    reg load_key;
    reg [127:0] key_in;
    reg [1:0] key_type_in;

    // Outputs
    wire key_valid;
    wire [127:0] key_out;
    wire [1:0] key_type_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .load_key(load_key), 
        .key_in(key_in), 
        .key_type_in(key_type_in), 
        .key_valid(key_valid), 
        .key_out(key_out), 
        .key_type_out(key_type_out)
    );

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 1;
        load_key = 0;
        key_in = 128'hDEADBEEFCAFEBABE1234567890ABCDEF;
        key_type_in = 2'b10;

        // Wait for stabilization
        #10;

        // -------------------------------------------------------
        // Pre-condition: Load a valid key to set key_valid = 1
        // -------------------------------------------------------
        load_key = 1;
        #5 clk = 1; // Rising edge
        #5 clk = 0; // Falling edge
        load_key = 0;

        #1;
        if (key_valid !== 1'b1) begin
            $display("[TEST] FAIL: Pre-condition failed. key_valid did not assert after load_key.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 1: Verify Asynchronous Reset
        // Requirement: "When rst_n is asserted... key_valid shall be asynchronously reset"
        // -------------------------------------------------------
        rst_n = 0;
        #1; // Small delay for propagation, NO clock edge here.
            // If the reset is synchronous, key_valid will remain 1 here.

        if (key_valid !== 1'b0) begin
            $display("[TEST] FAIL: key_valid did not reset asynchronously (value is %b).", key_valid);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Reset Priority (regardless of load_key/clk)
        // Requirement: "...regardless of the state of load_key or clk"
        // -------------------------------------------------------
        load_key = 1; // Attempt to load while reset is active
        #5 clk = 1;   // Clock edge
        #5 clk = 0;

        if (key_valid !== 1'b0) begin
            $display("[TEST] FAIL: key_valid asserted during active reset with load_key=1.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Recovery Check
        // Ensure the module functions again after reset is released
        // -------------------------------------------------------
        rst_n = 1;
        load_key = 1;
        #5 clk = 1;
        #5 clk = 0;
        load_key = 0;
        
        if (key_valid !== 1'b1) begin
            $display("[TEST] FAIL: key_valid did not recover (assert high) after reset release.");
            $finish;
        end

        $display("[TEST] PASS: key_valid resets asynchronously and holds 0 during reset.");
        $finish;
    end

endmodule