`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs to UUT
    reg clk;
    reg rst_n;
    reg load_key;
    reg [127:0] key_in;
    reg [1:0] key_type_in;

    // Outputs from UUT
    wire key_valid;
    wire [127:0] key_out;
    wire [1:0] key_type_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .load_key(load_key),
        .key_in(key_in),
        .key_type_in(key_type_in),
        .key_valid(key_valid),
        .key_out(key_out),
        .key_type_out(key_type_out)
    );

    // Clock generation
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        load_key = 0;
        key_in = 128'h0;
        key_type_in = 2'b00;

        // Wait for global reset
        #20;
        
        // Release reset (Requirement condition: rst_n inactive)
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Load a valid key
        // Requirement: On rising edge clk, if rst_n=1 and load_key=1, capture inputs
        // -------------------------------------------------------
        load_key = 1;
        key_in = 128'hDEADBEEF_00000000_FFFFFFFF_12345678;
        key_type_in = 2'b10;

        // Wait for rising edge of clk
        @(posedge clk);
        
        // Allow for propagation delay
        #1;

        // Check if values were captured
        if (key_valid !== 1'b1) begin
            $display("[TEST] FAIL: key_valid is not 1 after load_key assertion.");
            $finish;
        end

        if (key_out !== 128'hDEADBEEF_00000000_FFFFFFFF_12345678) begin
            $display("[TEST] FAIL: key_out mismatch. Expected %h, Got %h", 
                     128'hDEADBEEF_00000000_FFFFFFFF_12345678, key_out);
            $finish;
        end

        if (key_type_out !== 2'b10) begin
            $display("[TEST] FAIL: key_type_out mismatch. Expected 2'b10, Got %b", key_type_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Update with a new key to ensure continuous capture capability
        // -------------------------------------------------------
        // Change inputs on the falling edge to ensure setup times for next rising edge
        @(negedge clk);
        key_in = 128'hCAFEBABE_11112222_33334444_55556666;
        key_type_in = 2'b01;
        
        @(posedge clk);
        #1;

        if (key_valid !== 1'b1) begin
            $display("[TEST] FAIL: key_valid dropped unexpectedly.");
            $finish;
        end

        if (key_out !== 128'hCAFEBABE_11112222_33334444_55556666) begin
            $display("[TEST] FAIL: key_out did not update. Expected %h, Got %h", 
                     128'hCAFEBABE_11112222_33334444_55556666, key_out);
            $finish;
        end

        if (key_type_out !== 2'b01) begin
            $display("[TEST] FAIL: key_type_out did not update. Expected 2'b01, Got %b", key_type_out);
            $finish;
        end

        $display("[TEST] PASS: Requirement [FUNCTIONAL-REQ-1] verified.");
        $finish;
    end

endmodule