`timescale 1ns / 1ps

module tb_functional_req_2;

    // Inputs to DUT
    reg clk;
    reg rst_n;
    reg load_key;
    reg [127:0] key_in;
    reg [1:0] key_type_in;

    // Outputs from DUT
    wire key_valid;
    wire [127:0] key_out;
    wire [1:0] key_type_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .load_key(load_key),
        .key_in(key_in),
        .key_type_in(key_type_in),
        .key_valid(key_valid),
        .key_out(key_out),
        .key_type_out(key_type_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        load_key = 0;
        key_in = 0;
        key_type_in = 0;

        // Reset the system
        #20;
        rst_n = 1;
        #20;

        // -------------------------------------------------------
        // Test Step 1: Load a known value into the registers
        // -------------------------------------------------------
        key_in = 128'h12345678_9ABCDEF0_12345678_9ABCDEF0;
        key_type_in = 2'b10;
        load_key = 1;

        @(posedge clk); // Trigger the load
        #1; // Allow for propagation delay

        // Verify outputs reflect the loaded value immediately
        if (key_out !== 128'h12345678_9ABCDEF0_12345678_9ABCDEF0 || key_type_out !== 2'b10) begin
            $display("[TEST] FAIL: Outputs did not reflect stored values immediately after load.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Step 2: Verify outputs drive stored values continuously
        // -------------------------------------------------------
        // De-assert load and change inputs to ensure outputs are not just passing inputs through
        load_key = 0;
        key_in = 128'hFFFFFFFF_FFFFFFFF_FFFFFFFF_FFFFFFFF;
        key_type_in = 2'b01;

        @(posedge clk); // Next cycle
        #1; // Allow for propagation delay

        // The outputs should still hold the OLD values (from Step 1), not the new inputs
        if (key_out === 128'h12345678_9ABCDEF0_12345678_9ABCDEF0 && key_type_out === 2'b10) begin
            $display("[TEST] PASS: Outputs continuously drive stored register values.");
        end else begin
            $display("[TEST] FAIL: Outputs changed unexpectedly. Expected stored values, got key_out=%h type=%b", key_out, key_type_out);
        end

        $finish;
    end

endmodule