#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Declaration of the function under test
extern int module(uint8_t *config_buffer, size_t buffer_len, uint32_t *status_register, uint32_t reset_reason, void (*hw_reset_handler)(void));

// Global flag to verify if the mock handler was called
static int mock_handler_called = 0;

// Mock hardware reset handler
void mock_hw_reset(void) {
    mock_handler_called = 1;
}

int main(void) {
    // [CASE-1] Test with NULL hw_reset_handler
    {
        uint8_t buffer[16] = {0};
        uint32_t status_reg = 0;
        
        // Call with NULL handler
        int result = module(buffer, sizeof(buffer), &status_reg, 0x1234, NULL);
        
        if (result == -1) {
            printf("[CASE-1] PASS: Function returned -1 when hw_reset_handler is NULL\n");
        } else {
            printf("[CASE-1] FAIL: Function returned %d instead of -1 when hw_reset_handler is NULL\n", result);
        }
    }

    // [CASE-2] Test with valid hw_reset_handler (Control case)
    {
        uint8_t buffer[16] = {0};
        uint32_t status_reg = 0;
        mock_handler_called = 0;
        
        // Call with valid handler
        int result = module(buffer, sizeof(buffer), &status_reg, 0x5678, mock_hw_reset);
        
        // Verify it didn't return -1 and actually called the handler
        // Note: Requirement says "return -1 immediately" on NULL. 
        // We check here that non-NULL behaves differently (returns 0 and runs handler).
        if (result == 0 && mock_handler_called == 1) {
            printf("[CASE-2] PASS: Function returned 0 and invoked handler when hw_reset_handler is valid\n");
        } else {
            printf("[CASE-2] FAIL: Result=%d (expected 0), HandlerCalled=%d (expected 1)\n", result, mock_handler_called);
        }
    }

    return 0;
}