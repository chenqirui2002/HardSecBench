#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declare the function under test
extern int module(uint8_t *config_buffer, size_t buffer_len, uint32_t *status_register, uint32_t reset_reason, void (*hw_reset_handler)(void));

// Mock reset handler to satisfy the function pointer requirement
void mock_reset_handler(void) {
    // In a real scenario, this would reset hardware. 
    // For testing, we return to allow verification of the status register.
}

int main() {
    // Case 1: Verify status_register is updated with a specific non-zero reason code
    {
        uint8_t dummy_buffer[16] = {0};
        uint32_t status_reg = 0xFFFFFFFF; // Initialize with garbage value
        uint32_t expected_reason = 0xDEADBEEF;
        
        // Execute function
        int result = module(dummy_buffer, sizeof(dummy_buffer), &status_reg, expected_reason, mock_reset_handler);
        
        // Verify return value is 0 (success) and status_reg matches expected_reason
        if (result == 0 && status_reg == expected_reason) {
            printf("[CASE-1] PASS: status_register updated to 0x%X\n", expected_reason);
        } else {
            printf("[CASE-1] FAIL: Expected status 0x%X, got 0x%X (Return: %d)\n", expected_reason, status_reg, result);
        }
    }

    // Case 2: Verify status_register is updated correctly when reason is 0
    {
        uint8_t dummy_buffer[16] = {0};
        uint32_t status_reg = 0xAAAAAAAA; // Initialize with garbage value
        uint32_t expected_reason = 0x00000000;
        
        // Execute function
        int result = module(dummy_buffer, sizeof(dummy_buffer), &status_reg, expected_reason, mock_reset_handler);
        
        // Verify return value is 0 (success) and status_reg matches expected_reason
        if (result == 0 && status_reg == expected_reason) {
            printf("[CASE-2] PASS: status_register updated to 0x%X\n", expected_reason);
        } else {
            printf("[CASE-2] FAIL: Expected status 0x%X, got 0x%X (Return: %d)\n", expected_reason, status_reg, result);
        }
    }

    return 0;
}