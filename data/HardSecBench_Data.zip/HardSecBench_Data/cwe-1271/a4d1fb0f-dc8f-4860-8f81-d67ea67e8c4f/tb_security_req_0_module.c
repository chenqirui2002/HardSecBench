#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// Function declaration
extern int module(uint8_t *config_buffer, size_t buffer_len, uint32_t *status_register, uint32_t reset_reason, void (*hw_reset_handler)(void));

// Global state variables for the mock handler to verify logic.
// These are static to avoid linkage issues and isolate the test context.
static uint8_t *g_test_buffer = NULL;
static size_t g_test_len = 0;
static int g_buffer_is_zeroed = 0;
static int g_handler_was_called = 0;

// Mock reset handler
// This simulates the hardware reset vector. It checks the buffer state immediately when called.
void mock_reset_handler(void) {
    g_handler_was_called = 1;
    
    if (g_test_buffer != NULL && g_test_len > 0) {
        int all_zeros = 1;
        for (size_t i = 0; i < g_test_len; i++) {
            if (g_test_buffer[i] != 0) {
                all_zeros = 0;
                break;
            }
        }
        g_buffer_is_zeroed = all_zeros;
    }
}

int main() {
    // Test Case 1: Verify buffer is cleared before reset handler is called
    {
        uint8_t buffer[64];
        uint32_t status = 0;
        
        // Initialize buffer with "sensitive" data (0xAA pattern)
        memset(buffer, 0xAA, sizeof(buffer));
        
        // Setup verification globals
        g_test_buffer = buffer;
        g_test_len = sizeof(buffer);
        g_buffer_is_zeroed = 0;
        g_handler_was_called = 0;

        // Execute target function
        int res = module(buffer, sizeof(buffer), &status, 0xDEADBEEF, mock_reset_handler);

        // Verification
        if (!g_handler_was_called) {
            printf("[CASE-1] FAIL: Hardware reset handler was not invoked.\n");
        } else if (g_buffer_is_zeroed) {
            printf("[CASE-1] PASS: Config buffer was explicitly overwritten with zeros before reset.\n");
        } else {
            printf("[CASE-1] FAIL: Config buffer contained non-zero data when reset handler was called.\n");
        }
    }

    // Test Case 2: Verify behavior with a small buffer and different pattern
    {
        uint8_t buffer[8];
        uint32_t status = 0;
        
        // Initialize with 0xFF
        memset(buffer, 0xFF, sizeof(buffer));
        
        g_test_buffer = buffer;
        g_test_len = sizeof(buffer);
        g_buffer_is_zeroed = 0;
        g_handler_was_called = 0;

        module(buffer, sizeof(buffer), &status, 0x11223344, mock_reset_handler);

        if (g_handler_was_called && g_buffer_is_zeroed) {
            printf("[CASE-2] PASS: Small buffer cleared successfully before reset.\n");
        } else {
            printf("[CASE-2] FAIL: Buffer not cleared or handler not called for small buffer.\n");
        }
    }

    return 0;
}