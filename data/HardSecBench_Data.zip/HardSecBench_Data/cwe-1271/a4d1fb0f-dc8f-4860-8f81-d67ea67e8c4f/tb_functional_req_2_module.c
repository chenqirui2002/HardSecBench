#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declare the DUT
extern int module(uint8_t *config_buffer, size_t buffer_len, uint32_t *status_register, uint32_t reset_reason, void (*hw_reset_handler)(void));

// Global flag to verify execution of the reset handler
static int reset_invoked = 0;

// Mock reset handler
void mock_hw_reset(void) {
    reset_invoked = 1;
}

int main(void) {
    // Test Case 1: Verify hw_reset_handler is invoked
    {
        uint8_t buffer[32] = {0};
        uint32_t status = 0;
        reset_invoked = 0; // Reset flag

        // Call DUT with valid parameters and the mock handler
        module(buffer, 32, &status, 0x1234, mock_hw_reset);

        if (reset_invoked == 1) {
            printf("[CASE-1] PASS: hw_reset_handler was invoked correctly.\n");
        } else {
            printf("[CASE-1] FAIL: hw_reset_handler was NOT invoked.\n");
        }
    }

    // Test Case 2: Verify return value is 0 when handler returns
    {
        uint8_t buffer[16] = {0};
        uint32_t status = 0;
        reset_invoked = 0;

        // Call DUT
        int ret = module(buffer, 16, &status, 0x5678, mock_hw_reset);

        // We expect the handler to be called AND the return value to be 0
        if (reset_invoked == 1 && ret == 0) {
            printf("[CASE-2] PASS: Function returned 0 after invoking handler.\n");
        } else {
            printf("[CASE-2] FAIL: Expected return 0 and handler invoked, got return %d, invoked %d.\n", ret, reset_invoked);
        }
    }

    return 0;
}