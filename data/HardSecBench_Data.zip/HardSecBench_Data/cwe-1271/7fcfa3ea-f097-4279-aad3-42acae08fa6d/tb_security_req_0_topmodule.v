`timescale 1ns/1ps

module testbench;

    // Inputs
    reg clk;
    reg rst_n;
    reg gen_enable;
    reg read_ack;

    // Outputs
    wire [31:0] random_data;
    wire random_data_valid;
    wire [2:0] entropy_level;
    wire system_error;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .gen_enable(gen_enable), 
        .read_ack(read_ack), 
        .random_data(random_data), 
        .random_data_valid(random_data_valid), 
        .entropy_level(entropy_level), 
        .system_error(system_error)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns period
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        gen_enable = 0;
        read_ack = 0;

        // Initial Reset to start clean
        #10;
        rst_n = 0;
        #10;
        rst_n = 1;
        #10;

        // ---------------------------------------------------------
        // Step 1: Drive random_data_valid HIGH
        // ---------------------------------------------------------
        @(negedge clk);
        gen_enable = 1;
        
        @(posedge clk); // Signal should update here
        #2; // Wait for propagation delay
        
        if (random_data_valid !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed - random_data_valid did not assert high when gen_enable was 1.");
            $finish;
        end

        // ---------------------------------------------------------
        // Step 2: Verify Asynchronous Reset
        // ---------------------------------------------------------
        // Assert reset NOW (between clock edges)
        rst_n = 0;
        #1; // Small delay for combinatorial propagation (much less than clock period)

        // Check immediately. We are still in the same clock cycle.
        // If the reset is synchronous, the value will still be 1 until the next edge.
        // If the reset is asynchronous, it should be 0 now.
        if (random_data_valid === 1'b0) begin
            $display("[TEST] PASS: random_data_valid was asynchronously reset to 0.");
        end else begin
            $display("[TEST] FAIL: random_data_valid did not reset to 0 immediately upon rst_n low (Value: %b).", random_data_valid);
        end

        $finish;
    end

endmodule