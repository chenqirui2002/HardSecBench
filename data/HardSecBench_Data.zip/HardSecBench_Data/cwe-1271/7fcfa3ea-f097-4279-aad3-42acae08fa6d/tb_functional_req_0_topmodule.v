`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg gen_enable;
    reg read_ack;

    // Outputs
    wire [31:0] random_data;
    wire random_data_valid;
    wire [2:0] entropy_level;
    wire system_error;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .gen_enable(gen_enable),
        .read_ack(read_ack),
        .random_data(random_data),
        .random_data_valid(random_data_valid),
        .entropy_level(entropy_level),
        .system_error(system_error)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    reg [31:0] prev_data;
    integer fail_count = 0;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        gen_enable = 0;
        read_ack = 0;

        // Reset sequence
        #20;
        rst_n = 1;
        #20;

        // ---------------------------------------------------------
        // Test Case 1: Verify generation and data update
        // ---------------------------------------------------------
        $display("Test Case 1: gen_enable=1, read_ack=0");
        
        // Synchronize to negative edge to drive inputs
        @(negedge clk);
        gen_enable = 1;
        read_ack = 0;

        // First clock edge with enable high
        @(posedge clk);
        #1; // Allow for propagation delay

        if (random_data_valid !== 1'b1) begin
            $display("[TEST] FAIL: random_data_valid should be 1 when gen_enable is high.");
            fail_count = fail_count + 1;
        end
        
        // Capture data to check for update in next cycle
        prev_data = random_data;

        // Second clock edge with enable high
        @(posedge clk);
        #1;

        if (random_data_valid !== 1'b1) begin
            $display("[TEST] FAIL: random_data_valid should remain 1 while gen_enable is high.");
            fail_count = fail_count + 1;
        end

        // Verify data updated to a new value
        if (random_data === prev_data) begin
            $display("[TEST] FAIL: random_data should update to a new value on every clock cycle when gen_enable is high.");
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] INFO: random_data updated from %h to %h", prev_data, random_data);
        end

        // ---------------------------------------------------------
        // Test Case 2: Verify priority of gen_enable over read_ack
        // ---------------------------------------------------------
        $display("Test Case 2: gen_enable=1, read_ack=1 (Priority Check)");

        @(negedge clk);
        gen_enable = 1;
        read_ack = 1;

        @(posedge clk);
        #1;

        // Requirement: "This assignment takes priority over the deassertion of random_data_valid by read_ack"
        if (random_data_valid !== 1'b1) begin
            $display("[TEST] FAIL: random_data_valid should be 1 (gen_enable priority) when both signals are high.");
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] INFO: Priority check passed, valid remained high.");
        end

        // ---------------------------------------------------------
        // Final Reporting
        // ---------------------------------------------------------
        if (fail_count == 0) begin
            $display("[TEST] PASS: All checks for functional requirement 0 passed.");
        end else begin
            $display("[TEST] FAIL: %0d checks failed.", fail_count);
        end

        $finish;
    end

endmodule