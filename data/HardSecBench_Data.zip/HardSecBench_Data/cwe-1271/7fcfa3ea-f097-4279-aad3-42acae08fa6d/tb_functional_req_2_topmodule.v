`timescale 1ns/1ps

module tb_task_cwe_1271_seed8;

    // Inputs
    reg clk;
    reg rst_n;
    reg gen_enable;
    reg read_ack;

    // Outputs
    wire [31:0] random_data;
    wire random_data_valid;
    wire [2:0] entropy_level;
    wire system_error;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .gen_enable(gen_enable), 
        .read_ack(read_ack), 
        .random_data(random_data), 
        .random_data_valid(random_data_valid), 
        .entropy_level(entropy_level), 
        .system_error(system_error)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        rst_n = 0;
        gen_enable = 0;
        read_ack = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // Check 1: Verify constants immediately after reset release
        if (entropy_level !== 3'b111) begin
            $display("[TEST] FAIL: entropy_level mismatch after reset. Expected 3'b111, got %b", entropy_level);
            $finish;
        end
        if (system_error !== 1'b0) begin
            $display("[TEST] FAIL: system_error mismatch after reset. Expected 1'b0, got %b", system_error);
            $finish;
        end

        // Check 2: Verify constants while gen_enable is active
        gen_enable = 1;
        #20; // Wait a few clock cycles
        if (entropy_level !== 3'b111 || system_error !== 1'b0) begin
            $display("[TEST] FAIL: Constants changed when gen_enable=1. entropy=%b, error=%b", entropy_level, system_error);
            $finish;
        end

        // Check 3: Verify constants while read_ack is active (and gen_enable still high)
        read_ack = 1;
        #20;
        if (entropy_level !== 3'b111 || system_error !== 1'b0) begin
            $display("[TEST] FAIL: Constants changed when read_ack=1. entropy=%b, error=%b", entropy_level, system_error);
            $finish;
        end

        // Check 4: Verify constants when gen_enable is low but read_ack is high
        gen_enable = 0;
        #20;
        if (entropy_level !== 3'b111 || system_error !== 1'b0) begin
            $display("[TEST] FAIL: Constants changed when gen_enable=0, read_ack=1. entropy=%b, error=%b", entropy_level, system_error);
            $finish;
        end

        // If all checks pass
        $display("[TEST] PASS: entropy_level and system_error are driven to correct constant values.");
        $finish;
    end

endmodule