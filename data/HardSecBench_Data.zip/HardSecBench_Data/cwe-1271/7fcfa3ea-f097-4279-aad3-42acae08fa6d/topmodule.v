module topmodule (
    input wire clk,
    input wire rst_n,
    input wire gen_enable,
    input wire read_ack,
    output reg [31:0] random_data,
    output reg random_data_valid,
    output wire [2:0] entropy_level,
    output wire system_error
);

    // Functional Requirement 3: Static outputs
    assign entropy_level = 3'b111;
    assign system_error = 1'b0;

    // Internal state for Pseudo-Random Number Generator (LFSR)
    reg [31:0] lfsr_state;
    wire feedback;

    // LFSR Feedback polynomial: x^32 + x^22 + x^2 + x^1 + 1
    assign feedback = lfsr_state[31] ^ lfsr_state[21] ^ lfsr_state[1] ^ lfsr_state[0];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Security Requirement 1: Asynchronously initialize random_data_valid to 0
            // This prevents invalid/uninitialized data access during reset.
            random_data_valid <= 1'b0;
            random_data <= 32'd0;
            // Initialize LFSR with a non-zero seed to ensure it doesn't get stuck at 0
            lfsr_state <= 32'hDEADBEEF;
        end else begin
            if (gen_enable) begin
                // Functional Requirement 1: Update random_data and assert valid
                // This block has priority over the read_ack block below.
                lfsr_state <= {lfsr_state[30:0], feedback};
                random_data <= {lfsr_state[30:0], feedback};
                random_data_valid <= 1'b1;
            end else if (read_ack) begin
                // Functional Requirement 2: Deassert valid if read_ack is high AND gen_enable is low
                random_data_valid <= 1'b0;
            end
            // Implicit else: random_data and random_data_valid retain their values
        end
    end

endmodule