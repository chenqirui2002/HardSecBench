`timescale 1ns/1ps

module tb_functional_req_1;

    // Signals
    reg clk;
    reg rst_n;
    reg gen_enable;
    reg read_ack;
    wire [31:0] random_data;
    wire random_data_valid;
    wire [2:0] entropy_level;
    wire system_error;

    // DUT Instantiation
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .gen_enable(gen_enable),
        .read_ack(read_ack),
        .random_data(random_data),
        .random_data_valid(random_data_valid),
        .entropy_level(entropy_level),
        .system_error(system_error)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize inputs
        rst_n = 0;
        gen_enable = 0;
        read_ack = 0;

        // Release reset
        #15;
        rst_n = 1;
        #5;

        // -------------------------------------------------------
        // Pre-condition Setup:
        // Assert gen_enable to set random_data_valid to 1 first.
        // This ensures we are testing the deassertion transition.
        // -------------------------------------------------------
        @(posedge clk);
        gen_enable = 1;
        read_ack = 0;

        @(posedge clk);
        #1; // Wait for output to settle
        
        // -------------------------------------------------------
        // Target Test: [FUNCTIONAL-REQ-1]
        // Condition: read_ack = 1, gen_enable = 0
        // Expected: random_data_valid -> 0
        // -------------------------------------------------------
        gen_enable = 0;
        read_ack = 1;

        @(posedge clk);
        #1; // Wait for output propagation

        if (random_data_valid === 1'b0) begin
            $display("[TEST] PASS: random_data_valid deasserted to 0 when read_ack=1 and gen_enable=0.");
        end else begin
            $display("[TEST] FAIL: random_data_valid expected 0, got %b (read_ack=1, gen_enable=0).", random_data_valid);
        end

        $finish;
    end

endmodule