module tb_task_cwe_1271_seed0;
    // Signal Declarations
    reg clk;
    reg rst_n;
    reg cfg_en;
    reg [2:0] cfg_addr;
    reg [7:0] cfg_data;
    
    wire debug_unlocked;
    wire status_ready;
    wire cfg_error;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cfg_en(cfg_en),
        .cfg_addr(cfg_addr),
        .cfg_data(cfg_data),
        .debug_unlocked(debug_unlocked),
        .status_ready(status_ready),
        .cfg_error(cfg_error)
    );

    // Clock Generation (10ns period)
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 1;
        cfg_en = 0;
        cfg_addr = 0;
        cfg_data = 0;

        // Wait for global stabilization
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Asynchronous Reset
        // -------------------------------------------------------
        $display("Test Case 1: Asserting Reset (Async Check)");
        rst_n = 0;
        #1; // Small delay for async logic propagation
        
        if (status_ready !== 1'b0) begin
            $display("[TEST] FAIL: status_ready did not reset to 0 asynchronously when rst_n was low.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Set on First Positive Clock Edge
        // -------------------------------------------------------
        $display("Test Case 2: Releasing Reset and checking next Posedge");
        
        // Synchronize to negedge to safely release reset before posedge
        @(negedge clk);
        rst_n = 1;

        // Wait for the specific positive edge where it should assert
        @(posedge clk);
        #1; // Allow for clock-to-q delay

        if (status_ready !== 1'b1) begin
            $display("[TEST] FAIL: status_ready did not set to 1 on the first posedge clk after rst_n high.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Verify Async Reset Interrupts Operation
        // -------------------------------------------------------
        $display("Test Case 3: Asserting Reset during operation");
        #20; // Let it run for a few cycles
        rst_n = 0;
        #1; // Async propagation

        if (status_ready !== 1'b0) begin
            $display("[TEST] FAIL: status_ready did not reset to 0 asynchronously during operation.");
            $finish;
        end

        // Final Success
        $display("[TEST] PASS: status_ready reset and set behavior verified.");
        $finish;
    end

endmodule