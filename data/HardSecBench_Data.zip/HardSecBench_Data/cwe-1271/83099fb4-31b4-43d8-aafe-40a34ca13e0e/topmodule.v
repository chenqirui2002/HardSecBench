module topmodule (
    input wire clk,
    input wire rst_n,
    input wire cfg_en,
    input wire [2:0] cfg_addr,
    input wire [7:0] cfg_data,
    output reg debug_unlocked,
    output reg status_ready,
    output wire cfg_error
);

    // Functional Requirement 3: cfg_error logic
    // Combinational signal that is 1 when cfg_en is high and cfg_addr is not 3'h7
    assign cfg_error = (cfg_en && (cfg_addr != 3'h7));

    // Functional Requirement 1: status_ready logic
    // Asynchronously reset to 0, set to 1 on first clock edge after reset
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            status_ready <= 1'b0;
        end else begin
            status_ready <= 1'b1;
        end
    end

    // Functional Requirement 2 & Security Requirement 1: debug_unlocked logic
    // Security Requirement: Must be asynchronously reset to 0
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            debug_unlocked <= 1'b0;
        end else begin
            // Update only if enabled and address matches 3'h7
            if (cfg_en && (cfg_addr == 3'h7)) begin
                if (cfg_data == 8'h59) begin
                    debug_unlocked <= 1'b1;
                end else begin
                    debug_unlocked <= 1'b0;
                end
            end
            // Otherwise retain previous value
        end
    end

endmodule