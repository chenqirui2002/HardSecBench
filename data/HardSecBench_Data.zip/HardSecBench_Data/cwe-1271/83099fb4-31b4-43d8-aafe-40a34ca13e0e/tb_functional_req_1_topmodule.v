module tb_functional_req_1;
    reg clk;
    reg rst_n;
    reg cfg_en;
    reg [2:0] cfg_addr;
    reg [7:0] cfg_data;
    wire debug_unlocked;
    wire status_ready;
    wire cfg_error;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cfg_en(cfg_en),
        .cfg_addr(cfg_addr),
        .cfg_data(cfg_data),
        .debug_unlocked(debug_unlocked),
        .status_ready(status_ready),
        .cfg_error(cfg_error)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cfg_en = 0;
        cfg_addr = 0;
        cfg_data = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #20;

        // ---------------------------------------------------------
        // Test Case 1: Unlock Condition
        // cfg_en=1, addr=7, data=0x59 -> debug_unlocked should be 1
        // ---------------------------------------------------------
        @(negedge clk);
        cfg_en = 1;
        cfg_addr = 3'h7;
        cfg_data = 8'h59;
        @(posedge clk);
        #1; // Allow for propagation delay
        
        if (debug_unlocked === 1'b1) begin
            $display("[TEST] PASS: debug_unlocked updated to 1 with correct key");
        end else begin
            $display("[TEST] FAIL: debug_unlocked failed to update to 1. Got: %b", debug_unlocked);
        end

        // ---------------------------------------------------------
        // Test Case 2: Lock Condition (Wrong Data)
        // cfg_en=1, addr=7, data=0xAA -> debug_unlocked should be 0
        // ---------------------------------------------------------
        @(negedge clk);
        cfg_en = 1;
        cfg_addr = 3'h7;
        cfg_data = 8'hAA;
        @(posedge clk);
        #1;

        if (debug_unlocked === 1'b0) begin
            $display("[TEST] PASS: debug_unlocked updated to 0 with incorrect key");
        end else begin
            $display("[TEST] FAIL: debug_unlocked failed to update to 0. Got: %b", debug_unlocked);
        end

        // ---------------------------------------------------------
        // Test Case 3: Retention Condition (cfg_en=0) - Hold High
        // First set it to 1, then disable enable and try to change it
        // ---------------------------------------------------------
        
        // Setup: Set to 1
        @(negedge clk);
        cfg_en = 1;
        cfg_addr = 3'h7;
        cfg_data = 8'h59;
        @(posedge clk);
        #1;
        
        // Check Setup
        if (debug_unlocked !== 1'b1) begin
             $display("[TEST] FAIL: Setup for retention test failed (could not set to 1)");
             $finish;
        end

        // Action: Disable cfg_en, change inputs to 'clear' value
        @(negedge clk);
        cfg_en = 0;
        cfg_addr = 3'h7;
        cfg_data = 8'h00; 
        @(posedge clk);
        #1;

        if (debug_unlocked === 1'b1) begin
            $display("[TEST] PASS: debug_unlocked retained value 1 when cfg_en=0");
        end else begin
            $display("[TEST] FAIL: debug_unlocked changed when cfg_en=0. Got: %b", debug_unlocked);
        end

        // ---------------------------------------------------------
        // Test Case 4: Retention Condition (cfg_en=0) - Hold Low
        // ---------------------------------------------------------
        
        // Setup: Set to 0
        @(negedge clk);
        cfg_en = 1;
        cfg_addr = 3'h7;
        cfg_data = 8'hAA;
        @(posedge clk);
        #1;
        
        // Action: Disable cfg_en, try to set to 1
        @(negedge clk);
        cfg_en = 0;
        cfg_addr = 3'h7;
        cfg_data = 8'h59; 
        @(posedge clk);
        #1;

        if (debug_unlocked === 1'b0) begin
            $display("[TEST] PASS: debug_unlocked retained value 0 when cfg_en=0");
        end else begin
            $display("[TEST] FAIL: debug_unlocked changed when cfg_en=0. Got: %b", debug_unlocked);
        end

        $finish;
    end

endmodule