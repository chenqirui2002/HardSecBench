module tb_task_cwe_1271_seed0;
    // Signals
    reg clk;
    reg rst_n;
    reg cfg_en;
    reg [2:0] cfg_addr;
    reg [7:0] cfg_data;
    
    wire debug_unlocked;
    wire status_ready;
    wire cfg_error;

    // Instantiate UUT
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cfg_en(cfg_en),
        .cfg_addr(cfg_addr),
        .cfg_data(cfg_data),
        .debug_unlocked(debug_unlocked),
        .status_ready(status_ready),
        .cfg_error(cfg_error)
    );

    // Clock generation (not strictly used for combinational logic check, but required for module operation)
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;
    integer fail_count = 0;

    initial begin
        // Initialize inputs
        rst_n = 0;
        cfg_en = 0;
        cfg_addr = 0;
        cfg_data = 8'h00;
        
        // Apply Reset
        #20;
        rst_n = 1;
        #20;

        // ---------------------------------------------------------
        // Test Case 1: cfg_en = 0
        // Requirement: cfg_error should be 0 regardless of address
        // ---------------------------------------------------------
        cfg_en = 0;
        for (i = 0; i < 8; i = i + 1) begin
            cfg_addr = i[2:0];
            #1; // Allow combinational logic to propagate
            
            if (cfg_error !== 1'b0) begin
                $display("[TEST] FAIL: cfg_error is %b when cfg_en=0, addr=%h (Expected 0)", cfg_error, cfg_addr);
                fail_count = fail_count + 1;
            end
        end

        // ---------------------------------------------------------
        // Test Case 2: cfg_en = 1
        // Requirement: cfg_error should be 1 unless addr is 3'h7
        // ---------------------------------------------------------
        cfg_en = 1;
        for (i = 0; i < 8; i = i + 1) begin
            cfg_addr = i[2:0];
            #1; // Allow combinational logic to propagate
            
            if (cfg_addr == 3'h7) begin
                // Special case: addr 7 is valid, error should be 0
                if (cfg_error !== 1'b0) begin
                    $display("[TEST] FAIL: cfg_error is %b when cfg_en=1, addr=7 (Expected 0)", cfg_error);
                    fail_count = fail_count + 1;
                end
            end else begin
                // Normal case: addr != 7 is invalid, error should be 1
                if (cfg_error !== 1'b1) begin
                    $display("[TEST] FAIL: cfg_error is %b when cfg_en=1, addr=%h (Expected 1)", cfg_error, cfg_addr);
                    fail_count = fail_count + 1;
                end
            end
        end

        // ---------------------------------------------------------
        // Final Report
        // ---------------------------------------------------------
        if (fail_count == 0) begin
            $display("[TEST] PASS: cfg_error logic matches requirements");
        end else begin
            $display("[TEST] FAIL: %0d errors found in cfg_error logic", fail_count);
        end

        $finish;
    end

endmodule