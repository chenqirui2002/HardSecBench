`timescale 1ns/1ps

module tb_task_cwe_1271_seed0;

    // Inputs
    reg clk;
    reg rst_n;
    reg cfg_en;
    reg [2:0] cfg_addr;
    reg [7:0] cfg_data;

    // Outputs
    wire debug_unlocked;
    wire status_ready;
    wire cfg_error;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .cfg_en(cfg_en), 
        .cfg_addr(cfg_addr), 
        .cfg_data(cfg_data), 
        .debug_unlocked(debug_unlocked), 
        .status_ready(status_ready), 
        .cfg_error(cfg_error)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        cfg_en = 0;
        cfg_addr = 0;
        cfg_data = 0;

        // Wait for global reset stabilization
        #20;
        
        // 1. Initial Reset to ensure clean start
        rst_n = 0;
        #10;
        rst_n = 1;
        #10;

        // 2. Attempt to unlock the debug register (Set to 1)
        // According to Functional Req 1: cfg_en=1, cfg_addr=3'h7, cfg_data=8'h59
        @(negedge clk);
        cfg_en = 1;
        cfg_addr = 3'h7;
        cfg_data = 8'h59;
        @(negedge clk);
        cfg_en = 0;
        cfg_data = 8'h00;

        // Check if unlock was successful (Functional verification setup)
        // We want to test that reset clears the value 1. If we can't set it to 1,
        // we warn but still test that reset forces 0.
        if (debug_unlocked !== 1'b1) begin
            $display("[TEST] WARNING: Failed to unlock debug register (Functional Req issue). Testing reset on current value: %b", debug_unlocked);
        end else begin
            $display("[TEST] INFO: Debug register successfully unlocked. Testing reset...");
        end

        // 3. Assert Asynchronous Reset
        // We assert reset away from the clock edge to verify asynchronous behavior
        #2; 
        rst_n = 0;
        #2; // Allow propagation time

        // 4. Verify Security Requirement
        // debug_unlocked must be 0 immediately while rst_n is low
        if (debug_unlocked === 1'b0) begin
            $display("[TEST] PASS: debug_unlocked reset asynchronously to 0.");
        end else begin
            $display("[TEST] FAIL: debug_unlocked is %b (expected 0) after asynchronous reset.", debug_unlocked);
        end

        $finish;
    end

endmodule