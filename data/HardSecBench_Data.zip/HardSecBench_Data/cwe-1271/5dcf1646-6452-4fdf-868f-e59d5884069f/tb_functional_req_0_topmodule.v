`timescale 1ns/1ps

module tb_task_cwe_1271_seed16;

    // Inputs
    reg clk;
    reg rst_n;
    reg lock_we;
    reg lock_data;
    reg req_read;
    reg req_write;

    // Outputs
    wire lock_state;
    wire bus_grant;
    wire irq;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .lock_we(lock_we),
        .lock_data(lock_data),
        .req_read(req_read),
        .req_write(req_write),
        .lock_state(lock_state),
        .bus_grant(bus_grant),
        .irq(irq)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer fail_count = 0;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        lock_we = 0;
        lock_data = 0;
        req_read = 0;
        req_write = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Write 0 to lock_state
        // -------------------------------------------------------
        @(negedge clk);
        lock_we = 1;
        lock_data = 0;
        @(posedge clk); // Trigger update
        #1; // Allow propagation delay
        
        if (lock_state !== 1'b0) begin
            $display("[TEST] FAIL: lock_state did not update to 0 with lock_we=1. Got: %b", lock_state);
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: lock_state updated to 0 with lock_we=1");
        end

        // -------------------------------------------------------
        // Test Case 2: Write 1 to lock_state
        // -------------------------------------------------------
        @(negedge clk);
        lock_we = 1;
        lock_data = 1;
        @(posedge clk);
        #1;

        if (lock_state !== 1'b1) begin
            $display("[TEST] FAIL: lock_state did not update to 1 with lock_we=1. Got: %b", lock_state);
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: lock_state updated to 1 with lock_we=1");
        end

        // -------------------------------------------------------
        // Test Case 3: Verify Write Enable (Hold value 1)
        // -------------------------------------------------------
        // Current state is 1. Set WE=0, Data=0. State should remain 1.
        @(negedge clk);
        lock_we = 0;
        lock_data = 0;
        @(posedge clk);
        #1;

        if (lock_state !== 1'b1) begin
            $display("[TEST] FAIL: lock_state changed to %b when lock_we=0 (Expected hold 1)", lock_state);
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: lock_state held value 1 when lock_we=0");
        end

        // -------------------------------------------------------
        // Test Case 4: Verify Write Enable (Hold value 0)
        // -------------------------------------------------------
        // First, write 0
        @(negedge clk);
        lock_we = 1;
        lock_data = 0;
        @(posedge clk);
        #1;
        
        // Now set WE=0, Data=1. State should remain 0.
        @(negedge clk);
        lock_we = 0;
        lock_data = 1;
        @(posedge clk);
        #1;

        if (lock_state !== 1'b0) begin
            $display("[TEST] FAIL: lock_state changed to %b when lock_we=0 (Expected hold 0)", lock_state);
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: lock_state held value 0 when lock_we=0");
        end

        // Final Report
        if (fail_count == 0) begin
            $display("[TEST] PASS: All lock_state update requirements met.");
        end else begin
            $display("[TEST] FAIL: %0d checks failed.", fail_count);
        end

        $finish;
    end

endmodule