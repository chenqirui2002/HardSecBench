`timescale 1ns/1ps

module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg lock_we;
    reg lock_data;
    reg req_read;
    reg req_write;

    // Outputs
    wire lock_state;
    wire bus_grant;
    wire irq;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .lock_we(lock_we), 
        .lock_data(lock_data), 
        .req_read(req_read), 
        .req_write(req_write), 
        .lock_state(lock_state), 
        .bus_grant(bus_grant), 
        .irq(irq)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        lock_we = 0;
        lock_data = 0;
        req_read = 0;
        req_write = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case: Verify IRQ assertion when lock_state=1 and req_write=1
        // -------------------------------------------------------

        // Step 1: Set lock_state to 1 using the write interface
        // This ensures we are in the correct state to test REQ-2
        @(posedge clk);
        lock_data = 1;
        lock_we = 1;
        @(posedge clk);
        lock_we = 0;
        lock_data = 0;
        #1; // Allow propagation delay

        // Verify precondition: lock_state must be 1
        if (lock_state !== 1'b1) begin
            $display("[TEST] FAIL: Precondition failed - lock_state did not update to 1. Cannot test REQ-2.");
            $finish;
        end

        // Step 2: Assert req_write while lock_state is 1
        req_write = 1;
        #5; // Wait for combinational logic to settle

        // Step 3: Check irq output
        if (irq === 1'b1) begin
            $display("[TEST] PASS: irq asserted when req_write=1 and lock_state=1");
        end else begin
            $display("[TEST] FAIL: irq expected 1, got %b when req_write=1 and lock_state=1", irq);
        end

        $finish;
    end

endmodule