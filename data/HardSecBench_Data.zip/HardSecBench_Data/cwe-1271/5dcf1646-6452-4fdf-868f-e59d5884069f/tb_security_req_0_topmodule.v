`timescale 1ns/1ps

module testbench;

    // Inputs
    reg clk;
    reg rst_n;
    reg lock_we;
    reg lock_data;
    reg req_read;
    reg req_write;

    // Outputs
    wire lock_state;
    wire bus_grant;
    wire irq;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .lock_we(lock_we),
        .lock_data(lock_data),
        .req_read(req_read),
        .req_write(req_write),
        .lock_state(lock_state),
        .bus_grant(bus_grant),
        .irq(irq)
    );

    // Clock generation: 10ns period
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        lock_we = 0;
        lock_data = 0;
        req_read = 0;
        req_write = 0;

        // -------------------------------------------------------
        // Test Case 1: Power-on Reset Verification
        // -------------------------------------------------------
        // Assert reset immediately
        rst_n = 0;
        #10; // Wait for propagation

        if (lock_state !== 1'b1) begin
            $display("[TEST] FAIL: lock_state is %b after power-on reset (expected 1)", lock_state);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Asynchronous Reset Verification
        // -------------------------------------------------------
        // Release reset
        rst_n = 1;
        #20;

        // Attempt to unlock the module (set lock_state to 0)
        // This relies on functional logic, but is necessary to prove reset forces 1 from 0
        @(negedge clk);
        lock_we = 1;
        lock_data = 0;
        @(posedge clk); // Write happens here
        #2;
        lock_we = 0;

        // Wait a bit to ensure state is stable
        #5;

        // Check if we managed to unlock it (Functional check, not security failure if this fails, 
        // but helps context)
        if (lock_state === 1'b0) begin
            $display("Info: Module unlocked successfully. Testing asynchronous reset...");
        end else begin
            $display("Info: Module did not unlock (Functional issue?). Testing reset overrides anyway...");
        end

        // Assert Reset Asynchronously
        // We ensure we are NOT on a clock edge to prove async behavior
        // Current time is roughly post-edge + hold + wait. 
        rst_n = 0;
        #1; // Small propagation delay, definitely less than a clock cycle

        if (lock_state !== 1'b1) begin
            $display("[TEST] FAIL: lock_state did not reset to 1 asynchronously. Current state: %b", lock_state);
            $finish;
        end

        // Ensure it stays 1 while reset is held
        #10;
        if (lock_state !== 1'b1) begin
            $display("[TEST] FAIL: lock_state did not maintain 1 while reset held");
            $finish;
        end

        $display("[TEST] PASS: lock_state correctly resets to 1 (locked) on active low reset");
        $finish;
    end

endmodule