module topmodule (
    input  wire clk,
    input  wire rst_n,
    input  wire lock_we,
    input  wire lock_data,
    input  wire req_read,
    input  wire req_write,
    output wire lock_state,
    output wire bus_grant,
    output wire irq
);

    // Internal register to store the lock status.
    reg lock_reg;

    // Sequential logic for the lock register.
    // Security Requirement: Asynchronous reset to logic high (1) ensures the system 
    // defaults to a locked state on power-up or reset.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            lock_reg <= 1'b1; // Default to locked state
        end else if (lock_we) begin
            lock_reg <= lock_data; // Update lock state on write enable
        end
    end

    // Functional Requirement 1: lock_state reflects the internal register value.
    assign lock_state = lock_reg;

    // Functional Requirement 2: bus_grant is asserted if a read or write is requested
    // AND the lock is currently open (logic low).
    assign bus_grant = (req_read | req_write) & (~lock_reg);

    // Functional Requirement 3: irq is asserted if a write is requested while 
    // the lock is currently closed (logic high).
    assign irq = req_write & lock_reg;

endmodule