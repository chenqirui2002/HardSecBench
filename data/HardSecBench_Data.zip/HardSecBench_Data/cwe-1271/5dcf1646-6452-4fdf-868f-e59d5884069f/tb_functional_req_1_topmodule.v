`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg lock_we;
    reg lock_data;
    reg req_read;
    reg req_write;

    // Outputs
    wire lock_state;
    wire bus_grant;
    wire irq;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .lock_we(lock_we),
        .lock_data(lock_data),
        .req_read(req_read),
        .req_write(req_write),
        .lock_state(lock_state),
        .bus_grant(bus_grant),
        .irq(irq)
    );

    // Clock generation: 10ns period
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        lock_we = 0;
        lock_data = 0;
        req_read = 0;
        req_write = 0;

        // Reset Sequence
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Setup: Unlock the module (lock_state -> 0)
        // -------------------------------------------------------
        // Requirement implies bus_grant depends on lock_state being low.
        // We must write 0 to the lock register first.
        @(posedge clk);
        lock_we = 1;
        lock_data = 0;
        @(posedge clk);
        lock_we = 0;
        
        // Wait for propagation
        #1;
        
        // Verify Pre-condition
        if (lock_state !== 1'b0) begin
            $display("[TEST] FAIL: Unable to set lock_state to 0. Cannot verify REQ-1.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 1: req_read = 1, req_write = 0
        // -------------------------------------------------------
        req_read = 1;
        req_write = 0;
        
        // Wait for next clock edge + delay to handle both combinational and synchronous implementations
        @(posedge clk);
        #1;
        
        if (bus_grant !== 1'b1) begin
            $display("[TEST] FAIL: bus_grant not asserted (0) when req_read=1 and lock_state=0");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: req_read = 0, req_write = 1
        // -------------------------------------------------------
        req_read = 0;
        req_write = 1;
        
        @(posedge clk);
        #1;
        
        if (bus_grant !== 1'b1) begin
            $display("[TEST] FAIL: bus_grant not asserted (0) when req_write=1 and lock_state=0");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: req_read = 1, req_write = 1
        // -------------------------------------------------------
        req_read = 1;
        req_write = 1;
        
        @(posedge clk);
        #1;
        
        if (bus_grant !== 1'b1) begin
            $display("[TEST] FAIL: bus_grant not asserted (0) when req_read=1, req_write=1 and lock_state=0");
            $finish;
        end

        // If all checks pass
        $display("[TEST] PASS: bus_grant asserted correctly for all request combinations when unlocked");
        $finish;
    end

endmodule