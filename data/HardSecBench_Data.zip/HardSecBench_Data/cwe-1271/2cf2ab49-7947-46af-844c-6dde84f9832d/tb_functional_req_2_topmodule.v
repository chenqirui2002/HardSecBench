module tb_functional_req_2;
    // Signals
    reg clk;
    reg rst_n;
    reg set_protect;
    reg clr_protect;
    reg lock_config;
    wire write_protect;
    wire config_locked;
    wire [3:0] status_out;

    // Instantiate UUT
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .set_protect(set_protect),
        .clr_protect(clr_protect),
        .lock_config(lock_config),
        .write_protect(write_protect),
        .config_locked(config_locked),
        .status_out(status_out)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize inputs
        clk = 0;
        rst_n = 0;
        set_protect = 0;
        clr_protect = 0;
        lock_config = 0;

        // 1. Verify Reset clears config_locked
        #10;
        if (config_locked !== 1'b0) begin
            $display("[TEST] FAIL: config_locked should be 0 after initial reset");
            $finish;
        end

        // Release reset
        rst_n = 1;
        #10;

        // 2. Verify lock_config sets config_locked
        lock_config = 1;
        @(posedge clk);
        #1; // Allow for propagation delay
        if (config_locked !== 1'b1) begin
            $display("[TEST] FAIL: config_locked did not set to 1 when lock_config was asserted");
            $finish;
        end

        // 3. Verify config_locked stays set when lock_config is removed (Sticky bit)
        lock_config = 0;
        @(posedge clk);
        #1;
        if (config_locked !== 1'b1) begin
            $display("[TEST] FAIL: config_locked cleared when lock_config was de-asserted (should only clear on reset)");
            $finish;
        end

        // 4. Verify config_locked clears on Reset
        rst_n = 0;
        #5; // Async reset check
        if (config_locked !== 1'b0) begin
            $display("[TEST] FAIL: config_locked did not clear when rst_n was asserted");
            $finish;
        end

        // Success
        $display("[TEST] PASS: config_locked sets on command and clears only on reset");
        $finish;
    end

endmodule