`timescale 1ns/1ps

module tb_task_cwe_1271_seed10;

    // Inputs
    reg clk;
    reg rst_n;
    reg set_protect;
    reg clr_protect;
    reg lock_config;

    // Outputs
    wire write_protect;
    wire config_locked;
    wire [3:0] status_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .set_protect(set_protect), 
        .clr_protect(clr_protect), 
        .lock_config(lock_config), 
        .write_protect(write_protect), 
        .config_locked(config_locked), 
        .status_out(status_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Verification task
    task verify_status;
        input [8*20:1] state_name;
        begin
            #1; // Allow for combinational logic propagation after clock edge
            if (status_out !== {2'b00, config_locked, write_protect}) begin
                $display("[TEST] FAIL: status_out mismatch during %s.", state_name);
                $display("       Expected: %b ( {2'b00, config_locked=%b, write_protect=%b} )", 
                         {2'b00, config_locked, write_protect}, config_locked, write_protect);
                $display("       Got:      %b", status_out);
                $finish;
            end
        end
    endtask

    initial begin
        // Initialize Inputs
        rst_n = 0;
        set_protect = 0;
        clr_protect = 0;
        lock_config = 0;

        // Wait for global reset
        #100;
        rst_n = 1;
        #10;
        verify_status("After Reset");

        // Test Case 1: Set Protect
        @(negedge clk);
        set_protect = 1;
        clr_protect = 0;
        lock_config = 0;
        @(negedge clk);
        set_protect = 0;
        verify_status("Set Protect");

        // Test Case 2: Clear Protect
        @(negedge clk);
        set_protect = 0;
        clr_protect = 1;
        lock_config = 0;
        @(negedge clk);
        clr_protect = 0;
        verify_status("Clear Protect");

        // Test Case 3: Lock Config
        @(negedge clk);
        set_protect = 0;
        clr_protect = 0;
        lock_config = 1;
        @(negedge clk);
        lock_config = 0;
        verify_status("Lock Config");

        // Test Case 4: Attempt Set Protect while Locked
        // Even if the state doesn't change, status_out must still match the outputs
        @(negedge clk);
        set_protect = 1;
        clr_protect = 0;
        lock_config = 0;
        @(negedge clk);
        set_protect = 0;
        verify_status("Set Protect (Locked)");

        // Test Case 5: Attempt Clear Protect while Locked
        @(negedge clk);
        set_protect = 0;
        clr_protect = 1;
        lock_config = 0;
        @(negedge clk);
        clr_protect = 0;
        verify_status("Clear Protect (Locked)");

        // Final success message
        $display("[TEST] PASS: status_out correctly reflects internal state concatenation");
        $finish;
    end

endmodule