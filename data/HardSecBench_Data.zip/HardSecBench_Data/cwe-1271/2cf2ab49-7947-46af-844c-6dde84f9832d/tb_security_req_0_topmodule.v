module testbench_security_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg set_protect;
    reg clr_protect;
    reg lock_config;

    // Outputs
    wire write_protect;
    wire config_locked;
    wire [3:0] status_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .set_protect(set_protect),
        .clr_protect(clr_protect),
        .lock_config(lock_config),
        .write_protect(write_protect),
        .config_locked(config_locked),
        .status_out(status_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 1;
        set_protect = 0;
        clr_protect = 0;
        lock_config = 0;

        // -------------------------------------------------------
        // Test Case 1: Initial Power-on Reset Check
        // -------------------------------------------------------
        #10;
        rst_n = 0; // Assert active-low reset
        #2;        // Wait small delay for async propagation (less than clock cycle)

        if (write_protect !== 1'b1) begin
            $display("[TEST] FAIL: write_protect was not set to 1 immediately upon reset assertion.");
            $finish;
        end

        // Release reset
        rst_n = 1;
        #10;

        // Verify it stays 1 after reset release (default state)
        if (write_protect !== 1'b1) begin
            $display("[TEST] FAIL: write_protect did not remain 1 after reset release.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Reset Assertion from Unprotected State
        // -------------------------------------------------------
        // Attempt to clear protection to 0 to verify reset restores it to 1
        clr_protect = 1;
        @(posedge clk); // Wait for clock edge to process command
        #1;             // Propagation delay
        clr_protect = 0;

        // Only proceed with this check if we successfully cleared it (functional dependency).
        // If we couldn't clear it, it's stuck at 1, which technically satisfies the 
        // security requirement of being protected, but we want to test the reset logic specifically.
        if (write_protect === 1'b0) begin
            #5;
            rst_n = 0; // Assert reset again
            #2;        // Async check
            
            if (write_protect !== 1'b1) begin
                $display("[TEST] FAIL: write_protect did not return to 1 immediately when reset was asserted from 0 state.");
                $finish;
            end
        end else begin
            $display("[TEST] INFO: Could not clear write_protect (Functional issue?), but initial reset test passed.");
        end

        // If we reached here, the security requirement is satisfied
        $display("[TEST] PASS: write_protect is correctly initialized to 1 on asynchronous reset.");
        $finish;
    end

endmodule