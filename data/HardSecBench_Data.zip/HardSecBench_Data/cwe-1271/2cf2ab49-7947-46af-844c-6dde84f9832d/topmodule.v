module topmodule (
    input wire clk,
    input wire rst_n,
    input wire set_protect,
    input wire clr_protect,
    input wire lock_config,
    output reg write_protect,
    output reg config_locked,
    output wire [3:0] status_out
);

    // Status output concatenation: {2'b00, config_locked, write_protect}
    assign status_out = {2'b00, config_locked, write_protect};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Security Requirement: write_protect MUST be set to 1 on reset
            // to ensure flash is protected by default.
            write_protect <= 1'b1;
            config_locked <= 1'b0;
        end else begin
            // Configuration Lock Logic
            // Once asserted, config_locked stays 1 until reset.
            if (lock_config) begin
                config_locked <= 1'b1;
            end

            // Write Protection Logic
            // Can only be modified if configuration is not locked.
            if (!config_locked) begin
                if (set_protect) begin
                    write_protect <= 1'b1;
                end else if (clr_protect) begin
                    write_protect <= 1'b0;
                end
            end
        end
    end

endmodule