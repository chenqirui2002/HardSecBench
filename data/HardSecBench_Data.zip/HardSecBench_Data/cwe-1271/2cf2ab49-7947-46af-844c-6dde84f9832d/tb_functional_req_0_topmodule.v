module tb_functional_req_0;

    // Testbench signals
    reg clk;
    reg rst_n;
    reg set_protect;
    reg clr_protect;
    reg lock_config;

    // Outputs from UUT
    wire write_protect;
    wire config_locked;
    wire [3:0] status_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .set_protect(set_protect),
        .clr_protect(clr_protect),
        .lock_config(lock_config),
        .write_protect(write_protect),
        .config_locked(config_locked),
        .status_out(status_out)
    );

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;       // Start in reset
        set_protect = 0;
        clr_protect = 0;
        lock_config = 0;

        // Apply reset and wait
        #10;
        rst_n = 1;       // Release reset
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Rising Edge Sensitivity
        // -------------------------------------------------------
        // We use the behavior defined in REQ-2 (lock_config sets config_locked)
        // to verify that changes only happen on the rising edge.
        
        lock_config = 1;
        
        // Check before rising edge (clk is 0)
        #5;
        if (config_locked !== 1'b0) begin
            $display("[TEST] FAIL: config_locked changed before rising edge of clk");
            $finish;
        end

        // Generate Rising Edge
        clk = 1;
        #5; // Allow propagation delay

        // Check after rising edge
        if (config_locked !== 1'b1) begin
            $display("[TEST] FAIL: config_locked did not update on rising edge of clk");
            $finish;
        end

        $display("[TEST] PASS: Logic operates on rising edge of clk");

        // -------------------------------------------------------
        // Test Case 2: Verify Active-Low Asynchronous Reset
        // -------------------------------------------------------
        // Currently config_locked is 1. We will assert rst_n (low)
        // while the clock is static (no edge) to prove async behavior.
        
        clk = 0; // Set clock low
        #5;
        
        rst_n = 0; // Assert active-low reset
        #2;        // Small delay for propagation, no clock edge

        // Verify immediate reset of config_locked (REQ-2 states it clears to 0)
        if (config_locked !== 1'b0) begin
            $display("[TEST] FAIL: Asynchronous reset did not clear config_locked immediately");
            $finish;
        end

        // Verify reset holds
        clk = 1; // Even with a clock edge, it should stay reset
        #5;
        if (config_locked !== 1'b0) begin
            $display("[TEST] FAIL: Reset state not maintained while rst_n is low");
            $finish;
        end

        $display("[TEST] PASS: Active-low asynchronous reset verified");
        $finish;
    end

endmodule