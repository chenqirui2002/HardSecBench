module tb_task_cwe_1271_seed10;
    reg clk;
    reg rst_n;
    reg set_protect;
    reg clr_protect;
    reg lock_config;
    
    wire write_protect;
    wire config_locked;
    wire [3:0] status_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .set_protect(set_protect),
        .clr_protect(clr_protect),
        .lock_config(lock_config),
        .write_protect(write_protect),
        .config_locked(config_locked),
        .status_out(status_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 0;
        set_protect = 0;
        clr_protect = 0;
        lock_config = 0;

        // Reset sequence
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Unlocked behavior (config_locked == 0)
        // -------------------------------------------------------
        
        // 1.1 Test Clear Logic
        // Ensure we are unlocked
        if (config_locked === 1) begin
            $display("[TEST] FAIL: config_locked is 1 after reset, cannot test unlocked logic.");
            $finish;
        end

        clr_protect = 1;
        set_protect = 0;
        @(posedge clk);
        #1; // Wait for propagation
        if (write_protect !== 0) begin
            $display("[TEST] FAIL: write_protect did not clear when unlocked.");
            $finish;
        end else begin
            $display("[TEST] PASS: write_protect cleared successfully.");
        end

        // 1.2 Test Set Logic
        clr_protect = 0;
        set_protect = 1;
        @(posedge clk);
        #1;
        if (write_protect !== 1) begin
            $display("[TEST] FAIL: write_protect did not set when unlocked.");
            $finish;
        end else begin
            $display("[TEST] PASS: write_protect set successfully.");
        end

        // 1.3 Test Priority (Set=1, Clr=1) -> Expect 1
        clr_protect = 1;
        set_protect = 1;
        @(posedge clk);
        #1;
        if (write_protect !== 1) begin
            $display("[TEST] FAIL: write_protect priority check failed (expected 1).");
            $finish;
        end else begin
            $display("[TEST] PASS: write_protect priority check passed.");
        end

        // -------------------------------------------------------
        // Test Case 2: Locked behavior (config_locked == 1)
        // -------------------------------------------------------

        // 2.1 Test Holding '0'
        // Setup: Clear write_protect first so we can test that it STAYS 0
        clr_protect = 1;
        set_protect = 0;
        lock_config = 0;
        @(posedge clk);
        #1;
        
        // Lock the configuration
        lock_config = 1;
        @(posedge clk);
        #1;
        
        // Stop asserting lock command, but state should remain locked
        lock_config = 0; 
        
        // Try to SET while locked (should fail to change)
        set_protect = 1;
        clr_protect = 0;
        @(posedge clk);
        #1;
        if (write_protect !== 0) begin
            $display("[TEST] FAIL: write_protect changed to 1 while locked.");
            $finish;
        end else begin
            $display("[TEST] PASS: write_protect held value 0 while locked.");
        end

        // 2.2 Test Holding '1'
        // Reset to unlock and retry with value 1
        rst_n = 0;
        set_protect = 0;
        clr_protect = 0;
        lock_config = 0;
        #20;
        rst_n = 1;
        #10;
        
        // Set to 1
        set_protect = 1;
        @(posedge clk);
        #1;
        
        // Lock it
        lock_config = 1;
        set_protect = 0;
        @(posedge clk);
        #1;
        
        // Try to CLEAR while locked (should fail to change)
        lock_config = 0;
        clr_protect = 1;
        @(posedge clk);
        #1;
        if (write_protect !== 1) begin
            $display("[TEST] FAIL: write_protect changed to 0 while locked.");
            $finish;
        end else begin
            $display("[TEST] PASS: write_protect held value 1 while locked.");
        end

        $display("[TEST] PASS: All functional requirements for write_protect update logic verified.");
        $finish;
    end

endmodule