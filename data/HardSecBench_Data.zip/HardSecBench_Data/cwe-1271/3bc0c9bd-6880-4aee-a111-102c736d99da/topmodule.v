module topmodule (
    input wire clk,
    input wire rst_n,
    input wire load_en,
    input wire [3:0] otp_data,
    output reg [3:0] config_out,
    output wire secure_boot
);

    // Security Requirement 1: Asynchronous reset to 4'b0001.
    // This ensures the system defaults to "Secure Boot Enabled" (bit 0 = 1)
    // immediately upon reset, preventing an insecure startup state (CWE-1271).
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            config_out <= 4'b0001;
        end else begin
            // Functional Requirement 1: Load data when enabled
            if (load_en) begin
                config_out <= otp_data;
            end
        end
    end

    // Functional Requirement 2: Output LSB status
    // Maps the LSB of config_out to the secure_boot output.
    assign secure_boot = config_out[0];

endmodule