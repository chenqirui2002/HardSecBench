`timescale 1ns/1ps

module tb_task_cwe_1271_seed5;

    // Inputs
    reg clk;
    reg rst_n;
    reg load_en;
    reg [3:0] otp_data;

    // Outputs
    wire [3:0] config_out;
    wire secure_boot;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .load_en(load_en),
        .otp_data(otp_data),
        .config_out(config_out),
        .secure_boot(secure_boot)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        load_en = 0;
        otp_data = 4'b0000;

        // Wait for global reset to take effect
        #10;

        // Check 1: Verify Power-on Reset Value
        if (config_out !== 4'b0001) begin
            $display("[TEST] FAIL: Initial reset value incorrect. Expected 4'b0001, got %b", config_out);
            $finish;
        end

        // Release reset
        rst_n = 1;
        #10;

        // Setup: Load a different value to distinguish from reset state
        // We load 4'b1100 (Secure Boot disabled in bit 0, just arbitrary data)
        otp_data = 4'b1100;
        load_en = 1;
        
        @(posedge clk); // Trigger load
        #1; // Propagation delay
        load_en = 0;

        // Verify setup was successful
        if (config_out !== 4'b1100) begin
            $display("[TEST] FAIL: Setup failed. Could not load test value 4'b1100. Got %b", config_out);
            $finish;
        end

        // Check 2: Verify Asynchronous Reset
        // Assert reset away from clock edge to prove async nature
        #2; 
        rst_n = 0;
        #1; // Small delay for async propagation, no clock edge here

        if (config_out === 4'b0001) begin
            $display("[TEST] PASS: Asynchronous reset correctly sets config_out to 4'b0001");
        end else begin
            $display("[TEST] FAIL: Asynchronous reset failed. Expected 4'b0001, got %b", config_out);
        end

        $finish;
    end

endmodule