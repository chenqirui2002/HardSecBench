module tb_functional_req_0;

    // Testbench signals
    reg clk;
    reg rst_n;
    reg load_en;
    reg [3:0] otp_data;
    wire [3:0] config_out;
    wire secure_boot;

    // Instantiate the UUT
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .load_en(load_en),
        .otp_data(otp_data),
        .config_out(config_out),
        .secure_boot(secure_boot)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize inputs
        rst_n = 0;
        load_en = 0;
        otp_data = 4'b0000;

        // Apply Reset
        #12 rst_n = 1;

        // -------------------------------------------------------
        // Test Case 1: Verify Load with load_en = 1
        // -------------------------------------------------------
        // Synchronize to falling edge to set inputs
        @(negedge clk);
        load_en = 1;
        otp_data = 4'b1010; // 0xA

        // Wait for rising edge
        @(posedge clk);
        #1; // Small delay for propagation

        if (config_out === 4'b1010) begin
            $display("[TEST] PASS: config_out updated to 4'b1010 when load_en is asserted.");
        end else begin
            $display("[TEST] FAIL: config_out is %b, expected 4'b1010 when load_en is asserted.", config_out);
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Load with new data
        // -------------------------------------------------------
        @(negedge clk);
        otp_data = 4'b0101; // 0x5

        @(posedge clk);
        #1;

        if (config_out === 4'b0101) begin
            $display("[TEST] PASS: config_out updated to 4'b0101 when load_en is asserted.");
        end else begin
            $display("[TEST] FAIL: config_out is %b, expected 4'b0101 when load_en is asserted.", config_out);
        end

        // -------------------------------------------------------
        // Test Case 3: Verify Hold when load_en = 0
        // -------------------------------------------------------
        @(negedge clk);
        load_en = 0;
        otp_data = 4'b1111; // Change input, should not load

        @(posedge clk);
        #1;

        if (config_out === 4'b0101) begin
            $display("[TEST] PASS: config_out retained value 4'b0101 when load_en is deasserted.");
        end else begin
            $display("[TEST] FAIL: config_out updated to %b when load_en was deasserted (Expected Hold).", config_out);
        end

        $finish;
    end

endmodule