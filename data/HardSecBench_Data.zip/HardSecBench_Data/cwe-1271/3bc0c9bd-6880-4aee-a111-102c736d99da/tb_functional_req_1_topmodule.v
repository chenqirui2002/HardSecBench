`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg load_en;
    reg [3:0] otp_data;

    // Outputs
    wire [3:0] config_out;
    wire secure_boot; // Corresponds to 'mode_bit' in the requirement text based on module definition

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .load_en(load_en),
        .otp_data(otp_data),
        .config_out(config_out),
        .secure_boot(secure_boot)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;
    reg test_pass;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        load_en = 0;
        otp_data = 0;
        test_pass = 1;

        // Wait for global reset
        #100;
        rst_n = 1;
        #10;

        // Test Case 1: Check relationship immediately after reset
        // We do not verify the specific reset value (Security Req), only the LSB relationship.
        if (secure_boot !== config_out[0]) begin
            $display("[TEST] FAIL: secure_boot (%b) != config_out[0] (%b) after reset", secure_boot, config_out[0]);
            test_pass = 0;
        end

        // Test Case 2: Load all possible 4-bit patterns and check relationship
        // We toggle load_en to update config_out and verify secure_boot tracks bit 0.
        for (i = 0; i < 16; i = i + 1) begin
            @(negedge clk);
            otp_data = i[3:0];
            load_en = 1;
            
            @(posedge clk); // Load should occur here
            #1; // Allow for propagation delay
            
            if (secure_boot !== config_out[0]) begin
                $display("[TEST] FAIL: secure_boot (%b) != config_out[0] (%b) for config_out=%b", secure_boot, config_out[0], config_out);
                test_pass = 0;
            end
        end

        // Test Case 3: Verify relationship holds when load_en is disabled
        @(negedge clk);
        load_en = 0;
        otp_data = 4'b1010; // Change inputs, config_out should hold previous value
        
        @(posedge clk);
        #1;
        
        if (secure_boot !== config_out[0]) begin
             $display("[TEST] FAIL: secure_boot (%b) != config_out[0] (%b) when load_en=0", secure_boot, config_out[0]);
             test_pass = 0;
        end

        // Final Result
        if (test_pass) begin
            $display("[TEST] PASS: secure_boot is continuously assigned LSB of config_out");
        end else begin
            $display("[TEST] FAIL: secure_boot mismatch detected");
        end

        $finish;
    end

endmodule