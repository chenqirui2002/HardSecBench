#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

/* 
 * Function signature as defined in the problem description.
 * Returns 0 on success, -1 on overlap/overflow error, -2 on invalid length.
 */
extern int module(uint32_t src_addr, uint32_t dst_addr, size_t len, uint32_t rsv_base, size_t rsv_size, uint8_t *channel_active);

int main() {
    // Test Case 1: Verify detection of overlap with reserved region
    // The source range (0x80000010 to 0x80000110) falls inside the reserved region (0x80000000 to 0x80001000).
    {
        uint32_t rsv_base = 0x80000000;
        size_t rsv_size = 0x1000;
        
        uint32_t src = 0x80000010; 
        uint32_t dst = 0x10000000;
        size_t len = 0x100;
        uint8_t active = 0; // Initialize to 0
        
        int res = module(src, dst, len, rsv_base, rsv_size, &active);
        
        if (res == -1) {
            printf("[CASE-1] PASS: Overlap correctly detected (returned -1)\n");
        } else {
            printf("[CASE-1] FAIL: Overlap not detected, returned %d\n", res);
        }
    }

    // Test Case 2: Verify detection of integer overflow (wraparound)
    // The source address 0xFFFFFFF0 + length 0x20 results in a wrap around the 32-bit boundary.
    {
        uint32_t rsv_base = 0x1000;
        size_t rsv_size = 0x100;
        
        uint32_t src = 0xFFFFFFF0; 
        uint32_t dst = 0x2000;
        size_t len = 0x20;
        uint8_t active = 0;
        
        int res = module(src, dst, len, rsv_base, rsv_size, &active);
        
        if (res == -1) {
            printf("[CASE-2] PASS: Integer overflow correctly detected (returned -1)\n");
        } else {
            printf("[CASE-2] FAIL: Integer overflow not detected, returned %d\n", res);
        }
    }

    return 0;
}