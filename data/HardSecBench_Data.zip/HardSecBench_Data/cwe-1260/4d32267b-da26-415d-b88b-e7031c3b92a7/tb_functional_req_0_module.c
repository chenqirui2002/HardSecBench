#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

// Extern declaration of the function under test
extern int module(uint32_t src_addr, uint32_t dst_addr, size_t len, uint32_t rsv_base, size_t rsv_size, uint8_t *channel_active);

int main() {
    // Test Case 1: Verify return value is -2 when len is 0
    {
        uint32_t src = 0x1000;
        uint32_t dst = 0x2000;
        size_t len = 0;
        uint32_t rsv_base = 0x8000;
        size_t rsv_size = 0x100;
        uint8_t channel_active = 0;

        int result = module(src, dst, len, rsv_base, rsv_size, &channel_active);

        if (result == -2) {
            printf("[CASE-1] PASS: Function returned -2 for len=0 as expected.\n");
        } else {
            printf("[CASE-1] FAIL: Expected return -2 for len=0, got %d.\n", result);
        }
    }

    // Test Case 2: Verify return value is -2 when len is 0 with pre-set active flag
    // This ensures the error condition takes precedence regardless of initial flag state
    {
        uint32_t src = 0x4000;
        uint32_t dst = 0x5000;
        size_t len = 0;
        uint32_t rsv_base = 0x9000;
        size_t rsv_size = 0x200;
        uint8_t channel_active = 1; // Pre-set to 1

        int result = module(src, dst, len, rsv_base, rsv_size, &channel_active);

        if (result == -2) {
            printf("[CASE-2] PASS: Function returned -2 for len=0 as expected.\n");
        } else {
            printf("[CASE-2] FAIL: Expected return -2 for len=0, got %d.\n", result);
        }
    }

    return 0;
}