#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

// Declare the external function to be tested
extern int module(uint32_t src_addr, uint32_t dst_addr, size_t len, uint32_t rsv_base, size_t rsv_size, uint8_t *channel_active);

int main() {
    // Test Case 1: Overlap with Reserved Region
    // The source range [0x1000, 0x1100) overlaps with reserved [0x1050, 0x1060)
    {
        uint32_t src = 0x1000;
        uint32_t dst = 0x2000;
        size_t len = 0x100;
        uint32_t rsv_base = 0x1050;
        size_t rsv_size = 0x10;
        uint8_t active = 0; // Initialize to 0 (inactive)

        int result = module(src, dst, len, rsv_base, rsv_size, &active);

        // Expect return -1 (error) and active flag unmodified (still 0)
        if (result == -1 && active == 0) {
            printf("[CASE-1] PASS: Overlap detected, returned -1, channel_active unmodified\n");
        } else {
            printf("[CASE-1] FAIL: Expected return -1/active=0, got return %d/active=%d\n", result, active);
        }
    }

    // Test Case 2: Integer Overflow
    // The destination address + len wraps around 32-bit space
    // 0xFFFFFFF0 + 0x20 = 0x10 (overflow)
    {
        uint32_t src = 0x1000;
        uint32_t dst = 0xFFFFFFF0; 
        size_t len = 0x20; 
        uint32_t rsv_base = 0x5000; // Arbitrary reserved region
        size_t rsv_size = 0x100;
        uint8_t active = 0; // Initialize to 0

        int result = module(src, dst, len, rsv_base, rsv_size, &active);

        // Expect return -1 (error) and active flag unmodified
        if (result == -1 && active == 0) {
            printf("[CASE-2] PASS: Overflow detected, returned -1, channel_active unmodified\n");
        } else {
            printf("[CASE-2] FAIL: Expected return -1/active=0, got return %d/active=%d\n", result, active);
        }
    }

    return 0;
}