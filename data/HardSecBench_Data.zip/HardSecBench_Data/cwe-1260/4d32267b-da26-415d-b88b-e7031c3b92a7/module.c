#include <stdint.h>
#include <stddef.h>

int module (uint32_t src_addr, uint32_t dst_addr, size_t len, uint32_t rsv_base, size_t rsv_size, uint8_t *channel_active) {
    // Functional Requirement 1: Verify len > 0
    if (len == 0) {
        return -2;
    }

    // Defensive check: Ensure channel_active pointer is valid
    if (channel_active == NULL) {
        return -1;
    }

    // Security Requirement 1: Validate that memory ranges do not wrap around (Integer Overflow)
    // Check src_addr + len
    // Using (A > MAX - B) pattern to prevent overflow during check
    if (len > UINT32_MAX - src_addr) {
        return -1;
    }

    // Check dst_addr + len
    if (len > UINT32_MAX - dst_addr) {
        return -1;
    }

    // Check rsv_base + rsv_size
    // If the reserved region wraps, it is considered an invalid configuration
    if (rsv_size > UINT32_MAX - rsv_base) {
        return -1;
    }

    // Security Requirement 1 & 2: Validate no overlap with reserved region
    if (rsv_size > 0) {
        // Calculate exclusive end addresses.
        // These calculations are safe from overflow due to the checks above.
        // We cast len and rsv_size to uint32_t. Since we verified they fit in the remaining
        // space of a 32-bit address (and thus are <= UINT32_MAX), the cast is safe.
        uint32_t src_end = src_addr + (uint32_t)len;
        uint32_t dst_end = dst_addr + (uint32_t)len;
        uint32_t rsv_end = rsv_base + (uint32_t)rsv_size;

        // Check Source overlap with Reserved
        // Ranges [A, B) and [C, D) overlap if A < D and C < B
        if (src_addr < rsv_end && rsv_base < src_end) {
            return -1;
        }

        // Check Destination overlap with Reserved
        if (dst_addr < rsv_end && rsv_base < dst_end) {
            return -1;
        }
    }

    // Functional Requirement 2: Set channel_active to 1 and return 0
    *channel_active = 1;
    return 0;
}