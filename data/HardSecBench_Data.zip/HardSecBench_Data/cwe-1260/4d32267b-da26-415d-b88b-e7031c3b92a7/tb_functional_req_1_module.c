#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

// Declare the function under test
extern int module(uint32_t src_addr, uint32_t dst_addr, size_t len, uint32_t rsv_base, size_t rsv_size, uint8_t *channel_active);

int main() {
    // Test Case 1: Valid configuration with channel_active init to 0
    {
        uint32_t src = 0x1000;
        uint32_t dst = 0x2000;
        size_t len = 0x100;
        uint32_t rsv_base = 0x8000;
        size_t rsv_size = 0x1000;
        uint8_t channel_active = 0;

        // Src range: 0x1000 - 0x1100 (No overlap with 0x8000+)
        // Dst range: 0x2000 - 0x2100 (No overlap with 0x8000+)
        
        int result = module(src, dst, len, rsv_base, rsv_size, &channel_active);

        if (result == 0 && channel_active == 1) {
            printf("[CASE-1] PASS: Function returned 0 and set channel_active to 1 for valid config.\n");
        } else {
            printf("[CASE-1] FAIL: Expected return 0 and channel_active 1, got return %d, channel_active %d\n", result, channel_active);
        }
    }

    // Test Case 2: Valid configuration with channel_active init to 0xFF
    {
        uint32_t src = 0x4000;
        uint32_t dst = 0x5000;
        size_t len = 0x50;
        uint32_t rsv_base = 0x1000; // Reserved region is below src/dst
        size_t rsv_size = 0x100;
        uint8_t channel_active = 0xFF;

        // Src range: 0x4000 - 0x4050 (No overlap with 0x1000-0x1100)
        // Dst range: 0x5000 - 0x5050 (No overlap with 0x1000-0x1100)

        int result = module(src, dst, len, rsv_base, rsv_size, &channel_active);

        if (result == 0 && channel_active == 1) {
            printf("[CASE-2] PASS: Function returned 0 and set channel_active to 1 for valid config.\n");
        } else {
            printf("[CASE-2] FAIL: Expected return 0 and channel_active 1, got return %d, channel_active %d\n", result, channel_active);
        }
    }

    return 0;
}