module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg [31:0] addr;
    reg [31:0] sram_base;
    reg [31:0] sram_bound;
    reg [31:0] ext_base;
    reg [31:0] ext_bound;

    // Outputs
    wire sram_sel;
    wire ext_sel;
    wire overlap_err;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .sram_base(sram_base),
        .sram_bound(sram_bound),
        .ext_base(ext_base),
        .ext_bound(ext_bound),
        .sram_sel(sram_sel),
        .ext_sel(ext_sel),
        .overlap_err(overlap_err)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        sram_base = 0;
        sram_bound = 0;
        ext_base = 0;
        ext_bound = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // ---------------------------------------------------------------------
        // Test Case 1: Address inside overlapping region
        // SRAM Range: 0x1000 - 0x3000
        // EXT Range:  0x2000 - 0x4000
        // Overlap:    0x2000 - 0x3000
        // Address:    0x2500 (Match both)
        // ---------------------------------------------------------------------
        @(negedge clk);
        sram_base  = 32'h0000_1000;
        sram_bound = 32'h0000_3000;
        ext_base   = 32'h0000_2000;
        ext_bound  = 32'h0000_4000;
        addr       = 32'h0000_2500;

        // Wait for registered output (1 clock cycle latency)
        @(posedge clk); 
        @(negedge clk);

        if (overlap_err === 1'b1) begin
            $display("[TEST] PASS: overlap_err asserted high when address (0x2500) is in both ranges.");
        end else begin
            $display("[TEST] FAIL: overlap_err expected 1, got %b when address (0x2500) is in both ranges.", overlap_err);
        end

        // ---------------------------------------------------------------------
        // Test Case 2: Boundary Overlap
        // SRAM Range: 0x1000 - 0x2000
        // EXT Range:  0x2000 - 0x3000
        // Address:    0x2000 (Inclusive bound of SRAM, Inclusive base of EXT)
        // ---------------------------------------------------------------------
        @(negedge clk);
        sram_base  = 32'h0000_1000;
        sram_bound = 32'h0000_2000;
        ext_base   = 32'h0000_2000;
        ext_bound  = 32'h0000_3000;
        addr       = 32'h0000_2000;

        @(posedge clk);
        @(negedge clk);

        if (overlap_err === 1'b1) begin
            $display("[TEST] PASS: overlap_err asserted high at boundary overlap (0x2000).");
        end else begin
            $display("[TEST] FAIL: overlap_err expected 1, got %b at boundary overlap (0x2000).", overlap_err);
        end

        // ---------------------------------------------------------------------
        // Test Case 3: No Overlap (Control Case)
        // Using previous ranges: SRAM [1000, 2000], EXT [2000, 3000]
        // Address: 0x1500 (Only SRAM)
        // ---------------------------------------------------------------------
        @(negedge clk);
        addr = 32'h0000_1500;

        @(posedge clk);
        @(negedge clk);

        if (overlap_err === 1'b0) begin
            $display("[TEST] PASS: overlap_err deasserted when address (0x1500) is only in SRAM range.");
        end else begin
            $display("[TEST] FAIL: overlap_err expected 0, got %b when address (0x1500) is only in SRAM range.", overlap_err);
        end

        $finish;
    end

endmodule