module testbench;
    // Signal declarations
    reg clk;
    reg rst_n;
    reg [31:0] addr;
    reg [31:0] sram_base;
    reg [31:0] sram_bound;
    reg [31:0] ext_base;
    reg [31:0] ext_bound;

    wire sram_sel;
    wire ext_sel;
    wire overlap_err;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .sram_base(sram_base),
        .sram_bound(sram_bound),
        .ext_base(ext_base),
        .ext_bound(ext_bound),
        .sram_sel(sram_sel),
        .ext_sel(ext_sel),
        .overlap_err(overlap_err)
    );

    // Clock generation: 10 time units period
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        addr = 0;
        
        // Define ranges ensuring NO OVERLAP to isolate FUNCTIONAL-REQ-3
        // SRAM: 0x1000_0000 to 0x1000_00FF
        sram_base = 32'h1000_0000;
        sram_bound = 32'h1000_00FF;
        
        // External: 0x2000_0000 to 0x2000_00FF
        ext_base = 32'h2000_0000;
        ext_bound = 32'h2000_00FF;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Address strictly inside SRAM range
        // -------------------------------------------------------
        addr = 32'h1000_0050; 
        @(posedge clk); // Wait for register update
        #1; // Allow for propagation delay
        
        if (sram_sel !== 1'b1) begin
            $display("[TEST] FAIL: sram_sel should be 1 for address inside SRAM range. Addr: %h, sram_sel: %b", addr, sram_sel);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Address at SRAM Base (Inclusive check)
        // -------------------------------------------------------
        addr = 32'h1000_0000;
        @(posedge clk);
        #1;
        
        if (sram_sel !== 1'b1) begin
            $display("[TEST] FAIL: sram_sel should be 1 at sram_base. Addr: %h, sram_sel: %b", addr, sram_sel);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Address at SRAM Bound (Inclusive check)
        // -------------------------------------------------------
        addr = 32'h1000_00FF;
        @(posedge clk);
        #1;
        
        if (sram_sel !== 1'b1) begin
            $display("[TEST] FAIL: sram_sel should be 1 at sram_bound. Addr: %h, sram_sel: %b", addr, sram_sel);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 4: Address outside SRAM range
        // -------------------------------------------------------
        addr = 32'h1000_0100;
        @(posedge clk);
        #1;
        
        if (sram_sel !== 1'b0) begin
            $display("[TEST] FAIL: sram_sel should be 0 outside SRAM range. Addr: %h, sram_sel: %b", addr, sram_sel);
            $finish;
        end

        // Success
        $display("[TEST] PASS: sram_sel assertion logic verified.");
        $finish;
    end

endmodule