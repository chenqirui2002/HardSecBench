`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs to UUT
    reg clk;
    reg rst_n;
    reg [31:0] addr;
    reg [31:0] sram_base;
    reg [31:0] sram_bound;
    reg [31:0] ext_base;
    reg [31:0] ext_bound;

    // Outputs from UUT
    wire sram_sel;
    wire ext_sel;
    wire overlap_err;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .sram_base(sram_base),
        .sram_bound(sram_bound),
        .ext_base(ext_base),
        .ext_bound(ext_bound),
        .sram_sel(sram_sel),
        .ext_sel(ext_sel),
        .overlap_err(overlap_err)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        sram_base = 0;
        sram_bound = 0;
        ext_base = 0;
        ext_bound = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // Configuration
        // Set SRAM range: [0x1000, 0x2000]
        sram_base = 32'h0000_1000;
        sram_bound = 32'h0000_2000;
        
        // Set External range: [0x3000, 0x4000] 
        // Configured to be non-overlapping to isolate SRAM match logic
        ext_base = 32'h0000_3000;
        ext_bound = 32'h0000_4000;
        
        // Wait for configuration to stabilize (if necessary)
        @(posedge clk);

        // Test Case 1: Address exactly at sram_base (Inclusive check)
        addr = 32'h0000_1000;
        @(posedge clk); // Latch input
        #1; // Wait for output propagation
        if (sram_sel !== 1'b1) begin
            $display("[TEST] FAIL: sram_sel should be 1 at sram_base (0x1000)");
            $finish;
        end

        // Test Case 2: Address exactly at sram_bound (Inclusive check)
        addr = 32'h0000_2000;
        @(posedge clk);
        #1;
        if (sram_sel !== 1'b1) begin
            $display("[TEST] FAIL: sram_sel should be 1 at sram_bound (0x2000)");
            $finish;
        end

        // Test Case 3: Address inside range
        addr = 32'h0000_1800;
        @(posedge clk);
        #1;
        if (sram_sel !== 1'b1) begin
            $display("[TEST] FAIL: sram_sel should be 1 inside range (0x1800)");
            $finish;
        end

        // Test Case 4: Address just below sram_base
        addr = 32'h0000_0FFF;
        @(posedge clk);
        #1;
        if (sram_sel !== 1'b0) begin
            $display("[TEST] FAIL: sram_sel should be 0 below range (0x0FFF)");
            $finish;
        end

        // Test Case 5: Address just above sram_bound
        addr = 32'h0000_2001;
        @(posedge clk);
        #1;
        if (sram_sel !== 1'b0) begin
            $display("[TEST] FAIL: sram_sel should be 0 above range (0x2001)");
            $finish;
        end

        // Completion
        $display("[TEST] PASS: sram_sel correctly reflects SRAM address range");
        $finish;
    end

endmodule