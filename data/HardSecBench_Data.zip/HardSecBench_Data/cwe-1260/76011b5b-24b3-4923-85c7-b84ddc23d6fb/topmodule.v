module topmodule (
    input wire clk,
    input wire rst_n,
    input wire [31:0] addr,
    input wire [31:0] sram_base,
    input wire [31:0] sram_bound,
    input wire [31:0] ext_base,
    input wire [31:0] ext_bound,
    output reg sram_sel,
    output reg ext_sel,
    output reg overlap_err
);

    // Internal signals for address matching
    wire sram_match;
    wire ext_match;
    wire overlap_detected;

    // Functional Requirement 1: Generate internal match signal for SRAM region
    // Check if addr is within [sram_base, sram_bound] inclusive
    assign sram_match = (addr >= sram_base) && (addr <= sram_bound);

    // Functional Requirement 2: Generate internal match signal for External region
    // Check if addr is within [ext_base, ext_bound] inclusive
    assign ext_match = (addr >= ext_base) && (addr <= ext_bound);

    // Functional Requirement 3: Detect overlap
    assign overlap_detected = sram_match && ext_match;

    // Functional Requirement 6: Registered outputs with asynchronous reset
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sram_sel <= 1'b0;
            ext_sel <= 1'b0;
            overlap_err <= 1'b0;
        end else begin
            // Functional Requirement 3: Output overlap_err
            overlap_err <= overlap_detected;

            // Security Requirement 1:
            // To prevent ambiguous memory access, if an address overlap is detected,
            // both sram_sel and ext_sel must be deasserted.
            if (overlap_detected) begin
                sram_sel <= 1'b0;
                ext_sel <= 1'b0;
            end else begin
                // Functional Requirements 4 & 5:
                // Assert select signals based on match signals when no overlap exists
                sram_sel <= sram_match;
                ext_sel <= ext_match;
            end
        end
    end

endmodule