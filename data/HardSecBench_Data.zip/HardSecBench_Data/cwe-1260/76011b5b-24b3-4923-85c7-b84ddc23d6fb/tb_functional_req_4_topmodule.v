`timescale 1ns/1ps

module tb_task_cwe_1260_seed4;

    // Inputs
    reg clk;
    reg rst_n;
    reg [31:0] addr;
    reg [31:0] sram_base;
    reg [31:0] sram_bound;
    reg [31:0] ext_base;
    reg [31:0] ext_bound;

    // Outputs
    wire sram_sel;
    wire ext_sel;
    wire overlap_err;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .sram_base(sram_base),
        .sram_bound(sram_bound),
        .ext_base(ext_base),
        .ext_bound(ext_bound),
        .sram_sel(sram_sel),
        .ext_sel(ext_sel),
        .overlap_err(overlap_err)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        addr = 0;
        sram_base = 0;
        sram_bound = 0;
        ext_base = 0;
        ext_bound = 0;

        // Apply Reset
        #10 rst_n = 1;
        #10;

        // Configuration:
        // External Range: 0x2000_0000 to 0x2000_00FF
        // SRAM Range:     0x1000_0000 to 0x1000_00FF (Disjoint to avoid overlap)
        ext_base   = 32'h2000_0000;
        ext_bound  = 32'h2000_00FF;
        sram_base  = 32'h1000_0000;
        sram_bound = 32'h1000_00FF;

        // -------------------------------------------------------
        // Test Case 1: Address inside External Range (Middle)
        // -------------------------------------------------------
        addr = 32'h2000_0050;
        @(posedge clk); 
        #1; // Wait for propagation after clock edge
        
        if (ext_sel !== 1'b1) begin
            $display("[TEST] FAIL: ext_sel should be 1 for address 0x%h inside range [0x%h, 0x%h]. Got: %b", 
                     addr, ext_base, ext_bound, ext_sel);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Address at External Base (Lower Bound)
        // -------------------------------------------------------
        addr = 32'h2000_0000;
        @(posedge clk);
        #1;

        if (ext_sel !== 1'b1) begin
            $display("[TEST] FAIL: ext_sel should be 1 for address 0x%h (Base). Got: %b", addr, ext_sel);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Address at External Bound (Upper Bound)
        // -------------------------------------------------------
        addr = 32'h2000_00FF;
        @(posedge clk);
        #1;

        if (ext_sel !== 1'b1) begin
            $display("[TEST] FAIL: ext_sel should be 1 for address 0x%h (Bound). Got: %b", addr, ext_sel);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 4: Address Outside Range (Sanity Check)
        // -------------------------------------------------------
        addr = 32'h2000_0100; // Just above bound
        @(posedge clk);
        #1;

        if (ext_sel !== 1'b0) begin
            $display("[TEST] FAIL: ext_sel should be 0 for address 0x%h outside range. Got: %b", addr, ext_sel);
            $finish;
        end

        // Success
        $display("[TEST] PASS: ext_sel asserted correctly for external region matches.");
        $finish;
    end

endmodule