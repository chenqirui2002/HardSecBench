module tb_functional_req_5;

    // Inputs
    reg clk;
    reg rst_n;
    reg [31:0] addr;
    reg [31:0] sram_base;
    reg [31:0] sram_bound;
    reg [31:0] ext_base;
    reg [31:0] ext_bound;

    // Outputs
    wire sram_sel;
    wire ext_sel;
    wire overlap_err;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .sram_base(sram_base),
        .sram_bound(sram_bound),
        .ext_base(ext_base),
        .ext_bound(ext_bound),
        .sram_sel(sram_sel),
        .ext_sel(ext_sel),
        .overlap_err(overlap_err)
    );

    // Clock generation: 10ns period
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        // Initialize ranges to values that do not match addr=0 to ensure clean start
        sram_base = 32'h1000_0000;
        sram_bound = 32'h1000_0100;
        ext_base = 32'h2000_0000;
        ext_bound = 32'h2000_0100;

        // Wait for global reset
        #20;

        // -------------------------------------------------------
        // Check 1: Initial Reset State
        // -------------------------------------------------------
        if (sram_sel !== 0 || ext_sel !== 0 || overlap_err !== 0) begin
            $display("[TEST] FAIL: Outputs not 0 during initial reset");
            $finish;
        end

        // Release Reset at negedge to safely setup next test
        @(negedge clk);
        rst_n = 1;

        // -------------------------------------------------------
        // Check 2: Registered Output Behavior (Synchronous Update)
        // -------------------------------------------------------
        // Configure inputs to generate a match on SRAM
        sram_base = 32'h3000_0000;
        sram_bound = 32'h3000_00FF;
        addr = 32'h3000_0050; // Valid match inside SRAM range

        // Wait a small delay (still clk=0) to verify outputs don't change immediately
        #2;
        if (sram_sel !== 0) begin
            $display("[TEST] FAIL: sram_sel updated before clock edge (combinational behavior detected)");
            $finish;
        end

        // Trigger rising edge
        @(posedge clk);
        #1; // Allow for propagation delay

        // Verify output updated after clock edge
        if (sram_sel !== 1) begin
            $display("[TEST] FAIL: sram_sel did not assert after rising clock edge");
            $finish;
        end

        // -------------------------------------------------------
        // Check 3: Asynchronous Reset Behavior
        // -------------------------------------------------------
        // Assert reset (active low) while sram_sel is high
        #2;
        rst_n = 0;
        #1; // Small delay to check immediate effect

        // Verify outputs cleared immediately
        if (sram_sel !== 0) begin
            $display("[TEST] FAIL: sram_sel did not reset asynchronously immediately after rst_n low");
            $finish;
        end

        // Verify outputs stay 0 even if clock continues running while reset is held
        @(posedge clk);
        #1;
        if (sram_sel !== 0) begin
            $display("[TEST] FAIL: sram_sel asserted while rst_n was low");
            $finish;
        end

        $display("[TEST] PASS: Outputs are registered and reset asynchronously");
        $finish;
    end

endmodule