module tb_functional_req_1;
    // Inputs
    reg clk;
    reg rst_n;
    reg [31:0] addr;
    reg [31:0] sram_base;
    reg [31:0] sram_bound;
    reg [31:0] ext_base;
    reg [31:0] ext_bound;

    // Outputs
    wire sram_sel;
    wire ext_sel;
    wire overlap_err;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .sram_base(sram_base),
        .sram_bound(sram_bound),
        .ext_base(ext_base),
        .ext_bound(ext_bound),
        .sram_sel(sram_sel),
        .ext_sel(ext_sel),
        .overlap_err(overlap_err)
    );

    // Clock generation
    always #5 clk = ~clk;

    integer errors = 0;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        addr = 0;
        sram_base = 0;
        sram_bound = 0;
        ext_base = 0;
        ext_bound = 0;

        // Reset the system
        #10 rst_n = 1;
        #10;

        // Configuration:
        // Set SRAM range to 0x1000_0000 - 0x1000_00FF
        // Set EXT range to  0x2000_0000 - 0x2000_00FF
        // These ranges do NOT overlap, ensuring we test the match logic
        // without triggering overlap error suppression.
        sram_base  = 32'h1000_0000;
        sram_bound = 32'h1000_00FF;
        ext_base   = 32'h2000_0000;
        ext_bound  = 32'h2000_00FF;

        // Wait for inputs to settle/register if needed (though config inputs are usually static or registered)
        @(posedge clk);

        // -------------------------------------------------------
        // Test Case 1: Address inside External Range
        // -------------------------------------------------------
        addr = 32'h2000_0050; // Middle of range
        @(posedge clk);       // Wait for register update
        #1;                   // Hold time
        if (ext_sel !== 1'b1) begin
            $display("[TEST] FAIL: ext_sel should be 1 for addr inside range (0x%h)", addr);
            errors = errors + 1;
        end else begin
            $display("[TEST] PASS: ext_sel is 1 for addr inside range");
        end

        // -------------------------------------------------------
        // Test Case 2: Address at Lower Bound
        // -------------------------------------------------------
        addr = 32'h2000_0000; // ext_base
        @(posedge clk);
        #1;
        if (ext_sel !== 1'b1) begin
            $display("[TEST] FAIL: ext_sel should be 1 at lower bound (0x%h)", addr);
            errors = errors + 1;
        end else begin
            $display("[TEST] PASS: ext_sel is 1 at lower bound");
        end

        // -------------------------------------------------------
        // Test Case 3: Address at Upper Bound
        // -------------------------------------------------------
        addr = 32'h2000_00FF; // ext_bound
        @(posedge clk);
        #1;
        if (ext_sel !== 1'b1) begin
            $display("[TEST] FAIL: ext_sel should be 1 at upper bound (0x%h)", addr);
            errors = errors + 1;
        end else begin
            $display("[TEST] PASS: ext_sel is 1 at upper bound");
        end

        // -------------------------------------------------------
        // Test Case 4: Address Below Range
        // -------------------------------------------------------
        addr = 32'h1FFF_FFFF; // Just below ext_base
        @(posedge clk);
        #1;
        if (ext_sel !== 1'b0) begin
            $display("[TEST] FAIL: ext_sel should be 0 below range (0x%h)", addr);
            errors = errors + 1;
        end else begin
            $display("[TEST] PASS: ext_sel is 0 below range");
        end

        // -------------------------------------------------------
        // Test Case 5: Address Above Range
        // -------------------------------------------------------
        addr = 32'h2000_0100; // Just above ext_bound
        @(posedge clk);
        #1;
        if (ext_sel !== 1'b0) begin
            $display("[TEST] FAIL: ext_sel should be 0 above range (0x%h)", addr);
            errors = errors + 1;
        end else begin
            $display("[TEST] PASS: ext_sel is 0 above range");
        end

        // Final Report
        if (errors == 0)
            $display("[TEST] ALL PASS");
        else
            $display("[TEST] FAIL: %0d errors found", errors);

        $finish;
    end

endmodule