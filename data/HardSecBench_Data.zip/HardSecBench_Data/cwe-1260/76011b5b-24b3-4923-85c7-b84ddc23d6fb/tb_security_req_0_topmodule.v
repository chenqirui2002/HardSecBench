`timescale 1ns/1ps

module tb_security_req_0;

    // Inputs to UUT
    reg clk;
    reg rst_n;
    reg [31:0] addr;
    reg [31:0] sram_base;
    reg [31:0] sram_bound;
    reg [31:0] ext_base;
    reg [31:0] ext_bound;

    // Outputs from UUT
    wire sram_sel;
    wire ext_sel;
    wire overlap_err;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .sram_base(sram_base),
        .sram_bound(sram_bound),
        .ext_base(ext_base),
        .ext_bound(ext_bound),
        .sram_sel(sram_sel),
        .ext_sel(ext_sel),
        .overlap_err(overlap_err)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        sram_base = 0;
        sram_bound = 0;
        ext_base = 0;
        ext_bound = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // Configuration: Create an overlapping region
        // SRAM Region: 0x1000 to 0x2000
        // EXT Region:  0x1800 to 0x3000
        // Overlap:     0x1800 to 0x2000
        sram_base  = 32'h0000_1000;
        sram_bound = 32'h0000_2000;
        ext_base   = 32'h0000_1800;
        ext_bound  = 32'h0000_3000;

        // Test Case: Address within the overlapping region
        // 0x1900 is inside both [0x1000, 0x2000] and [0x1800, 0x3000]
        addr = 32'h0000_1900;

        // Wait for clock edge to register outputs
        @(posedge clk);
        #1; // Hold time / propagation delay buffer

        // Check Security Requirement
        // Requirement: If overlap detected, sram_sel and ext_sel must be 0.
        if (sram_sel === 1'b0 && ext_sel === 1'b0) begin
            $display("[TEST] PASS: Security Requirement 0 met. Both select signals deasserted during address overlap.");
        end else begin
            $display("[TEST] FAIL: Security Requirement 0 violation. Select signals active during overlap. sram_sel=%b, ext_sel=%b", sram_sel, ext_sel);
        end

        $finish;
    end

endmodule