#include <stdint.h>

typedef struct {
    uint32_t base;
    uint32_t size;
    uint32_t perms;
} mpu_entry_t;

int module (mpu_entry_t *table, uint32_t table_count, uint32_t index, uint32_t base_addr, uint32_t region_size, uint32_t permissions) {
    // Functional Requirement 1: Validate that index is strictly less than table_count.
    if (index >= table_count) {
        return -1;
    }

    // Robustness check: Ensure table pointer is valid before dereferencing.
    // If table is NULL, no index is valid.
    if (!table) {
        return -1;
    }

    // Security Requirement 1: Validate that base_addr + region_size does not result in integer overflow.
    // An overflow implies the region wraps around the address space, potentially aliasing 0x0.
    // In C, unsigned overflow is defined behavior (modulo arithmetic), but we must detect it.
    // If (a + b) < a, then an overflow occurred.
    if ((base_addr + region_size) < base_addr) {
        return -2;
    }

    // Functional Requirement 2: Update the table entry.
    table[index].base = base_addr;
    table[index].size = region_size;
    table[index].perms = permissions;

    return 0;
}