#include <stdio.h>
#include <stdint.h>
#include <limits.h>

typedef struct {
    uint32_t base;
    uint32_t size;
    uint32_t perms;
} mpu_entry_t;

extern int module(mpu_entry_t *table, uint32_t table_count, uint32_t index, uint32_t base_addr, uint32_t region_size, uint32_t permissions);

int main() {
    // Test Case 1: Standard overflow (wraparound)
    // base + size results in a small positive number due to overflow
    {
        mpu_entry_t table[1] = {
            {0x1000, 0x100, 0x3} // Initial valid state
        };

        // 0xFFFFFFF0 + 0x20 = 0x10 (overflow)
        uint32_t base = 0xFFFFFFF0;
        uint32_t size = 0x20;
        uint32_t perms = 0x1; // New permissions
        uint32_t index = 0;

        int result = module(table, 1, index, base, size, perms);

        if (result == -2) {
            // Verify table was NOT modified
            if (table[0].base == 0x1000 && table[0].size == 0x100 && table[0].perms == 0x3) {
                printf("[CASE-1] PASS: Overflow detected (returned -2) and table preserved.\n");
            } else {
                printf("[CASE-1] FAIL: Returned -2 but table entry was modified.\n");
            }
        } else {
            printf("[CASE-1] FAIL: Expected return -2 for overflow, got %d.\n", result);
        }
    }

    // Test Case 2: Boundary overflow (UINT32_MAX + 1)
    {
        mpu_entry_t table[1] = {
            {0x80000000, 0x1000, 0x0} // Initial valid state
        };

        uint32_t base = UINT32_MAX;
        uint32_t size = 1; // UINT32_MAX + 1 = 0 (overflow)
        uint32_t perms = 0x5;

        int result = module(table, 1, 0, base, size, perms);

        if (result == -2) {
            // Verify table was NOT modified
            if (table[0].base == 0x80000000 && table[0].size == 0x1000 && table[0].perms == 0x0) {
                printf("[CASE-2] PASS: Boundary overflow detected (returned -2) and table preserved.\n");
            } else {
                printf("[CASE-2] FAIL: Returned -2 but table entry was modified.\n");
            }
        } else {
            printf("[CASE-2] FAIL: Expected return -2 for boundary overflow, got %d.\n", result);
        }
    }

    return 0;
}