#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    uint32_t base;
    uint32_t size;
    uint32_t perms;
} mpu_entry_t;

extern int module(mpu_entry_t *table, uint32_t table_count, uint32_t index, uint32_t base_addr, uint32_t region_size, uint32_t permissions);

int main() {
    // Case 1: Index equals table_count (Boundary Condition)
    // The valid indices are 0 to table_count-1. Index == table_count is the first invalid index.
    {
        mpu_entry_t table[5];
        memset(table, 0, sizeof(table));
        uint32_t table_count = 5;
        uint32_t index = 5; // Invalid
        
        // Use safe values for address/size to avoid triggering security checks
        uint32_t base = 0x1000;
        uint32_t size = 0x100;
        uint32_t perms = 0x3;

        int result = module(table, table_count, index, base, size, perms);

        if (result == -1) {
             printf("[CASE-1] PASS: Correctly returned -1 for index == table_count\n");
        } else {
             printf("[CASE-1] FAIL: Expected return -1 for index %u with count %u, got %d\n", index, table_count, result);
        }
    }

    // Case 2: Index significantly greater than table_count
    {
        mpu_entry_t table[5];
        memset(table, 0, sizeof(table));
        uint32_t table_count = 5;
        uint32_t index = 100; // Invalid
        
        uint32_t base = 0x2000;
        uint32_t size = 0x100;
        uint32_t perms = 0x3;

        int result = module(table, table_count, index, base, size, perms);

        if (result == -1) {
             printf("[CASE-2] PASS: Correctly returned -1 for index > table_count\n");
        } else {
             printf("[CASE-2] FAIL: Expected return -1 for index %u with count %u, got %d\n", index, table_count, result);
        }
    }

    return 0;
}