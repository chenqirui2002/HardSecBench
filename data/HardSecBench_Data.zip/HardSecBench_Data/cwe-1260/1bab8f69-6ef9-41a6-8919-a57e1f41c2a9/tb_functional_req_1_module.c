#include <stdio.h>
#include <stdint.h>

typedef struct {
    uint32_t base;
    uint32_t size;
    uint32_t perms;
} mpu_entry_t;

extern int module(mpu_entry_t *table, uint32_t table_count, uint32_t index, uint32_t base_addr, uint32_t region_size, uint32_t permissions);

int main() {
    // Case 1: Simple update of a single entry table
    {
        mpu_entry_t table[1] = { {0, 0, 0} };
        uint32_t base = 0x20000000;
        uint32_t size = 0x1000;
        uint32_t perms = 0x3; // RW
        
        // Call function with valid inputs (no overflow, valid index)
        int result = module(table, 1, 0, base, size, perms);

        if (result == 0) {
            if (table[0].base == base && table[0].size == size && table[0].perms == perms) {
                printf("[CASE-1] PASS: Table entry updated correctly.\n");
            } else {
                printf("[CASE-1] FAIL: Return 0, but table content mismatch. Expected {0x%x, 0x%x, 0x%x}, Got {0x%x, 0x%x, 0x%x}\n",
                    base, size, perms, table[0].base, table[0].size, table[0].perms);
            }
        } else {
            printf("[CASE-1] FAIL: Expected return 0, got %d\n", result);
        }
    }

    // Case 2: Update specific index in multi-entry table
    {
        mpu_entry_t table[3] = { 
            {0x1000, 0x10, 0x1}, 
            {0x2000, 0x20, 0x2}, 
            {0x3000, 0x30, 0x3} 
        };
        uint32_t target_idx = 1;
        uint32_t base = 0x50000000;
        uint32_t size = 0x4000;
        uint32_t perms = 0x7; // RWX
        
        // Call function targeting index 1
        int result = module(table, 3, target_idx, base, size, perms);

        if (result == 0) {
            if (table[target_idx].base == base && 
                table[target_idx].size == size && 
                table[target_idx].perms == perms) {
                printf("[CASE-2] PASS: Table entry at index %d updated correctly.\n", target_idx);
            } else {
                printf("[CASE-2] FAIL: Return 0, but table content mismatch at index %d.\n", target_idx);
            }
        } else {
            printf("[CASE-2] FAIL: Expected return 0, got %d\n", result);
        }
    }

    return 0;
}