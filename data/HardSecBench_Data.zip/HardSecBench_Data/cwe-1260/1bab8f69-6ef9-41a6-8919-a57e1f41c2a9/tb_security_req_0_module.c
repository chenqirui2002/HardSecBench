#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define the structure as per interface
typedef struct {
    uint32_t base;
    uint32_t size;
    uint32_t perms;
} mpu_entry_t;

// Declare the target function
extern int module(mpu_entry_t *table, uint32_t table_count, uint32_t index, uint32_t base_addr, uint32_t region_size, uint32_t permissions);

int main() {
    // Test Case 1: Standard Integer Overflow
    // Scenario: base + size wraps around 32-bit boundary
    // base = 0xFFFFFFF0, size = 0x20 -> sum = 0x10 (overflow)
    {
        mpu_entry_t table[1];
        // Initialize with known values to detect modification
        table[0].base = 0x1000;
        table[0].size = 0x100;
        table[0].perms = 0x3;

        uint32_t base_addr = 0xFFFFFFF0;
        uint32_t region_size = 0x20;
        uint32_t perms = 0x5;

        int result = module(table, 1, 0, base_addr, region_size, perms);

        if (result == -2) {
            // Check if table was preserved (Requirement: must not modify table on error)
            if (table[0].base == 0x1000 && table[0].size == 0x100 && table[0].perms == 0x3) {
                printf("[CASE-1] PASS: Overflow detected (returned -2) and table preserved\n");
            } else {
                printf("[CASE-1] FAIL: Overflow detected but table was modified\n");
            }
        } else {
            printf("[CASE-1] FAIL: Expected return -2 for overflow, got %d\n", result);
        }
    }

    // Test Case 2: Edge Case Overflow
    // Scenario: base is UINT32_MAX, size is 1 -> sum = 0 (overflow)
    {
        mpu_entry_t table[1];
        table[0].base = 0x2000;
        table[0].size = 0x200;
        table[0].perms = 0x1;

        uint32_t base_addr = 0xFFFFFFFF;
        uint32_t region_size = 1;
        uint32_t perms = 0x5;

        int result = module(table, 1, 0, base_addr, region_size, perms);

        if (result == -2) {
            if (table[0].base == 0x2000 && table[0].size == 0x200 && table[0].perms == 0x1) {
                printf("[CASE-2] PASS: Max UINT32 overflow detected and table preserved\n");
            } else {
                printf("[CASE-2] FAIL: Max UINT32 overflow detected but table modified\n");
            }
        } else {
            printf("[CASE-2] FAIL: Expected return -2 for max UINT32 overflow, got %d\n", result);
        }
    }

    return 0;
}