module testbench;
    // Signal declarations
    reg clk;
    reg rst_n;
    reg [15:0] addr;
    reg [15:0] region_base;
    reg [15:0] region_limit;
    reg [1:0] req_cmd;
    reg [1:0] bg_perm;
    reg [1:0] region_perm;
    wire access_granted;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .region_base(region_base),
        .region_limit(region_limit),
        .req_cmd(req_cmd),
        .bg_perm(bg_perm),
        .region_perm(region_perm),
        .access_granted(access_granted)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test variables
    integer i_cmd;
    integer i_perm;
    reg expected_grant;

    initial begin
        // 1. Initialize Inputs
        rst_n = 0;
        addr = 0;
        region_base = 16'h1000;
        region_limit = 16'h2000;
        req_cmd = 0;
        bg_perm = 2'b00; // Should not affect outcome inside region, but set to known value
        region_perm = 0;

        // 2. Apply Reset
        @(negedge clk);
        rst_n = 0;
        @(negedge clk);
        rst_n = 1; // Release reset

        // 3. Test Loop: Inside Region Logic
        // We test addresses strictly inside [region_base, region_limit]
        // Addresses tested: region_base, region_limit, and a middle value.
        
        for (i_cmd = 0; i_cmd < 4; i_cmd = i_cmd + 1) begin
            for (i_perm = 0; i_perm < 4; i_perm = i_perm + 1) begin
                
                // Set up permissions and command
                req_cmd = i_cmd[1:0];
                region_perm = i_perm[1:0];
                
                // Set bg_perm to inverse of region_perm to ensure we aren't accidentally passing due to bg logic
                // (Though strictly, functional req says bg shouldn't matter here, we focus on region_perm logic)
                bg_perm = ~region_perm; 

                // Calculate expected result based on requirement:
                // access_granted = 1 if (req_cmd & region_perm) == req_cmd
                expected_grant = ((req_cmd & region_perm) == req_cmd) ? 1'b1 : 1'b0;

                // --- Sub-test A: Address at region_base ---
                addr = region_base;
                @(negedge clk); // Setup inputs
                @(posedge clk); // Clock edge
                #1; // Propagation delay
                
                if (access_granted !== expected_grant) begin
                    $display("[TEST] FAIL: Addr=Base (0x%h) | Cmd=%b Perm=%b | Exp=%b Got=%b", 
                             addr, req_cmd, region_perm, expected_grant, access_granted);
                    $finish;
                end

                // --- Sub-test B: Address at region_limit ---
                addr = region_limit;
                @(negedge clk);
                @(posedge clk);
                #1;

                if (access_granted !== expected_grant) begin
                    $display("[TEST] FAIL: Addr=Limit (0x%h) | Cmd=%b Perm=%b | Exp=%b Got=%b", 
                             addr, req_cmd, region_perm, expected_grant, access_granted);
                    $finish;
                end

                // --- Sub-test C: Address in Middle ---
                addr = (region_base + region_limit) / 2;
                @(negedge clk);
                @(posedge clk);
                #1;

                if (access_granted !== expected_grant) begin
                    $display("[TEST] FAIL: Addr=Mid (0x%h) | Cmd=%b Perm=%b | Exp=%b Got=%b", 
                             addr, req_cmd, region_perm, expected_grant, access_granted);
                    $finish;
                end
            end
        end

        // If we reached here, all checks passed
        $display("[TEST] PASS: Region permission logic verified correctly.");
        $finish;
    end

endmodule