module tb_functional_req_0;
    // Signal declarations
    reg clk;
    reg rst_n;
    reg [15:0] addr;
    reg [15:0] region_base;
    reg [15:0] region_limit;
    reg [1:0] req_cmd;
    reg [1:0] bg_perm;
    reg [1:0] region_perm;
    wire access_granted;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .region_base(region_base),
        .region_limit(region_limit),
        .req_cmd(req_cmd),
        .bg_perm(bg_perm),
        .region_perm(region_perm),
        .access_granted(access_granted)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test sequence
    initial begin
        // Initialize inputs
        rst_n = 1;
        addr = 0;
        region_base = 0;
        region_limit = 0;
        req_cmd = 0;
        bg_perm = 0;
        region_perm = 0;

        // Wait for global reset/stabilization
        #10;

        // -------------------------------------------------------
        // Test Case 1: Reset asserted during valid Background Access
        // -------------------------------------------------------
        // Setup inputs that would normally grant access (Background Read)
        rst_n = 0;              // Assert Reset
        addr = 16'h1000;        // Address outside region
        region_base = 16'h2000;
        region_limit = 16'h3000;
        req_cmd = 2'b01;        // Read Request
        bg_perm = 2'b01;        // Background Read Allowed
        region_perm = 2'b00;    // Irrelevant for this address

        // Wait for clock edge to sample reset
        @(posedge clk);
        #1; // Small delay to check output after clock edge

        if (access_granted !== 1'b0) begin
            $display("[TEST] FAIL: access_granted is %b, expected 0 when rst_n is 0 (Background scenario)", access_granted);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Reset asserted during valid Region Access
        // -------------------------------------------------------
        // Setup inputs that would normally grant access (Region Write)
        rst_n = 0;              // Assert Reset
        addr = 16'h2500;        // Address inside region [0x2000, 0x3000]
        region_base = 16'h2000;
        region_limit = 16'h3000;
        req_cmd = 2'b10;        // Write Request
        bg_perm = 2'b00;        // Irrelevant for this address
        region_perm = 2'b10;    // Region Write Allowed

        // Wait for clock edge
        @(posedge clk);
        #1;

        if (access_granted !== 1'b0) begin
            $display("[TEST] FAIL: access_granted is %b, expected 0 when rst_n is 0 (Region scenario)", access_granted);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Reset asserted with Full Permissions
        // -------------------------------------------------------
        rst_n = 0;
        addr = 16'h2500;
        region_base = 16'h2000;
        region_limit = 16'h3000;
        req_cmd = 2'b11;        // Read/Write Request
        bg_perm = 2'b11;        // Allow All
        region_perm = 2'b11;    // Allow All

        @(posedge clk);
        #1;

        if (access_granted !== 1'b0) begin
            $display("[TEST] FAIL: access_granted is %b, expected 0 when rst_n is 0 (Full Perm scenario)", access_granted);
            $finish;
        end

        // If all checks pass
        $display("[TEST] PASS: Reset strictly overrides logic driving access_granted to 0");
        $finish;
    end

endmodule