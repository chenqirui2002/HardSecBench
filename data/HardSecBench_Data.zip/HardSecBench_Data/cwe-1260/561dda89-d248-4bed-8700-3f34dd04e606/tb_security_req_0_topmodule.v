`timescale 1ns / 1ps

module tb_security_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg [15:0] addr;
    reg [15:0] region_base;
    reg [15:0] region_limit;
    reg [1:0] req_cmd;
    reg [1:0] bg_perm;
    reg [1:0] region_perm;

    // Outputs
    wire access_granted;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .addr(addr), 
        .region_base(region_base), 
        .region_limit(region_limit), 
        .req_cmd(req_cmd), 
        .bg_perm(bg_perm), 
        .region_perm(region_perm), 
        .access_granted(access_granted)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;
    integer cmd_i, rperm_i, bperm_i;
    reg expected_access;
    reg test_failed;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        region_base = 16'h1000;
        region_limit = 16'h2000;
        req_cmd = 0;
        bg_perm = 0;
        region_perm = 0;
        test_failed = 0;

        // Reset sequence
        #20;
        rst_n = 1;
        #10;

        $display("[TEST] Starting Security Requirement 0 Verification...");

        // Test Strategy:
        // Iterate addresses strictly INSIDE the region [0x1000, 0x2000].
        // For each address, iterate all combinations of req_cmd, region_perm, and bg_perm.
        // Ensure proper clock synchronization: Set Inputs -> Posedge (Sample) -> Negedge (Check).

        for (i = 0; i < 3; i = i + 1) begin
            // Set Address
            case (i)
                0: addr = 16'h1000; // Boundary: Base
                1: addr = 16'h1500; // Internal
                2: addr = 16'h2000; // Boundary: Limit
            endcase

            // Iterate req_cmd (1=Read, 2=Write, 3=RW)
            for (cmd_i = 1; cmd_i <= 3; cmd_i = cmd_i + 1) begin
                req_cmd = cmd_i[1:0];

                // Iterate Region Permissions
                for (rperm_i = 0; rperm_i <= 3; rperm_i = rperm_i + 1) begin
                    region_perm = rperm_i[1:0];

                    // Iterate Background Permissions
                    // The core check: bg_perm must NOT affect output inside the region
                    for (bperm_i = 0; bperm_i <= 3; bperm_i = bperm_i + 1) begin
                        bg_perm = bperm_i[1:0];

                        // Synchronization:
                        // 1. Inputs are stable now.
                        // 2. Wait for rising edge for DUT to sample inputs.
                        @(posedge clk);
                        // 3. Wait for falling edge to check outputs (ensures stability).
                        @(negedge clk);

                        // Calculate Expected Result
                        // Inside region: Only region_perm matters.
                        expected_access = ((req_cmd & region_perm) == req_cmd);

                        // Verify
                        if (access_granted !== expected_access) begin
                            test_failed = 1;
                            $display("[TEST] FAIL: Mismatch at Addr: 0x%h (Inside Region [0x%h:0x%h])", 
                                     addr, region_base, region_limit);
                            $display("       Inputs -> Cmd: %b, RegionPerm: %b, BgPerm: %b", 
                                     req_cmd, region_perm, bg_perm);
                            $display("       Expected: %b (based on RegionPerm), Got: %b", 
                                     expected_access, access_granted);
                            
                            if (expected_access == 0 && access_granted == 1) begin
                                $display("       CRITICAL: Privilege Escalation! Region denied access but it was granted.");
                                if ((req_cmd & bg_perm) == req_cmd)
                                    $display("                 (Likely cause: Background permissions overrode Region permissions)");
                            end
                        end
                    end
                end
            end
        end

        if (test_failed) begin
            $display("[TEST] FAIL: Security requirement 0 not met. Background permissions affect region access or logic is incorrect.");
        end else begin
            $display("[TEST] PASS: Security requirement 0 met. Region permissions strictly enforced inside region boundaries.");
        end

        $finish;
    end

endmodule