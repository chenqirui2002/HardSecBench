module topmodule (
    input wire clk,
    input wire rst_n,
    input wire [15:0] addr,
    input wire [15:0] region_base,
    input wire [15:0] region_limit,
    input wire [1:0] req_cmd,
    input wire [1:0] bg_perm,
    input wire [1:0] region_perm,
    output reg access_granted
);

    always @(posedge clk) begin
        if (!rst_n) begin
            // Reset condition: strictly override any logic
            access_granted <= 1'b0;
        end else begin
            // Check if the address falls within the specific programmable region
            // inclusive range [region_base, region_limit]
            if (addr >= region_base && addr <= region_limit) begin
                // Inside the specific region:
                // Security Requirement: Access is determined SOLELY by region_perm.
                // bg_perm must have no effect here to prevent privilege escalation via overlap.
                // Logic: All active bits in req_cmd must be set in region_perm.
                if ((req_cmd & region_perm) == req_cmd) begin
                    access_granted <= 1'b1;
                end else begin
                    access_granted <= 1'b0;
                end
            end else begin
                // Outside the specific region (Background):
                // Logic: All active bits in req_cmd must be set in bg_perm.
                if ((req_cmd & bg_perm) == req_cmd) begin
                    access_granted <= 1'b1;
                end else begin
                    access_granted <= 1'b0;
                end
            end
        end
    end

endmodule