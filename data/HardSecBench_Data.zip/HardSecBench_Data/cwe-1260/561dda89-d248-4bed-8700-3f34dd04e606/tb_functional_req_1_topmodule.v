module tb_functional_req_1;
    reg clk;
    reg rst_n;
    reg [15:0] addr;
    reg [15:0] region_base;
    reg [15:0] region_limit;
    reg [1:0] req_cmd;
    reg [1:0] bg_perm;
    reg [1:0] region_perm;
    wire access_granted;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .region_base(region_base),
        .region_limit(region_limit),
        .req_cmd(req_cmd),
        .bg_perm(bg_perm),
        .region_perm(region_perm),
        .access_granted(access_granted)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i, j;
    reg expected_access;

    initial begin
        // Initialize inputs
        rst_n = 0;
        addr = 0;
        region_base = 16'h1000;
        region_limit = 16'h2000;
        req_cmd = 0;
        bg_perm = 0;
        region_perm = 0;

        // Apply Reset
        #10 rst_n = 1;
        #10;

        // Test Case 1: Address strictly below region base (addr < 0x1000)
        check_background_access(16'h0FFF);
        check_background_access(16'h0000);

        // Test Case 2: Address strictly above region limit (addr > 0x2000)
        check_background_access(16'h2001);
        check_background_access(16'hFFFF);

        $display("[TEST] PASS: All background access checks passed.");
        $finish;
    end

    // Task to verify access logic for a specific address
    task check_background_access;
        input [15:0] test_addr;
        begin
            addr = test_addr;
            
            // Iterate through all command (0-3) and background permission (0-3) combinations
            for (i = 0; i < 4; i = i + 1) begin
                for (j = 0; j < 4; j = j + 1) begin
                    req_cmd = i[1:0];
                    bg_perm = j[1:0];
                    
                    // Set region_perm to a value that would cause failure if incorrectly used
                    // e.g., if we expect PASS (bg_perm allows), set region_perm to DENY (0)
                    // This implicitly checks that region_perm is ignored, though strictly we are testing bg_perm logic.
                    region_perm = ~bg_perm; 

                    // Calculate expected result based on Requirement 1
                    // Logic: (req_cmd & bg_perm) == req_cmd
                    if ((req_cmd & bg_perm) == req_cmd) begin
                        expected_access = 1'b1;
                    end else begin
                        expected_access = 1'b0;
                    end

                    // Synchronize with clock
                    @(negedge clk); // Setup inputs
                    // Wait for processing
                    @(posedge clk); 
                    #1; // Allow output propagation

                    // Check result
                    if (access_granted !== expected_access) begin
                        $display("[TEST] FAIL: Addr=0x%h (Outside [0x%h:0x%h]), Cmd=%b, BgPerm=%b, Expected=%b, Got=%b",
                            addr, region_base, region_limit, req_cmd, bg_perm, expected_access, access_granted);
                        $finish;
                    end
                end
            end
        end
    endtask

endmodule