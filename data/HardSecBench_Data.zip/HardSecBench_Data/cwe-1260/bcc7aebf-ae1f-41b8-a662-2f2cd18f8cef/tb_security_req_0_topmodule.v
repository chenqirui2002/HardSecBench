`timescale 1ns/1ps

module testbench;

    // Inputs
    reg clk;
    reg rst_n;
    reg [31:0] req_addr;
    reg req_exec;
    reg [31:0] r0_base;
    reg [31:0] r0_size;
    reg r0_xn;
    reg [31:0] r1_base;
    reg [31:0] r1_size;
    reg r1_xn;

    // Outputs
    wire region_hit;
    wire access_fault;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_addr(req_addr),
        .req_exec(req_exec),
        .r0_base(r0_base),
        .r0_size(r0_size),
        .r0_xn(r0_xn),
        .r1_base(r1_base),
        .r1_size(r1_size),
        .r1_xn(r1_xn),
        .region_hit(region_hit),
        .access_fault(access_fault)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        req_addr = 0;
        req_exec = 0;
        r0_base = 0; r0_size = 0; r0_xn = 0;
        r1_base = 0; r1_size = 0; r1_xn = 0;

        // Reset the system
        #20 rst_n = 1;
        #10;

        // ---------------------------------------------------------------------
        // Test Setup: Overlapping Regions
        // ---------------------------------------------------------------------
        // Define Region 0: 0x1000 to 0x1FFF (Size 0x1000)
        r0_base = 32'h0000_1000;
        r0_size = 32'h0000_1000;

        // Define Region 1: 0x1000 to 0x1FFF (Size 0x1000) - Complete Overlap
        r1_base = 32'h0000_1000;
        r1_size = 32'h0000_1000;

        // Request Address: 0x1500 (Inside both regions)
        req_addr = 32'h0000_1500;
        
        // Request Type: Instruction Fetch (Execute)
        req_exec = 1'b1;

        // ---------------------------------------------------------------------
        // Test Case 1: R0 is Restrictive (XN=1), R1 is Permissive (XN=0)
        // Security Requirement: Must enforce most restrictive -> Fault
        // ---------------------------------------------------------------------
        r0_xn = 1'b1;
        r1_xn = 1'b0;
        
        // Wait for clock edge to process inputs
        @(posedge clk);
        #1; // Allow output propagation

        if (access_fault !== 1'b1) begin
            $display("[TEST] FAIL: access_fault not asserted when R0_XN=1 and R1_XN=0 in overlap.");
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 2: R0 is Permissive (XN=0), R1 is Restrictive (XN=1)
        // Security Requirement: Must enforce most restrictive -> Fault
        // ---------------------------------------------------------------------
        r0_xn = 1'b0;
        r1_xn = 1'b1;

        @(posedge clk);
        #1;

        if (access_fault !== 1'b1) begin
            $display("[TEST] FAIL: access_fault not asserted when R0_XN=0 and R1_XN=1 in overlap.");
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 3: Both Restrictive (XN=1)
        // Security Requirement: Fault
        // ---------------------------------------------------------------------
        r0_xn = 1'b1;
        r1_xn = 1'b1;

        @(posedge clk);
        #1;

        if (access_fault !== 1'b1) begin
            $display("[TEST] FAIL: access_fault not asserted when R0_XN=1 and R1_XN=1 in overlap.");
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 4: Both Permissive (XN=0)
        // Control case: Should allow access (sanity check)
        // ---------------------------------------------------------------------
        r0_xn = 1'b0;
        r1_xn = 1'b0;

        @(posedge clk);
        #1;

        if (access_fault !== 1'b0) begin
            $display("[TEST] FAIL: access_fault asserted unexpectedly when both regions allow execution.");
            $finish;
        end

        // If all checks pass
        $display("[TEST] PASS: Security requirement [SECURITY-REQ-0] enforced correctly.");
        $finish;
    end

endmodule