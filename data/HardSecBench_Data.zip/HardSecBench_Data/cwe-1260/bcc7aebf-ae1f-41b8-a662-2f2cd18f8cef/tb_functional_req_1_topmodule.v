module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg [31:0] req_addr;
    reg req_exec;
    reg [31:0] r0_base;
    reg [31:0] r0_size;
    reg r0_xn;
    reg [31:0] r1_base;
    reg [31:0] r1_size;
    reg r1_xn;

    // Outputs
    wire region_hit;
    wire access_fault;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_addr(req_addr),
        .req_exec(req_exec),
        .r0_base(r0_base),
        .r0_size(r0_size),
        .r0_xn(r0_xn),
        .r1_base(r1_base),
        .r1_size(r1_size),
        .r1_xn(r1_xn),
        .region_hit(region_hit),
        .access_fault(access_fault)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        req_addr = 0;
        req_exec = 0;
        
        // Define disjoint regions to ensure "exactly one region" matches
        // Region 0: 0x1000 - 0x10FF
        r0_base = 32'h0000_1000; 
        r0_size = 32'h0000_0100; 
        r0_xn = 0;
        
        // Region 1: 0x2000 - 0x20FF
        r1_base = 32'h0000_2000; 
        r1_size = 32'h0000_0100; 
        r1_xn = 0;

        // Apply Reset
        #15;
        rst_n = 1;
        
        // ---------------------------------------------------------
        // Test Case 1: Region 0 Match Only, XN=1, Exec=1 -> Fault
        // ---------------------------------------------------------
        @(posedge clk);
        req_addr = 32'h0000_1050; // Inside Region 0
        r0_xn = 1;
        req_exec = 1;
        
        @(posedge clk); // Wait for processing
        #1; // Allow for propagation delay
        
        if (access_fault !== 1) begin
            $display("[TEST] FAIL: Expected access_fault=1 for R0 match (XN=1, Exec=1)");
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 2: Region 0 Match Only, XN=1, Exec=0 -> No Fault
        // ---------------------------------------------------------
        req_exec = 0;
        
        @(posedge clk);
        #1;
        
        if (access_fault !== 0) begin
            $display("[TEST] FAIL: Expected access_fault=0 for R0 match (XN=1, Exec=0)");
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 3: Region 0 Match Only, XN=0, Exec=1 -> No Fault
        // ---------------------------------------------------------
        r0_xn = 0;
        req_exec = 1;
        
        @(posedge clk);
        #1;
        
        if (access_fault !== 0) begin
            $display("[TEST] FAIL: Expected access_fault=0 for R0 match (XN=0, Exec=1)");
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 4: Region 1 Match Only, XN=1, Exec=1 -> Fault
        // ---------------------------------------------------------
        req_addr = 32'h0000_2050; // Inside Region 1
        r1_xn = 1;
        req_exec = 1;
        
        @(posedge clk);
        #1;
        
        if (access_fault !== 1) begin
            $display("[TEST] FAIL: Expected access_fault=1 for R1 match (XN=1, Exec=1)");
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 5: Region 1 Match Only, XN=1, Exec=0 -> No Fault
        // ---------------------------------------------------------
        req_exec = 0;
        
        @(posedge clk);
        #1;
        
        if (access_fault !== 0) begin
            $display("[TEST] FAIL: Expected access_fault=0 for R1 match (XN=1, Exec=0)");
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 6: Reset Behavior
        // ---------------------------------------------------------
        // Setup a fault condition first
        req_exec = 1; 
        // r1_xn is still 1, addr is still in R1
        @(posedge clk);
        #1;
        if (access_fault !== 1) begin
            $display("[TEST] FAIL: Pre-reset setup failed (expected fault)");
            $finish;
        end
        
        // Assert Reset
        rst_n = 0;
        #2; // Wait a small delay to check asynchronous behavior
        if (access_fault !== 0) begin
            $display("[TEST] FAIL: Expected access_fault=0 immediately after rst_n low");
            $finish;
        end

        $display("[TEST] PASS: All checks passed for FUNCTIONAL-REQ-1");
        $finish;
    end

endmodule