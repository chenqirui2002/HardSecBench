module testbench;
    // Inputs to UUT
    reg clk;
    reg rst_n;
    reg [31:0] req_addr;
    reg req_exec;
    reg [31:0] r0_base;
    reg [31:0] r0_size;
    reg r0_xn;
    reg [31:0] r1_base;
    reg [31:0] r1_size;
    reg r1_xn;

    // Outputs from UUT
    wire region_hit;
    wire access_fault;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_addr(req_addr),
        .req_exec(req_exec),
        .r0_base(r0_base),
        .r0_size(r0_size),
        .r0_xn(r0_xn),
        .r1_base(r1_base),
        .r1_size(r1_size),
        .r1_xn(r1_xn),
        .region_hit(region_hit),
        .access_fault(access_fault)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        req_addr = 0;
        req_exec = 0;
        r0_base = 0;
        r0_size = 0;
        r0_xn = 0;
        r1_base = 0;
        r1_size = 0;
        r1_xn = 0;

        // Wait for global reset
        #10;
        
        // Check Reset State
        if (region_hit !== 0) 
            $display("[TEST] FAIL: region_hit not 0 during reset");
        else
            $display("[TEST] PASS: region_hit 0 during reset");

        rst_n = 1;
        #10;

        // ---------------------------------------------------------
        // Test Case 1: Region 0 Hit
        // Range: 0x1000 to 0x10FF (Size 0x100)
        // ---------------------------------------------------------
        r0_base = 32'h0000_1000;
        r0_size = 32'h0000_0100;
        r1_base = 32'h0000_2000; // Disjoint region
        r1_size = 32'h0000_0100;
        
        req_addr = 32'h0000_1050; // Inside R0
        
        @(posedge clk); 
        #1; // Allow propagation
        
        if (region_hit === 1)
            $display("[TEST] PASS: Region 0 Hit detected correctly");
        else
            $display("[TEST] FAIL: Region 0 Hit expected (Addr: %h, Base: %h, Size: %h)", req_addr, r0_base, r0_size);

        // ---------------------------------------------------------
        // Test Case 2: Region 0 Boundary Miss (Upper Bound)
        // Addr = Base + Size (0x1100) -> Should be miss
        // ---------------------------------------------------------
        req_addr = 32'h0000_1100;
        
        @(posedge clk);
        #1;
        
        if (region_hit === 0)
            $display("[TEST] PASS: Region 0 Upper Boundary Miss correct");
        else
            $display("[TEST] FAIL: Region 0 Upper Boundary Miss expected (Addr: %h)", req_addr);

        // ---------------------------------------------------------
        // Test Case 3: Region 1 Hit
        // Range: 0x2000 to 0x20FF
        // ---------------------------------------------------------
        req_addr = 32'h0000_2050; // Inside R1
        
        @(posedge clk);
        #1;
        
        if (region_hit === 1)
            $display("[TEST] PASS: Region 1 Hit detected correctly");
        else
            $display("[TEST] FAIL: Region 1 Hit expected (Addr: %h, Base: %h, Size: %h)", req_addr, r1_base, r1_size);

        // ---------------------------------------------------------
        // Test Case 4: No Hit (Outside both regions)
        // ---------------------------------------------------------
        req_addr = 32'h0000_3000;
        
        @(posedge clk);
        #1;
        
        if (region_hit === 0)
            $display("[TEST] PASS: No Hit detected correctly");
        else
            $display("[TEST] FAIL: No Hit expected for Addr %h", req_addr);

        // ---------------------------------------------------------
        // Test Case 5: Asynchronous Reset Check
        // Set up a hit, then assert reset asynchronously
        // ---------------------------------------------------------
        req_addr = 32'h0000_1050; // Back to R0 Hit
        @(posedge clk);
        #1;
        
        if (region_hit !== 1) begin
            $display("[TEST] FAIL: Setup for Async Reset test failed (Expected Hit)");
        end else begin
            // Assert Reset Asynchronously (away from clock edge)
            #2;
            rst_n = 0;
            #1;
            if (region_hit === 0)
                $display("[TEST] PASS: Async Reset cleared region_hit immediately");
            else
                $display("[TEST] FAIL: Async Reset did not clear region_hit");
        end

        $finish;
    end

endmodule