module topmodule (
    input wire clk,
    input wire rst_n,
    input wire [31:0] req_addr,
    input wire req_exec,
    input wire [31:0] r0_base,
    input wire [31:0] r0_size,
    input wire r0_xn,
    input wire [31:0] r1_base,
    input wire [31:0] r1_size,
    input wire r1_xn,
    output reg region_hit,
    output reg access_fault
);

    // -------------------------------------------------------------------------
    // Region Hit Logic
    // -------------------------------------------------------------------------
    
    // We use 33-bit arithmetic for the limit calculation to correctly handle 
    // cases where base + size equals 2^32 (overflows 32-bit register).
    // The range is defined as [base, base + size).
    wire [32:0] r0_limit = {1'b0, r0_base} + {1'b0, r0_size};
    wire [32:0] r1_limit = {1'b0, r1_base} + {1'b0, r1_size};

    // Check if req_addr is within Region 0
    // Condition: req_addr >= base AND req_addr < limit
    wire hit0 = (req_addr >= r0_base) && ({1'b0, req_addr} < r0_limit);

    // Check if req_addr is within Region 1
    wire hit1 = (req_addr >= r1_base) && ({1'b0, req_addr} < r1_limit);

    // -------------------------------------------------------------------------
    // Fault Logic
    // -------------------------------------------------------------------------

    // Determine if the access violates permissions.
    // Security Requirement: In case of overlap, enforce the most restrictive policy.
    // This means if the address falls in multiple regions, and ANY of those regions
    // has XN (Execute Never) set, an execution request must fault.
    //
    // Logic:
    // If hit0 is true and r0_xn is 1 -> Fault
    // If hit1 is true and r1_xn is 1 -> Fault
    // If both are true, the OR operation ensures the fault is asserted if either XN is 1.
    wire fault_condition = (hit0 && r0_xn) || (hit1 && r1_xn);

    // -------------------------------------------------------------------------
    // Output Registers
    // -------------------------------------------------------------------------

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            region_hit   <= 1'b0;
            access_fault <= 1'b0;
        end else begin
            // Functional Requirement 1: Assert region_hit if address is in either region
            region_hit   <= hit0 || hit1;
            
            // Functional Requirement 2 & Security Requirement 1: Assert access_fault
            // only if req_exec is high and the fault condition is met.
            if (req_exec) begin
                access_fault <= fault_condition;
            end else begin
                access_fault <= 1'b0;
            end
        end
    end

endmodule