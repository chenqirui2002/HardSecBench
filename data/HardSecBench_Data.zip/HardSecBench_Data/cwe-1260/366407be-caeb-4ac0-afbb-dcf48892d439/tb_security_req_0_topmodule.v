`timescale 1ns / 1ps

module tb_task_cwe_1260_seed0;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg [7:0] r0_start;
    reg [7:0] r0_end;
    reg r0_perm;
    reg [7:0] r1_start;
    reg [7:0] r1_end;
    reg r1_perm;

    // Outputs
    wire access_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .addr(addr), 
        .r0_start(r0_start), 
        .r0_end(r0_end), 
        .r0_perm(r0_perm), 
        .r1_start(r1_start), 
        .r1_end(r1_end), 
        .r1_perm(r1_perm), 
        .access_out(access_out)
    );

    // Clock generation
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        r0_start = 0;
        r0_end = 0;
        r0_perm = 0;
        r1_start = 0;
        r1_end = 0;
        r1_perm = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        
        // ---------------------------------------------------------------------
        // Test Case 1: Overlap Priority Check (R0=Allow, R1=Deny)
        // Region 0: 0x10 - 0x50 (Allow)
        // Region 1: 0x30 - 0x60 (Deny)
        // Address : 0x40 (Inside both)
        // Expected: R1 takes priority -> Deny (0)
        // ---------------------------------------------------------------------
        @(negedge clk);
        r0_start = 8'h10; r0_end = 8'h50; r0_perm = 1'b1;
        r1_start = 8'h30; r1_end = 8'h60; r1_perm = 1'b0;
        addr = 8'h40;

        @(posedge clk); // Wait for logic update
        #1; // Allow for propagation delay
        
        if (access_out !== 1'b0) begin
            $display("[TEST] FAIL: Priority violation in overlap. R0=Allow, R1=Deny. Expected 0, got %b", access_out);
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 2: Overlap Priority Check (R0=Deny, R1=Allow)
        // Region 0: 0x10 - 0x50 (Deny)
        // Region 1: 0x30 - 0x60 (Allow)
        // Address : 0x40 (Inside both)
        // Expected: R1 takes priority -> Allow (1)
        // ---------------------------------------------------------------------
        @(negedge clk);
        r0_start = 8'h10; r0_end = 8'h50; r0_perm = 1'b0;
        r1_start = 8'h30; r1_end = 8'h60; r1_perm = 1'b1;
        addr = 8'h40;

        @(posedge clk); // Wait for logic update
        #1; // Allow for propagation delay

        if (access_out !== 1'b1) begin
            $display("[TEST] FAIL: Priority violation in overlap. R0=Deny, R1=Allow. Expected 1, got %b", access_out);
            $finish;
        end

        // Success
        $display("[TEST] PASS: Region 1 correctly prioritized over Region 0 in overlapping ranges.");
        $finish;
    end
      
endmodule