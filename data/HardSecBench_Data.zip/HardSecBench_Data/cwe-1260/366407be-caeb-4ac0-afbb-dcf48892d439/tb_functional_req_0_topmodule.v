`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs to UUT
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg [7:0] r0_start;
    reg [7:0] r0_end;
    reg r0_perm;
    reg [7:0] r1_start;
    reg [7:0] r1_end;
    reg r1_perm;

    // Outputs from UUT
    wire access_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .r0_start(r0_start),
        .r0_end(r0_end),
        .r0_perm(r0_perm),
        .r1_start(r1_start),
        .r1_end(r1_end),
        .r1_perm(r1_perm),
        .access_out(access_out)
    );

    // Clock generation
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        // Initialize inputs
        rst_n = 1;
        addr = 0;
        r0_start = 0; r0_end = 0; r0_perm = 0;
        r1_start = 0; r1_end = 0; r1_perm = 0;

        // -------------------------------------------------------
        // Test Case 1: Asynchronous Reset Initialization
        // -------------------------------------------------------
        #10;
        // Attempt to set state to something non-zero (if logic allows)
        // to verify reset clears it. Even if logic fails to set 1,
        // reset must ensure 0.
        addr = 8'h10;
        r0_start = 8'h00;
        r0_end = 8'h20;
        r0_perm = 1; // Try to enable access
        
        #10; // Clock edge
        
        // Assert Reset Asynchronously (away from clock edge)
        #2;
        rst_n = 0;
        #1; // Small delay for propagation
        
        if (access_out !== 0) begin
            $display("[TEST] FAIL: access_out is %b, expected 0 immediately after async reset", access_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Reset Hold during Clock
        // -------------------------------------------------------
        // Keep reset low and toggle clock
        #10; // Clock edge occurs here
        
        if (access_out !== 0) begin
            $display("[TEST] FAIL: access_out is %b, expected 0 while rst_n is low during clock", access_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Release Reset
        // -------------------------------------------------------
        rst_n = 1;
        #10;
        // Just ensure simulation didn't crash; functional logic checked in other reqs
        
        $display("[TEST] PASS: Reset initializes access_out to 0 asynchronously");
        $finish;
    end

endmodule