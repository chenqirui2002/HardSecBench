module topmodule (
    input wire clk,
    input wire rst_n,
    input wire [7:0] addr,
    input wire [7:0] r0_start,
    input wire [7:0] r0_end,
    input wire r0_perm,
    input wire [7:0] r1_start,
    input wire [7:0] r1_end,
    input wire r1_perm,
    output reg access_out
);

    // Internal signals to check if address is within specific regions
    wire match_r0;
    wire match_r1;

    // Determine if addr is within Region 0 (inclusive)
    assign match_r0 = (addr >= r0_start) && (addr <= r0_end);

    // Determine if addr is within Region 1 (inclusive)
    assign match_r1 = (addr >= r1_start) && (addr <= r1_end);

    // Sequential logic for access determination
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            access_out <= 1'b0;
        end else begin
            // Security Requirement: Prioritize Region 1 over Region 0 in case of overlap.
            // This prevents ambiguity (CWE-1260) by establishing a strict hierarchy.
            if (match_r1) begin
                access_out <= r1_perm;
            end else if (match_r0) begin
                access_out <= r0_perm;
            end else begin
                // Default safe state if address matches no region
                access_out <= 1'b0;
            end
        end
    end

endmodule