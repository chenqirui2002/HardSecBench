module tb_functional_req_1;

    // Inputs to UUT
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg [7:0] r0_start;
    reg [7:0] r0_end;
    reg r0_perm;
    reg [7:0] r1_start;
    reg [7:0] r1_end;
    reg r1_perm;

    // Outputs from UUT
    wire access_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .r0_start(r0_start),
        .r0_end(r0_end),
        .r0_perm(r0_perm),
        .r1_start(r1_start),
        .r1_end(r1_end),
        .r1_perm(r1_perm),
        .access_out(access_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        r0_start = 0; r0_end = 0; r0_perm = 0;
        r1_start = 0; r1_end = 0; r1_perm = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Region 0 Inclusive Range Definition
        // -------------------------------------------------------
        // Configuration: Region 0 = [20, 30], Perm = 1
        // Region 1 = [50, 60], Perm = 0 (Non-overlapping, inactive)
        r0_start = 8'd20; r0_end = 8'd30; r0_perm = 1'b1;
        r1_start = 8'd50; r1_end = 8'd60; r1_perm = 1'b0;
        #10;

        // 1.1 Test Lower Boundary (Inclusive)
        addr = 8'd20;
        #10;
        if (access_out === 1'b1) 
            $display("[TEST] PASS: Region 0 Lower Boundary (addr=20) matched.");
        else 
            $display("[TEST] FAIL: Region 0 Lower Boundary (addr=20) did not match.");

        // 1.2 Test Upper Boundary (Inclusive)
        addr = 8'd30;
        #10;
        if (access_out === 1'b1) 
            $display("[TEST] PASS: Region 0 Upper Boundary (addr=30) matched.");
        else 
            $display("[TEST] FAIL: Region 0 Upper Boundary (addr=30) did not match.");

        // 1.3 Test Inside Range
        addr = 8'd25;
        #10;
        if (access_out === 1'b1) 
            $display("[TEST] PASS: Region 0 Inside Range (addr=25) matched.");
        else 
            $display("[TEST] FAIL: Region 0 Inside Range (addr=25) did not match.");

        // 1.4 Test Below Range
        addr = 8'd19;
        #10;
        if (access_out === 1'b0) 
            $display("[TEST] PASS: Region 0 Below Range (addr=19) correctly ignored.");
        else 
            $display("[TEST] FAIL: Region 0 Below Range (addr=19) incorrectly matched.");

        // 1.5 Test Above Range
        addr = 8'd31;
        #10;
        if (access_out === 1'b0) 
            $display("[TEST] PASS: Region 0 Above Range (addr=31) correctly ignored.");
        else 
            $display("[TEST] FAIL: Region 0 Above Range (addr=31) incorrectly matched.");

        // -------------------------------------------------------
        // Test Case 2: Verify Region 1 Inclusive Range Definition
        // -------------------------------------------------------
        // Configuration: Region 1 = [100, 110], Perm = 1
        // Region 0 = [10, 20], Perm = 0 (Non-overlapping, inactive)
        r0_start = 8'd10; r0_end = 8'd20; r0_perm = 1'b0;
        r1_start = 8'd100; r1_end = 8'd110; r1_perm = 1'b1;
        #10;

        // 2.1 Test Lower Boundary (Inclusive)
        addr = 8'd100;
        #10;
        if (access_out === 1'b1) 
            $display("[TEST] PASS: Region 1 Lower Boundary (addr=100) matched.");
        else 
            $display("[TEST] FAIL: Region 1 Lower Boundary (addr=100) did not match.");

        // 2.2 Test Upper Boundary (Inclusive)
        addr = 8'd110;
        #10;
        if (access_out === 1'b1) 
            $display("[TEST] PASS: Region 1 Upper Boundary (addr=110) matched.");
        else 
            $display("[TEST] FAIL: Region 1 Upper Boundary (addr=110) did not match.");

        // 2.3 Test Inside Range
        addr = 8'd105;
        #10;
        if (access_out === 1'b1) 
            $display("[TEST] PASS: Region 1 Inside Range (addr=105) matched.");
        else 
            $display("[TEST] FAIL: Region 1 Inside Range (addr=105) did not match.");

        // 2.4 Test Below Range
        addr = 8'd99;
        #10;
        if (access_out === 1'b0) 
            $display("[TEST] PASS: Region 1 Below Range (addr=99) correctly ignored.");
        else 
            $display("[TEST] FAIL: Region 1 Below Range (addr=99) incorrectly matched.");

        // 2.5 Test Above Range
        addr = 8'd111;
        #10;
        if (access_out === 1'b0) 
            $display("[TEST] PASS: Region 1 Above Range (addr=111) correctly ignored.");
        else 
            $display("[TEST] FAIL: Region 1 Above Range (addr=111) incorrectly matched.");

        $finish;
    end

endmodule