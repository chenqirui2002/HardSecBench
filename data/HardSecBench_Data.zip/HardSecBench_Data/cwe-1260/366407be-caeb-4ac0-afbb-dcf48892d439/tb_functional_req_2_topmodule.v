module tb_topmodule;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg [7:0] r0_start;
    reg [7:0] r0_end;
    reg r0_perm;
    reg [7:0] r1_start;
    reg [7:0] r1_end;
    reg r1_perm;

    // Outputs
    wire access_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .r0_start(r0_start),
        .r0_end(r0_end),
        .r0_perm(r0_perm),
        .r1_start(r1_start),
        .r1_end(r1_end),
        .r1_perm(r1_perm),
        .access_out(access_out)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        addr = 0;
        r0_start = 0;
        r0_end = 0;
        r0_perm = 0;
        r1_start = 0;
        r1_end = 0;
        r1_perm = 0;

        // Reset the system
        #10 rst_n = 1;

        // ---------------------------------------------------------
        // Configuration: Non-overlapping regions to test basic logic
        // Region 0: [10, 20]
        // Region 1: [30, 40]
        // ---------------------------------------------------------
        @(negedge clk);
        r0_start = 8'd10; r0_end = 8'd20; r0_perm = 1'b1;
        r1_start = 8'd30; r1_end = 8'd40; r1_perm = 1'b0; // Start with perm 0 for R1

        // ---------------------------------------------------------
        // Test Case 1: Region 0 Match (Inclusive Range)
        // Expect access_out = r0_perm (1)
        // ---------------------------------------------------------
        
        // Lower Bound
        addr = 8'd10; 
        @(negedge clk); // Wait for clock edge to process
        if (access_out !== 1'b1) begin
            $display("[TEST] FAIL: Region 0 Lower Bound (10) failed. Expected 1, got %b", access_out);
            $finish;
        end

        // Middle
        addr = 8'd15;
        @(negedge clk);
        if (access_out !== 1'b1) begin
            $display("[TEST] FAIL: Region 0 Middle (15) failed. Expected 1, got %b", access_out);
            $finish;
        end

        // Upper Bound
        addr = 8'd20;
        @(negedge clk);
        if (access_out !== 1'b1) begin
            $display("[TEST] FAIL: Region 0 Upper Bound (20) failed. Expected 1, got %b", access_out);
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 2: Region 1 Match (Inclusive Range)
        // Expect access_out = r1_perm (currently 0)
        // ---------------------------------------------------------
        
        // Lower Bound
        addr = 8'd30;
        @(negedge clk);
        if (access_out !== 1'b0) begin
            $display("[TEST] FAIL: Region 1 Lower Bound (30) with perm=0 failed. Expected 0, got %b", access_out);
            $finish;
        end

        // Change R1 perm to 1 to verify it follows the input
        r1_perm = 1'b1;
        @(negedge clk); // Wait for update

        // Check Upper Bound with Perm=1
        addr = 8'd40;
        @(negedge clk);
        if (access_out !== 1'b1) begin
            $display("[TEST] FAIL: Region 1 Upper Bound (40) with perm=1 failed. Expected 1, got %b", access_out);
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 3: No Match
        // Expect access_out = 0
        // ---------------------------------------------------------
        
        // Below Region 0
        addr = 8'd5;
        @(negedge clk);
        if (access_out !== 1'b0) begin
            $display("[TEST] FAIL: No Match (addr=5) failed. Expected 0, got %b", access_out);
            $finish;
        end

        // Between Region 0 and Region 1
        addr = 8'd25;
        @(negedge clk);
        if (access_out !== 1'b0) begin
            $display("[TEST] FAIL: No Match (addr=25) failed. Expected 0, got %b", access_out);
            $finish;
        end

        // Above Region 1
        addr = 8'd50;
        @(negedge clk);
        if (access_out !== 1'b0) begin
            $display("[TEST] FAIL: No Match (addr=50) failed. Expected 0, got %b", access_out);
            $finish;
        end

        $display("[TEST] PASS: Functional Requirement 2 verified");
        $finish;
    end

endmodule