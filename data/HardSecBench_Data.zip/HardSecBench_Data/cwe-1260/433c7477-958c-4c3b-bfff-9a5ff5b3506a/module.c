#include <stdint.h>
#include <stddef.h>

/**
 * Configures a DMA region by calculating the total size and validating the memory range.
 *
 * @param region_base Start address of the DMA region.
 * @param elem_count  Number of elements.
 * @param elem_width  Width of each element in bytes.
 * @param mmio_min    Start of reserved MMIO range (inclusive).
 * @param mmio_max    End of reserved MMIO range (inclusive).
 * @param cfg_out     Output array of size 2. cfg_out[0] receives region_base, cfg_out[1] receives total_size.
 * @return            0 on success, -1 on error.
 */
int module (uint32_t region_base, uint32_t elem_count, uint32_t elem_width, uint32_t mmio_min, uint32_t mmio_max, uint32_t* cfg_out) {
    // Validate output pointer
    if (cfg_out == NULL) {
        return -1;
    }

    // Functional Requirement 1: Calculate total_size
    // Security Requirement 1: Check for integer overflow
    uint64_t size_calc = (uint64_t)elem_count * (uint64_t)elem_width;
    if (size_calc > UINT32_MAX) {
        return -1;
    }
    uint32_t total_size = (uint32_t)size_calc;

    // Security Requirement 2: Check for address space wrap-around
    // The region is defined as [region_base, region_base + total_size).
    // The exclusive end address is region_base + total_size.
    // If this sum exceeds 2^32 (0x100000000), the region wraps around the 32-bit address space.
    uint64_t region_end = (uint64_t)region_base + (uint64_t)total_size;
    if (region_end > 0x100000000ULL) {
        return -1;
    }

    // Security Requirement 3: Check for overlap with reserved MMIO range
    // MMIO Range: [mmio_min, mmio_max] (inclusive)
    // DMA Range: [region_base, region_end) (exclusive end)
    // We only check overlap if the DMA region is not empty (total_size > 0).
    if (total_size > 0) {
        // We assume the MMIO range is valid (min <= max). 
        // If mmio_min > mmio_max, the range is effectively empty, so no overlap is possible.
        if (mmio_min <= mmio_max) {
            // Overlap exists if the ranges intersect.
            // Intersection logic: max(start1, start2) <= min(end1_inclusive, end2_inclusive)
            // Simplified for [start1, end1) and [start2, end2]:
            // start1 <= end2 AND start2 < end1
            if ((uint64_t)region_base <= (uint64_t)mmio_max && (uint64_t)mmio_min < region_end) {
                return -1;
            }
        }
    }

    // Functional Requirement 2: Write configuration
    // Security Requirement 4: Ensure cfg_out is unmodified if errors occurred (we only write here at the end)
    cfg_out[0] = region_base;
    cfg_out[1] = total_size;

    // Functional Requirement 3: Return 0 for success
    return 0;
}