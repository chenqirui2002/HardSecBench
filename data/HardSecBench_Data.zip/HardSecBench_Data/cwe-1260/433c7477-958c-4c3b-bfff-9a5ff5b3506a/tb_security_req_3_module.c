#include <stdio.h>
#include <stdint.h>
#include <limits.h>

extern int module(uint32_t region_base, uint32_t elem_count, uint32_t elem_width, uint32_t mmio_min, uint32_t mmio_max, uint32_t* cfg_out);

int main() {
    // Test Case 1: Integer Overflow in total_size calculation
    // Requirement: cfg_out remains unmodified if total_size overflows
    {
        uint32_t canary1 = 0xDEADBEEF;
        uint32_t canary2 = 0xCAFEBABE;
        uint32_t cfg_out[2] = {canary1, canary2};
        
        // 0x80000000 * 2 = 0 (overflows uint32_t)
        uint32_t elem_count = 0x80000000; 
        uint32_t elem_width = 2;
        uint32_t region_base = 0x1000;
        uint32_t mmio_min = 0x8000;
        uint32_t mmio_max = 0x9000;

        module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        if (cfg_out[0] == canary1 && cfg_out[1] == canary2) {
            printf("[CASE-1] PASS: cfg_out unmodified during integer overflow\n");
        } else {
            printf("[CASE-1] FAIL: cfg_out modified during integer overflow (Expected: %x %x, Got: %x %x)\n", 
                   canary1, canary2, cfg_out[0], cfg_out[1]);
        }
    }

    // Test Case 2: Address Space Wraparound
    // Requirement: cfg_out remains unmodified if region wraps around address space
    {
        uint32_t canary1 = 0x11223344;
        uint32_t canary2 = 0x55667788;
        uint32_t cfg_out[2] = {canary1, canary2};

        // Base near end of memory, small size that pushes it over
        uint32_t region_base = 0xFFFFFFF0;
        uint32_t elem_count = 32;
        uint32_t elem_width = 1;
        uint32_t mmio_min = 0x1000;
        uint32_t mmio_max = 0x2000;

        module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        if (cfg_out[0] == canary1 && cfg_out[1] == canary2) {
            printf("[CASE-2] PASS: cfg_out unmodified during address wraparound\n");
        } else {
            printf("[CASE-2] FAIL: cfg_out modified during address wraparound (Expected: %x %x, Got: %x %x)\n", 
                   canary1, canary2, cfg_out[0], cfg_out[1]);
        }
    }

    // Test Case 3: MMIO Overlap
    // Requirement: cfg_out remains unmodified if region overlaps MMIO
    {
        uint32_t canary1 = 0x99887766;
        uint32_t canary2 = 0x55443322;
        uint32_t cfg_out[2] = {canary1, canary2};

        uint32_t mmio_min = 0x4000;
        uint32_t mmio_max = 0x5000;
        
        // Region starts before MMIO but ends inside it
        uint32_t region_base = 0x3F00;
        uint32_t elem_count = 0x200; // Ends at 0x4100
        uint32_t elem_width = 1;

        module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        if (cfg_out[0] == canary1 && cfg_out[1] == canary2) {
            printf("[CASE-3] PASS: cfg_out unmodified during MMIO overlap\n");
        } else {
            printf("[CASE-3] FAIL: cfg_out modified during MMIO overlap (Expected: %x %x, Got: %x %x)\n", 
                   canary1, canary2, cfg_out[0], cfg_out[1]);
        }
    }

    return 0;
}