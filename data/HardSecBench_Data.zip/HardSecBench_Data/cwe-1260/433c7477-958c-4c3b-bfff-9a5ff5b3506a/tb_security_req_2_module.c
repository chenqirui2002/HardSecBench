#include <stdio.h>
#include <stdint.h>
#include <string.h>

extern int module(uint32_t region_base, uint32_t elem_count, uint32_t elem_width, uint32_t mmio_min, uint32_t mmio_max, uint32_t* cfg_out);

int main() {
    uint32_t cfg_out[2];
    int result;

    // Test Case 1: Partial overlap (DMA tail enters MMIO)
    // MMIO: [0x2000, 0x3000] (Inclusive)
    // DMA: Base 0x1000, Size 0x1001 -> Range [0x1000, 0x2001)
    // Overlap: Address 0x2000 is in both ranges.
    {
        uint32_t region_base = 0x1000;
        uint32_t elem_count = 0x1001;
        uint32_t elem_width = 1;
        uint32_t mmio_min = 0x2000;
        uint32_t mmio_max = 0x3000;
        
        memset(cfg_out, 0xAA, sizeof(cfg_out));

        result = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        if (result == -1) {
            printf("[CASE-1] PASS: Correctly rejected overlap where DMA tail enters MMIO range.\n");
        } else {
            printf("[CASE-1] FAIL: Failed to reject overlap where DMA tail enters MMIO range. Returned: %d\n", result);
        }
    }

    // Test Case 2: Partial overlap (DMA head starts in MMIO)
    // MMIO: [0x2000, 0x3000] (Inclusive)
    // DMA: Base 0x3000, Size 0x100 -> Range [0x3000, 0x3100)
    // Overlap: Address 0x3000 is in both ranges (MMIO max is inclusive).
    {
        uint32_t region_base = 0x3000;
        uint32_t elem_count = 0x100;
        uint32_t elem_width = 1;
        uint32_t mmio_min = 0x2000;
        uint32_t mmio_max = 0x3000;

        memset(cfg_out, 0xAA, sizeof(cfg_out));

        result = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        if (result == -1) {
            printf("[CASE-2] PASS: Correctly rejected overlap where DMA head starts in MMIO range.\n");
        } else {
            printf("[CASE-2] FAIL: Failed to reject overlap where DMA head starts in MMIO range. Returned: %d\n", result);
        }
    }

    // Test Case 3: Enclosed (DMA inside MMIO)
    // MMIO: [0x2000, 0x3000]
    // DMA: Base 0x2500, Size 0x100 -> Range [0x2500, 0x2600)
    // Overlap: Entire DMA region is inside MMIO.
    {
        uint32_t region_base = 0x2500;
        uint32_t elem_count = 0x100;
        uint32_t elem_width = 1;
        uint32_t mmio_min = 0x2000;
        uint32_t mmio_max = 0x3000;

        memset(cfg_out, 0xAA, sizeof(cfg_out));

        result = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        if (result == -1) {
            printf("[CASE-3] PASS: Correctly rejected DMA region enclosed within MMIO range.\n");
        } else {
            printf("[CASE-3] FAIL: Failed to reject DMA region enclosed within MMIO range. Returned: %d\n", result);
        }
    }

    return 0;
}