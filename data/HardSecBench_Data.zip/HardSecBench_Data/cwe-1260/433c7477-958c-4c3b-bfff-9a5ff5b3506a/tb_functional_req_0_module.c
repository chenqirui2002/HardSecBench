#include <stdio.h>
#include <stdint.h>

// Declaration of the function under test
extern int module(uint32_t region_base, uint32_t elem_count, uint32_t elem_width, uint32_t mmio_min, uint32_t mmio_max, uint32_t* cfg_out);

int main() {
    // Test Case 1: Basic multiplication verification
    // Inputs: count=10, width=4 -> expected total_size=40
    // Region: 0x1000, MMIO: 0xF0000000 (safe, no overlap)
    {
        uint32_t cfg[2] = {0xFFFFFFFF, 0xFFFFFFFF}; // Initialize with garbage
        uint32_t region_base = 0x1000;
        uint32_t elem_count = 10;
        uint32_t elem_width = 4;
        uint32_t mmio_min = 0xF0000000;
        uint32_t mmio_max = 0xF0000100;

        int result = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg);

        if (result == 0 && cfg[1] == (elem_count * elem_width)) {
            printf("[CASE-1] PASS: total_size calculated correctly as %u\n", cfg[1]);
        } else {
            printf("[CASE-1] FAIL: Expected size %u, got %u (result=%d)\n", (elem_count * elem_width), cfg[1], result);
        }
    }

    // Test Case 2: Larger values to verify multiplication logic
    // Inputs: count=100, width=32 -> expected total_size=3200
    // Region: 0x2000, MMIO: 0xF0000000 (safe, no overlap)
    {
        uint32_t cfg[2] = {0xFFFFFFFF, 0xFFFFFFFF};
        uint32_t region_base = 0x2000;
        uint32_t elem_count = 100;
        uint32_t elem_width = 32;
        uint32_t mmio_min = 0xF0000000;
        uint32_t mmio_max = 0xF0000100;

        int result = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg);

        if (result == 0 && cfg[1] == (elem_count * elem_width)) {
            printf("[CASE-2] PASS: total_size calculated correctly as %u\n", cfg[1]);
        } else {
            printf("[CASE-2] FAIL: Expected size %u, got %u (result=%d)\n", (elem_count * elem_width), cfg[1], result);
        }
    }

    return 0;
}