#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declaration of the function to be tested
extern int module(uint32_t region_base, uint32_t elem_count, uint32_t elem_width, uint32_t mmio_min, uint32_t mmio_max, uint32_t* cfg_out);

int main() {
    // Test Case 1: Verify cfg_out population with standard values
    {
        uint32_t region_base = 0x1000;
        uint32_t elem_count = 10;
        uint32_t elem_width = 4;
        // MMIO range set high to avoid overlap with region_base
        uint32_t mmio_min = 0xA0000000;
        uint32_t mmio_max = 0xA0001000;
        uint32_t cfg_out[2] = {0xFFFFFFFF, 0xFFFFFFFF}; // Initialize with known garbage

        int ret = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        uint32_t expected_size = elem_count * elem_width;

        // Check if return is success AND cfg_out values are correct
        if (ret == 0 && cfg_out[0] == region_base && cfg_out[1] == expected_size) {
            printf("[CASE-1] PASS: cfg_out correctly populated with base 0x%x and size %u\n", region_base, expected_size);
        } else {
            printf("[CASE-1] FAIL: Expected ret=0, cfg_out[0]=0x%x, cfg_out[1]=%u. Got ret=%d, cfg_out[0]=0x%x, cfg_out[1]=%u\n",
                   region_base, expected_size, ret, cfg_out[0], cfg_out[1]);
        }
    }

    // Test Case 2: Verify cfg_out population with different valid values
    {
        uint32_t region_base = 0x5000;
        uint32_t elem_count = 32;
        uint32_t elem_width = 8;
        // MMIO range set high to avoid overlap
        uint32_t mmio_min = 0xB0000000;
        uint32_t mmio_max = 0xB0001000;
        uint32_t cfg_out[2] = {0xDEADBEEF, 0xDEADBEEF}; // Initialize with known garbage

        int ret = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        uint32_t expected_size = elem_count * elem_width;

        if (ret == 0 && cfg_out[0] == region_base && cfg_out[1] == expected_size) {
            printf("[CASE-2] PASS: cfg_out correctly populated with base 0x%x and size %u\n", region_base, expected_size);
        } else {
            printf("[CASE-2] FAIL: Expected ret=0, cfg_out[0]=0x%x, cfg_out[1]=%u. Got ret=%d, cfg_out[0]=0x%x, cfg_out[1]=%u\n",
                   region_base, expected_size, ret, cfg_out[0], cfg_out[1]);
        }
    }

    return 0;
}