#include <stdio.h>
#include <stdint.h>

// Declaration of the external function to be tested
extern int module(uint32_t region_base, uint32_t elem_count, uint32_t elem_width, uint32_t mmio_min, uint32_t mmio_max, uint32_t* cfg_out);

int main() {
    // Case 1: Standard valid configuration
    // Region: [0x1000, 0x1040), MMIO: [0x80000000, 0x80001000]
    // No overlap, no overflow.
    {
        uint32_t region_base = 0x1000;
        uint32_t elem_count = 16;
        uint32_t elem_width = 4;
        uint32_t mmio_min = 0x80000000;
        uint32_t mmio_max = 0x80001000;
        uint32_t cfg_out[2] = {0xFFFFFFFF, 0xFFFFFFFF}; // Initialize with non-zero

        int result = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        if (result == 0) {
            printf("[CASE-1] PASS: Function returned 0 for valid configuration.\n");
        } else {
            printf("[CASE-1] FAIL: Function returned %d instead of 0 for valid configuration.\n", result);
        }
    }

    // Case 2: Valid configuration with MMIO range preceding the region
    // Region: [0x20000, 0x20064), MMIO: [0x10000, 0x1FFFF]
    // No overlap, no overflow.
    {
        uint32_t region_base = 0x20000;
        uint32_t elem_count = 100;
        uint32_t elem_width = 1;
        uint32_t mmio_min = 0x10000;
        uint32_t mmio_max = 0x1FFFF;
        uint32_t cfg_out[2] = {0, 0};

        int result = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        if (result == 0) {
            printf("[CASE-2] PASS: Function returned 0 for valid configuration.\n");
        } else {
            printf("[CASE-2] FAIL: Function returned %d instead of 0 for valid configuration.\n", result);
        }
    }

    return 0;
}