#include <stdio.h>
#include <stdint.h>

// Declaration of the function to be tested
extern int module(uint32_t region_base, uint32_t elem_count, uint32_t elem_width, uint32_t mmio_min, uint32_t mmio_max, uint32_t* cfg_out);

int main() {
    uint32_t cfg_out[2];
    int result;

    // Test Case 1: Region wraps around the end of 32-bit address space
    // region_base: 0xFFFFFFF0
    // total_size: 32 * 1 = 32 (0x20) bytes
    // Range: [0xFFFFFFF0, 0xFFFFFFF0 + 0x20) -> [0xFFFFFFF0, 0x10) (Wrapped)
    // This should trigger the wrap-around check.
    {
        uint32_t region_base = 0xFFFFFFF0;
        uint32_t elem_count = 32;
        uint32_t elem_width = 1;
        // Set MMIO range to a safe low value to ensure we don't trigger the overlap check instead
        uint32_t mmio_min = 0x1000;
        uint32_t mmio_max = 0x2000;

        // Initialize output with canary values
        cfg_out[0] = 0xDEADBEEF;
        cfg_out[1] = 0xDEADBEEF;

        result = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        if (result == -1) {
            printf("[CASE-1] PASS: Wrap-around detected correctly (returned -1).\n");
        } else {
            printf("[CASE-1] FAIL: Wrap-around not detected (returned %d).\n", result);
        }
    }

    // Test Case 2: Extreme edge case wrap-around
    // region_base: 0xFFFFFFFF (Last byte of 32-bit space)
    // total_size: 2 * 1 = 2 bytes
    // Range: [0xFFFFFFFF, 0x1) (Wrapped)
    {
        uint32_t region_base = 0xFFFFFFFF;
        uint32_t elem_count = 2;
        uint32_t elem_width = 1;
        // Set MMIO range to a safe low value
        uint32_t mmio_min = 0x1000;
        uint32_t mmio_max = 0x2000;

        cfg_out[0] = 0xDEADBEEF;
        cfg_out[1] = 0xDEADBEEF;

        result = module(region_base, elem_count, elem_width, mmio_min, mmio_max, cfg_out);

        if (result == -1) {
            printf("[CASE-2] PASS: Edge case wrap-around detected correctly (returned -1).\n");
        } else {
            printf("[CASE-2] FAIL: Edge case wrap-around not detected (returned %d).\n", result);
        }
    }

    return 0;
}