#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define the structure as per requirements
struct Region {
    uint64_t gpa;
    uint64_t hpa;
    uint64_t size;
};

// Declare the external function
extern int module(struct Region *mappings, uint32_t *count, uint32_t max_entries, uint64_t gpa, uint64_t hpa, uint64_t size);

int main() {
    // Test Case 1: Overlap where new region starts inside an existing region
    // Existing: [0x2000, 0x2FFF]
    // New:      [0x2500, 0x34FF] -> Overlap
    {
        struct Region mappings[5];
        uint32_t count = 0;
        uint32_t max_entries = 5;

        // Setup existing region: HPA 0x2000, Size 0x1000 (Range: 0x2000 - 0x2FFF)
        mappings[0].gpa = 0x2000;
        mappings[0].hpa = 0x2000;
        mappings[0].size = 0x1000;
        count = 1;

        // Attempt to add new region: HPA 0x2500, Size 0x1000
        // This starts inside the existing region.
        int result = module(mappings, &count, max_entries, 0x9000, 0x2500, 0x1000);

        if (result == -2) {
            printf("[CASE-1] PASS: Correctly rejected overlap starting inside existing region\n");
        } else {
            printf("[CASE-1] FAIL: Expected return -2 for overlap, got %d\n", result);
        }
    }

    // Test Case 2: Overlap where new region ends inside an existing region
    // Existing: [0x5000, 0x5FFF]
    // New:      [0x4500, 0x54FF] -> Overlap
    {
        struct Region mappings[5];
        uint32_t count = 0;
        uint32_t max_entries = 5;

        // Setup existing region: HPA 0x5000, Size 0x1000 (Range: 0x5000 - 0x5FFF)
        mappings[0].gpa = 0x5000;
        mappings[0].hpa = 0x5000;
        mappings[0].size = 0x1000;
        count = 1;

        // Attempt to add new region: HPA 0x4500, Size 0x1000
        // This ends inside the existing region (at 0x54FF).
        int result = module(mappings, &count, max_entries, 0xA000, 0x4500, 0x1000);

        if (result == -2) {
            printf("[CASE-2] PASS: Correctly rejected overlap ending inside existing region\n");
        } else {
            printf("[CASE-2] FAIL: Expected return -2 for overlap, got %d\n", result);
        }
    }

    return 0;
}