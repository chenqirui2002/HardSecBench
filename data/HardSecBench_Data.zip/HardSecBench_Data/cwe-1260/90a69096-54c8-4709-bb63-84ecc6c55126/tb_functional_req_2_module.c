#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Define the structure as per inputs
struct Region {
    uint64_t gpa;
    uint64_t hpa;
    uint64_t size;
};

// Declare the external function
extern int module(struct Region *mappings, uint32_t *count, uint32_t max_entries, uint64_t gpa, uint64_t hpa, uint64_t size);

int main() {
    // Test Case 1: Add first entry to empty table
    // Objective: Verify count increments from 0 to 1 and returns 0
    {
        struct Region mappings[5];
        memset(mappings, 0, sizeof(mappings));
        uint32_t count = 0;
        uint32_t max_entries = 5;
        
        // Valid inputs (no overflow, simple range)
        uint64_t gpa = 0x1000;
        uint64_t hpa = 0x2000;
        uint64_t size = 0x100;

        int result = module(mappings, &count, max_entries, gpa, hpa, size);

        if (result == 0 && count == 1) {
            printf("[CASE-1] PASS: count incremented to 1 and returned 0\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0, count=1. Got ret=%d, count=%u\n", result, count);
        }
    }

    // Test Case 2: Add entry to partially filled table
    // Objective: Verify count increments from N to N+1 and returns 0
    {
        struct Region mappings[5];
        memset(mappings, 0, sizeof(mappings));
        
        // Setup existing entry to ensure we don't overlap (context requirement)
        mappings[0].gpa = 0x1000;
        mappings[0].hpa = 0x2000;
        mappings[0].size = 0x100;
        
        uint32_t count = 1;
        uint32_t max_entries = 5;
        
        // New valid inputs distinct from existing entry
        uint64_t gpa = 0x5000;
        uint64_t hpa = 0x6000;
        uint64_t size = 0x100;

        int result = module(mappings, &count, max_entries, gpa, hpa, size);

        if (result == 0 && count == 2) {
            printf("[CASE-2] PASS: count incremented to 2 and returned 0\n");
        } else {
            printf("[CASE-2] FAIL: Expected ret=0, count=2. Got ret=%d, count=%u\n", result, count);
        }
    }

    return 0;
}