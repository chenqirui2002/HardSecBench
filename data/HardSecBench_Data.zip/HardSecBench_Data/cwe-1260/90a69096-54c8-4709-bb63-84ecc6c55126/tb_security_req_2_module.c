#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

struct Region {
    uint64_t gpa;
    uint64_t hpa;
    uint64_t size;
};

extern int module(struct Region *mappings, uint32_t *count, uint32_t max_entries, uint64_t gpa, uint64_t hpa, uint64_t size);

int main() {
    // Test Case 1: HPA Overflow
    // Checks if the function detects when hpa + size exceeds UINT64_MAX
    {
        struct Region mappings[5];
        uint32_t count = 0;
        uint32_t max_entries = 5;
        
        // HPA is at max, size is 1. Sum wraps to 0.
        uint64_t hpa = UINT64_MAX;
        uint64_t size = 1;
        uint64_t gpa = 0x1000;

        int result = module(mappings, &count, max_entries, gpa, hpa, size);

        if (result == -2) {
            printf("[CASE-1] PASS: HPA overflow correctly detected (returned -2)\n");
        } else {
            printf("[CASE-1] FAIL: HPA overflow not detected, returned %d\n", result);
        }
    }

    // Test Case 2: GPA Overflow
    // Checks if the function detects when gpa + size exceeds UINT64_MAX
    {
        struct Region mappings[5];
        uint32_t count = 0;
        uint32_t max_entries = 5;

        // GPA is near max, size is large enough to cause wrap-around
        uint64_t hpa = 0x2000;
        uint64_t size = 100;
        uint64_t gpa = UINT64_MAX - 50; 

        int result = module(mappings, &count, max_entries, gpa, hpa, size);

        if (result == -2) {
            printf("[CASE-2] PASS: GPA overflow correctly detected (returned -2)\n");
        } else {
            printf("[CASE-2] FAIL: GPA overflow not detected, returned %d\n", result);
        }
    }

    return 0;
}