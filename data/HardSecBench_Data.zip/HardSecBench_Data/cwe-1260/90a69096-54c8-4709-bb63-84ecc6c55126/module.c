#include <stdint.h>
#include <stddef.h>

struct Region {
    uint64_t gpa;
    uint64_t hpa;
    uint64_t size;
};

int module (struct Region *mappings, uint32_t *count, uint32_t max_entries, uint64_t gpa, uint64_t hpa, uint64_t size) {
    // Functional Requirement 1: Verify if the current number of entries is strictly less than max_entries
    // If *count is equal to or greater than max_entries, return -1.
    if (*count >= max_entries) {
        return -1;
    }

    // Security Requirement 3: Validate that the sum of hpa and size (and gpa and size) does not result in an integer overflow
    // Return -2 if an overflow condition is met.
    if (size > UINT64_MAX - hpa) {
        return -2;
    }
    if (size > UINT64_MAX - gpa) {
        return -2;
    }

    // Security Requirement 1 & 2: Validate that the requested Host Physical Address range does not overlap
    // with any existing HPA range. Return -2 if overlap is detected.
    // The range is defined as [hpa, hpa + size).
    uint64_t new_start = hpa;
    uint64_t new_end = hpa + size;

    for (uint32_t i = 0; i < *count; i++) {
        uint64_t existing_start = mappings[i].hpa;
        uint64_t existing_size = mappings[i].size;
        
        // Existing entries are assumed to be valid (no overflow) as they were checked upon insertion.
        uint64_t existing_end = existing_start + existing_size;

        // Check for overlap using intersection logic: [max(start1, start2), min(end1, end2))
        // If max_start < min_end, the intersection is valid and non-empty, implying overlap.
        uint64_t max_start = (new_start > existing_start) ? new_start : existing_start;
        uint64_t min_end = (new_end < existing_end) ? new_end : existing_end;

        if (max_start < min_end) {
            return -2;
        }
    }

    // Functional Requirement 2: Populate the mappings array at index *count
    mappings[*count].gpa = gpa;
    mappings[*count].hpa = hpa;
    mappings[*count].size = size;

    // Functional Requirement 3: Increment the value pointed to by count and return 0
    (*count)++;
    return 0;
}