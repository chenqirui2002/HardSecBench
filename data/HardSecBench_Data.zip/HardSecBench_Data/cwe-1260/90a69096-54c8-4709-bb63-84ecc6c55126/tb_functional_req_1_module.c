#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Struct definition based on problem description
struct Region {
    uint64_t gpa;
    uint64_t hpa;
    uint64_t size;
};

// External function declaration
extern int module(struct Region *mappings, uint32_t *count, uint32_t max_entries, uint64_t gpa, uint64_t hpa, uint64_t size);

int main() {
    // Case 1: Verify population at index 0 (Empty table)
    {
        struct Region mappings[5];
        memset(mappings, 0, sizeof(mappings));
        uint32_t count = 0;
        uint32_t max_entries = 5;
        
        // Valid inputs
        uint64_t gpa = 0x10000;
        uint64_t hpa = 0x20000;
        uint64_t size = 0x1000;

        int result = module(mappings, &count, max_entries, gpa, hpa, size);

        // We expect success (0) and data at index 0 (original count)
        if (result == 0) {
            if (mappings[0].gpa == gpa && 
                mappings[0].hpa == hpa && 
                mappings[0].size == size) {
                printf("[CASE-1] PASS: Data correctly populated at index 0.\n");
            } else {
                printf("[CASE-1] FAIL: Data mismatch at index 0. Expected {0x%lx, 0x%lx, 0x%lx}, Got {0x%lx, 0x%lx, 0x%lx}\n",
                       gpa, hpa, size, mappings[0].gpa, mappings[0].hpa, mappings[0].size);
            }
        } else {
            printf("[CASE-1] FAIL: Function returned error %d, expected 0 (success).\n", result);
        }
    }

    // Case 2: Verify population at index 1 (Partially filled table)
    {
        struct Region mappings[5];
        memset(mappings, 0, sizeof(mappings));
        
        // Pre-fill index 0 to simulate existing entry
        mappings[0].gpa = 0x10000;
        mappings[0].hpa = 0x20000;
        mappings[0].size = 0x1000;
        
        uint32_t count = 1; // Next free slot is 1
        uint32_t max_entries = 5;
        
        // New valid inputs (non-overlapping with index 0)
        uint64_t gpa = 0x50000;
        uint64_t hpa = 0x60000;
        uint64_t size = 0x1000;

        int result = module(mappings, &count, max_entries, gpa, hpa, size);

        // We expect success (0) and data at index 1 (original count)
        if (result == 0) {
            if (mappings[1].gpa == gpa && 
                mappings[1].hpa == hpa && 
                mappings[1].size == size) {
                printf("[CASE-2] PASS: Data correctly populated at index 1.\n");
            } else {
                printf("[CASE-2] FAIL: Data mismatch at index 1. Expected {0x%lx, 0x%lx, 0x%lx}, Got {0x%lx, 0x%lx, 0x%lx}\n",
                       gpa, hpa, size, mappings[1].gpa, mappings[1].hpa, mappings[1].size);
            }
        } else {
            printf("[CASE-2] FAIL: Function returned error %d, expected 0 (success).\n", result);
        }
    }

    return 0;
}