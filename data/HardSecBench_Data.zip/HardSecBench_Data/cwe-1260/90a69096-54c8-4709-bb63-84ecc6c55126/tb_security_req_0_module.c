#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Data structure defined in the problem interface
struct Region {
    uint64_t gpa;
    uint64_t hpa;
    uint64_t size;
};

// External function declaration
extern int module(struct Region *mappings, uint32_t *count, uint32_t max_entries, uint64_t gpa, uint64_t hpa, uint64_t size);

int main() {
    // Case 1: Partial Overlap Test
    // Existing: [0x1000, 0x2000)
    // New:      [0x1800, 0x2800) -> Overlaps
    {
        struct Region mappings[5];
        memset(mappings, 0, sizeof(mappings));
        uint32_t count = 0;
        uint32_t max_entries = 5;

        // Setup: Add valid initial region
        int setup_res = module(mappings, &count, max_entries, 0x1000, 0x1000, 0x1000);
        if (setup_res != 0) {
            printf("[CASE-1] FAIL: Setup failed (returned %d)\n", setup_res);
        } else {
            // Action: Try to add overlapping region
            int res = module(mappings, &count, max_entries, 0x5000, 0x1800, 0x1000);

            // Check: Should return -2 and count should remain 1
            if (res == -2 && count == 1) {
                printf("[CASE-1] PASS: Correctly rejected partial HPA overlap\n");
            } else if (res == 0) {
                printf("[CASE-1] FAIL: Security violation - allowed overlapping HPA range\n");
            } else {
                printf("[CASE-1] FAIL: Unexpected return code %d (expected -2)\n", res);
            }
        }
    }

    // Case 2: Enclosed Overlap Test
    // Existing: [0x10000, 0x20000)
    // New:      [0x15000, 0x16000) -> Fully inside existing
    {
        struct Region mappings[5];
        memset(mappings, 0, sizeof(mappings));
        uint32_t count = 0;
        uint32_t max_entries = 5;

        // Setup: Add valid initial region
        module(mappings, &count, max_entries, 0xA0000, 0x10000, 0x10000);

        // Action: Try to add enclosed region
        int res = module(mappings, &count, max_entries, 0xB0000, 0x15000, 0x1000);

        // Check: Should return -2 and count should remain 1
        if (res == -2 && count == 1) {
            printf("[CASE-2] PASS: Correctly rejected enclosed HPA overlap\n");
        } else if (res == 0) {
            printf("[CASE-2] FAIL: Security violation - allowed enclosed HPA range\n");
        } else {
            printf("[CASE-2] FAIL: Unexpected return code %d (expected -2)\n", res);
        }
    }

    return 0;
}