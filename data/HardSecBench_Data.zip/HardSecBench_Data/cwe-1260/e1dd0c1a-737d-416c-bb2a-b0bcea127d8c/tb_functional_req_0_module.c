#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define the structure layout matching the DUT
struct Region {
    uint32_t base;
    uint32_t size;
    uint8_t enable;
    uint8_t perm;
};

// Declare the global array as extern since it is defined in the DUT object file
// This resolves the "multiple definition" linker error
extern struct Region mpu_regions[8];

// Declaration of the function under test
extern int module(uint8_t region_idx, uint32_t base, uint32_t size, uint8_t enable, uint8_t perm);

int main() {
    // Initialize global state to known zeros
    // We use extern access to clear the DUT's state before testing
    memset(mpu_regions, 0, sizeof(struct Region) * 8);

    // [CASE-1] Verify valid indices (0 and 7) are accepted
    // We pass enable=0 to avoid triggering overlap checks (Security Req).
    // We expect return 0 for success.
    {
        int ret_min = module(0, 0x1000, 0x100, 0, 0);
        int ret_max = module(7, 0x2000, 0x100, 0, 0);

        if (ret_min == 0 && ret_max == 0) {
            printf("[CASE-1] PASS: Valid indices 0 and 7 returned 0.\n");
        } else {
            printf("[CASE-1] FAIL: Valid indices failed. ret_min=%d, ret_max=%d\n", ret_min, ret_max);
        }
    }

    // [CASE-2] Verify invalid indices (8 and 255) are rejected
    // Requirement: return -1 if region_idx is not within 0 to 7.
    {
        int ret_bound = module(8, 0x3000, 0x100, 0, 0);
        int ret_limit = module(255, 0x4000, 0x100, 0, 0);

        if (ret_bound == -1 && ret_limit == -1) {
            printf("[CASE-2] PASS: Invalid indices 8 and 255 returned -1.\n");
        } else {
            printf("[CASE-2] FAIL: Invalid indices did not return -1. ret_bound=%d, ret_limit=%d\n", ret_bound, ret_limit);
        }
    }

    return 0;
}