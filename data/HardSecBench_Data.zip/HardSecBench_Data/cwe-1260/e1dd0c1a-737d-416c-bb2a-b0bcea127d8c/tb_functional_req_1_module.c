#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define the structure as specified in the problem description
struct Region {
    uint32_t base;
    uint32_t size;
    uint8_t enable;
    uint8_t perm;
};

// Declare the global array as extern to avoid multiple definition errors.
// The DUT object file provides the definition/storage for this array.
extern struct Region mpu_regions[8];

// Declare the function under test
extern int module(uint8_t region_idx, uint32_t base, uint32_t size, uint8_t enable, uint8_t perm);

int main() {
    // Initialize global state to known values (0)
    // This ensures no regions are enabled initially, preventing overlap errors.
    memset(mpu_regions, 0, sizeof(struct Region) * 8);

    // Test Case 1: Verify update of base, size, and perm for region 2
    {
        uint8_t idx = 2;
        uint32_t test_base = 0x20000000;
        uint32_t test_size = 0x1000;
        uint8_t test_perm = 0x5; // Read/Execute
        uint8_t test_enable = 1;

        // Call function
        int res = module(idx, test_base, test_size, test_enable, test_perm);

        if (res != 0) {
            printf("[CASE-1] FAIL: Function returned error %d instead of success\n", res);
        } else {
            // Verify specific fields targeted by [FUNCTIONAL-REQ-1]
            if (mpu_regions[idx].base == test_base &&
                mpu_regions[idx].size == test_size &&
                mpu_regions[idx].perm == test_perm) {
                printf("[CASE-1] PASS\n");
            } else {
                printf("[CASE-1] FAIL: Fields mismatch. Expected {B:0x%x, S:0x%x, P:0x%x}, Got {B:0x%x, S:0x%x, P:0x%x}\n",
                       test_base, test_size, test_perm,
                       mpu_regions[idx].base, mpu_regions[idx].size, mpu_regions[idx].perm);
            }
        }
    }

    // Test Case 2: Verify update for region 5 with different values
    {
        uint8_t idx = 5;
        uint32_t test_base = 0x40000000;
        uint32_t test_size = 0x400;
        uint8_t test_perm = 0x2; // Write only
        uint8_t test_enable = 0;

        // Note: Region 2 (from Case 1) is at 0x20000000. Region 5 is at 0x40000000.
        // No overlap, so security checks (if present) should pass.

        int res = module(idx, test_base, test_size, test_enable, test_perm);

        if (res != 0) {
            printf("[CASE-2] FAIL: Function returned error %d instead of success\n", res);
        } else {
            if (mpu_regions[idx].base == test_base &&
                mpu_regions[idx].size == test_size &&
                mpu_regions[idx].perm == test_perm) {
                printf("[CASE-2] PASS\n");
            } else {
                printf("[CASE-2] FAIL: Fields mismatch. Expected {B:0x%x, S:0x%x, P:0x%x}, Got {B:0x%x, S:0x%x, P:0x%x}\n",
                       test_base, test_size, test_perm,
                       mpu_regions[idx].base, mpu_regions[idx].size, mpu_regions[idx].perm);
            }
        }
    }

    return 0;
}