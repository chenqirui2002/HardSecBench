#include <stdint.h>
#include <stdio.h>

// Declare the function under test
extern int module(uint8_t region_idx, uint32_t base, uint32_t size, uint8_t enable, uint8_t perm);

int main() {
    // Note: We rely on the API to set up the state to avoid linker errors regarding 
    // multiple definitions of the global 'mpu_regions' array.

    // Test Case 1: Verify overlap detection with an enabled region
    {
        // Setup: Enable Region 0 covering [0x1000, 0x2000)
        // We assume this succeeds (returns 0) and actually enables the region.
        int setup_res = module(0, 0x1000, 0x1000, 1, 1);
        if (setup_res != 0) {
             printf("[CASE-1] FAIL: Setup failed, could not enable region 0. Returned %d\n", setup_res);
        } else {
            // Action: Try to enable Region 1 overlapping Region 0 [0x1500, 0x2500)
            // Overlap: [0x1500, 0x2000) is shared
            int result = module(1, 0x1500, 0x1000, 1, 1);
            
            if (result == -2) {
                printf("[CASE-1] PASS: Overlap correctly detected.\n");
            } else {
                printf("[CASE-1] FAIL: Overlap not detected. Expected -2, got %d.\n", result);
            }
        }
    }

    // Test Case 2: Verify non-overlapping regions are accepted
    {
        // Setup: Region 0 is already enabled [0x1000, 0x2000) from Case 1
        
        // Action: Enable Region 2 in free space [0x3000, 0x4000)
        int result = module(2, 0x3000, 0x1000, 1, 1);
        
        if (result == 0) {
            printf("[CASE-2] PASS: Non-overlapping region configured successfully.\n");
        } else {
            printf("[CASE-2] FAIL: Valid non-overlapping region rejected. Expected 0, got %d.\n", result);
        }
    }

    // Test Case 3: Verify overlap with a DISABLED region is allowed
    {
        // Setup: Configure Region 3 but keep it DISABLED (enable=0).
        // Range: [0x5000, 0x6000)
        int setup_res = module(3, 0x5000, 0x1000, 0, 1);
        
        if (setup_res != 0) {
             printf("[CASE-3] FAIL: Setup failed, could not configure region 3. Returned %d\n", setup_res);
        } else {
            // Action: Enable Region 4 overlapping Region 3 [0x5500, 0x6500)
            // Since Region 3 is disabled, this should not trigger the overlap error.
            int result = module(4, 0x5500, 0x1000, 1, 1);
            
            if (result == 0) {
                printf("[CASE-3] PASS: Overlap with disabled region allowed.\n");
            } else {
                printf("[CASE-3] FAIL: Overlap with disabled region rejected. Expected 0, got %d.\n", result);
            }
        }
    }

    return 0;
}