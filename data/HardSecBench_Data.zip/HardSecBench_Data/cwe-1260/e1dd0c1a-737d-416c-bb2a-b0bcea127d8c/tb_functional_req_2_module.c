#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define the structure as used in the DUT
struct Region {
    uint32_t base;
    uint32_t size;
    uint8_t enable;
    uint8_t perm;
};

// Declare the global array defined in the DUT object file to resolve "multiple definition" error
extern struct Region mpu_regions[8];

// Declare the function under test
extern int module(uint8_t region_idx, uint32_t base, uint32_t size, uint8_t enable, uint8_t perm);

int main() {
    // Test Case 1: Verify enabling a region updates the enable field and returns 0
    {
        // Initialize global state to 0 to ensure no overlaps (validation success)
        memset(mpu_regions, 0, sizeof(struct Region) * 8);

        uint8_t idx = 2;
        uint32_t base = 0x1000;
        uint32_t size = 0x100;
        uint8_t enable = 1;
        uint8_t perm = 0x3;

        int ret = module(idx, base, size, enable, perm);

        if (ret == 0 && mpu_regions[idx].enable == 1) {
            printf("[CASE-1] PASS\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0, enable=1. Got ret=%d, enable=%d\n", ret, mpu_regions[idx].enable);
        }
    }

    // Test Case 2: Verify disabling a region updates the enable field and returns 0
    {
        // Initialize global state
        memset(mpu_regions, 0, sizeof(struct Region) * 8);

        uint8_t idx = 4;
        // Setup existing enabled region
        mpu_regions[idx].base = 0x2000;
        mpu_regions[idx].size = 0x100;
        mpu_regions[idx].enable = 1;
        mpu_regions[idx].perm = 0x1;

        // Call function to disable (enable=0)
        int ret = module(idx, 0x2000, 0x100, 0, 0x1);

        if (ret == 0 && mpu_regions[idx].enable == 0) {
            printf("[CASE-2] PASS\n");
        } else {
            printf("[CASE-2] FAIL: Expected ret=0, enable=0. Got ret=%d, enable=%d\n", ret, mpu_regions[idx].enable);
        }
    }

    return 0;
}