#include <stdint.h>

struct Region {
    uint32_t base;
    uint32_t size;
    uint8_t enable;
    uint8_t perm;
};

// Global array mirroring the hardware MPU state
struct Region mpu_regions[8];

int module (uint8_t region_idx, uint32_t base, uint32_t size, uint8_t enable, uint8_t perm) {
    // 1. Validate region_idx
    if (region_idx > 7) {
        return -1;
    }

    // 2. Security Check: Overlap detection
    // We only need to check for overlaps if the new configuration is intended to be enabled.
    if (enable != 0) {
        // Use uint64_t to prevent integer overflow when calculating end addresses.
        // This ensures robust checking even if base + size exceeds 32-bit range.
        uint64_t req_start = (uint64_t)base;
        uint64_t req_end = req_start + size;

        for (int i = 0; i < 8; i++) {
            // Skip the region currently being configured (it can't overlap itself)
            if (i == region_idx) {
                continue;
            }
            // Skip disabled regions (they don't occupy address space)
            if (mpu_regions[i].enable == 0) {
                continue;
            }

            uint64_t curr_start = (uint64_t)mpu_regions[i].base;
            uint64_t curr_end = curr_start + mpu_regions[i].size;

            // Check for intersection: [req_start, req_end) vs [curr_start, curr_end)
            // Two ranges overlap if max(starts) < min(ends).
            // Note: If size is 0, start == end, so max_start < min_end will be false (no overlap).
            uint64_t max_start = (req_start > curr_start) ? req_start : curr_start;
            uint64_t min_end = (req_end < curr_end) ? req_end : curr_end;

            if (max_start < min_end) {
                return -2; // Overlap detected
            }
        }
    }

    // 3. Security Measure: Disable region before modification
    // This prevents a race condition where the hardware might see a mix of old and new values
    // (e.g., old size with new base) which could temporarily expose protected memory.
    // We explicitly set enable to 0 before touching other fields.
    mpu_regions[region_idx].enable = 0;

    // 4. Update region configuration
    mpu_regions[region_idx].base = base;
    mpu_regions[region_idx].size = size;
    mpu_regions[region_idx].perm = perm;

    // 5. Apply the requested enable state
    // Only after the configuration is fully updated do we re-enable the region (if requested).
    mpu_regions[region_idx].enable = enable;

    return 0;
}