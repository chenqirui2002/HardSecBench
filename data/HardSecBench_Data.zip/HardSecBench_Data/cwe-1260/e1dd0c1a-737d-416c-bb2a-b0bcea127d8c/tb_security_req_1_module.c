#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

// Structure definition matching the problem description
struct Region {
    uint32_t base;
    uint32_t size;
    uint8_t enable;
    uint8_t perm;
};

// External declaration of the global array
extern struct Region mpu_regions[8];

// Function prototype
extern int module(uint8_t region_idx, uint32_t base, uint32_t size, uint8_t enable, uint8_t perm);

// Context for the signal handler, allocated via mmap to ensure isolation from the protected page
typedef struct {
    int fault_detected;
    int passed;
    void *expected_addr;
    void *page_start;
    size_t page_len;
} TestContext;

// Global pointer to the context
TestContext *ctx = NULL;

// Signal handler to catch the first write attempt
void handler(int sig, siginfo_t *si, void *unused) {
    (void)unused;
    if (sig == SIGSEGV && ctx) {
        void *addr = si->si_addr;
        
        // Check if the faulting address matches the address of the 'enable' field
        if (addr == ctx->expected_addr) {
            ctx->passed = 1;
        } else {
            ctx->passed = 0;
        }
        
        ctx->fault_detected = 1;
        
        // Unprotect the page immediately to allow the function to proceed
        if (ctx->page_start) {
            // Restore Read/Write permissions
            if (mprotect(ctx->page_start, ctx->page_len, PROT_READ | PROT_WRITE) == -1) {
                // If unprotect fails, we cannot continue safely
                _exit(2);
            }
        }
    } else {
        // Unexpected signal or context missing
        _exit(3);
    }
}

int main() {
    // 1. Setup Test Context on a separate page to avoid placement on the protected page
    ctx = (TestContext *)mmap(NULL, sizeof(TestContext), PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    if (ctx == MAP_FAILED) {
        perror("mmap");
        return 1;
    }
    ctx->fault_detected = 0;
    ctx->passed = 0;

    // 2. Setup Signal Handler
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = handler;
    if (sigaction(SIGSEGV, &sa, NULL) == -1) {
        perror("sigaction");
        return 1;
    }

    // 3. Initialize Global State
    // We assume mpu_regions is writable initially.
    // Set Region 0 as enabled. We will attempt to reconfigure it.
    memset(mpu_regions, 0, sizeof(struct Region) * 8);
    mpu_regions[0].base = 0x1000;
    mpu_regions[0].size = 0x100;
    mpu_regions[0].enable = 1; 
    mpu_regions[0].perm = 0;

    // 4. Calculate protection boundaries
    long pagesize = sysconf(_SC_PAGESIZE);
    if (pagesize == -1) pagesize = 4096;
    
    uintptr_t array_addr = (uintptr_t)mpu_regions;
    uintptr_t page_start = array_addr & ~((uintptr_t)pagesize - 1);
    uintptr_t array_end = array_addr + sizeof(struct Region) * 8;
    size_t len = array_end - page_start;
    
    // Align length to page size
    if (len % pagesize != 0) {
        len = (len / pagesize + 1) * pagesize;
    }
    
    ctx->page_start = (void*)page_start;
    ctx->page_len = len;
    
    // The requirement is to set enable to 0 FIRST.
    ctx->expected_addr = (void*)&mpu_regions[0].enable;

    // 5. Protect Memory (Read-Only)
    // Any write attempt to mpu_regions will trigger SIGSEGV.
    if (mprotect(ctx->page_start, ctx->page_len, PROT_READ) == -1) {
        perror("mprotect");
        return 1;
    }

    // 6. Call the function under test
    // We request a change to base/size while keeping enable=1.
    // Expected sequence:
    //   1. Check overlap (Read-only access, OK)
    //   2. Disable region (Write to enable -> SIGSEGV -> Handler verifies -> Unprotect)
    //   3. Update base/size (Write -> OK)
    //   4. Enable region (Write -> OK)
    int result = module(0, 0x2000, 0x200, 1, 0);
    (void)result;

    // 7. Verify results
    if (!ctx->fault_detected) {
        printf("[CASE-1] FAIL: No write operation detected (protection might have failed).\n");
    } else if (ctx->passed) {
        printf("[CASE-1] PASS: First write was to 'enable' field (safe reconfiguration).\n");
    } else {
        printf("[CASE-1] FAIL: First write was NOT to 'enable' field (unsafe reconfiguration).\n");
    }

    // Cleanup
    munmap(ctx, sizeof(TestContext));
    return 0;
}