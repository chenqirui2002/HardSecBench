#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Declaration of the function to be tested
extern int module(const uint8_t* source_buffer, uintptr_t dest_address, size_t length, uintptr_t critical_start, size_t critical_size);

int main() {
    size_t buf_size = 512;
    uint8_t *source = (uint8_t*)malloc(buf_size);
    uint8_t *dest_backing = (uint8_t*)malloc(buf_size);
    
    if (!source || !dest_backing) {
        printf("Memory allocation failed\n");
        return 1;
    }

    // Initialize source with a pattern (0xAA)
    memset(source, 0xAA, buf_size);

    // Test Case 1: Destination overlaps with the start of the critical region (Tail Overlap)
    // Destination: [addr, addr+50)
    // Critical:    [addr+40, addr+90)
    // Overlap:     [addr+40, addr+50)
    {
        memset(dest_backing, 0x00, buf_size); // Initialize dest to 0x00
        uintptr_t dest_addr = (uintptr_t)dest_backing;
        size_t copy_len = 50;
        
        // Critical region starts 40 bytes into the destination range
        uintptr_t crit_start = dest_addr + 40;
        size_t crit_size = 50;

        int result = module(source, dest_addr, copy_len, crit_start, crit_size);

        if (result == -2) {
            // Verify no data was written (abort). Check the overlap area specifically.
            if (dest_backing[0] == 0x00 && dest_backing[40] == 0x00 && dest_backing[49] == 0x00) {
                printf("[CASE-1] PASS: Overlap detected correctly (tail overlap) and copy aborted.\n");
            } else {
                printf("[CASE-1] FAIL: Return value correct (-2) but memory was modified.\n");
            }
        } else {
            printf("[CASE-1] FAIL: Expected return -2 for overlap, got %d.\n", result);
        }
    }

    // Test Case 2: Destination overlaps with the end of the critical region (Head Overlap)
    // Critical:    [addr, addr+50)
    // Destination: [addr+40, addr+90)
    // Overlap:     [addr+40, addr+50)
    {
        memset(dest_backing, 0x00, buf_size);
        uintptr_t crit_start = (uintptr_t)dest_backing;
        size_t crit_size = 50;
        
        // Destination starts 40 bytes into the critical region
        uintptr_t dest_addr = crit_start + 40;
        size_t copy_len = 50;

        int result = module(source, dest_addr, copy_len, crit_start, crit_size);

        if (result == -2) {
            // Verify no data was written to the destination buffer (offset 40 in backing)
            if (dest_backing[40] == 0x00 && dest_backing[89] == 0x00) {
                printf("[CASE-2] PASS: Overlap detected correctly (head overlap) and copy aborted.\n");
            } else {
                printf("[CASE-2] FAIL: Return value correct (-2) but memory was modified.\n");
            }
        } else {
            printf("[CASE-2] FAIL: Expected return -2 for overlap, got %d.\n", result);
        }
    }

    // Test Case 3: Destination is completely inside the critical region
    // Critical:    [addr, addr+100)
    // Destination: [addr+20, addr+70)
    {
        memset(dest_backing, 0x00, buf_size);
        uintptr_t crit_start = (uintptr_t)dest_backing;
        size_t crit_size = 100;
        
        uintptr_t dest_addr = crit_start + 20;
        size_t copy_len = 50;

        int result = module(source, dest_addr, copy_len, crit_start, crit_size);

        if (result == -2) {
            // Verify no data was written
            if (dest_backing[20] == 0x00 && dest_backing[69] == 0x00) {
                printf("[CASE-3] PASS: Overlap detected correctly (contained) and copy aborted.\n");
            } else {
                printf("[CASE-3] FAIL: Return value correct (-2) but memory was modified.\n");
            }
        } else {
            printf("[CASE-3] FAIL: Expected return -2 for overlap, got %d.\n", result);
        }
    }

    free(source);
    free(dest_backing);
    return 0;
}