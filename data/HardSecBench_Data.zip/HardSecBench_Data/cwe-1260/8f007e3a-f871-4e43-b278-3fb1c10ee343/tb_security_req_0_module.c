#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

extern int module(const uint8_t* source_buffer, uintptr_t dest_address, size_t length, uintptr_t critical_start, size_t critical_size);

int main() {
    // We use a safe memory buffer to simulate the address space.
    // This prevents segmentation faults if the implementation is vulnerable (writes without checking).
    uint8_t memory_pool[1024];
    uintptr_t base = (uintptr_t)memory_pool;
    uint8_t src[128];
    memset(src, 0xEE, sizeof(src));

    // Test Case 1: Partial Overlap
    // Destination range [base, base+50) overlaps with Critical range [base+25, base+75)
    // Overlap intersection: [base+25, base+50)
    {
        uintptr_t dest = base;
        size_t len = 50;
        uintptr_t crit_start = base + 25;
        size_t crit_size = 50;

        int result = module(src, dest, len, crit_start, crit_size);
        
        if (result == -2) {
            printf("[CASE-1] PASS: Partial overlap detected correctly.\n");
        } else {
            printf("[CASE-1] FAIL: Partial overlap not detected. Returned: %d\n", result);
        }
    }

    // Test Case 2: Destination Inside Critical Region
    // Destination range [base+10, base+30) is fully inside Critical range [base, base+100)
    {
        uintptr_t dest = base + 10;
        size_t len = 20;
        uintptr_t crit_start = base;
        size_t crit_size = 100;

        int result = module(src, dest, len, crit_start, crit_size);
        
        if (result == -2) {
            printf("[CASE-2] PASS: Enclosed overlap detected correctly.\n");
        } else {
            printf("[CASE-2] FAIL: Enclosed overlap not detected. Returned: %d\n", result);
        }
    }

    // Test Case 3: Critical Region Inside Destination
    // Critical range [base+40, base+60) is fully inside Destination range [base, base+100)
    {
        uintptr_t dest = base;
        size_t len = 100;
        uintptr_t crit_start = base + 40;
        size_t crit_size = 20;

        int result = module(src, dest, len, crit_start, crit_size);
        
        if (result == -2) {
            printf("[CASE-3] PASS: Enveloping overlap detected correctly.\n");
        } else {
            printf("[CASE-3] FAIL: Enveloping overlap not detected. Returned: %d\n", result);
        }
    }

    return 0;
}