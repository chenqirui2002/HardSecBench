#include <stdint.h>
#include <stddef.h>
#include <string.h>

int module (const uint8_t* source_buffer, uintptr_t dest_address, size_t length, uintptr_t critical_start, size_t critical_size) {
    // Functional Requirement 3: Input Validation
    // If source_buffer is NULL or length is 0, the function shall return -1.
    if (source_buffer == NULL || length == 0) {
        return -1;
    }

    // Security Requirement 3: Destination Address Overflow Check
    // Validate that the summation of dest_address and length does not result in an integer overflow.
    // Return -3 if it occurs.
    if (length > UINTPTR_MAX - dest_address) {
        return -3;
    }

    // Security Requirement 1 & 2: Critical Region Overlap Check
    // Verify that the destination memory range [dest_address, dest_address + length)
    // does not overlap with the critical region [critical_start, critical_start + critical_size).
    if (critical_size > 0) {
        uintptr_t dest_end = dest_address + length;
        
        // Check if the critical region definition wraps around the address space.
        // Although a wrapping critical region is unusual, we handle it securely.
        int critical_wraps = (critical_size > UINTPTR_MAX - critical_start);

        if (critical_wraps) {
            // If critical region wraps, it effectively occupies two ranges:
            // 1. [critical_start, UINTPTR_MAX]
            // 2. [0, critical_end_wrapped)
            uintptr_t critical_end_wrapped = critical_start + critical_size;
            
            // Check overlap with the upper segment [critical_start, UINTPTR_MAX]
            // Overlap exists if the destination range ends after the critical region starts.
            if (dest_end > critical_start) {
                return -2;
            }
            
            // Check overlap with the lower segment [0, critical_end_wrapped)
            // Overlap exists if the destination range starts before the critical region ends (wrapped).
            if (dest_address < critical_end_wrapped) {
                return -2;
            }
        } else {
            // Standard contiguous critical region [critical_start, critical_end)
            uintptr_t critical_end = critical_start + critical_size;
            
            // Check intersection of two ranges: [dest_address, dest_end) and [critical_start, critical_end)
            // Intersection exists if (StartA < EndB) AND (StartB < EndA)
            if (dest_address < critical_end && critical_start < dest_end) {
                return -2;
            }
        }
    }

    // Functional Requirement 1 & 2: Perform Copy
    // Copy length bytes from source_buffer to dest_address.
    // Return 0 (SUCCESS).
    memcpy((void*)dest_address, (const void*)source_buffer, length);
    
    return 0;
}