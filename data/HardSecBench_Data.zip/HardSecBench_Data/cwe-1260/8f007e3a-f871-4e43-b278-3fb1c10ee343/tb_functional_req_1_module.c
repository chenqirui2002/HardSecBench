#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Declare the external function
extern int module(const uint8_t* source_buffer, uintptr_t dest_address, size_t length, uintptr_t critical_start, size_t critical_size);

int main() {
    // Test Case 1: Basic valid copy with no critical region defined
    {
        const char* src_data = "FirmwareData";
        size_t len = strlen(src_data) + 1;
        
        // Allocate destination on heap to ensure valid address
        uint8_t* dest_ptr = (uint8_t*)malloc(len);
        if (!dest_ptr) {
            printf("[CASE-1] FAIL: Setup failed (malloc)\n");
            return 1;
        }
        memset(dest_ptr, 0, len);

        // Critical region is empty/null (0, 0)
        int result = module((const uint8_t*)src_data, (uintptr_t)dest_ptr, len, 0, 0);

        if (result == 0) {
            // Verify data integrity as part of "successful completion"
            if (memcmp(dest_ptr, src_data, len) == 0) {
                printf("[CASE-1] PASS: Function returned 0 and data copied successfully\n");
            } else {
                printf("[CASE-1] FAIL: Function returned 0 but data mismatch\n");
            }
        } else {
            printf("[CASE-1] FAIL: Expected return 0, got %d\n", result);
        }

        free(dest_ptr);
    }

    // Test Case 2: Valid copy with a non-overlapping critical region
    {
        const char* src_data = "SegmentLoad";
        size_t len = strlen(src_data) + 1;

        // Use distinct stack arrays to guarantee non-overlapping memory addresses
        uint8_t dest_buffer[32]; 
        uint8_t critical_buffer[32];
        
        // Initialize buffers
        memset(dest_buffer, 0, sizeof(dest_buffer));
        memset(critical_buffer, 0xFF, sizeof(critical_buffer)); // Fill critical with pattern

        // Setup addresses
        uintptr_t dest_addr = (uintptr_t)dest_buffer;
        uintptr_t crit_addr = (uintptr_t)critical_buffer;

        // Call function
        int result = module((const uint8_t*)src_data, dest_addr, len, crit_addr, sizeof(critical_buffer));

        if (result == 0) {
            if (memcmp(dest_buffer, src_data, len) == 0) {
                printf("[CASE-2] PASS: Function returned 0 with non-overlapping critical region\n");
            } else {
                printf("[CASE-2] FAIL: Function returned 0 but data mismatch\n");
            }
        } else {
            printf("[CASE-2] FAIL: Expected return 0, got %d\n", result);
        }
    }

    return 0;
}