`timescale 1ns/1ps

module tb_functional_req_0;
    // Inputs
    reg clk;
    reg rst_n;
    reg req;
    reg [15:0] addr;
    reg [15:0] prog_base;
    reg prog_en;

    // Outputs
    wire rom_sel;
    wire periph_sel;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req(req),
        .addr(addr),
        .prog_base(prog_base),
        .prog_en(prog_en),
        .rom_sel(rom_sel),
        .periph_sel(periph_sel)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        rst_n = 0;
        req = 0;
        addr = 0;
        // Set prog_base to a safe non-overlapping value (0x8000) and disable periph
        // to isolate testing of the fixed ROM region.
        prog_base = 16'h8000; 
        prog_en = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Valid ROM Access (0x0000 - 0x0FFF)
        // -------------------------------------------------------
        req = 1;
        
        // Sub-test 1.1: Lower Boundary (0x0000)
        addr = 16'h0000;
        @(posedge clk);
        #1; // Allow for propagation delay
        if (rom_sel === 1'b1) begin
            $display("[TEST] PASS: rom_sel asserted for addr 0x0000");
        end else begin
            $display("[TEST] FAIL: rom_sel not asserted for addr 0x0000");
        end

        // Sub-test 1.2: Upper Boundary (0x0FFF)
        addr = 16'h0FFF;
        @(posedge clk);
        #1;
        if (rom_sel === 1'b1) begin
            $display("[TEST] PASS: rom_sel asserted for addr 0x0FFF");
        end else begin
            $display("[TEST] FAIL: rom_sel not asserted for addr 0x0FFF");
        end

        // Sub-test 1.3: Middle Address (0x0800)
        addr = 16'h0800;
        @(posedge clk);
        #1;
        if (rom_sel === 1'b1) begin
            $display("[TEST] PASS: rom_sel asserted for addr 0x0800");
        end else begin
            $display("[TEST] FAIL: rom_sel not asserted for addr 0x0800");
        end

        // -------------------------------------------------------
        // Test Case 2: Invalid ROM Access (Out of Range)
        // -------------------------------------------------------
        
        // Sub-test 2.1: Just above boundary (0x1000)
        addr = 16'h1000;
        @(posedge clk);
        #1;
        if (rom_sel === 1'b0) begin
            $display("[TEST] PASS: rom_sel deasserted for addr 0x1000");
        end else begin
            $display("[TEST] FAIL: rom_sel incorrectly asserted for addr 0x1000");
        end

        // Sub-test 2.2: High Address (0xFFFF)
        addr = 16'hFFFF;
        @(posedge clk);
        #1;
        if (rom_sel === 1'b0) begin
            $display("[TEST] PASS: rom_sel deasserted for addr 0xFFFF");
        end else begin
            $display("[TEST] FAIL: rom_sel incorrectly asserted for addr 0xFFFF");
        end

        // -------------------------------------------------------
        // Test Case 3: Request Signal Dependency
        // -------------------------------------------------------
        
        // Sub-test 3.1: Valid Address but req = 0
        req = 0;
        addr = 16'h0000;
        @(posedge clk);
        #1;
        if (rom_sel === 1'b0) begin
            $display("[TEST] PASS: rom_sel deasserted when req=0");
        end else begin
            $display("[TEST] FAIL: rom_sel incorrectly asserted when req=0");
        end

        $finish;
    end

endmodule