module test_security_req_0;
  // Testbench signals
  reg clk;
  reg rst_n;
  reg req;
  reg [15:0] addr;
  reg [15:0] prog_base;
  reg prog_en;
  wire rom_sel;
  wire periph_sel;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .req(req),
    .addr(addr),
    .prog_base(prog_base),
    .prog_en(prog_en),
    .rom_sel(rom_sel),
    .periph_sel(periph_sel)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  // Test Logic
  initial begin
    // Initialize inputs
    rst_n = 0;
    req = 0;
    addr = 0;
    prog_base = 0;
    prog_en = 0;

    // Apply reset
    #20;
    rst_n = 1;
    #10;

    // ----------------------------------------------------------------------
    // Test Case 1: prog_base = 0x0000 (Complete Overlap)
    // ----------------------------------------------------------------------
    // Set inputs to condition that would normally trigger periph_sel
    prog_base = 16'h0000; // Invalid base (< 0x1000)
    prog_en = 1;
    req = 1;
    addr = 16'h0000;      // Matches prog_base
    
    @(negedge clk);       // Setup inputs before clock edge
    @(posedge clk);       // Capture on rising edge
    #1;                   // Allow for propagation delay
    
    if (periph_sel !== 1'b0) begin
      $display("[TEST] FAIL: periph_sel asserted (logic 1) when prog_base is 0x0000 (Overlap with ROM)");
      $finish;
    end

    // ----------------------------------------------------------------------
    // Test Case 2: prog_base = 0x0800 (Partial Overlap)
    // ----------------------------------------------------------------------
    prog_base = 16'h0800; // Invalid base (< 0x1000)
    addr = 16'h0800;      // Matches prog_base
    
    @(negedge clk);
    @(posedge clk);
    #1;

    if (periph_sel !== 1'b0) begin
      $display("[TEST] FAIL: periph_sel asserted (logic 1) when prog_base is 0x0800 (Overlap with ROM)");
      $finish;
    end

    // ----------------------------------------------------------------------
    // Test Case 3: prog_base = 0x0FFF (Boundary Condition)
    // ----------------------------------------------------------------------
    prog_base = 16'h0FFF; // Invalid base (< 0x1000)
    addr = 16'h0FFF;      // Matches prog_base
    
    @(negedge clk);
    @(posedge clk);
    #1;

    if (periph_sel !== 1'b0) begin
      $display("[TEST] FAIL: periph_sel asserted (logic 1) when prog_base is 0x0FFF (Overlap with ROM)");
      $finish;
    end

    // ----------------------------------------------------------------------
    // Test Case 4: prog_base < 0x1000, but addr outside ROM range
    // ----------------------------------------------------------------------
    // Even if the specific address accessed doesn't overlap ROM, the 
    // configuration itself is invalid, so periph_sel must be 0.
    prog_base = 16'h0800; // Invalid base
    addr = 16'h1000;      // 0x1000 is inside peripheral range [0x0800 : 0x17FF] but outside ROM
    
    @(negedge clk);
    @(posedge clk);
    #1;

    if (periph_sel !== 1'b0) begin
      $display("[TEST] FAIL: periph_sel asserted when prog_base < 0x1000, even though addr was outside ROM range");
      $finish;
    end

    // If all checks pass
    $display("[TEST] PASS: periph_sel correctly forced to 0 when prog_base < 0x1000");
    $finish;
  end

endmodule