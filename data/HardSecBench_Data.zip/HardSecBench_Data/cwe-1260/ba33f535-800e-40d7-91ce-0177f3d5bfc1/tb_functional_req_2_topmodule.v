module tb_functional_req_2;
    // Testbench signals
    reg clk;
    reg rst_n;
    reg req;
    reg [15:0] addr;
    reg [15:0] prog_base;
    reg prog_en;
    wire rom_sel;
    wire periph_sel;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req(req),
        .addr(addr),
        .prog_base(prog_base),
        .prog_en(prog_en),
        .rom_sel(rom_sel),
        .periph_sel(periph_sel)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize inputs
        clk = 0;
        rst_n = 1;
        req = 0;
        addr = 16'h0000;
        prog_base = 16'h2000; // Safe base address > 0x1000 to avoid security logic interference
        prog_en = 0;

        // Wait for global reset/startup
        #10;

        // -------------------------------------------------------
        // Test Case 1: Asynchronous Reset Assertion
        // -------------------------------------------------------
        // Setup: Enable ROM selection (Address 0x0000 is valid ROM)
        req = 1;
        addr = 16'h0000;
        
        // Clock edge to latch inputs and drive output high
        @(posedge clk);
        #1; // Wait for propagation
        
        if (rom_sel !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed, rom_sel should be high before reset test.");
            $finish;
        end

        // Action: Assert Reset asynchronously (away from clock edge)
        #2;
        rst_n = 0;
        #1; // Small delay for async logic propagation

        // Check: Outputs must be 0 immediately
        if (rom_sel !== 1'b0 || periph_sel !== 1'b0) begin
            $display("[TEST] FAIL: Outputs did not go to 0 immediately upon asynchronous reset assertion.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Reset Hold (Synchronous Check)
        // -------------------------------------------------------
        // Setup: Try to enable Peripheral selection while reset is HELD low
        // Using prog_base 0x2000, addr 0x2000, req=1, prog_en=1
        prog_en = 1;
        addr = 16'h2000;
        prog_base = 16'h2000;

        // Clock edge while rst_n is still 0
        @(posedge clk);
        #1;

        // Check: Outputs must remain 0
        if (rom_sel !== 1'b0 || periph_sel !== 1'b0) begin
            $display("[TEST] FAIL: Outputs were asserted while rst_n was low.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Reset Release (Recovery)
        // -------------------------------------------------------
        // Action: Release reset
        rst_n = 1;

        // Clock edge to process inputs (Peripheral select inputs still active)
        @(posedge clk);
        #1;

        // Check: Normal operation should resume (periph_sel should go high)
        if (periph_sel !== 1'b1) begin
            $display("[TEST] FAIL: Module did not resume normal operation after reset release.");
            $finish;
        end

        // Success
        $display("[TEST] PASS: Asynchronous reset logic verified correctly.");
        $finish;
    end

endmodule