`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg req;
    reg [15:0] addr;
    reg [15:0] prog_base;
    reg prog_en;

    // Outputs
    wire rom_sel;
    wire periph_sel;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req(req),
        .addr(addr),
        .prog_base(prog_base),
        .prog_en(prog_en),
        .rom_sel(rom_sel),
        .periph_sel(periph_sel)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        rst_n = 0;
        req = 0;
        addr = 0;
        prog_base = 0;
        prog_en = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Valid Access inside Programmable Region
        // -------------------------------------------------------
        // Set base to 0x2000 (Safe region > 0x1000 to avoid ROM overlap/security triggers)
        prog_base = 16'h2000; 
        prog_en = 1;
        req = 1;
        
        // Sub-case 1a: Lower Boundary (addr == prog_base)
        addr = 16'h2000;
        @(negedge clk); // Setup inputs
        @(posedge clk); // Capture
        #1; // Hold time check
        if (periph_sel !== 1'b1) begin
            $display("[TEST] FAIL: periph_sel should be 1 at lower boundary (Addr: 0x%h, Base: 0x%h)", addr, prog_base);
            $finish;
        end

        // Sub-case 1b: Upper Boundary (addr == prog_base + 0x0FFF)
        addr = 16'h2FFF;
        @(negedge clk);
        @(posedge clk);
        #1;
        if (periph_sel !== 1'b1) begin
            $display("[TEST] FAIL: periph_sel should be 1 at upper boundary (Addr: 0x%h, Base: 0x%h)", addr, prog_base);
            $finish;
        end

        // Sub-case 1c: Middle of range
        addr = 16'h2800;
        @(negedge clk);
        @(posedge clk);
        #1;
        if (periph_sel !== 1'b1) begin
            $display("[TEST] FAIL: periph_sel should be 1 inside range (Addr: 0x%h, Base: 0x%h)", addr, prog_base);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Out of Range Accesses
        // -------------------------------------------------------
        
        // Sub-case 2a: Just below range
        addr = 16'h1FFF;
        @(negedge clk);
        @(posedge clk);
        #1;
        if (periph_sel !== 1'b0) begin
            $display("[TEST] FAIL: periph_sel should be 0 below range (Addr: 0x%h, Base: 0x%h)", addr, prog_base);
            $finish;
        end

        // Sub-case 2b: Just above range
        addr = 16'h3000;
        @(negedge clk);
        @(posedge clk);
        #1;
        if (periph_sel !== 1'b0) begin
            $display("[TEST] FAIL: periph_sel should be 0 above range (Addr: 0x%h, Base: 0x%h)", addr, prog_base);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Control Signal Dependencies
        // -------------------------------------------------------
        
        // Sub-case 3a: req low
        addr = 16'h2000; // Valid address
        req = 0;         // Request low
        prog_en = 1;
        @(negedge clk);
        @(posedge clk);
        #1;
        if (periph_sel !== 1'b0) begin
            $display("[TEST] FAIL: periph_sel should be 0 when req is low");
            $finish;
        end

        // Sub-case 3b: prog_en low
        req = 1;
        prog_en = 0;     // Enable low
        @(negedge clk);
        @(posedge clk);
        #1;
        if (periph_sel !== 1'b0) begin
            $display("[TEST] FAIL: periph_sel should be 0 when prog_en is low");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 4: Different Base Address
        // -------------------------------------------------------
        prog_base = 16'h8000;
        prog_en = 1;
        req = 1;
        addr = 16'h8000; // New lower boundary
        
        @(negedge clk);
        @(posedge clk);
        #1;
        if (periph_sel !== 1'b1) begin
            $display("[TEST] FAIL: periph_sel should be 1 with new base address 0x8000");
            $finish;
        end

        $display("[TEST] PASS: Functional Requirement 1 verified");
        $finish;
    end

endmodule