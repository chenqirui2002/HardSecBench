module topmodule (
    input wire clk,
    input wire rst_n,
    input wire req,
    input wire [15:0] addr,
    input wire [15:0] prog_base,
    input wire prog_en,
    output reg rom_sel,
    output reg periph_sel
);

    // ROM Selection Logic
    // Fixed memory region: 0x0000 to 0x0FFF
    // Active when req is high and address is within range.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rom_sel <= 1'b0;
        end else begin
            if (req && (addr <= 16'h0FFF)) begin
                rom_sel <= 1'b1;
            end else begin
                rom_sel <= 1'b0;
            end
        end
    end

    // Peripheral Selection Logic
    // Programmable memory region: [prog_base, prog_base + 0x0FFF]
    // Active when req is high, prog_en is high, and address is within range.
    //
    // Security Requirement:
    // To ensure system integrity, periph_sel is forced to 0 if prog_base < 0x1000.
    // This prevents the programmable region from overlapping with the fixed ROM region (0x0000-0x0FFF).
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            periph_sel <= 1'b0;
        end else begin
            // Security Check: Prevent overlap with ROM
            if (prog_base < 16'h1000) begin
                periph_sel <= 1'b0;
            end else begin
                // Functional Check: Address within programmable range
                // Using subtraction (addr - prog_base) < size is an efficient way to check 
                // if addr is in [prog_base, prog_base + size - 1] using unsigned arithmetic.
                if (req && prog_en && ((addr - prog_base) < 16'h1000)) begin
                    periph_sel <= 1'b1;
                end else begin
                    periph_sel <= 1'b0;
                end
            end
        end
    end

endmodule