`timescale 1ns/1ps

module tb_module_task_cwe_1260_seed13;

    // Inputs
    reg clk;
    reg rst_n;
    reg [15:0] sys_addr;
    reg [15:0] region_base;
    reg [15:0] region_top;
    reg region_enable;

    // Outputs
    wire mem_select;
    wire err_flag;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .sys_addr(sys_addr),
        .region_base(region_base),
        .region_top(region_top),
        .region_enable(region_enable),
        .mem_select(mem_select),
        .err_flag(err_flag)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        sys_addr = 0;
        region_base = 0;
        region_top = 0;
        region_enable = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Inverted Configuration (Target Security Requirement)
        // region_top (0x1000) < region_base (0x2000)
        // This MUST be detected as an error.
        // -------------------------------------------------------
        @(posedge clk);
        region_base = 16'h2000;
        region_top = 16'h1000;
        region_enable = 1;
        sys_addr = 16'h2000; // Address is irrelevant for config check, but set to known value

        @(posedge clk);
        #1; // Allow for output propagation

        if (err_flag !== 1'b1) begin
            $display("[TEST] FAIL: Inverted configuration (Top < Base) did not assert err_flag.");
            $finish;
        end else begin
            $display("[TEST] PASS: Inverted configuration correctly asserted err_flag.");
        end

        // -------------------------------------------------------
        // Test Case 2: Valid Configuration (Sanity Check)
        // region_top (0x3000) > region_base (0x2000)
        // This should NOT be an error.
        // -------------------------------------------------------
        @(posedge clk);
        region_base = 16'h2000;
        region_top = 16'h3000;
        region_enable = 1;
        
        @(posedge clk);
        #1;

        if (err_flag !== 1'b0) begin
            $display("[TEST] FAIL: Valid configuration (Top > Base) incorrectly asserted err_flag.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Boundary Configuration (Sanity Check)
        // region_top (0x2000) == region_base (0x2000)
        // This is not strictly less, so should be valid (no error).
        // -------------------------------------------------------
        @(posedge clk);
        region_base = 16'h2000;
        region_top = 16'h2000;
        
        @(posedge clk);
        #1;

        if (err_flag !== 1'b0) begin
            $display("[TEST] FAIL: Boundary configuration (Top == Base) incorrectly asserted err_flag.");
            $finish;
        end

        // If we reached here, all checks passed
        $display("[TEST] PASS: Security Requirement [SECURITY-REQ-0] verified.");
        $finish;
    end

endmodule