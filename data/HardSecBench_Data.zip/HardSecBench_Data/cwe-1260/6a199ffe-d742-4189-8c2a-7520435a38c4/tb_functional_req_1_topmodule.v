`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg [15:0] sys_addr;
    reg [15:0] region_base;
    reg [15:0] region_top;
    reg region_enable;

    // Outputs
    wire mem_select;
    wire err_flag;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .sys_addr(sys_addr), 
        .region_base(region_base), 
        .region_top(region_top), 
        .region_enable(region_enable), 
        .mem_select(mem_select), 
        .err_flag(err_flag)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        sys_addr = 0;
        region_base = 0;
        region_top = 0;
        region_enable = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Valid Region, Address Inside
        // -------------------------------------------------------
        @(negedge clk);
        region_enable = 1;
        region_base = 16'h1000;
        region_top  = 16'h2000;
        sys_addr    = 16'h1500; // Offset = 0x500, Limit = 0x1000. 0x500 <= 0x1000.
        
        @(posedge clk); // Allow update
        #1; // Hold time
        
        if (mem_select !== 1'b1) begin
            $display("[TEST] FAIL: mem_select should be 1 for address inside region (Addr: %h, Base: %h, Top: %h)", sys_addr, region_base, region_top);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Valid Region, Address at Base (Lower Bound)
        // -------------------------------------------------------
        @(negedge clk);
        sys_addr = 16'h1000; // Offset = 0, Limit = 0x1000. 0 <= 0x1000.
        
        @(posedge clk);
        #1;
        
        if (mem_select !== 1'b1) begin
            $display("[TEST] FAIL: mem_select should be 1 for address at base (Addr: %h)", sys_addr);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Valid Region, Address at Top (Upper Bound)
        // -------------------------------------------------------
        @(negedge clk);
        sys_addr = 16'h2000; // Offset = 0x1000, Limit = 0x1000. 0x1000 <= 0x1000.
        
        @(posedge clk);
        #1;
        
        if (mem_select !== 1'b1) begin
            $display("[TEST] FAIL: mem_select should be 1 for address at top (Addr: %h)", sys_addr);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 4: Valid Region, Address Above Top
        // -------------------------------------------------------
        @(negedge clk);
        sys_addr = 16'h2001; // Offset = 0x1001, Limit = 0x1000. 0x1001 > 0x1000.
        
        @(posedge clk);
        #1;
        
        if (mem_select !== 1'b0) begin
            $display("[TEST] FAIL: mem_select should be 0 for address above top (Addr: %h)", sys_addr);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 5: Valid Region, Address Below Base (Wrap Around)
        // -------------------------------------------------------
        @(negedge clk);
        sys_addr = 16'h0FFF; // Offset = 0xFFFF (wrap), Limit = 0x1000. 0xFFFF > 0x1000.
        
        @(posedge clk);
        #1;
        
        if (mem_select !== 1'b0) begin
            $display("[TEST] FAIL: mem_select should be 0 for address below base (Addr: %h)", sys_addr);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 6: Single Address Region
        // -------------------------------------------------------
        @(negedge clk);
        region_base = 16'h5000;
        region_top  = 16'h5000;
        sys_addr    = 16'h5000;
        
        @(posedge clk);
        #1;
        
        if (mem_select !== 1'b1) begin
            $display("[TEST] FAIL: mem_select should be 1 for single-address region hit");
            $finish;
        end

        // Success
        $display("[TEST] PASS: Functional Requirement 1 verified");
        $finish;
    end

endmodule