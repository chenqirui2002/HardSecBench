`timescale 1ns/1ps

module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg [15:0] sys_addr;
    reg [15:0] region_base;
    reg [15:0] region_top;
    reg region_enable;

    // Outputs
    wire mem_select;
    wire err_flag;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .sys_addr(sys_addr),
        .region_base(region_base),
        .region_top(region_top),
        .region_enable(region_enable),
        .mem_select(mem_select),
        .err_flag(err_flag)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        sys_addr = 0;
        region_base = 0;
        region_top = 0;
        region_enable = 0;

        // -------------------------------------------------------
        // Test Case 1: Initial Reset Check
        // -------------------------------------------------------
        #10;
        rst_n = 0; // Assert Reset
        #5;        // Wait a bit
        
        if (mem_select !== 1'b0 || err_flag !== 1'b0) begin
            $display("[TEST] FAIL: Outputs did not reset to 0. mem_select=%b, err_flag=%b", mem_select, err_flag);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Asynchronous Reset Assertion
        // -------------------------------------------------------
        // Release reset and setup inputs that might cause outputs to toggle high
        // (Assuming normal operation works, but even if it doesn't, reset must force 0)
        rst_n = 1;
        sys_addr = 16'h0100;
        region_base = 16'h0000;
        region_top = 16'h0200;
        region_enable = 1;

        // Wait for a few clock cycles to allow internal state to settle/update
        @(posedge clk);
        @(posedge clk);
        
        // Assert reset asynchronously (away from clock edge)
        #2; 
        rst_n = 0;
        #1; // Small delay for async propagation

        if (mem_select !== 1'b0 || err_flag !== 1'b0) begin
            $display("[TEST] FAIL: Asynchronous reset failed to force outputs to 0 immediately. mem_select=%b, err_flag=%b", mem_select, err_flag);
            $finish;
        end

        // Hold reset and ensure it stays 0 across a clock edge
        @(posedge clk);
        #1;
        if (mem_select !== 1'b0 || err_flag !== 1'b0) begin
            $display("[TEST] FAIL: Outputs did not remain 0 while reset was held active during clock edge.");
            $finish;
        end

        $display("[TEST] PASS: Asynchronous reset requirement verified.");
        $finish;
    end

endmodule