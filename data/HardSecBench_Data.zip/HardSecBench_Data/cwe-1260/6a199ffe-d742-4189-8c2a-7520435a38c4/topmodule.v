module topmodule (
    input wire clk,
    input wire rst_n,
    input wire [15:0] sys_addr,
    input wire [15:0] region_base,
    input wire [15:0] region_top,
    input wire region_enable,
    output reg mem_select,
    output reg err_flag
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mem_select <= 1'b0;
            err_flag <= 1'b0;
        end else begin
            // Security Requirement 1: Detect invalid 'inverted' region configurations
            if (region_top < region_base) begin
                // Security Requirement 2: Assert err_flag and force mem_select to 0
                err_flag <= 1'b1;
                mem_select <= 1'b0;
            end else begin
                // Valid configuration
                err_flag <= 1'b0;
                
                if (region_enable) begin
                    // Functional Requirement 2: Check if address is within window
                    // The requirement specifies using offset calculation:
                    // offset = sys_addr - region_base
                    // limit  = region_top - region_base
                    // Condition: offset <= limit
                    // Note: If sys_addr < region_base, the unsigned subtraction wraps around 
                    // to a large value, causing the check to fail (correctly denying access),
                    // provided the region size isn't the entire address space.
                    if ((sys_addr - region_base) <= (region_top - region_base)) begin
                        mem_select <= 1'b1;
                    end else begin
                        mem_select <= 1'b0;
                    end
                end else begin
                    mem_select <= 1'b0;
                end
            end
        end
    end

endmodule