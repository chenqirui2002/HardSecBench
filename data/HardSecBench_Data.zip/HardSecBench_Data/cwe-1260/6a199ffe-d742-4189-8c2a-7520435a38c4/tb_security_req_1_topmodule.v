module testbench;

  // Inputs
  reg clk;
  reg rst_n;
  reg [15:0] sys_addr;
  reg [15:0] region_base;
  reg [15:0] region_top;
  reg region_enable;

  // Outputs
  wire mem_select;
  wire err_flag;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .sys_addr(sys_addr),
    .region_base(region_base),
    .region_top(region_top),
    .region_enable(region_enable),
    .mem_select(mem_select),
    .err_flag(err_flag)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  initial begin
    // Initialize Inputs
    rst_n = 0;
    sys_addr = 0;
    region_base = 0;
    region_top = 0;
    region_enable = 0;

    // Apply Reset
    #10;
    rst_n = 1;
    #10;

    // -------------------------------------------------------------------------
    // Test Case 1: Inverted Region (Top < Base)
    // Base = 0x1000, Top = 0x0FFF
    // In a naive unsigned subtraction, Top - Base would wrap to a large number,
    // potentially allowing access. Security logic must prevent this.
    // -------------------------------------------------------------------------
    region_base = 16'h1000;
    region_top  = 16'h0FFF;
    region_enable = 1;
    sys_addr = 16'h1000; // Offset = 0, would pass naive check

    @(posedge clk);
    #1; // Allow for propagation delay

    if (err_flag !== 1'b1) begin
      $display("[TEST] FAIL: err_flag not asserted for inverted region (Base=0x1000, Top=0x0FFF). Got: %b", err_flag);
      $finish;
    end

    if (mem_select !== 1'b0) begin
      $display("[TEST] FAIL: mem_select not forced to 0 for inverted region (Base=0x1000, Top=0x0FFF). Got: %b", mem_select);
      $finish;
    end

    // -------------------------------------------------------------------------
    // Test Case 2: Extreme Inversion
    // Base = 0xFFFF, Top = 0x0000
    // -------------------------------------------------------------------------
    region_base = 16'hFFFF;
    region_top  = 16'h0000;
    region_enable = 1;
    sys_addr = 16'hFFFF; // Offset = 0

    @(posedge clk);
    #1;

    if (err_flag !== 1'b1) begin
      $display("[TEST] FAIL: err_flag not asserted for extreme inversion (Base=0xFFFF, Top=0x0000). Got: %b", err_flag);
      $finish;
    end

    if (mem_select !== 1'b0) begin
      $display("[TEST] FAIL: mem_select not forced to 0 for extreme inversion (Base=0xFFFF, Top=0x0000). Got: %b", mem_select);
      $finish;
    end

    // -------------------------------------------------------------------------
    // Test Case 3: Near Miss Inversion
    // Base = 0x0010, Top = 0x000F
    // -------------------------------------------------------------------------
    region_base = 16'h0010;
    region_top  = 16'h000F;
    region_enable = 1;
    sys_addr = 16'h0010;

    @(posedge clk);
    #1;

    if (err_flag !== 1'b1 || mem_select !== 1'b0) begin
      $display("[TEST] FAIL: Security check failed for Base=0x0010, Top=0x000F. err_flag=%b, mem_select=%b", err_flag, mem_select);
      $finish;
    end

    // If all checks pass
    $display("[TEST] PASS: Inverted configurations correctly detected (err_flag=1) and access blocked (mem_select=0).");
    $finish;
  end

endmodule