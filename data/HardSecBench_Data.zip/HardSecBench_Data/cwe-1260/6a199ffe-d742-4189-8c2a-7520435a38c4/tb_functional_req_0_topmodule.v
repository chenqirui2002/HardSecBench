module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg [15:0] sys_addr;
    reg [15:0] region_base;
    reg [15:0] region_top;
    reg region_enable;

    // Outputs
    wire mem_select;
    wire err_flag;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .sys_addr(sys_addr),
        .region_base(region_base),
        .region_top(region_top),
        .region_enable(region_enable),
        .mem_select(mem_select),
        .err_flag(err_flag)
    );

    // Clock generation: 10ns period
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        sys_addr = 0;
        region_base = 0;
        region_top = 0;
        region_enable = 0;

        // Wait for global reset stability
        #12;

        // -------------------------------------------------------
        // Test Case 1: Verify Asynchronous Reset Initialization
        // -------------------------------------------------------
        if (mem_select !== 0) begin
            $display("[TEST] FAIL: mem_select not 0 during reset");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Synchronous Update (Rising Edge)
        // -------------------------------------------------------
        
        // Release reset
        rst_n = 1;
        
        // Synchronize to falling edge to change inputs safely
        @(negedge clk);
        
        // Set inputs that should result in mem_select = 1
        // Condition: enable=1, base=0x1000, top=0x2000, addr=0x1500
        // Offset = 0x500, Limit = 0x1000. 0x500 <= 0x1000 -> Pass
        region_enable = 1;
        region_base = 16'h1000;
        region_top = 16'h2000;
        sys_addr = 16'h1500;

        // Wait a small amount of time (still before rising edge)
        #2;
        
        // Check that output has NOT changed yet (should still be 0 from reset)
        // If it changes here, the logic is likely combinational or latched incorrectly
        if (mem_select !== 0) begin
            $display("[TEST] FAIL: Output changed asynchronously (before rising edge)");
            $finish;
        end

        // Wait for rising edge
        @(posedge clk);
        
        // Allow for propagation delay (delta cycle)
        #1;
        
        // Check that output has updated
        if (mem_select !== 1) begin
            $display("[TEST] FAIL: Output did not update on rising edge");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Verify Asynchronous Reset Action
        // -------------------------------------------------------
        
        // Assert reset asynchronously (away from clock edge)
        #2;
        rst_n = 0;
        #1; // Propagation delay
        
        // Check immediate effect
        if (mem_select !== 0) begin
            $display("[TEST] FAIL: Asynchronous reset did not clear output immediately");
            $finish;
        end

        // Success
        $display("[TEST] PASS: Clock edge update and async reset verified");
        $finish;
    end

endmodule