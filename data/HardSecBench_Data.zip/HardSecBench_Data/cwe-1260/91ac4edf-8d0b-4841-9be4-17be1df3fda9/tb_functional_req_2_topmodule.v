module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg req_write;
    reg [7:0] limit0;
    reg [1:0] perm0;
    reg [7:0] limit1;
    reg [1:0] perm1;

    // Outputs
    wire granted;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .addr(addr), 
        .req_write(req_write), 
        .limit0(limit0), 
        .perm0(perm0), 
        .limit1(limit1), 
        .perm1(perm1), 
        .granted(granted)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Tasks
    task check_access;
        input [7:0] test_addr;
        input test_req_write;
        input expected_granted;
        input [127:0] description;
        begin
            addr = test_addr;
            req_write = test_req_write;
            
            // Wait for clock edge to capture inputs and update outputs
            @(negedge clk); 
            @(negedge clk); 
            
            if (granted !== expected_granted) begin
                $display("[TEST] FAIL: %0s. Addr=%d, Write=%b. Expected %b, Got %b", 
                    description, test_addr, test_req_write, expected_granted, granted);
            end else begin
                $display("[TEST] PASS: %0s. Addr=%d, Write=%b, Granted=%b", 
                    description, test_addr, test_req_write, granted);
            end
        end
    endtask

    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        req_write = 0;
        limit0 = 0;
        perm0 = 0;
        limit1 = 0;
        perm1 = 0;

        // Reset
        #10 rst_n = 1;
        #10;

        // ---------------------------------------------------------
        // Configuration: 
        // Region 0: [0, 50]
        // Region 1: [0, 100] (Effective logic check: 51-100)
        // ---------------------------------------------------------
        limit0 = 8'd50;
        limit1 = 8'd100;

        $display("--- Starting Test for FUNCTIONAL-REQ-2 ---");

        // ---------------------------------------------------------
        // Test Group 1: Region 0 Access (addr <= limit0)
        // ---------------------------------------------------------
        
        // Case 1.1: Read in Region 0 (addr=25)
        // perm0=[0]=1 (Allow), perm1=[0]=0 (Deny) -> Should Allow (Region 0 priority)
        perm0 = 2'b01; // Read=1, Write=0
        perm1 = 2'b10; // Read=0, Write=1
        check_access(8'd25, 0, 1, "Region 0 Read Allowed");

        // Case 1.2: Write in Region 0 (addr=25)
        // perm0=[1]=0 (Deny), perm1=[1]=1 (Allow) -> Should Deny (Region 0 priority)
        check_access(8'd25, 1, 0, "Region 0 Write Denied");

        // Case 1.3: Boundary Condition (addr = limit0 = 50)
        // Should use perm0
        perm0 = 2'b10; // Read=0, Write=1
        perm1 = 2'b01; // Read=1, Write=0
        check_access(8'd50, 1, 1, "Boundary limit0 Write Allowed");
        check_access(8'd50, 0, 0, "Boundary limit0 Read Denied");

        // ---------------------------------------------------------
        // Test Group 2: Region 1 Access (limit0 < addr <= limit1)
        // ---------------------------------------------------------

        // Case 2.1: Read in Region 1 (addr=75)
        // perm1=[0]=1 (Allow), perm0=[0]=0 (Deny) -> Should Allow (Region 1 logic)
        perm0 = 2'b10; // Read=0
        perm1 = 2'b01; // Read=1
        check_access(8'd75, 0, 1, "Region 1 Read Allowed");

        // Case 2.2: Write in Region 1 (addr=75)
        // perm1=[1]=0 (Deny)
        check_access(8'd75, 1, 0, "Region 1 Write Denied");

        // Case 2.3: Boundary Condition (addr = limit0 + 1 = 51)
        // Should use perm1
        perm0 = 2'b11; // Allow all
        perm1 = 2'b00; // Deny all
        check_access(8'd51, 0, 0, "Boundary limit0+1 Read Denied (Uses perm1)");

        // Case 2.4: Boundary Condition (addr = limit1 = 100)
        // Should use perm1
        perm1 = 2'b11; // Allow all
        check_access(8'd100, 1, 1, "Boundary limit1 Write Allowed");

        $finish;
    end

endmodule