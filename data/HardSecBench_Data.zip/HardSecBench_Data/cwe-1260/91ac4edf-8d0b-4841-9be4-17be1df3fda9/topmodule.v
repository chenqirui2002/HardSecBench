module topmodule (
    input wire clk,
    input wire rst_n,
    input wire [7:0] addr,
    input wire req_write,
    input wire [7:0] limit0,
    input wire [1:0] perm0,
    input wire [7:0] limit1,
    input wire [1:0] perm1,
    output reg granted
);

    always @(posedge clk) begin
        if (!rst_n) begin
            granted <= 1'b0;
        end else begin
            // Security Requirement: Prevent privilege escalation via overlapping regions.
            // Region 0 has strict precedence over Region 1.
            // If the address falls within Region 0 [0, limit0], the access decision
            // is based SOLELY on perm0. Region 1 is ignored.
            if (addr <= limit0) begin
                // req_write: 0 for Read (bit 0), 1 for Write (bit 1)
                granted <= perm0[req_write];
            end
            // If not in Region 0, check Region 1 [0, limit1].
            // Due to the 'else', this effectively handles the range (limit0, limit1].
            else if (addr <= limit1) begin
                granted <= perm1[req_write];
            end
            // Address is outside both regions
            else begin
                granted <= 1'b0;
            end
        end
    end

endmodule