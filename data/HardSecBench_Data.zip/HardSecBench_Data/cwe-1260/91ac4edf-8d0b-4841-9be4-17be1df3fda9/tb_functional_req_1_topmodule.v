module tb_module_task_cwe_1260_seed2;
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg req_write;
    reg [7:0] limit0;
    reg [1:0] perm0;
    reg [7:0] limit1;
    reg [1:0] perm1;
    wire granted;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .req_write(req_write),
        .limit0(limit0),
        .perm0(perm0),
        .limit1(limit1),
        .perm1(perm1),
        .granted(granted)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        req_write = 0;
        limit0 = 0;
        perm0 = 0;
        limit1 = 0;
        perm1 = 0;

        // Apply Reset
        @(negedge clk);
        rst_n = 1;

        // -------------------------------------------------------
        // Test Case 1: Verify Region 0 Upper Bound (limit0)
        // -------------------------------------------------------
        // Setup: Region 0 allows, Region 1 denies.
        // limit0 = 50, limit1 = 100
        @(negedge clk);
        limit0 = 8'd50;
        limit1 = 8'd100;
        perm0 = 2'b11; // Allow R/W
        perm1 = 2'b00; // Deny R/W
        req_write = 0; // Read

        // Check addr == limit0 (Should be Region 0 -> Allowed)
        @(negedge clk);
        addr = 8'd50;
        @(negedge clk); // Wait for DUT to process on posedge
        if (granted === 1'b1) begin
            $display("[TEST] PASS: Address at limit0 granted by Region 0 permissions.");
        end else begin
            $display("[TEST] FAIL: Address at limit0 denied (Expected Grant from Region 0).");
        end

        // Check addr == limit0 + 1 (Should be Region 1 -> Denied)
        // This verifies the boundary of Region 0
        @(negedge clk);
        addr = 8'd51;
        @(negedge clk);
        if (granted === 1'b0) begin
            $display("[TEST] PASS: Address > limit0 denied by Region 1 permissions.");
        end else begin
            $display("[TEST] FAIL: Address > limit0 granted (Expected Deny from Region 1).");
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Region 1 Upper Bound (limit1)
        // -------------------------------------------------------
        // Setup: Region 0 denies, Region 1 allows.
        // limit0 = 50, limit1 = 100
        @(negedge clk);
        perm0 = 2'b00; // Deny
        perm1 = 2'b11; // Allow
        
        // Check addr == limit1 (Should be Region 1 -> Allowed)
        @(negedge clk);
        addr = 8'd100;
        @(negedge clk);
        if (granted === 1'b1) begin
            $display("[TEST] PASS: Address at limit1 granted by Region 1 permissions.");
        end else begin
            $display("[TEST] FAIL: Address at limit1 denied (Expected Grant from Region 1).");
        end

        // Check addr == limit1 + 1 (Should be Outside -> Denied)
        // This verifies the boundary of Region 1
        @(negedge clk);
        addr = 8'd101;
        @(negedge clk);
        if (granted === 1'b0) begin
            $display("[TEST] PASS: Address > limit1 denied (Outside defined regions).");
        end else begin
            $display("[TEST] FAIL: Address > limit1 granted (Expected Deny).");
        end

        $finish;
    end

endmodule