module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg req_write;
    reg [7:0] limit0;
    reg [1:0] perm0;
    reg [7:0] limit1;
    reg [1:0] perm1;

    // Outputs
    wire granted;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .req_write(req_write),
        .limit0(limit0),
        .perm0(perm0),
        .limit1(limit1),
        .perm1(perm1),
        .granted(granted)
    );

    // Clock generation: 10 time units period
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        addr = 0;
        req_write = 0;
        limit0 = 0;
        perm0 = 0;
        limit1 = 0;
        perm1 = 0;

        // Wait a few cycles
        #20;

        // --- Test Case: Synchronous Reset Assertion ---
        
        // 1. Assert Reset on negative edge to ensure setup time for posedge
        @(negedge clk);
        rst_n = 0;
        
        // Randomize other inputs to ensure reset works regardless of input state
        addr = 8'hAA;
        limit0 = 8'hFF;
        perm0 = 2'b11;
        req_write = 1;

        // 2. Wait for the active clock edge (rising edge)
        @(posedge clk);
        #1; // Small delay for output propagation

        // 3. Verify granted is 0
        if (granted !== 1'b0) begin
            $display("[TEST] FAIL: granted is %b (expected 0) after synchronous reset", granted);
            $finish;
        end

        // 4. Hold reset for another cycle to ensure stability
        @(posedge clk);
        #1;
        if (granted !== 1'b0) begin
            $display("[TEST] FAIL: granted is %b (expected 0) while reset is held", granted);
            $finish;
        end

        // 5. Release reset
        @(negedge clk);
        rst_n = 1;
        @(posedge clk);
        #1;

        // Test Passed
        $display("[TEST] PASS: granted is 0 on reset");
        $finish;
    end

endmodule