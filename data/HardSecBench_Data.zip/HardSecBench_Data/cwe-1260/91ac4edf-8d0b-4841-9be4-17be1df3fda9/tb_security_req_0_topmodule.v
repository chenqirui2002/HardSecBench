module tb_task_cwe_1260_seed2;
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg req_write;
    reg [7:0] limit0;
    reg [1:0] perm0;
    reg [7:0] limit1;
    reg [1:0] perm1;
    wire granted;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .req_write(req_write),
        .limit0(limit0),
        .perm0(perm0),
        .limit1(limit1),
        .perm1(perm1),
        .granted(granted)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;
    reg [7:0] current_addr;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        req_write = 0;
        limit0 = 0;
        perm0 = 0;
        limit1 = 0;
        perm1 = 0;

        // Apply Reset
        @(negedge clk);
        rst_n = 1;

        // ---------------------------------------------------------------------
        // Test Configuration: Overlapping Regions
        // Region 0: [0, 50]
        // Region 1: [0, 100]
        // ---------------------------------------------------------------------
        @(negedge clk);
        limit0 = 8'd50;
        limit1 = 8'd100;

        // We test addresses that are definitely inside Region 0 (and thus also Region 1)
        // Addresses: 0 (Lower bound), 25 (Middle), 50 (Upper bound of Region 0)
        
        for (i = 0; i < 3; i = i + 1) begin
            case(i)
                0: current_addr = 8'd0;
                1: current_addr = 8'd25;
                2: current_addr = 8'd50;
            endcase

            // -----------------------------------------------------------------
            // Scenario 1: Region 0 DENY, Region 1 ALLOW
            // Security Requirement: Region 1 must be ignored. Access must be DENIED.
            // -----------------------------------------------------------------
            @(negedge clk);
            addr = current_addr;
            req_write = 0;      // Read Request
            perm0 = 2'b10;      // Region 0: Write Only (Read Denied)
            perm1 = 2'b01;      // Region 1: Read Only (Read Allowed)
            
            @(posedge clk);     // Wait for DUT to process
            @(negedge clk);     // Sample output
            
            if (granted !== 1'b0) begin
                $display("[TEST] FAIL: Privilege Escalation! Addr %d inside Region 0. Region 0 Denies, Region 1 Allows. Granted=1.", current_addr);
                $finish;
            end

            // -----------------------------------------------------------------
            // Scenario 2: Region 0 ALLOW, Region 1 DENY
            // Security Requirement: Region 0 is authoritative. Access must be GRANTED.
            // -----------------------------------------------------------------
            @(negedge clk);
            addr = current_addr;
            req_write = 1;      // Write Request
            perm0 = 2'b10;      // Region 0: Write Allowed
            perm1 = 2'b01;      // Region 1: Write Denied
            
            @(posedge clk);
            @(negedge clk);

            if (granted !== 1'b1) begin
                $display("[TEST] FAIL: Precedence Error! Addr %d inside Region 0. Region 0 Allows, Region 1 Denies. Granted=0.", current_addr);
                $finish;
            end
        end

        // ---------------------------------------------------------------------
        // Completion
        // ---------------------------------------------------------------------
        $display("[TEST] PASS: Region 0 correctly takes precedence over Region 1.");
        $finish;
    end

endmodule