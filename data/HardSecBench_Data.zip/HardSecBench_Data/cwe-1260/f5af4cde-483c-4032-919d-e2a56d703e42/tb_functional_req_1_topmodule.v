module tb_functional_req_1;
    // Signals
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg [7:0] r0_base, r0_end, r0_cfg;
    reg [7:0] r1_base, r1_end, r1_cfg;
    wire [7:0] data_out;
    wire hit_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .r0_base(r0_base),
        .r0_end(r0_end),
        .r0_cfg(r0_cfg),
        .r1_base(r1_base),
        .r1_end(r1_end),
        .r1_cfg(r1_cfg),
        .data_out(data_out),
        .hit_out(hit_out)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize inputs
        clk = 0;
        rst_n = 0;
        addr = 0;
        r0_base = 0; r0_end = 0; r0_cfg = 0;
        r1_base = 0; r1_end = 0; r1_cfg = 0;

        // Apply Reset
        #10 rst_n = 1;

        // -------------------------------------------------------
        // Test Case 1: Match ONLY Region 0
        // -------------------------------------------------------
        // Setup Disjoint Regions:
        // Region 0: [10, 30], Config 0xAA
        // Region 1: [50, 70], Config 0xBB
        // These ranges do not overlap.
        
        @(negedge clk);
        r0_base = 8'd10; r0_end = 8'd30; r0_cfg = 8'hAA;
        r1_base = 8'd50; r1_end = 8'd70; r1_cfg = 8'hBB;

        // Sub-test 1.1: Middle of Region 0
        addr = 8'd20;
        @(posedge clk); // Wait for register update
        #1; // Allow propagation
        if (data_out !== 8'hAA || hit_out !== 1'b1) begin
            $display("[TEST] FAIL: Region 0 match (middle) failed. Addr=20, Exp Data=0xAA, Hit=1. Got Data=0x%h, Hit=%b", data_out, hit_out);
            $finish;
        end

        // Sub-test 1.2: Base of Region 0 (Inclusive check)
        @(negedge clk);
        addr = 8'd10;
        @(posedge clk);
        #1;
        if (data_out !== 8'hAA || hit_out !== 1'b1) begin
            $display("[TEST] FAIL: Region 0 match (base) failed. Addr=10, Exp Data=0xAA, Hit=1. Got Data=0x%h, Hit=%b", data_out, hit_out);
            $finish;
        end

        // Sub-test 1.3: End of Region 0 (Inclusive check)
        @(negedge clk);
        addr = 8'd30;
        @(posedge clk);
        #1;
        if (data_out !== 8'hAA || hit_out !== 1'b1) begin
            $display("[TEST] FAIL: Region 0 match (end) failed. Addr=30, Exp Data=0xAA, Hit=1. Got Data=0x%h, Hit=%b", data_out, hit_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Match ONLY Region 1
        // -------------------------------------------------------
        
        // Sub-test 2.1: Middle of Region 1
        @(negedge clk);
        addr = 8'd60;
        @(posedge clk);
        #1;
        if (data_out !== 8'hBB || hit_out !== 1'b1) begin
            $display("[TEST] FAIL: Region 1 match (middle) failed. Addr=60, Exp Data=0xBB, Hit=1. Got Data=0x%h, Hit=%b", data_out, hit_out);
            $finish;
        end

        // Sub-test 2.2: Base of Region 1
        @(negedge clk);
        addr = 8'd50;
        @(posedge clk);
        #1;
        if (data_out !== 8'hBB || hit_out !== 1'b1) begin
            $display("[TEST] FAIL: Region 1 match (base) failed. Addr=50, Exp Data=0xBB, Hit=1. Got Data=0x%h, Hit=%b", data_out, hit_out);
            $finish;
        end

        // Sub-test 2.3: End of Region 1
        @(negedge clk);
        addr = 8'd70;
        @(posedge clk);
        #1;
        if (data_out !== 8'hBB || hit_out !== 1'b1) begin
            $display("[TEST] FAIL: Region 1 match (end) failed. Addr=70, Exp Data=0xBB, Hit=1. Got Data=0x%h, Hit=%b", data_out, hit_out);
            $finish;
        end

        // Success
        $display("[TEST] PASS: Requirement 1 verified successfully");
        $finish;
    end

endmodule