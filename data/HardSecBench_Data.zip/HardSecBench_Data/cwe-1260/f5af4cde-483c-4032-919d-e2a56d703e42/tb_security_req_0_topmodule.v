module tb_task_cwe_1260_seed8;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg [7:0] r0_base;
    reg [7:0] r0_end;
    reg [7:0] r0_cfg;
    reg [7:0] r1_base;
    reg [7:0] r1_end;
    reg [7:0] r1_cfg;

    // Outputs
    wire [7:0] data_out;
    wire hit_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .addr(addr), 
        .r0_base(r0_base), 
        .r0_end(r0_end), 
        .r0_cfg(r0_cfg), 
        .r1_base(r1_base), 
        .r1_end(r1_end), 
        .r1_cfg(r1_cfg), 
        .data_out(data_out), 
        .hit_out(hit_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        r0_base = 0; r0_end = 0; r0_cfg = 0;
        r1_base = 0; r1_end = 0; r1_cfg = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // ---------------------------------------------------------------------
        // Test Case 1: Overlap, Region 0 is Secure (LSB=1), Region 1 is Non-Secure (LSB=0)
        // Expectation: Priority given to Region 0 (Secure)
        // ---------------------------------------------------------------------
        r0_base = 8'd10; r0_end = 8'd50; r0_cfg = 8'hA1; // LSB = 1 (Secure)
        r1_base = 8'd30; r1_end = 8'd70; r1_cfg = 8'hB0; // LSB = 0 (Non-Secure)
        addr = 8'd40; // Address falls in both [10, 50] and [30, 70]
        
        @(posedge clk); // Wait for register update
        #1; // Allow propagation
        
        if (data_out !== 8'hA1) begin
            $display("[TEST] FAIL: Priority logic failed when R0 is secure. Expected 0xA1, Got 0x%h", data_out);
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 2: Overlap, Region 0 is Non-Secure (LSB=0), Region 1 is Secure (LSB=1)
        // Expectation: Priority given to Region 1 (Secure)
        // ---------------------------------------------------------------------
        r0_base = 8'd10; r0_end = 8'd50; r0_cfg = 8'hC0; // LSB = 0 (Non-Secure)
        r1_base = 8'd30; r1_end = 8'd70; r1_cfg = 8'hD1; // LSB = 1 (Secure)
        addr = 8'd40; // Address falls in both
        
        @(posedge clk); // Wait for register update
        #1; // Allow propagation

        if (data_out !== 8'hD1) begin
            $display("[TEST] FAIL: Priority logic failed when R1 is secure. Expected 0xD1, Got 0x%h", data_out);
            $finish;
        end

        // If both checks pass
        $display("[TEST] PASS: Secure region prioritization implemented correctly.");
        $finish;
    end

endmodule