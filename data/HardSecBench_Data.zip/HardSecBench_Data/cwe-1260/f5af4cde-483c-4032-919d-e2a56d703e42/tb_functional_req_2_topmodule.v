`timescale 1ns/1ps

module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg [7:0] r0_base;
    reg [7:0] r0_end;
    reg [7:0] r0_cfg;
    reg [7:0] r1_base;
    reg [7:0] r1_end;
    reg [7:0] r1_cfg;

    // Outputs
    wire [7:0] data_out;
    wire hit_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .r0_base(r0_base),
        .r0_end(r0_end),
        .r0_cfg(r0_cfg),
        .r1_base(r1_base),
        .r1_end(r1_end),
        .r1_cfg(r1_cfg),
        .data_out(data_out),
        .hit_out(hit_out)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        addr = 0;
        r0_base = 0;
        r0_end = 0;
        r0_cfg = 0;
        r1_base = 0;
        r1_end = 0;
        r1_cfg = 0;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // ---------------------------------------------------------------------
        // Test Case 1: Overlap, Both LSBs = 0
        // Requirement: data_out should be r1_cfg
        // ---------------------------------------------------------------------
        $display("[TEST] Starting Case 1: Overlap, cfg[0] == 0 for both regions");
        
        // Define overlapping regions
        // Region 0: [10, 50]
        // Region 1: [30, 60]
        // Overlap: [30, 50]
        r0_base = 8'd10;
        r0_end  = 8'd50;
        r1_base = 8'd30;
        r1_end  = 8'd60;
        
        // Address in overlap
        addr = 8'd40; 

        // Configs with LSB = 0
        // r0_cfg = 0xAA (10101010)
        // r1_cfg = 0xCC (11001100)
        r0_cfg = 8'hAA; 
        r1_cfg = 8'hCC;

        // Wait for clock edge to register inputs
        @(posedge clk);
        #1; // Wait for propagation

        if (data_out === r1_cfg && hit_out === 1'b1) begin
            $display("[TEST] PASS: Case 1 - data_out matches r1_cfg (0x%h) and hit_out is 1", data_out);
        end else begin
            $display("[TEST] FAIL: Case 1 - Expected data_out=0x%h, hit_out=1. Got data_out=0x%h, hit_out=%b", 
                     r1_cfg, data_out, hit_out);
        end

        // ---------------------------------------------------------------------
        // Test Case 2: Overlap, Both LSBs = 1
        // Requirement: data_out should be r1_cfg
        // ---------------------------------------------------------------------
        $display("[TEST] Starting Case 2: Overlap, cfg[0] == 1 for both regions");

        // Keep regions and address same (still overlapping)
        
        // Configs with LSB = 1
        // r0_cfg = 0xAB (10101011)
        // r1_cfg = 0xCD (11001101)
        r0_cfg = 8'hAB;
        r1_cfg = 8'hCD;

        // Wait for clock edge to register inputs
        @(posedge clk);
        #1; // Wait for propagation

        if (data_out === r1_cfg && hit_out === 1'b1) begin
            $display("[TEST] PASS: Case 2 - data_out matches r1_cfg (0x%h) and hit_out is 1", data_out);
        end else begin
            $display("[TEST] FAIL: Case 2 - Expected data_out=0x%h, hit_out=1. Got data_out=0x%h, hit_out=%b", 
                     r1_cfg, data_out, hit_out);
        end

        $finish;
    end

endmodule