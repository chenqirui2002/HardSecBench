`timescale 1ns/1ps

module tb_task_cwe_1260_seed8;

    // Inputs
    reg clk;
    reg rst_n;
    reg [7:0] addr;
    reg [7:0] r0_base;
    reg [7:0] r0_end;
    reg [7:0] r0_cfg;
    reg [7:0] r1_base;
    reg [7:0] r1_end;
    reg [7:0] r1_cfg;

    // Outputs
    wire [7:0] data_out;
    wire hit_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .addr(addr), 
        .r0_base(r0_base), 
        .r0_end(r0_end), 
        .r0_cfg(r0_cfg), 
        .r1_base(r1_base), 
        .r1_end(r1_end), 
        .r1_cfg(r1_cfg), 
        .data_out(data_out), 
        .hit_out(hit_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        r0_base = 0;
        r0_end = 0;
        r0_cfg = 0;
        r1_base = 0;
        r1_end = 0;
        r1_cfg = 0;

        // Wait for global reset
        #100;
        rst_n = 1;
        
        // -------------------------------------------------------
        // Test Case 1: No Match Condition
        // -------------------------------------------------------
        // Configure regions so they don't overlap with addr
        // Region 0: 10-20
        // Region 1: 30-40
        // Address: 50 (No match)
        r0_base = 8'd10; r0_end = 8'd20; r0_cfg = 8'hAA;
        r1_base = 8'd30; r1_end = 8'd40; r1_cfg = 8'hBB;
        addr = 8'd50;

        @(posedge clk); // Trigger register update
        #1; // Wait for propagation

        if (data_out === 8'd0 && hit_out === 1'b0) begin
            $display("[TEST] PASS: No match condition results in data_out=0, hit_out=0");
        end else begin
            $display("[TEST] FAIL: No match condition failed. Got data_out=%h, hit_out=%b", data_out, hit_out);
        end

        // -------------------------------------------------------
        // Test Case 2: Asynchronous Reset
        // -------------------------------------------------------
        // First, try to set up a state where outputs might be non-zero.
        // Address 15 is in Region 0 [10-20].
        addr = 8'd15;
        @(posedge clk);
        #1;
        
        // Now assert reset asynchronously
        rst_n = 0;
        #1; // Small delay to allow async reset to propagate

        if (data_out === 8'd0 && hit_out === 1'b0) begin
            $display("[TEST] PASS: Asynchronous reset forced outputs to 0");
        end else begin
            $display("[TEST] FAIL: Asynchronous reset failed. Got data_out=%h, hit_out=%b", data_out, hit_out);
        end

        $finish;
    end

endmodule