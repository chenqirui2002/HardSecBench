module topmodule (
    input wire clk,
    input wire rst_n,
    input wire [7:0] addr,
    input wire [7:0] r0_base,
    input wire [7:0] r0_end,
    input wire [7:0] r0_cfg,
    input wire [7:0] r1_base,
    input wire [7:0] r1_end,
    input wire [7:0] r1_cfg,
    output reg [7:0] data_out,
    output reg hit_out
);

    reg match0;
    reg match1;
    reg [7:0] next_data_out;
    reg next_hit_out;

    // Combinational logic for address matching and priority resolution
    always @(*) begin
        // Determine if address falls within Region 0 [r0_base, r0_end]
        match0 = (addr >= r0_base) && (addr <= r0_end);
        
        // Determine if address falls within Region 1 [r1_base, r1_end]
        match1 = (addr >= r1_base) && (addr <= r1_end);

        // Default values (no match)
        next_data_out = 8'd0;
        next_hit_out = 1'b0;

        if (match0 && match1) begin
            // Overlap Case: Address is in both regions
            next_hit_out = 1'b1;
            
            // Security Requirement: If configuration LSBs differ, prioritize the one with LSB=1 (Secure)
            if (r0_cfg[0] != r1_cfg[0]) begin
                if (r0_cfg[0] == 1'b1) begin
                    next_data_out = r0_cfg;
                end else begin
                    next_data_out = r1_cfg;
                end
            end 
            // Functional Requirement: If configuration LSBs are identical, prioritize Region 1
            else begin
                next_data_out = r1_cfg;
            end
        end 
        else if (match0) begin
            // Only Region 0 matches
            next_hit_out = 1'b1;
            next_data_out = r0_cfg;
        end 
        else if (match1) begin
            // Only Region 1 matches
            next_hit_out = 1'b1;
            next_data_out = r1_cfg;
        end
    end

    // Sequential logic for registering outputs
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_out <= 8'd0;
            hit_out <= 1'b0;
        end else begin
            data_out <= next_data_out;
            hit_out <= next_hit_out;
        end
    end

endmodule