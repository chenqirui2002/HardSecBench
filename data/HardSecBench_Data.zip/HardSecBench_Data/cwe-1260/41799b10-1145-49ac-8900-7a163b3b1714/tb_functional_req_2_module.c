#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

// Define the structure as per requirements
typedef struct {
    uint32_t base;
    uint32_t size;
    uint8_t owner;
    uint8_t is_active;
} Region;

// Define ownership constants
#define OWNER_USER 1
#define OWNER_SYSTEM 2

// Declare the external function to be tested
extern int32_t module(Region *region_table, size_t table_cap, uint32_t req_base, uint32_t req_size);

int main() {
    // Test Case 1: Verify return -1 when region_table is NULL
    {
        // Inputs: NULL table, arbitrary cap, valid base/size
        int32_t result = module(NULL, 10, 0x1000, 0x100);
        
        if (result == -1) {
            printf("[CASE-1] PASS: Returned -1 for NULL region_table\n");
        } else {
            printf("[CASE-1] FAIL: Expected -1 for NULL region_table, got %d\n", result);
        }
    }

    // Test Case 2: Verify return -1 when req_size is 0
    {
        Region table[1];
        // Initialize table with a free slot
        table[0].is_active = 0;
        table[0].base = 0;
        table[0].size = 0;
        table[0].owner = 0;

        // Inputs: Valid table, valid cap, valid base, size 0
        int32_t result = module(table, 1, 0x1000, 0);

        if (result == -1) {
            printf("[CASE-2] PASS: Returned -1 for req_size == 0\n");
        } else {
            printf("[CASE-2] FAIL: Expected -1 for req_size == 0, got %d\n", result);
        }
    }

    // Test Case 3: Verify return -1 when no free entry is available
    {
        Region table[2];
        // Initialize table to be full (all active)
        // Use OWNER_USER to ensure we don't trigger security overlap checks (which return -2)
        table[0].is_active = 1;
        table[0].base = 0x1000;
        table[0].size = 0x100;
        table[0].owner = OWNER_USER;

        table[1].is_active = 1;
        table[1].base = 0x2000;
        table[1].size = 0x100;
        table[1].owner = OWNER_USER;

        // Inputs: Full table, valid cap, valid base/size (non-overlapping just to be safe)
        int32_t result = module(table, 2, 0x3000, 0x100);

        if (result == -1) {
            printf("[CASE-3] PASS: Returned -1 for full table\n");
        } else {
            printf("[CASE-3] FAIL: Expected -1 for full table, got %d\n", result);
        }
    }

    return 0;
}