#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Define the structure and constants as specified
typedef struct { 
    uint32_t base; 
    uint32_t size; 
    uint8_t owner; 
    uint8_t is_active; 
} Region;

#define OWNER_USER 1
#define OWNER_SYSTEM 2

// Declare the target function
extern int32_t module(Region *region_table, size_t table_cap, uint32_t req_base, uint32_t req_size);

int main() {
    // Case 1: Overlap with System Region located AFTER a free slot
    // This tests the requirement: "ensuring that all active system regions in the table are checked regardless of the position of any free slots"
    {
        Region table[3];
        memset(table, 0, sizeof(table));
        
        // Index 0: Free (is_active = 0)
        table[0].is_active = 0;
        
        // Index 1: Active System Region [1000, 1100)
        table[1].base = 1000;
        table[1].size = 100;
        table[1].owner = OWNER_SYSTEM;
        table[1].is_active = 1;
        
        // Index 2: Free
        table[2].is_active = 0;

        // Request: [1050, 1150) - Overlaps with Index 1
        // If the function grabs Index 0 without checking Index 1, it returns 0 (FAIL).
        // If it checks properly, it returns -2 (PASS).
        int32_t result = module(table, 3, 1050, 100);
        
        if (result == -2) {
            printf("[CASE-1] PASS: Detected overlap with SYSTEM region despite earlier free slot.\n");
        } else {
            printf("[CASE-1] FAIL: Failed to detect overlap with SYSTEM region (returned %d). Expected -2.\n", result);
        }
    }

    // Case 2: Overlap with System Region (Enclosed)
    // Checks if the function detects when the request is fully inside a system region
    {
        Region table[1];
        memset(table, 0, sizeof(table));
        
        // Active System Region [5000, 6000)
        table[0].base = 5000;
        table[0].size = 1000;
        table[0].owner = OWNER_SYSTEM;
        table[0].is_active = 1;

        // Request: [5200, 5300) - Completely inside [5000, 6000)
        int32_t result = module(table, 1, 5200, 100);
        
        if (result == -2) {
            printf("[CASE-2] PASS: Detected enclosed overlap with SYSTEM region.\n");
        } else {
            printf("[CASE-2] FAIL: Failed to detect enclosed overlap (returned %d). Expected -2.\n", result);
        }
    }
    
    // Case 3: Overlap with System Region (Enclosing)
    // Checks if the function detects when the request fully surrounds a system region
    {
        Region table[1];
        memset(table, 0, sizeof(table));
        
        // Active System Region [8000, 8100)
        table[0].base = 8000;
        table[0].size = 100;
        table[0].owner = OWNER_SYSTEM;
        table[0].is_active = 1;

        // Request: [7900, 8200) - Encloses [8000, 8100)
        int32_t result = module(table, 1, 7900, 300);
        
        if (result == -2) {
            printf("[CASE-3] PASS: Detected enclosing overlap with SYSTEM region.\n");
        } else {
            printf("[CASE-3] FAIL: Failed to detect enclosing overlap (returned %d). Expected -2.\n", result);
        }
    }

    return 0;
}