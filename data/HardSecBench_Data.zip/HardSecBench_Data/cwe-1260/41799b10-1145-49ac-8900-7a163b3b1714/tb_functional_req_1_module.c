#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    uint32_t base;
    uint32_t size;
    uint8_t owner;
    uint8_t is_active;
} Region;

#define OWNER_USER 1
#define OWNER_SYSTEM 2

// Declaration of the function under test
extern int32_t module(Region *region_table, size_t table_cap, uint32_t req_base, uint32_t req_size);

int main() {
    // Case 1: Verify allocation into the first slot (index 0) when it is free.
    {
        Region table[3];
        memset(table, 0, sizeof(table));
        
        // Setup: Slot 0 is free (all 0s), Slot 1 is active/occupied
        // We use OWNER_USER for existing slots to avoid triggering security checks related to SYSTEM overlaps
        table[1].base = 0x8000;
        table[1].size = 0x100;
        table[1].owner = OWNER_USER;
        table[1].is_active = 1;

        uint32_t req_base = 0x1000;
        uint32_t req_size = 0x100;

        int32_t res = module(table, 3, req_base, req_size);

        if (res == 0 && 
            table[0].is_active == 1 && 
            table[0].base == req_base && 
            table[0].size == req_size && 
            table[0].owner == OWNER_USER) {
            printf("[CASE-1] PASS: Successfully allocated first slot with correct metadata\n");
        } else {
            printf("[CASE-1] FAIL: Expected index 0. Got %d. Slot 0 State: active=%d, base=0x%x, owner=%d\n", 
                   res, table[0].is_active, table[0].base, table[0].owner);
        }
    }

    // Case 2: Verify allocation into the second slot (index 1) when index 0 is occupied.
    {
        Region table[3];
        memset(table, 0, sizeof(table));

        // Setup: Slot 0 is active, Slot 1 is free
        table[0].base = 0x1000;
        table[0].size = 0x100;
        table[0].owner = OWNER_USER;
        table[0].is_active = 1;

        // Request non-overlapping region
        uint32_t req_base = 0x2000;
        uint32_t req_size = 0x100;

        int32_t res = module(table, 3, req_base, req_size);

        if (res == 1 && 
            table[1].is_active == 1 && 
            table[1].base == req_base && 
            table[1].size == req_size && 
            table[1].owner == OWNER_USER &&
            // Verify slot 0 remains unchanged
            table[0].base == 0x1000 &&
            table[0].is_active == 1) {
            printf("[CASE-2] PASS: Successfully skipped occupied slot and allocated second slot\n");
        } else {
            printf("[CASE-2] FAIL: Expected index 1. Got %d. Slot 1 State: active=%d, base=0x%x\n", 
                   res, table[1].is_active, table[1].base);
        }
    }

    return 0;
}