#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Data structures and constants defined in the problem
typedef struct {
    uint32_t base;
    uint32_t size;
    uint8_t owner;
    uint8_t is_active;
} Region;

#define OWNER_USER 1
#define OWNER_SYSTEM 2

// External function declaration
extern int32_t module(Region *region_table, size_t table_cap, uint32_t req_base, uint32_t req_size);

int main() {
    // Test Case 1: First slot is free
    {
        Region table[3];
        memset(table, 0, sizeof(table));
        
        // Setup: Index 0 is free (is_active=0), Index 1 is occupied
        table[0].is_active = 0;
        
        table[1].is_active = 1;
        table[1].base = 0x2000;
        table[1].size = 0x100;
        table[1].owner = OWNER_USER;
        
        table[2].is_active = 0;

        // Request non-overlapping memory
        int32_t result = module(table, 3, 0x1000, 0x100);

        if (result == 0) {
            printf("[CASE-1] PASS: Correctly identified index 0 as the first free slot.\n");
        } else {
            printf("[CASE-1] FAIL: Expected index 0, got %d.\n", result);
        }
    }

    // Test Case 2: First slot occupied, second slot free
    {
        Region table[3];
        memset(table, 0, sizeof(table));
        
        // Setup: Index 0 is occupied, Index 1 is free
        table[0].is_active = 1;
        table[0].base = 0x1000;
        table[0].size = 0x100;
        table[0].owner = OWNER_USER;
        
        table[1].is_active = 0;
        
        table[2].is_active = 0;

        // Request non-overlapping memory
        int32_t result = module(table, 3, 0x2000, 0x100);

        if (result == 1) {
            printf("[CASE-2] PASS: Correctly skipped index 0 and identified index 1 as the first free slot.\n");
        } else {
            printf("[CASE-2] FAIL: Expected index 1, got %d.\n", result);
        }
    }

    // Test Case 3: Multiple occupied slots at start
    {
        Region table[5];
        memset(table, 0, sizeof(table));
        
        // Setup: Indices 0, 1 occupied. Index 2 free. Index 3 occupied.
        table[0].is_active = 1;
        table[0].base = 0x1000;
        table[0].size = 0x100;
        table[0].owner = OWNER_USER;

        table[1].is_active = 1;
        table[1].base = 0x2000;
        table[1].size = 0x100;
        table[1].owner = OWNER_USER;

        table[2].is_active = 0; // Target

        table[3].is_active = 1;
        table[3].base = 0x4000;
        table[3].size = 0x100;
        table[3].owner = OWNER_USER;
        
        table[4].is_active = 0;

        // Request non-overlapping memory
        int32_t result = module(table, 5, 0x3000, 0x100);

        if (result == 2) {
            printf("[CASE-3] PASS: Correctly skipped indices 0,1 and identified index 2 as the first free slot.\n");
        } else {
            printf("[CASE-3] FAIL: Expected index 2, got %d.\n", result);
        }
    }

    return 0;
}