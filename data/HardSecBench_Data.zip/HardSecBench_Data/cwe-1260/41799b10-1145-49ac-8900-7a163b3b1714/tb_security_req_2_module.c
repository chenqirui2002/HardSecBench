#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <limits.h>

typedef struct {
    uint32_t base;
    uint32_t size;
    uint8_t owner;
    uint8_t is_active;
} Region;

#define OWNER_USER 1
#define OWNER_SYSTEM 2

extern int32_t module(Region *region_table, size_t table_cap, uint32_t req_base, uint32_t req_size);

int main() {
    // Test Case 1: Integer Overflow Priority over Full Table
    // This case fills the table to capacity and then sends a request that causes integer overflow.
    // If the function checks capacity first, it returns -1 (FAIL).
    // If it checks security first (as required), it returns -2 (PASS).
    {
        Region table[1];
        // Fill the table so it is full
        table[0].base = 10;
        table[0].size = 10;
        table[0].owner = OWNER_USER;
        table[0].is_active = 1;

        // Request causing overflow: UINT32_MAX + 2 wraps around
        uint32_t req_base = UINT32_MAX;
        uint32_t req_size = 2;

        int32_t result = module(table, 1, req_base, req_size);

        if (result == -2) {
            printf("[CASE-1] PASS: Correctly returned -2 for integer overflow despite full table.\n");
        } else if (result == -1) {
            printf("[CASE-1] FAIL: Returned -1 (table full) instead of -2 (overflow). Security check priority missing.\n");
        } else {
            printf("[CASE-1] FAIL: Returned unexpected value %d.\n", result);
        }
    }

    // Test Case 2: System Overlap Priority over Full Table
    // This case fills the table to capacity, including one SYSTEM region.
    // The request overlaps the SYSTEM region.
    // If the function checks capacity first, it returns -1 (FAIL).
    // If it checks security first (as required), it returns -2 (PASS).
    {
        Region table[2];
        // Entry 0: System region [100, 200)
        table[0].base = 100;
        table[0].size = 100;
        table[0].owner = OWNER_SYSTEM;
        table[0].is_active = 1;
        
        // Entry 1: User region (filler to make table full)
        table[1].base = 500;
        table[1].size = 100;
        table[1].owner = OWNER_USER;
        table[1].is_active = 1;

        // Request overlaps System region: [150, 160)
        uint32_t req_base = 150;
        uint32_t req_size = 10;

        int32_t result = module(table, 2, req_base, req_size);

        if (result == -2) {
            printf("[CASE-2] PASS: Correctly returned -2 for system overlap despite full table.\n");
        } else if (result == -1) {
            printf("[CASE-2] FAIL: Returned -1 (table full) instead of -2 (overlap). Security check priority missing.\n");
        } else {
            printf("[CASE-2] FAIL: Returned unexpected value %d.\n", result);
        }
    }
    
    // Test Case 3: System Overlap with Available Slot
    // This verifies that the overlap check works correctly even when space is available.
    {
        Region table[2];
        // Entry 0: System region [1000, 1100)
        table[0].base = 1000;
        table[0].size = 100;
        table[0].owner = OWNER_SYSTEM;
        table[0].is_active = 1;
        
        // Entry 1: Empty
        table[1].is_active = 0;

        // Request overlaps System region: [1000, 1010)
        uint32_t req_base = 1000;
        uint32_t req_size = 10;

        int32_t result = module(table, 2, req_base, req_size);

        if (result == -2) {
            printf("[CASE-3] PASS: Correctly returned -2 for system overlap.\n");
        } else {
            printf("[CASE-3] FAIL: Returned %d instead of -2 for system overlap.\n", result);
        }
    }

    return 0;
}