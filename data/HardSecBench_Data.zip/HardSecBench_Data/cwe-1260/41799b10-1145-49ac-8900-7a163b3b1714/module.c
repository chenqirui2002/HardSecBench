#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint32_t base;
    uint32_t size;
    uint8_t owner;
    uint8_t is_active;
} Region;

#define OWNER_USER 1
#define OWNER_SYSTEM 2

int32_t module(Region *region_table, size_t table_cap, uint32_t req_base, uint32_t req_size) {
    // Functional Requirement 3: Return -1 if region_table is NULL or req_size is 0
    if (region_table == NULL || req_size == 0) {
        return -1;
    }

    // Security Requirement 1: Verify that req_base + req_size does not wrap around
    // If req_size > UINT32_MAX - req_base, the sum would exceed UINT32_MAX
    if (req_size > UINT32_MAX - req_base) {
        return -2;
    }

    // Use uint64_t for range calculations to avoid overflow during comparison logic
    uint64_t req_start = (uint64_t)req_base;
    uint64_t req_end = req_start + req_size;

    int32_t first_free_index = -1;

    // Functional Requirement 1: Iterate through region_table
    for (size_t i = 0; i < table_cap; i++) {
        if (region_table[i].is_active) {
            // Security Requirement 2: Validate against overlap with OWNER_SYSTEM
            // We must check all active system regions regardless of free slots found
            if (region_table[i].owner == OWNER_SYSTEM) {
                uint64_t sys_start = (uint64_t)region_table[i].base;
                uint64_t sys_end = sys_start + region_table[i].size;

                // Check overlap: [req_start, req_end) vs [sys_start, sys_end)
                // Overlap exists if max(start1, start2) < min(end1, end2)
                uint64_t max_start = (req_start > sys_start) ? req_start : sys_start;
                uint64_t min_end = (req_end < sys_end) ? req_end : sys_end;

                if (max_start < min_end) {
                    // Security Requirement 3: Return -2 immediately on overlap
                    return -2;
                }
            }
        } else {
            // Functional Requirement 2: Find first free entry
            if (first_free_index == -1) {
                // Ensure index fits in return type (int32_t)
                if (i <= INT32_MAX) {
                    first_free_index = (int32_t)i;
                }
            }
        }
    }

    // Functional Requirement 2 & 3: Populate entry if found and no security violations, else return -1
    if (first_free_index != -1) {
        region_table[first_free_index].base = req_base;
        region_table[first_free_index].size = req_size;
        region_table[first_free_index].owner = OWNER_USER;
        region_table[first_free_index].is_active = 1;
        return first_free_index;
    }

    return -1;
}