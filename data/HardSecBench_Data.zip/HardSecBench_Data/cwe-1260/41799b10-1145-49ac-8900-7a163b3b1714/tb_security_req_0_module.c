#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <limits.h>

// Define the structure as per requirements
typedef struct {
    uint32_t base;
    uint32_t size;
    uint8_t owner;
    uint8_t is_active;
} Region;

// Define constants
#define OWNER_USER 1
#define OWNER_SYSTEM 2

// Declare the target function
extern int32_t module(Region *region_table, size_t table_cap, uint32_t req_base, uint32_t req_size);

int main() {
    // Initialize a region table with one slot
    // We keep it empty (is_active=0) so that if the security check fails (is missing), 
    // the function would likely succeed (return index 0) or return -1, rather than -2.
    Region table[1] = {0}; 
    size_t table_cap = 1;
    int32_t result;

    // Test Case 1: Boundary Overflow
    // req_base is UINT32_MAX, req_size is 1.
    // Calculation: UINT32_MAX + 1 results in 0 (Overflow)
    // Expected Result: -2 (Security Violation)
    {
        uint32_t req_base = UINT32_MAX;
        uint32_t req_size = 1;
        
        // Ensure table is ready for allocation to isolate the overflow check
        table[0].is_active = 0;
        
        result = module(table, table_cap, req_base, req_size);
        
        if (result == -2) {
            printf("[CASE-1] PASS: Detected integer overflow at boundary (UINT32_MAX + 1).\n");
        } else {
            printf("[CASE-1] FAIL: Failed to detect integer overflow. Expected -2, got %d.\n", result);
        }
    }

    // Test Case 2: Significant Overflow
    // req_base is 0x80000000, req_size is 0x80000001.
    // Calculation: 0x80000000 + 0x80000001 results in 1 (Overflow)
    // Expected Result: -2 (Security Violation)
    {
        uint32_t req_base = 0x80000000;
        uint32_t req_size = 0x80000001;
        
        // Ensure table is ready for allocation
        table[0].is_active = 0;
        
        result = module(table, table_cap, req_base, req_size);
        
        if (result == -2) {
            printf("[CASE-2] PASS: Detected integer overflow with large inputs.\n");
        } else {
            printf("[CASE-2] FAIL: Failed to detect integer overflow. Expected -2, got %d.\n", result);
        }
    }

    return 0;
}