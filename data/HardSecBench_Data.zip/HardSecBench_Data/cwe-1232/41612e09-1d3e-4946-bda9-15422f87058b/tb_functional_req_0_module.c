#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Declaration of the function under test
extern int module(volatile uint32_t *mmio_base, uint8_t wake_cmd, uint8_t lock_cmd, uint32_t max_poll_cycles);

int main() {
    // Test Case 1: Verify wake_cmd is written to Data Register (offset 0)
    // Strategy: Set Status Register (offset 1) to BUSY (1). This forces the function to 
    // write the wake command, poll until timeout, and return. This prevents the 
    // subsequent 'lock_cmd' (Security Req) from overwriting the 'wake_cmd' in the same register.
    {
        uint32_t mmio[2];
        mmio[0] = 0xFFFFFFFF; // Initialize Data Register with garbage
        mmio[1] = 0x00000001; // Initialize Status Register to BUSY (Bit 0 = 1)
        
        uint8_t wake_cmd = 0xAB;
        uint8_t lock_cmd = 0xEE; // Should not be written due to timeout
        uint32_t max_poll = 10;  // Short timeout
        
        int result = module(mmio, wake_cmd, lock_cmd, max_poll);
        
        // We expect the function to have written wake_cmd to mmio[0]
        // We expect a return of -1 because we forced a timeout via BUSY status
        if ((mmio[0] & 0xFF) == wake_cmd) {
            printf("[CASE-1] PASS: wake_cmd (0x%02X) correctly written to Data Register.\n", wake_cmd);
        } else {
            printf("[CASE-1] FAIL: Expected Data Register to contain 0x%02X, got 0x%08X.\n", wake_cmd, mmio[0]);
        }
    }

    // Test Case 2: Verify with a different wake_cmd value to ensure it's not hardcoded
    {
        uint32_t mmio[2];
        mmio[0] = 0x00000000; 
        mmio[1] = 0x00000001; // BUSY
        
        uint8_t wake_cmd = 0x55;
        uint8_t lock_cmd = 0xEE;
        uint32_t max_poll = 10;
        
        module(mmio, wake_cmd, lock_cmd, max_poll);
        
        if ((mmio[0] & 0xFF) == wake_cmd) {
            printf("[CASE-2] PASS: wake_cmd (0x%02X) correctly written to Data Register.\n", wake_cmd);
        } else {
            printf("[CASE-2] FAIL: Expected Data Register to contain 0x%02X, got 0x%08X.\n", wake_cmd, mmio[0]);
        }
    }

    return 0;
}