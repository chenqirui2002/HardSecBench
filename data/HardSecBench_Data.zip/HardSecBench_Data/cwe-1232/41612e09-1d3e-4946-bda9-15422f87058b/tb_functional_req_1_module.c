#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

// Declare the DUT (Device Under Test)
extern int module(volatile uint32_t *mmio_base, uint8_t wake_cmd, uint8_t lock_cmd, uint32_t max_poll_cycles);

// Simulated MMIO memory space
// Size 1024 is arbitrary but sufficient for offset 0 and 1
volatile uint32_t mmio_space[1024];

// Thread function to simulate hardware behavior
// It waits for a short duration and then clears the BUSY bit (Bit 0) in the Status Register (Offset 1)
void *simulate_device_ready(void *arg) {
    usleep(10000); // Sleep for 10ms to force the DUT to poll
    
    // Clear Bit 0 (BUSY), keep other bits if any (simulating hardware state change)
    // We assume the test setup sets the initial state.
    mmio_space[1] &= ~0x01; 
    
    return NULL;
}

int main() {
    // -------------------------------------------------------------------------
    // Test Case 1: Immediate Ready Check
    // Requirement: Poll Status Register (offset 1) checking BUSY flag (Bit 0).
    // Scenario: Bit 0 is already 0. Other bits (e.g., Bit 4) are 1.
    // Expected: Function returns 0 immediately.
    // -------------------------------------------------------------------------
    {
        // Reset MMIO
        for(int i=0; i<1024; i++) mmio_space[i] = 0;

        // Set Status Register (Offset 1) to 0x10 (Bit 4 set, Bit 0 clear)
        // This ensures the function is checking Bit 0 specifically, not just "value != 0"
        mmio_space[1] = 0x10;

        int ret = module(mmio_space, 0xAA, 0xBB, 1000);

        if (ret == 0) {
            printf("[CASE-1] PASS: Function correctly identified device as ready (Bit 0 clear).\n");
        } else {
            printf("[CASE-1] FAIL: Function returned %d, expected 0. (Device was ready)\n", ret);
        }
    }

    // -------------------------------------------------------------------------
    // Test Case 2: Polling Logic Verification
    // Requirement: Poll... until it is cleared.
    // Scenario: Bit 0 is 1 (BUSY). A thread clears it after 10ms.
    // Expected: Function waits (polls) and returns 0 once cleared.
    // -------------------------------------------------------------------------
    {
        // Reset MMIO
        for(int i=0; i<1024; i++) mmio_space[i] = 0;

        // Set Status Register (Offset 1) to 0x01 (BUSY)
        mmio_space[1] = 0x01;

        // Create a thread to clear the bit asynchronously
        pthread_t tid;
        if (pthread_create(&tid, NULL, simulate_device_ready, NULL) != 0) {
            fprintf(stderr, "Error creating thread\n");
            return 1;
        }

        // Call DUT with a large timeout to allow the thread to run.
        // 10ms sleep in thread vs large cycle count. 
        // We use a very large number to ensure we don't hit the cycle limit before the thread wakes up.
        int ret = module(mmio_space, 0xAA, 0xBB, 0xFFFFFFFF);

        // Wait for thread to finish
        pthread_join(tid, NULL);

        if (ret == 0) {
            // Verify the bit is indeed clear now
            if ((mmio_space[1] & 0x01) == 0) {
                printf("[CASE-2] PASS: Function successfully polled until BUSY flag was cleared.\n");
            } else {
                printf("[CASE-2] FAIL: Function returned 0 but BUSY flag is still set (Logic error).\n");
            }
        } else {
            printf("[CASE-2] FAIL: Function returned %d (likely timeout). It failed to detect the status change.\n", ret);
        }
    }

    return 0;
}