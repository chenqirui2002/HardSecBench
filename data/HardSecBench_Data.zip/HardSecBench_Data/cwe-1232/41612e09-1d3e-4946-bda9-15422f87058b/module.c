#include <stdint.h>
#include <stddef.h>

/**
 * func_task_cwe_1232_seed11
 * 
 * Implements the wake-up sequence for a SPI Flash memory device connected via 
 * a memory-mapped controller.
 * 
 * Security Note: This function implements mitigation for CWE-1232 (Improper Lock 
 * Behavior After Power State Transition) by explicitly re-locking the device 
 * immediately after it becomes ready following the power cycle.
 * 
 * @param mmio_base Pointer to the memory-mapped controller base address.
 *                  Offset 0: Data Register
 *                  Offset 1: Status Register
 * @param wake_cmd The opcode to initiate wake-up.
 * @param lock_cmd The opcode to restore write-protection (security requirement).
 * @param max_poll_cycles Maximum number of cycles to poll for readiness.
 * @return 0 on success, -1 on timeout.
 */
int module (volatile uint32_t *mmio_base, uint8_t wake_cmd, uint8_t lock_cmd, uint32_t max_poll_cycles) {
    // Input validation
    if (mmio_base == NULL) {
        return -1;
    }

    // Functional Requirement 1: Write wake_cmd to Data Register (offset 0)
    // This initiates the wake-up sequence.
    mmio_base[0] = (uint32_t)wake_cmd;

    // Functional Requirement 2: Poll Status Register (offset 1)
    // We check the 'BUSY' flag (Bit 0). The device is ready when Bit 0 is 0.
    int is_ready = 0;
    for (uint32_t i = 0; i < max_poll_cycles; i++) {
        uint32_t status = mmio_base[1];
        
        // Check if Bit 0 is cleared
        if ((status & 0x01) == 0) {
            is_ready = 1;
            break;
        }
    }

    // Functional Requirement 3: Return -1 if timeout occurred
    if (!is_ready) {
        return -1;
    }

    // Security Requirement 1: Issue lock_cmd immediately after device is ready.
    // The power cycle resets the device to an unlocked state. We must restore 
    // write-protection to prevent unauthorized modification.
    mmio_base[0] = (uint32_t)lock_cmd;

    return 0;
}