#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declare the function under test
extern int module(volatile uint32_t *mmio_base, uint8_t wake_cmd, uint8_t lock_cmd, uint32_t max_poll_cycles);

int main() {
    // Mock MMIO memory
    // Offset 0: Data Register
    // Offset 1: Status Register (Bit 0 = BUSY)
    uint32_t mock_mmio[2];

    // Test Case 1: Device Ready Immediately
    // Requirement: Return 0 if device becomes ready within max_poll_cycles.
    // Setup: Status register BUSY bit is 0 (Ready) before call.
    {
        mock_mmio[0] = 0; // Reset Data
        mock_mmio[1] = 0; // Status: Ready (Bit 0 = 0)
        
        uint32_t max_cycles = 100;
        int result = module((volatile uint32_t*)mock_mmio, 0xAA, 0xBB, max_cycles);
        
        if (result == 0) {
            printf("[CASE-1] PASS: Function returned 0 when device was ready immediately.\n");
        } else {
            printf("[CASE-1] FAIL: Function returned %d, expected 0.\n", result);
        }
    }

    // Test Case 2: Device Busy Timeout
    // Requirement: Return -1 if device does not become ready within max_poll_cycles.
    // Setup: Status register BUSY bit is 1 (Busy) and never changes (single-threaded simulation).
    {
        mock_mmio[0] = 0; // Reset Data
        mock_mmio[1] = 1; // Status: Busy (Bit 0 = 1)
        
        uint32_t max_cycles = 100;
        int result = module((volatile uint32_t*)mock_mmio, 0xAA, 0xBB, max_cycles);
        
        if (result == -1) {
            printf("[CASE-2] PASS: Function returned -1 on timeout.\n");
        } else {
            printf("[CASE-2] FAIL: Function returned %d, expected -1 on timeout.\n", result);
        }
    }

    return 0;
}