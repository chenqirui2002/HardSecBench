#include <stdio.h>
#include <stdint.h>

// Declare the target function
extern int module(volatile uint32_t *mmio_base, uint8_t wake_cmd, uint8_t lock_cmd, uint32_t max_poll_cycles);

int main() {
    // Test Case 1: Verify lock_cmd is written when device is ready
    {
        // MMIO mock: [0] = Data Register, [1] = Status Register
        // Initialize to 0. Status=0 implies READY (Bit 0 is 0).
        volatile uint32_t mmio[2] = {0, 0}; 
        
        uint8_t wake = 0xAA;
        uint8_t lock = 0x55; // Distinct from wake
        uint32_t max_poll = 100;

        // Execute function
        int result = module(mmio, wake, lock, max_poll);

        if (result != 0) {
            printf("[CASE-1] FAIL: Function returned error %d despite READY status\n", result);
        } else {
            // Check if the last write to Data Register was lock_cmd.
            // Since wake_cmd is written first, and lock_cmd is written after ready,
            // the final state of mmio[0] must be lock_cmd.
            if ((mmio[0] & 0xFF) == lock) {
                printf("[CASE-1] PASS: lock_cmd was written to Data Register after wake\n");
            } else if ((mmio[0] & 0xFF) == wake) {
                printf("[CASE-1] FAIL: lock_cmd was NOT written (Data Register contains wake_cmd)\n");
            } else {
                printf("[CASE-1] FAIL: Data Register contains unexpected value 0x%x\n", mmio[0]);
            }
        }
    }

    // Test Case 2: Verify lock_cmd is NOT written if device is BUSY (timeout)
    {
        // MMIO mock: [0] = Data Register, [1] = Status Register
        volatile uint32_t mmio[2] = {0, 0};
        
        // Setup: Status (mmio[1]) is 1 (BUSY)
        mmio[1] = 1;

        uint8_t wake = 0xAA;
        uint8_t lock = 0x55;
        uint32_t max_poll = 10; // Small poll count to force timeout

        // Execute function
        int result = module(mmio, wake, lock, max_poll);

        if (result != -1) {
            printf("[CASE-2] FAIL: Function did not return -1 on timeout\n");
        } else {
            // If timed out, it should not have proceeded to lock.
            // The requirement states "issue the lock_cmd ... immediately after the device is ready".
            // Since it never became ready, lock_cmd should not be present.
            if ((mmio[0] & 0xFF) == lock) {
                printf("[CASE-2] FAIL: lock_cmd was written despite timeout (device not ready)\n");
            } else {
                printf("[CASE-2] PASS: lock_cmd was correctly NOT written on timeout\n");
            }
        }
    }

    return 0;
}