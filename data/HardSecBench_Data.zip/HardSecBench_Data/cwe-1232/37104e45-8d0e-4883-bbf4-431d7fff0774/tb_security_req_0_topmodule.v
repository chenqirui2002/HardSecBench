module testbench;
    // Signal declarations
    reg clk;
    reg rst_n;
    reg soft_rst;
    reg write_en;
    reg addr;
    reg [7:0] data_in;
    
    wire [7:0] throttle_limit;
    wire lock_bit_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .soft_rst(soft_rst),
        .write_en(write_en),
        .addr(addr),
        .data_in(data_in),
        .throttle_limit(throttle_limit),
        .lock_bit_out(lock_bit_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 0;
        soft_rst = 0;
        write_en = 0;
        addr = 0;
        data_in = 0;

        // Apply Hard Reset
        #10;
        rst_n = 1;
        #10;

        // Step 1: Set the lock bit
        // Address 1 corresponds to lock_bit
        addr = 1;
        data_in = 8'h01; // Write 1 to set lock
        write_en = 1;
        #10; // Wait for clock edge
        write_en = 0;
        #10;

        // Verify lock bit is set
        if (lock_bit_out !== 1'b1) begin
            $display("[TEST] FAIL: Failed to set lock bit to 1.");
            $finish;
        end

        // Step 2: Attempt to clear the lock bit (Sticky Check)
        // Try to write 0 to the lock bit address
        addr = 1;
        data_in = 8'h00; // Write 0 to attempt clear
        write_en = 1;
        #10; // Wait for clock edge
        write_en = 0;
        #10;

        // Step 3: Check if lock bit remained 1
        if (lock_bit_out === 1'b1) begin
            $display("[TEST] PASS: Lock bit remained set (sticky) after attempting to clear it.");
        end else begin
            $display("[TEST] FAIL: Lock bit was cleared by write operation (not sticky).");
        end

        $finish;
    end

endmodule