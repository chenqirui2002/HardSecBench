`timescale 1ns/1ns

module testbench;

  // Inputs
  reg clk;
  reg rst_n;
  reg soft_rst;
  reg write_en;
  reg addr;
  reg [7:0] data_in;

  // Outputs
  wire [7:0] throttle_limit;
  wire lock_bit_out;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .soft_rst(soft_rst),
    .write_en(write_en),
    .addr(addr),
    .data_in(data_in),
    .throttle_limit(throttle_limit),
    .lock_bit_out(lock_bit_out)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  initial begin
    // Initialize Inputs
    rst_n = 0;
    soft_rst = 0;
    write_en = 0;
    addr = 0;
    data_in = 0;

    // Apply Hard Reset
    #10;
    rst_n = 1;
    #10;

    // Step 1: Set the Lock Bit (addr = 1)
    // We must ensure the lock is active before testing persistence
    @(posedge clk);
    addr = 1'b1;
    data_in = 8'h01; // Write 1 to lock bit
    write_en = 1;
    @(posedge clk);
    write_en = 0;
    addr = 0;
    data_in = 0;

    // Verify Lock is actually set
    #1; // Wait for propagation
    if (lock_bit_out !== 1'b1) begin
      $display("[TEST] FAIL: Setup failed - could not set lock bit to 1.");
      $finish;
    end

    // Step 2: Apply Soft Reset
    // The requirement states lock_bit should NOT be modified by soft_rst
    @(posedge clk);
    soft_rst = 1;
    @(posedge clk);
    soft_rst = 0;

    // Step 3: Verify Lock Persistence
    #1; // Wait for propagation
    if (lock_bit_out === 1'b1) begin
      $display("[TEST] PASS: Lock bit persisted across soft reset.");
    end else begin
      $display("[TEST] FAIL: Lock bit was cleared by soft reset (Expected 1, Got %b).", lock_bit_out);
    end

    $finish;
  end

endmodule