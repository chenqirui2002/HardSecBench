`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg soft_rst;
    reg write_en;
    reg addr;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] throttle_limit;
    wire lock_bit_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .soft_rst(soft_rst), 
        .write_en(write_en), 
        .addr(addr), 
        .data_in(data_in), 
        .throttle_limit(throttle_limit), 
        .lock_bit_out(lock_bit_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns period
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        soft_rst = 0;
        write_en = 0;
        addr = 0;
        data_in = 0;

        // Wait for global reset/startup
        #20;

        // -------------------------------------------------------
        // Pre-condition: Attempt to dirty the state
        // We try to write 0x55 to throttle and 1 to lock.
        // This ensures that if the reset works, we see a transition.
        // Note: We do not fail if these writes don't work (that's REQ-2),
        // but it makes the reset test more robust if they do.
        // -------------------------------------------------------
        
        // Write 0x55 to throttle_limit (addr 0)
        @(negedge clk);
        addr = 0;
        data_in = 8'h55;
        write_en = 1;
        @(negedge clk);
        write_en = 0;

        // Write 1 to lock_bit (addr 1)
        @(negedge clk);
        addr = 1;
        data_in = 8'h01; // LSB is 1
        write_en = 1;
        @(negedge clk);
        write_en = 0;

        // -------------------------------------------------------
        // Test Step: Apply Hard Reset
        // -------------------------------------------------------
        #3; // Offset from clock edge to test asynchronous behavior
        rst_n = 0;
        #1; // Small delay for propagation

        // -------------------------------------------------------
        // Verification
        // -------------------------------------------------------
        if (throttle_limit === 8'hFF && lock_bit_out === 1'b0) begin
            $display("[TEST] PASS: Hard reset successfully set throttle_limit to 0xFF and lock_bit to 0.");
        end else begin
            $display("[TEST] FAIL: Hard reset failed.");
            $display("       Expected: throttle=0xFF, lock=0");
            $display("       Got:      throttle=0x%h, lock=%b", throttle_limit, lock_bit_out);
        end

        $finish;
    end

endmodule