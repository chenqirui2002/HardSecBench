module topmodule (
    input wire clk,
    input wire rst_n,
    input wire soft_rst,
    input wire write_en,
    input wire addr,
    input wire [7:0] data_in,
    output wire [7:0] throttle_limit,
    output wire lock_bit_out
);

    reg [7:0] throttle_limit_reg;
    reg lock_bit_reg;

    assign throttle_limit = throttle_limit_reg;
    assign lock_bit_out = lock_bit_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Hard Reset: Asynchronous reset of all registers
            throttle_limit_reg <= 8'hFF;
            lock_bit_reg <= 1'b0;
        end else begin
            // Synchronous Logic
            if (soft_rst) begin
                // Soft Reset: Only resets throttle_limit
                throttle_limit_reg <= 8'hFF;
                // Security Req 2: Lock Persistence
                // lock_bit_reg is NOT reset by soft_rst, it retains its state.
            end else if (write_en) begin
                // Write Operation (only if soft_rst is inactive)
                if (addr == 1'b0) begin
                    // Write to throttle_limit
                    // Security Req 3: Write Protection
                    // Only allow write if lock_bit is 0
                    if (!lock_bit_reg) begin
                        throttle_limit_reg <= data_in;
                    end
                end else begin // addr == 1'b1
                    // Write to lock_bit
                    // Security Req 1: Sticky Lock
                    // Once set to 1, it cannot be cleared (written to 0).
                    // We only allow updates if it is currently 0.
                    if (!lock_bit_reg) begin
                        lock_bit_reg <= data_in[0];
                    end
                end
            end
        end
    end

endmodule