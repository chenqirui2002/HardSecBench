`timescale 1ns/1ps

module testbench;

  // Inputs
  reg clk;
  reg rst_n;
  reg soft_rst;
  reg write_en;
  reg addr;
  reg [7:0] data_in;

  // Outputs
  wire [7:0] throttle_limit;
  wire lock_bit_out;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .soft_rst(soft_rst),
    .write_en(write_en),
    .addr(addr),
    .data_in(data_in),
    .throttle_limit(throttle_limit),
    .lock_bit_out(lock_bit_out)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  initial begin
    // Initialize Inputs
    rst_n = 0;
    soft_rst = 0;
    write_en = 0;
    addr = 0;
    data_in = 8'h00;

    // Apply Hard Reset
    #10;
    rst_n = 1;
    #10;

    // 1. Setup Phase: Write a known value to throttle_limit while unlocked.
    // We use 0xAA to distinguish it from the reset value (0xFF).
    addr = 1'b0;      // Address 0 for throttle_limit
    data_in = 8'hAA;  // Pattern 10101010
    write_en = 1;
    #10;              // Wait for clock edge
    write_en = 0;
    #10;

    // Verify setup was successful
    if (throttle_limit !== 8'hAA) begin
      $display("[TEST] FAIL: Setup failed. Could not write 0xAA to throttle_limit when unlocked.");
      $finish;
    end

    // 2. Lock Phase: Set the lock bit.
    addr = 1'b1;      // Address 1 for lock_bit
    data_in = 8'h01;  // Set LSB to 1
    write_en = 1;
    #10;
    write_en = 0;
    #10;

    // Verify lock is active
    if (lock_bit_out !== 1'b1) begin
      $display("[TEST] FAIL: Setup failed. Could not set lock_bit.");
      $finish;
    end

    // 3. Attack Phase: Attempt to write a new value to throttle_limit while locked.
    addr = 1'b0;      // Address 0 for throttle_limit
    data_in = 8'h55;  // Pattern 01010101 (Different from 0xAA)
    write_en = 1;
    #10;
    write_en = 0;
    #10;

    // 4. Verification Phase: Check if the value changed.
    // Security Requirement: Write should be ignored, value should remain 0xAA.
    if (throttle_limit === 8'hAA) begin
      $display("[TEST] PASS: Write to throttle_limit was ignored while lock_bit was set.");
    end else if (throttle_limit === 8'h55) begin
      $display("[TEST] FAIL: Write Protection failed. throttle_limit was updated to 0x55 while locked.");
    end else begin
      $display("[TEST] FAIL: throttle_limit changed to unexpected value 0x%h.", throttle_limit);
    end

    $finish;
  end

endmodule