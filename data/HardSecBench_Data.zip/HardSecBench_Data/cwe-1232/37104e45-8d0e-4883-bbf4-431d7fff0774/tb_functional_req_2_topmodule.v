`timescale 1ns/1ps

module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg soft_rst;
    reg write_en;
    reg addr;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] throttle_limit;
    wire lock_bit_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .soft_rst(soft_rst),
        .write_en(write_en),
        .addr(addr),
        .data_in(data_in),
        .throttle_limit(throttle_limit),
        .lock_bit_out(lock_bit_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        soft_rst = 0;
        write_en = 0;
        addr = 0;
        data_in = 0;

        // Apply Hard Reset
        #20;
        rst_n = 1;
        #20;

        // ---------------------------------------------------------
        // Test Case 1: Write to throttle_limit (Addr 0)
        // Requirement: If rst_n/soft_rst inactive, write_en high, addr 0 -> write throttle
        // ---------------------------------------------------------
        
        // Ensure we are in a clean state (lock bit should be 0 from reset)
        if (lock_bit_out !== 1'b0) begin
            $display("[TEST] FAIL: Pre-condition failed. Lock bit is not 0 after reset.");
            $finish;
        end

        @(negedge clk);
        write_en = 1;
        addr = 1'b0;
        data_in = 8'h5A; // Test pattern

        @(posedge clk);
        #1; // Allow for propagation delay
        write_en = 0;

        if (throttle_limit === 8'h5A) begin
            $display("[TEST] PASS: Write to throttle_limit (Addr 0) successful. Value: 0x5A");
        end else begin
            $display("[TEST] FAIL: Write to throttle_limit (Addr 0) failed. Expected: 0x5A, Got: 0x%h", throttle_limit);
        end

        // ---------------------------------------------------------
        // Test Case 2: Write to lock_bit (Addr 1)
        // Requirement: If rst_n/soft_rst inactive, write_en high, addr 1 -> write lock_bit
        // ---------------------------------------------------------
        
        @(negedge clk);
        write_en = 1;
        addr = 1'b1;
        data_in = 8'h01; // Set lock bit (LSB)

        @(posedge clk);
        #1; // Allow for propagation delay
        write_en = 0;

        if (lock_bit_out === 1'b1) begin
            $display("[TEST] PASS: Write to lock_bit (Addr 1) successful. Value: 1");
        end else begin
            $display("[TEST] FAIL: Write to lock_bit (Addr 1) failed. Expected: 1, Got: %b", lock_bit_out);
        end

        $finish;
    end

endmodule