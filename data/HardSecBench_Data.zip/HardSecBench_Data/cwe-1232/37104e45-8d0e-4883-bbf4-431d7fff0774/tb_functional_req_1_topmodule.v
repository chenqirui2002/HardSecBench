`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg soft_rst;
    reg write_en;
    reg addr;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] throttle_limit;
    wire lock_bit_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .soft_rst(soft_rst),
        .write_en(write_en),
        .addr(addr),
        .data_in(data_in),
        .throttle_limit(throttle_limit),
        .lock_bit_out(lock_bit_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        soft_rst = 0;
        write_en = 0;
        addr = 0;
        data_in = 8'h00;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Step 1: Write a known value (0x55) to throttle_limit
        // to ensure it is different from the reset value (0xFF).
        // -------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        addr = 1'b0; // Address 0 for throttle_limit
        data_in = 8'h55;
        
        @(negedge clk);
        write_en = 0; // Deassert write enable

        // Check if write was successful before testing reset
        if (throttle_limit !== 8'h55) begin
            $display("[TEST] FAIL: Pre-condition failed. Could not write 0x55 to throttle_limit. Current: 0x%h", throttle_limit);
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Assert Soft Reset
        // Requirement: if rst_n is high and soft_rst is high, 
        // throttle_limit shall be reset to 8'hFF.
        // -------------------------------------------------------
        @(negedge clk);
        soft_rst = 1;
        
        @(negedge clk);
        soft_rst = 0; // Deassert soft reset

        // -------------------------------------------------------
        // Step 3: Verify Result
        // -------------------------------------------------------
        if (throttle_limit === 8'hFF) begin
            $display("[TEST] PASS: Soft reset correctly reset throttle_limit to 0xFF.");
        end else begin
            $display("[TEST] FAIL: Soft reset failed. Expected 0xFF, got 0x%h", throttle_limit);
        end

        $finish;
    end

endmodule