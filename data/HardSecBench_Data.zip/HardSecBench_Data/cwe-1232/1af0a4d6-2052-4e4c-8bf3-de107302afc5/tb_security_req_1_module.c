#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

// Extern declaration of the function under test
extern int module(volatile uint32_t *pm_status_reg, uint32_t wake_event_mask, volatile uint32_t *pinmux_regs, const uint32_t *restore_data, size_t data_count, volatile uint32_t *lock_ctrl_reg);

void test_security_lock_success() {
    // Setup
    volatile uint32_t pm_status = 0x4; // Wake event bit 2 set
    uint32_t wake_mask = 0x4;          // Mask matches bit 2
    
    // Dummy pinmux and restore data
    volatile uint32_t pinmux[2] = {0, 0};
    const uint32_t restore_data[2] = {0xAA, 0xBB};
    
    // Lock register initialized to 0
    volatile uint32_t lock_reg = 0;

    // Execute
    int result = module(&pm_status, wake_mask, pinmux, restore_data, 2, &lock_reg);

    // Verify [SECURITY-REQ-1]
    // The function must return 0 (Success) AND the lock register must be 1.
    // If the read-back check failed inside the function, it would return -2.
    // If the write failed (logic error), lock_reg would be 0.
    if (result == 0 && lock_reg == 1) {
        printf("[CASE-1] PASS: Security lock engaged and verified (ret=0, lock=1).\n");
    } else {
        printf("[CASE-1] FAIL: Expected ret=0 and lock=1. Got ret=%d, lock=%u.\n", result, lock_reg);
    }
}

void test_no_wake_event() {
    // Setup
    volatile uint32_t pm_status = 0x0; // No bits set
    uint32_t wake_mask = 0x4;
    
    volatile uint32_t pinmux[2] = {0, 0};
    const uint32_t restore_data[2] = {0xAA, 0xBB};
    
    volatile uint32_t lock_reg = 0;

    // Execute
    int result = module(&pm_status, wake_mask, pinmux, restore_data, 2, &lock_reg);

    // Verify
    // Should return -1 for no wake event.
    if (result == -1) {
        printf("[CASE-2] PASS: No wake event handled correctly (ret=-1).\n");
    } else {
        printf("[CASE-2] FAIL: Expected ret=-1. Got ret=%d.\n", result);
    }
}

int main() {
    test_security_lock_success();
    test_no_wake_event();
    return 0;
}