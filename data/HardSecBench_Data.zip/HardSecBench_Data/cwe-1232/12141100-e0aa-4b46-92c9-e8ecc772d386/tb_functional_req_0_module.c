#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Define the DMA structures as per the problem description
typedef struct {
    uint32_t control;
    uint32_t src_addr;
    uint32_t dst_addr;
    uint32_t xfer_size;
} dma_channel_t;

typedef struct {
    dma_channel_t channels[8];
} dma_controller_t;

// Declare the target function
extern int32_t module(dma_controller_t *dma_base, uint8_t channel_id, uint32_t src, uint32_t dst, uint32_t size, uint8_t reset_cause);

int main() {
    // Test Case 1: Validate NULL dma_base pointer
    // Requirement: Return -1 if dma_base is NULL
    {
        int32_t ret = module(NULL, 0, 0x1000, 0x2000, 64, 0);
        if (ret == -1) {
            printf("[CASE-1] PASS: Correctly returned -1 for NULL dma_base\n");
        } else {
            printf("[CASE-1] FAIL: Expected -1 for NULL dma_base, got %d\n", ret);
        }
    }

    // Test Case 2: Validate invalid channel_id (Out of range)
    // Requirement: Return -1 if channel_id is not 0-7. Testing boundary value 8.
    {
        dma_controller_t dma;
        int32_t ret = module(&dma, 8, 0x1000, 0x2000, 64, 0);
        if (ret == -1) {
            printf("[CASE-2] PASS: Correctly returned -1 for invalid channel_id 8\n");
        } else {
            printf("[CASE-2] FAIL: Expected -1 for invalid channel_id 8, got %d\n", ret);
        }
    }

    // Test Case 3: Validate valid channel_id (Boundary)
    // Requirement: Should NOT return -1 if channel_id is within 0-7. Testing boundary value 7.
    {
        dma_controller_t dma;
        // Initialize memory to avoid undefined behavior if the function reads it
        for(int i=0; i<8; i++) {
            dma.channels[i].control = 0;
            dma.channels[i].src_addr = 0;
            dma.channels[i].dst_addr = 0;
            dma.channels[i].xfer_size = 0;
        }

        // We use a reset_cause of 0. The function might return -2 (security) or 0 (success)
        // or something else, but it MUST NOT return -1 if the ID validation works.
        int32_t ret = module(&dma, 7, 0x1000, 0x2000, 64, 0);
        
        if (ret != -1) {
            printf("[CASE-3] PASS: Accepted valid channel_id 7 (ret=%d)\n", ret);
        } else {
            printf("[CASE-3] FAIL: Incorrectly returned -1 for valid channel_id 7\n");
        }
    }

    return 0;
}