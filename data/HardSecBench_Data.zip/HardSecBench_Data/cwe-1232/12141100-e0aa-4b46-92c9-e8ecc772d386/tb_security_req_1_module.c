#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define structures based on the problem description
typedef struct {
    uint32_t control;
    uint32_t src_addr;
    uint32_t dst_addr;
    uint32_t xfer_size;
} dma_channel_t;

typedef struct {
    dma_channel_t channels[8];
} dma_controller_t;

// Declare the target function
extern int32_t module(dma_controller_t *dma_base, uint8_t channel_id, uint32_t src, uint32_t dst, uint32_t size, uint8_t reset_cause);

#define SECURE_LOCKED_BIT (1U << 31)
#define BROWNOUT_RESET    0x02

int main() {
    // Case 1: Unlocked Channel + Non-Brownout Reset -> Security Violation
    // The function must return -2 and NOT modify any registers.
    {
        dma_controller_t dma;
        memset(&dma, 0, sizeof(dma));

        // Setup Channel 0
        // SECURE_LOCKED (bit 31) is 0 (Unlocked)
        // Initialize registers with known patterns to detect unwanted writes
        dma.channels[0].control = 0x00000000; 
        dma.channels[0].src_addr = 0x11111111;
        dma.channels[0].dst_addr = 0x22222222;
        dma.channels[0].xfer_size = 0x100;

        uint32_t target_src = 0xAAAAAAAA;
        uint32_t target_dst = 0xBBBBBBBB;
        uint32_t target_size = 0x200;
        uint8_t reset_cause = 0x00; // Not Brownout

        int32_t result = module(&dma, 0, target_src, target_dst, target_size, reset_cause);

        if (result == -2) {
            // Verify strict no-write policy
            if (dma.channels[0].src_addr == 0x11111111 &&
                dma.channels[0].dst_addr == 0x22222222 &&
                dma.channels[0].xfer_size == 0x100 &&
                dma.channels[0].control == 0x00000000) {
                printf("[CASE-1] PASS: Security violation correctly identified (returned -2) and writes prevented.\n");
            } else {
                printf("[CASE-1] FAIL: Returned -2 but registers were modified.\n");
            }
        } else {
            printf("[CASE-1] FAIL: Expected -2 for unlocked non-brownout reset, got %d.\n", result);
        }
    }

    // Case 2: Unlocked Channel + Brownout Reset -> Exception Allowed
    // The function should NOT return -2, as Brownout reset is an exception to the lock requirement.
    {
        dma_controller_t dma;
        memset(&dma, 0, sizeof(dma));

        // Setup Channel 1
        // SECURE_LOCKED (bit 31) is 0 (Unlocked)
        dma.channels[1].control = 0x00000000; 

        uint32_t target_src = 0xCCCCCCCC;
        uint32_t target_dst = 0xDDDDDDDD;
        uint32_t target_size = 0x400;
        uint8_t reset_cause = BROWNOUT_RESET; // 0x02

        int32_t result = module(&dma, 1, target_src, target_dst, target_size, reset_cause);

        // We expect success (0) or at least NOT a security failure (-2)
        if (result != -2) {
            printf("[CASE-2] PASS: Brownout reset exception respected (did not return -2).\n");
        } else {
            printf("[CASE-2] FAIL: Brownout reset should bypass security lock check, but got -2.\n");
        }
    }

    return 0;
}