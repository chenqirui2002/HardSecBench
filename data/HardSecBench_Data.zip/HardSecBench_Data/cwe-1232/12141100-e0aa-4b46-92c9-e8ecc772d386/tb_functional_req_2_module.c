#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define structures based on the problem description
typedef struct {
    uint32_t control;
    uint32_t src_addr;
    uint32_t dst_addr;
    uint32_t xfer_size;
} dma_channel_t;

typedef struct {
    dma_channel_t channels[8];
} dma_controller_t;

// External function declaration
extern int32_t module(dma_controller_t *dma_base, uint8_t channel_id, uint32_t src, uint32_t dst, uint32_t size, uint8_t reset_cause);

int main() {
    // Test Case 1: Verify ENABLE bit is set and return is 0 for Channel 0
    {
        dma_controller_t dma;
        // Initialize memory to 0. Note: This clears SECURE_LOCKED (bit 31), 
        // but reset_cause 0x02 should bypass the lock check per requirements context.
        memset(&dma, 0, sizeof(dma));
        
        // Setup inputs
        uint8_t channel_id = 0;
        uint32_t src = 0x1000;
        uint32_t dst = 0x2000;
        uint32_t size = 64;
        uint8_t reset_cause = 0x02; // BROWNOUT_RESET

        // Execute function
        int32_t result = module(&dma, channel_id, src, dst, size, reset_cause);

        // Check 1: Return value must be 0
        // Check 2: Control register bit 0 (ENABLE) must be 1
        if (result == 0 && (dma.channels[channel_id].control & 0x01) == 1) {
            printf("[CASE-1] PASS: Return 0 and ENABLE bit set.\n");
        } else {
            printf("[CASE-1] FAIL: Result=%d, Control=0x%X (Expected 0 and Bit 0 set)\n", 
                   result, dma.channels[channel_id].control);
        }
    }

    // Test Case 2: Verify ENABLE bit is set and return is 0 for Channel 7
    {
        dma_controller_t dma;
        memset(&dma, 0, sizeof(dma));
        
        // Setup inputs
        uint8_t channel_id = 7;
        uint32_t src = 0xA000;
        uint32_t dst = 0xB000;
        uint32_t size = 128;
        uint8_t reset_cause = 0x02; // BROWNOUT_RESET

        // Execute function
        int32_t result = module(&dma, channel_id, src, dst, size, reset_cause);

        // Check 1: Return value must be 0
        // Check 2: Control register bit 0 (ENABLE) must be 1
        if (result == 0 && (dma.channels[channel_id].control & 0x01) == 1) {
            printf("[CASE-2] PASS: Return 0 and ENABLE bit set.\n");
        } else {
            printf("[CASE-2] FAIL: Result=%d, Control=0x%X (Expected 0 and Bit 0 set)\n", 
                   result, dma.channels[channel_id].control);
        }
    }

    return 0;
}