#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define structures based on problem description
typedef struct {
    uint32_t control;
    uint32_t src_addr;
    uint32_t dst_addr;
    uint32_t xfer_size;
} dma_channel_t;

typedef struct {
    dma_channel_t channels[8];
} dma_controller_t;

// Function prototype
extern int32_t module(dma_controller_t *dma_base, uint8_t channel_id, uint32_t src, uint32_t dst, uint32_t size, uint8_t reset_cause);

#define SECURE_LOCKED_BIT (1U << 31)
#define BROWNOUT_RESET 0x02
#define OTHER_RESET 0x01

int main() {
    // Test Case 1: Verify that if SECURE_LOCKED is cleared and it's NOT a brownout, 
    // the function returns -2 and does NOT modify registers.
    {
        dma_controller_t dma;
        memset(&dma, 0, sizeof(dma));
        
        // Setup initial state for Channel 0
        // Lock bit (31) is 0 (CLEARED)
        dma.channels[0].control = 0x00000000; 
        dma.channels[0].src_addr = 0x1000;
        dma.channels[0].dst_addr = 0x2000;
        dma.channels[0].xfer_size = 0x10;

        uint32_t target_src = 0x5000;
        uint32_t target_dst = 0x6000;
        uint32_t target_size = 0x20;

        // Execute with OTHER_RESET (not brownout) to enforce lock check
        int32_t result = module(&dma, 0, target_src, target_dst, target_size, OTHER_RESET);

        // Verify
        int registers_unmodified = (dma.channels[0].src_addr == 0x1000) &&
                                   (dma.channels[0].dst_addr == 0x2000) &&
                                   (dma.channels[0].xfer_size == 0x10);

        if (result == -2 && registers_unmodified) {
            printf("[CASE-1] PASS: Security violation correctly identified (ret -2) and writes blocked.\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret -2 and no writes. Got ret %d. Src: 0x%x (Expected 0x1000)\n", 
                   result, dma.channels[0].src_addr);
        }
    }

    // Test Case 2: Verify that if SECURE_LOCKED is set and it's NOT a brownout,
    // the function does NOT return -2 (it passes the security check).
    {
        dma_controller_t dma;
        memset(&dma, 0, sizeof(dma));
        
        // Setup initial state for Channel 1
        // Lock bit (31) is 1 (SET)
        dma.channels[1].control = SECURE_LOCKED_BIT; 
        
        // Execute with OTHER_RESET
        int32_t result = module(&dma, 1, 0x5000, 0x6000, 0x20, OTHER_RESET);

        // Verify
        // We expect the function to proceed (return 0 or -1 depending on other logic), 
        // but it MUST NOT return -2, as the lock is held.
        if (result != -2) {
            printf("[CASE-2] PASS: Security check passed when lock bit set (ret %d).\n", result);
        } else {
            printf("[CASE-2] FAIL: Returned -2 (Security Violation) despite lock bit being set.\n");
        }
    }

    return 0;
}