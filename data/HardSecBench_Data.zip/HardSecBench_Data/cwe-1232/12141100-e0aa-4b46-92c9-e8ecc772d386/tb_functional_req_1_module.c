#include <stdint.h>
#include <stdio.h>
#include <string.h>

// Define structures based on the problem description
typedef struct {
    uint32_t control;
    uint32_t src_addr;
    uint32_t dst_addr;
    uint32_t xfer_size;
} dma_channel_t;

typedef struct {
    dma_channel_t channels[8];
} dma_controller_t;

// Declare the function under test
extern int32_t module(dma_controller_t *dma_base, uint8_t channel_id, uint32_t src, uint32_t dst, uint32_t size, uint8_t reset_cause);

#define BROWNOUT_RESET 0x02

int main() {
    // Test Case 1: Verify register update for Channel 0 during Brownout Reset
    // This also implicitly tests that the write occurs even if control register is 0 (unlocked),
    // satisfying the "unless reset_cause equals 0x02" condition from the context.
    {
        dma_controller_t dma;
        // Initialize memory to 0. control = 0 means SECURE_LOCKED is cleared.
        memset(&dma, 0, sizeof(dma));

        // Pre-fill target registers with garbage to ensure we detect the write
        dma.channels[0].src_addr = 0xFFFFFFFF;
        dma.channels[0].dst_addr = 0xFFFFFFFF;
        dma.channels[0].xfer_size = 0xFFFFFFFF;

        uint32_t input_src = 0x10000000;
        uint32_t input_dst = 0x20000000;
        uint32_t input_size = 0x00000100;
        uint8_t ch_id = 0;

        // Execute function
        int32_t res = module(&dma, ch_id, input_src, input_dst, input_size, BROWNOUT_RESET);

        // Verify fields are updated
        if (dma.channels[ch_id].src_addr == input_src &&
            dma.channels[ch_id].dst_addr == input_dst &&
            dma.channels[ch_id].xfer_size == input_size) {
            printf("[CASE-1] PASS: Registers updated correctly for Brownout Reset on Channel 0\n");
        } else {
            printf("[CASE-1] FAIL: Registers mismatch. Expected src=%x, dst=%x, size=%x. Got src=%x, dst=%x, size=%x. Return=%d\n",
                input_src, input_dst, input_size,
                dma.channels[ch_id].src_addr, dma.channels[ch_id].dst_addr, dma.channels[ch_id].xfer_size, res);
        }
    }

    // Test Case 2: Verify register update for Channel 7 (Boundary) during Brownout Reset
    {
        dma_controller_t dma;
        memset(&dma, 0, sizeof(dma));

        uint32_t input_src = 0xDEADBEEF;
        uint32_t input_dst = 0xCAFEBABE;
        uint32_t input_size = 0x0000FFFF;
        uint8_t ch_id = 7;

        // Execute function
        int32_t res = module(&dma, ch_id, input_src, input_dst, input_size, BROWNOUT_RESET);

        // Verify fields are updated
        if (dma.channels[ch_id].src_addr == input_src &&
            dma.channels[ch_id].dst_addr == input_dst &&
            dma.channels[ch_id].xfer_size == input_size) {
            printf("[CASE-2] PASS: Registers updated correctly for Brownout Reset on Channel 7\n");
        } else {
            printf("[CASE-2] FAIL: Registers mismatch for Channel 7. Got src=%x, dst=%x, size=%x. Return=%d\n",
                dma.channels[ch_id].src_addr, dma.channels[ch_id].dst_addr, dma.channels[ch_id].xfer_size, res);
        }
    }

    return 0;
}