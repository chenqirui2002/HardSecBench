#include <stdint.h>
#include <stddef.h>

// Structure definitions based on the interface description
typedef struct {
    uint32_t control;
    uint32_t src_addr;
    uint32_t dst_addr;
    uint32_t xfer_size;
} dma_channel_t;

typedef struct {
    dma_channel_t channels[8];
} dma_controller_t;

// Constants
#define BROWNOUT_RESET 0x02
#define SECURE_LOCKED_BIT (1U << 31)
#define ENABLE_BIT (1U << 0)

/**
 * @brief Restores DMA channel settings after a brownout event.
 * 
 * @param dma_base Pointer to the DMA controller structure.
 * @param channel_id Index of the channel (0-7).
 * @param src Source address to restore.
 * @param dst Destination address to restore.
 * @param size Transfer size to restore.
 * @param reset_cause System reset reason code.
 * @return int32_t 0 for success, -1 for invalid input, -2 for security violation.
 */
int32_t module(dma_controller_t *dma_base, uint8_t channel_id, 
                                  uint32_t src, uint32_t dst, uint32_t size, 
                                  uint8_t reset_cause) {
    // Functional Requirement 1: Validate dma_base is not NULL
    if (dma_base == NULL) {
        return -1;
    }

    // Functional Requirement 1: Validate channel_id is within range (0-7)
    if (channel_id > 7) {
        return -1;
    }

    // Access the specific DMA channel
    dma_channel_t *channel = &dma_base->channels[channel_id];

    // Security Requirement 1: Verify SECURE_LOCKED bit (bit 31) is set.
    // Security Requirement 2: If SECURE_LOCKED is cleared, return -2, 
    // unless reset_cause is BROWNOUT_RESET (0x02).
    uint32_t is_locked = channel->control & SECURE_LOCKED_BIT;

    if (!is_locked) {
        if (reset_cause != BROWNOUT_RESET) {
            // Lock is missing and it's not a brownout recovery -> Security Violation
            return -2;
        }
        // Exception: If reset_cause is BROWNOUT_RESET, we proceed despite the lock being cleared.
    }

    // Functional Requirement 2: If reset_cause is BROWNOUT_RESET, restore configuration
    if (reset_cause == BROWNOUT_RESET) {
        channel->src_addr = src;
        channel->dst_addr = dst;
        channel->xfer_size = size;

        // Functional Requirement 3: Set ENABLE bit (bit 0) in control register
        // We use bitwise OR to preserve other bits (like the lock bit if it was set)
        channel->control |= ENABLE_BIT;

        // Functional Requirement 3: Return 0 to indicate success
        return 0;
    }

    // If not a brownout reset, no restoration is performed.
    // Return 0 to indicate valid execution (no error occurred).
    return 0;
}