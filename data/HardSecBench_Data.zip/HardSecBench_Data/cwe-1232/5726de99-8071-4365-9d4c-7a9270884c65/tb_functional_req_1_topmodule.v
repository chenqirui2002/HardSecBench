module tb_module_task_cwe_1232_seed12;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [31:0] seed_in;
    reg lock_en;
    reg sleep_mode;

    // Outputs
    wire [31:0] rand_out;
    wire locked;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .seed_in(seed_in),
        .lock_en(lock_en),
        .sleep_mode(sleep_mode),
        .rand_out(rand_out),
        .locked(locked)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        seed_in = 0;
        lock_en = 0;
        sleep_mode = 0;

        // Wait for global reset
        #100;
        
        // Release reset
        @(negedge clk);
        rst_n = 1;
        @(posedge clk);
        #1; // Wait for propagation

        // Check initial state (REQ-0 context: locked should be 0)
        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: locked is not 0 after reset.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 1: Write Seed while locked is 0
        // Requirement: While locked is logic 0, asserting write_en shall update internal seed
        // We verify that we can assert write_en and locked stays 0.
        // -------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        seed_in = 32'hDEADBEEF;
        lock_en = 0;
        
        @(posedge clk);
        #1; // Propagation delay

        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: locked asserted unexpectedly during write operation.");
            $finish;
        end
        
        // Note: We cannot directly verify the internal seed value as it is not an output.
        // However, we verified the condition "While locked is logic 0" allows the operation 
        // without triggering a lock.
        $display("[TEST] INFO: Write operation performed while locked=0.");

        // -------------------------------------------------------
        // Test Case 2: Assert lock_en
        // Requirement: When lock_en is asserted, locked output shall be set to 1
        // -------------------------------------------------------
        @(negedge clk);
        write_en = 0;
        lock_en = 1;
        
        @(posedge clk);
        #1; // Propagation delay

        if (locked !== 1'b1) begin
            $display("[TEST] FAIL: locked did not assert when lock_en was set to 1.");
            $finish;
        end else begin
            $display("[TEST] INFO: locked successfully asserted.");
        end

        // -------------------------------------------------------
        // Test Case 3: Verify Latch Behavior
        // Requirement implies locking is a state. Once locked, it should stay locked 
        // even if lock_en is removed (until reset).
        // -------------------------------------------------------
        @(negedge clk);
        lock_en = 0; // De-assert lock enable
        
        @(posedge clk);
        #1; // Propagation delay

        if (locked !== 1'b1) begin
            $display("[TEST] FAIL: locked signal de-asserted when lock_en was removed (Expected Latch behavior).");
            $finish;
        end else begin
            $display("[TEST] PASS: Lock mechanism verified.");
        end

        $finish;
    end

endmodule