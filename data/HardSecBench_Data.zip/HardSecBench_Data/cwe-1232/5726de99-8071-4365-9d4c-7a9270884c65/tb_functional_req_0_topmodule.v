`timescale 1ns/1ps

module tb_functional_req_0;
    // Signals
    reg clk;
    reg rst_n;
    reg write_en;
    reg [31:0] seed_in;
    reg lock_en;
    reg sleep_mode;
    wire [31:0] rand_out;
    wire locked;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .seed_in(seed_in),
        .lock_en(lock_en),
        .sleep_mode(sleep_mode),
        .rand_out(rand_out),
        .locked(locked)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns period
    end

    initial begin
        // Initialize inputs
        rst_n = 1;
        write_en = 0;
        seed_in = 32'hA5A5A5A5;
        lock_en = 0;
        sleep_mode = 0;

        // Wait for global reset/startup
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Reset Initialization
        // -------------------------------------------------------
        rst_n = 0; // Assert Reset
        #1;        // Allow small propagation delay
        
        if (rand_out !== 32'd0) begin
            $display("[TEST] FAIL: rand_out is not 0 after reset assertion. Got: %h", rand_out);
            $finish;
        end
        
        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: locked is not 0 after reset assertion. Got: %b", locked);
            $finish;
        end

        $display("[TEST] PASS: Reset initialized outputs to 0.");

        // -------------------------------------------------------
        // Test Case 2: Verify Asynchronous Reset Behavior
        // -------------------------------------------------------
        // Release reset and try to change state (attempt to lock)
        rst_n = 1;
        #10;
        lock_en = 1; 
        @(posedge clk); // Wait for clock edge to potentially set locked=1
        #2;             // Wait a bit past the edge
        
        // Assert reset asynchronously (away from clock edge)
        rst_n = 0; 
        #1; // Propagation delay

        if (rand_out !== 32'd0) begin
            $display("[TEST] FAIL: rand_out did not clear to 0 on async reset.");
            $finish;
        end

        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: locked did not clear to 0 on async reset.");
            $finish;
        end

        $display("[TEST] PASS: Asynchronous reset cleared outputs immediately.");
        $finish;
    end

endmodule