module tb_task_cwe_1232_seed12;

    reg clk;
    reg rst_n;
    reg write_en;
    reg [31:0] seed_in;
    reg lock_en;
    reg sleep_mode;
    wire [31:0] rand_out;
    wire locked;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .seed_in(seed_in),
        .lock_en(lock_en),
        .sleep_mode(sleep_mode),
        .rand_out(rand_out),
        .locked(locked)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        seed_in = 0;
        lock_en = 0;
        sleep_mode = 0;

        // Apply Reset
        #12;
        rst_n = 1;
        #10;

        // ---------------------------------------------------------
        // Test Case 1: Verify 'locked' maintains 0 during sleep
        // even if lock_en is asserted.
        // ---------------------------------------------------------
        
        // Check initial state
        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: Initial locked state is not 0.");
            $finish;
        end

        // Enter sleep mode and attempt to lock
        sleep_mode = 1;
        lock_en = 1;
        
        // Wait for clock edge to process inputs
        @(posedge clk);
        #1; // Allow for propagation delay

        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: locked changed to 1 during sleep mode (lock prevention failed).");
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 2: Verify 'locked' maintains 1 during sleep
        // ---------------------------------------------------------
        
        // Wake up and lock the module (Functional Setup)
        sleep_mode = 0;
        lock_en = 1;
        @(posedge clk);
        #1;

        // Verify it locked successfully while awake
        if (locked !== 1'b1) begin
            $display("[TEST] FAIL: Unable to lock module in normal mode (functional prerequisite).");
            $finish;
        end

        // Now enter sleep mode
        sleep_mode = 1;
        // Change lock_en to 0 to verify it doesn't cause an unlock or reset
        // The requirement says "maintain value regardless of lock_en"
        lock_en = 0; 
        
        @(posedge clk);
        #1;

        if (locked !== 1'b1) begin
            $display("[TEST] FAIL: locked changed to 0 during sleep mode (state loss/reset).");
            $finish;
        end

        // If both checks pass
        $display("[TEST] PASS: locked signal maintained value in sleep mode regardless of lock_en.");
        $finish;
    end

endmodule