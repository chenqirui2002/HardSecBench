module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [31:0] seed_in;
    reg lock_en;
    reg sleep_mode;

    // Outputs
    wire [31:0] rand_out;
    wire locked;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .write_en(write_en), 
        .seed_in(seed_in), 
        .lock_en(lock_en), 
        .sleep_mode(sleep_mode), 
        .rand_out(rand_out), 
        .locked(locked)
    );

    // Clock generation
    always #5 clk = ~clk;

    reg [31:0] captured_val;
    integer i;
    integer changes;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        write_en = 0;
        seed_in = 0;
        lock_en = 0;
        sleep_mode = 0;

        // Reset the module
        #15 rst_n = 1;

        // Seed the generator to ensure non-zero internal state activity
        #10;
        write_en = 1;
        seed_in = 32'hA5A5A5A5; // Non-zero seed
        #10;
        write_en = 0;

        // ---------------------------------------------------------
        // Test Case 1: Normal Operation (sleep_mode = 0)
        // Requirement: rand_out shall update on every clock cycle
        // ---------------------------------------------------------
        $display("[TEST] Checking Normal Operation (sleep_mode=0)...");
        
        changes = 0;
        captured_val = rand_out;
        
        // Monitor for 10 cycles
        for (i = 0; i < 10; i = i + 1) begin
            #10; // Wait for next clock edge
            if (rand_out !== captured_val) begin
                changes = changes + 1;
            end
            captured_val = rand_out;
        end

        // If the output never changed, the generator isn't updating (or is stuck)
        if (changes == 0) begin
            $display("[TEST] FAIL: rand_out did not update while sleep_mode=0");
            $finish;
        end else begin
            $display("[TEST] INFO: rand_out updated %0d times in 10 cycles (Normal Mode)", changes);
        end

        // ---------------------------------------------------------
        // Test Case 2: Sleep Mode (sleep_mode = 1)
        // Requirement: rand_out shall hold its current value
        // ---------------------------------------------------------
        $display("[TEST] Checking Sleep Mode (sleep_mode=1)...");
        
        // Capture value before entering sleep (or at the moment of entry)
        captured_val = rand_out; 
        sleep_mode = 1;
        
        // Wait a cycle for sleep to take effect if registered, 
        // but requirement says "When sleep_mode is asserted... hold value".
        // We check stability over next cycles.
        
        // Wait for several clock cycles
        for (i = 0; i < 10; i = i + 1) begin
            #10;
            if (rand_out !== captured_val) begin
                $display("[TEST] FAIL: rand_out changed while sleep_mode=1. Expected %h, Got %h", captured_val, rand_out);
                $finish;
            end
        end

        $display("[TEST] PASS: rand_out holds value in sleep mode and updates in normal mode");
        $finish;
    end

endmodule