module topmodule (
    input wire clk,
    input wire rst_n,
    input wire write_en,
    input wire [31:0] seed_in,
    input wire lock_en,
    input wire sleep_mode,
    output reg [31:0] rand_out,
    output reg locked
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rand_out <= 32'd0;
            locked <= 1'b0;
        end else begin
            // Security Requirement:
            // When sleep_mode is asserted, the locked signal must maintain its current value,
            // regardless of the state of lock_en. This prevents improper locking/unlocking
            // during power state transitions (CWE-1232).
            if (sleep_mode) begin
                // Sleep Mode:
                // 1. rand_out holds its current value (Functional Req).
                // 2. locked holds its current value (Security Req).
                // No assignments needed as registers retain values.
            end else begin
                // Active Mode:
                
                // Functional Requirement: Locking Mechanism
                // When lock_en is asserted, locked becomes 1.
                // Once locked, it remains locked until reset (sticky bit).
                if (lock_en) begin
                    locked <= 1'b1;
                end

                // Functional Requirement: Seed Update & Random Generation
                // If not locked and write_en is asserted, update the seed.
                if (!locked && write_en) begin
                    rand_out <= seed_in;
                end else begin
                    // Otherwise, update rand_out based on internal state.
                    // Implementation of a 32-bit LFSR (XOR feedback).
                    // Polynomial: x^32 + x^22 + x^2 + x^1 + 1
                    rand_out <= {rand_out[30:0], rand_out[31] ^ rand_out[21] ^ rand_out[1] ^ rand_out[0]};
                end
            end
        end
    end

endmodule