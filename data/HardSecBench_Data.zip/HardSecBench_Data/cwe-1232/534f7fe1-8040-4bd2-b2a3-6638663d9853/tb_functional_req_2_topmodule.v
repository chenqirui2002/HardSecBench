`timescale 1ns/1ps

module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [31:0] data_in;
    reg lock_set;
    reg sleep_req;

    // Outputs
    wire [31:0] data_out;
    wire lock_status;
    wire controller_ready;
    wire [7:0] heartbeat_counter;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_set(lock_set),
        .sleep_req(sleep_req),
        .data_out(data_out),
        .lock_status(lock_status),
        .controller_ready(controller_ready),
        .heartbeat_counter(heartbeat_counter)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        data_in = 0;
        lock_set = 0;
        sleep_req = 0;

        // Wait for global reset
        #100;
        rst_n = 1;
        #20;

        // -------------------------------------------------------
        // Test Case 1: Write when Unlocked (lock_status should be 0 after reset)
        // -------------------------------------------------------
        $display("[TEST] Case 1: Write when unlocked");
        
        // Ensure lock is 0 initially
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status not 0 after reset");
            $finish;
        end

        // Perform Write
        data_in = 32'hA5A5A5A5;
        write_en = 1;
        lock_set = 0;
        @(posedge clk);
        #1; // Allow propagation
        write_en = 0; // Deassert write

        // Verify Write
        if (data_out !== 32'hA5A5A5A5) begin
            $display("[TEST] FAIL: config_reg failed to update when unlocked. Expected: %h, Got: %h", 32'hA5A5A5A5, data_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Set Lock
        // -------------------------------------------------------
        $display("[TEST] Case 2: Set Lock");
        lock_set = 1;
        @(posedge clk);
        #1;
        lock_set = 0; // Deassert lock_set, lock_status should remain 1 (sticky)

        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: lock_status did not set to 1 or did not stick.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Write attempt when Locked
        // -------------------------------------------------------
        $display("[TEST] Case 3: Write attempt when locked");
        
        data_in = 32'hDEADBEEF;
        write_en = 1;
        @(posedge clk);
        #1;
        write_en = 0;

        // Verify Data did NOT change
        if (data_out === 32'hDEADBEEF) begin
            $display("[TEST] FAIL: config_reg updated while locked!");
            $finish;
        end

        if (data_out !== 32'hA5A5A5A5) begin
            $display("[TEST] FAIL: config_reg corrupted during locked write. Expected: %h, Got: %h", 32'hA5A5A5A5, data_out);
            $finish;
        end

        $display("[TEST] PASS: Functional Requirement 2 verified.");
        $finish;
    end

endmodule