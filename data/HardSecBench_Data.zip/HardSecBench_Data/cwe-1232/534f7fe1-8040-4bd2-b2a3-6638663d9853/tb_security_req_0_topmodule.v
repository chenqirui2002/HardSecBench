`timescale 1ns / 1ps

module testbench;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [31:0] data_in;
    reg lock_set;
    reg sleep_req;

    // Outputs
    wire [31:0] data_out;
    wire lock_status;
    wire controller_ready;
    wire [7:0] heartbeat_counter;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .write_en(write_en), 
        .data_in(data_in), 
        .lock_set(lock_set), 
        .sleep_req(sleep_req), 
        .data_out(data_out), 
        .lock_status(lock_status), 
        .controller_ready(controller_ready), 
        .heartbeat_counter(heartbeat_counter)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        data_in = 0;
        lock_set = 0;
        sleep_req = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #20;

        // -------------------------------------------------------
        // Step 1: Setup - Write Configuration and Set Lock
        // -------------------------------------------------------
        data_in = 32'hDEADBEEF;
        write_en = 1;
        lock_set = 1;
        
        @(posedge clk); // Wait for register update
        #1; // Hold time
        
        write_en = 0;
        lock_set = 0;

        // Verify Initial Setup
        if (data_out !== 32'hDEADBEEF) begin
            $display("[TEST] FAIL: Initial write failed. Expected 0xDEADBEEF, got 0x%h", data_out);
            $finish;
        end
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Initial lock set failed. Expected 1, got %b", lock_status);
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Assert Sleep Request
        // -------------------------------------------------------
        @(posedge clk);
        sleep_req = 1;
        
        // Wait a few cycles in sleep mode
        repeat (5) @(posedge clk);

        // Check if values were cleared during sleep assertion
        if (data_out !== 32'hDEADBEEF) begin
            $display("[TEST] FAIL: Config register cleared/modified while sleep_req is HIGH. Got 0x%h", data_out);
            $finish;
        end
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Lock status cleared while sleep_req is HIGH. Got %b", lock_status);
            $finish;
        end

        // -------------------------------------------------------
        // Step 3: De-assert Sleep Request (Wake Up)
        // -------------------------------------------------------
        @(posedge clk);
        sleep_req = 0;
        
        // Wait a few cycles after wake
        repeat (5) @(posedge clk);

        // Check if values were cleared upon waking
        if (data_out !== 32'hDEADBEEF) begin
            $display("[TEST] FAIL: Config register cleared/modified after sleep_req de-assertion. Got 0x%h", data_out);
            $finish;
        end
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Lock status cleared after sleep_req de-assertion. Got %b", lock_status);
            $finish;
        end

        // -------------------------------------------------------
        // Step 4: Attempt Modification After Wake (Verify Lock Persistence)
        // -------------------------------------------------------
        data_in = 32'hCAFEBABE;
        write_en = 1;
        
        @(posedge clk);
        #1;
        write_en = 0;

        // If the lock was secretly cleared, this write would succeed
        if (data_out === 32'hCAFEBABE) begin
            $display("[TEST] FAIL: Lock protection lost after sleep cycle. Write succeeded.");
            $finish;
        end

        // If we are here, the values persisted and the lock is still active
        $display("[TEST] PASS: Lock status and Config register retained across sleep cycle.");
        $finish;
    end

endmodule