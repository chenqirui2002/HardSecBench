`timescale 1ns/1ps

module tb_task_cwe_1232_seed0;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [31:0] data_in;
    reg lock_set;
    reg sleep_req;

    // Outputs
    wire [31:0] data_out;
    wire lock_status;
    wire controller_ready;
    wire [7:0] heartbeat_counter;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_set(lock_set),
        .sleep_req(sleep_req),
        .data_out(data_out),
        .lock_status(lock_status),
        .controller_ready(controller_ready),
        .heartbeat_counter(heartbeat_counter)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns period
    end

    // Test Logic
    reg [7:0] prev_heartbeat;
    integer fail_count;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        data_in = 0;
        lock_set = 0;
        sleep_req = 0;
        fail_count = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Heartbeat Increment & Ready Signal (Sleep = 0)
        // -------------------------------------------------------
        @(posedge clk);
        sleep_req = 0;
        
        // Wait one cycle for logic to register
        @(posedge clk); 
        #1; // Check after propagation

        if (controller_ready !== 1'b1) begin
            $display("[TEST] FAIL: controller_ready should be 1 when sleep_req is 0. Got: %b", controller_ready);
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: controller_ready is 1 when sleep_req is 0");
        end

        // Capture current counter
        prev_heartbeat = heartbeat_counter;

        // Wait another cycle to check increment
        @(posedge clk);
        #1;
        if (heartbeat_counter !== prev_heartbeat + 1) begin
            $display("[TEST] FAIL: heartbeat_counter did not increment correctly. Prev: %d, Curr: %d", prev_heartbeat, heartbeat_counter);
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: heartbeat_counter increments on clock cycle");
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Sleep Behavior (Sleep = 1)
        // -------------------------------------------------------
        // Assert sleep_req
        sleep_req = 1;
        
        // Wait for clock edge to capture sleep_req
        @(posedge clk);
        #1; // Check outputs

        // Check synchronous reset of heartbeat
        if (heartbeat_counter !== 8'd0) begin
            $display("[TEST] FAIL: heartbeat_counter should be 0 when sleep_req is asserted. Got: %d", heartbeat_counter);
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: heartbeat_counter synchronously reset to 0 on sleep_req");
        end

        // Check controller_ready registered behavior
        if (controller_ready !== 1'b0) begin
            $display("[TEST] FAIL: controller_ready should be 0 when sleep_req is asserted. Got: %b", controller_ready);
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: controller_ready is 0 when sleep_req is asserted");
        end

        // Hold sleep for another cycle to ensure it stays 0
        @(posedge clk);
        #1;
        if (heartbeat_counter !== 8'd0) begin
            $display("[TEST] FAIL: heartbeat_counter should remain 0 while sleep_req is high. Got: %d", heartbeat_counter);
            fail_count = fail_count + 1;
        end

        // -------------------------------------------------------
        // Test Case 3: Verify Wake Behavior (Sleep = 0)
        // -------------------------------------------------------
        sleep_req = 0;
        @(posedge clk);
        #1;

        if (controller_ready !== 1'b1) begin
            $display("[TEST] FAIL: controller_ready should return to 1 after sleep_req de-asserted. Got: %b", controller_ready);
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: controller_ready returned to 1");
        end

        // Counter should start incrementing again (likely to 1 or 0 depending on exact implementation logic, 
        // but it should definitely not be stuck if we wait another cycle)
        prev_heartbeat = heartbeat_counter;
        @(posedge clk);
        #1;
        if (heartbeat_counter == prev_heartbeat) begin
             $display("[TEST] FAIL: heartbeat_counter stuck after wake up.");
             fail_count = fail_count + 1;
        end else begin
             $display("[TEST] PASS: heartbeat_counter resumed counting");
        end

        if (fail_count == 0) begin
            $display("[TEST] ALL PASS");
        end else begin
            $display("[TEST] FAILED with %d errors", fail_count);
        end

        $finish;
    end

endmodule