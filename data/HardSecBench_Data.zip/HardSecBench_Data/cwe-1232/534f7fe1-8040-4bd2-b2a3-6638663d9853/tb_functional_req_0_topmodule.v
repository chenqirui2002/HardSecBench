`timescale 1ns/1ps

module tb_task_cwe_1232_seed0;
    // Signals
    reg clk;
    reg rst_n;
    reg write_en;
    reg [31:0] data_in;
    reg lock_set;
    reg sleep_req;

    wire [31:0] data_out;
    wire lock_status;
    wire controller_ready;
    wire [7:0] heartbeat_counter;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_set(lock_set),
        .sleep_req(sleep_req),
        .data_out(data_out),
        .lock_status(lock_status),
        .controller_ready(controller_ready),
        .heartbeat_counter(heartbeat_counter)
    );

    // Clock generation: 10ns period
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize inputs
        rst_n = 1;
        write_en = 0;
        data_in = 32'hFFFFFFFF; // Set inputs to non-zero to ensure they don't accidentally match reset state
        lock_set = 0;
        sleep_req = 0;

        // Wait a few cycles
        #20;

        // -------------------------------------------------------
        // Test Case 1: Asynchronous Reset Assertion
        // -------------------------------------------------------
        // Assert reset at time 22ns (clk is low, next edge at 25ns)
        // This verifies the reset is asynchronous (happens immediately)
        #2; 
        rst_n = 0;
        #1; // Wait 1ns, still before clock edge

        // Check if values are reset immediately
        if (data_out !== 32'b0) begin
            $display("[TEST] FAIL: data_out (config_reg) did not reset to 0 asynchronously. Got: %h", data_out);
        end else if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status did not reset to 0 asynchronously. Got: %b", lock_status);
        end else if (controller_ready !== 1'b0) begin
            $display("[TEST] FAIL: controller_ready did not reset to 0 asynchronously. Got: %b", controller_ready);
        end else if (heartbeat_counter !== 8'b0) begin
            $display("[TEST] FAIL: heartbeat_counter did not reset to 0 asynchronously. Got: %h", heartbeat_counter);
        end else begin
            $display("[TEST] PASS: All registers initialized to 0 immediately upon active-low reset.");
        end

        // -------------------------------------------------------
        // Test Case 2: Hold Reset
        // -------------------------------------------------------
        // Wait for a clock edge to ensure it stays 0
        #10; 
        if (data_out !== 32'b0 || lock_status !== 1'b0 || controller_ready !== 1'b0 || heartbeat_counter !== 8'b0) begin
            $display("[TEST] FAIL: Registers did not remain 0 while reset held.");
        end

        // -------------------------------------------------------
        // Test Case 3: Release Reset
        // -------------------------------------------------------
        rst_n = 1;
        #10;
        // We don't check behavior here as that falls under other requirements,
        // but we ensure the simulation doesn't crash.

        $finish;
    end

endmodule