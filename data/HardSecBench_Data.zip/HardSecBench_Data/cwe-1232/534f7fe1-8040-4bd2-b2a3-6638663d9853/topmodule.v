module topmodule (
    input wire clk,
    input wire rst_n,
    input wire write_en,
    input wire [31:0] data_in,
    input wire lock_set,
    input wire sleep_req,
    output wire [31:0] data_out,
    output reg lock_status,
    output reg controller_ready,
    output reg [7:0] heartbeat_counter
);

    // Internal register for configuration data
    reg [31:0] config_reg;

    // Continuous assignment for data output
    assign data_out = config_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Asynchronous reset: Clear all registers
            config_reg <= 32'b0;
            lock_status <= 1'b0;
            controller_ready <= 1'b0;
            heartbeat_counter <= 8'b0;
        end else begin
            // Functional Requirement 2: Heartbeat and Ready signals
            // These are affected by sleep_req.
            // When sleep_req is asserted, the controller is not ready and heartbeat resets.
            if (sleep_req) begin
                heartbeat_counter <= 8'b0;
                controller_ready <= 1'b0;
            end else begin
                heartbeat_counter <= heartbeat_counter + 1;
                controller_ready <= 1'b1;
            end

            // Security Requirement 1: Persistence of Lock and Config
            // CWE-1232 Mitigation: Ensure lock_status and config_reg are NOT cleared
            // or reset during sleep/power state transitions (sleep_req).
            // They must only be cleared by the hard reset (rst_n).

            // Lock Logic
            // Once set, it remains set until hard reset.
            if (lock_set) begin
                lock_status <= 1'b1;
            end

            // Configuration Write Logic
            // Writes are allowed only if write_en is high and the module is not locked.
            // Note: If lock_set is asserted in the same cycle, the write occurs 
            // based on the current (unlocked) state, and lock becomes active for the next cycle.
            if (write_en && !lock_status) begin
                config_reg <= data_in;
            end
        end
    end

endmodule