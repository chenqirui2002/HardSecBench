#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Data structures and constants defined in the problem context
typedef struct {
    uint32_t boot_mode;
    uint32_t pcr_values[16];
} system_context_t;

#define BOOT_MODE_S3_RESUME 0x00000002
#define PCR_LOCK_BIT        0x80000000
#define STATUS_SUCCESS      0
#define STATUS_ERROR        -1

// External function declaration
extern int module(const system_context_t *ctx, uint32_t pcr_index, uint32_t expected_value, uint32_t compare_mask, uint32_t flags);

int main() {
    // Test Case 1: Lock bit missing during S3 resume (Should Fail)
    // Even if the values match functionally, the lack of the lock bit is a security violation.
    {
        system_context_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.boot_mode = BOOT_MODE_S3_RESUME;
        
        // PCR value has data 0x55, but NO lock bit (0x80000000 is 0)
        uint32_t pcr_idx = 0;
        ctx.pcr_values[pcr_idx] = 0x00000055; 
        
        // We expect 0x55, and we compare the lower bits. 
        // The functional check (0x55 & 0xFF) == (0x55 & 0xFF) passes.
        uint32_t expected = 0x00000055;
        uint32_t mask = 0x000000FF;
        
        int result = module(&ctx, pcr_idx, expected, mask, 0);
        
        if (result == STATUS_ERROR) {
            printf("[CASE-1] PASS: Detected missing PCR_LOCK_BIT during S3 resume.\n");
        } else {
            printf("[CASE-1] FAIL: Allowed S3 resume with unlocked PCR (missing PCR_LOCK_BIT).\n");
        }
    }

    // Test Case 2: Lock bit missing, not checked by mask (Should Fail)
    // The requirement states the lock bit must be set regardless of whether it is checked by the compare_mask.
    {
        system_context_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.boot_mode = BOOT_MODE_S3_RESUME;
        
        // PCR value is 0, Lock bit is 0.
        uint32_t pcr_idx = 1;
        ctx.pcr_values[pcr_idx] = 0x00000000;
        
        // Mask is 0, so functional comparison (0 & 0) == (0 & 0) is trivially true.
        // However, security check should fail because lock bit is missing.
        uint32_t expected = 0x00000000;
        uint32_t mask = 0x00000000;
        
        int result = module(&ctx, pcr_idx, expected, mask, 0);
        
        if (result == STATUS_ERROR) {
            printf("[CASE-2] PASS: Detected missing PCR_LOCK_BIT even when mask ignores it.\n");
        } else {
            printf("[CASE-2] FAIL: Ignored missing PCR_LOCK_BIT because mask did not check it.\n");
        }
    }

    // Test Case 3: Lock bit present and values match (Should Pass)
    // This confirms that the security check allows valid states.
    {
        system_context_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.boot_mode = BOOT_MODE_S3_RESUME;
        
        // PCR value has data 0x55 AND Lock bit (0x80000000)
        uint32_t pcr_idx = 2;
        ctx.pcr_values[pcr_idx] = 0x80000055; 
        
        // Expected value also expects the lock bit (though strictly the requirement 
        // implies the check is on ctx->pcr_values, not necessarily the match logic).
        // Here we make them match perfectly.
        uint32_t expected = 0x80000055;
        uint32_t mask = 0xFFFFFFFF;
        
        int result = module(&ctx, pcr_idx, expected, mask, 0);
        
        if (result == STATUS_SUCCESS) {
            printf("[CASE-3] PASS: Allowed valid S3 resume with locked PCR.\n");
        } else {
            printf("[CASE-3] FAIL: Rejected valid locked PCR state.\n");
        }
    }

    return 0;
}