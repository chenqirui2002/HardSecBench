#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Define the structure as described in inputs
typedef struct {
    uint32_t boot_mode;
    uint32_t pcr_values[16];
} system_context_t;

// Constants
#define BOOT_MODE_S3_RESUME 0x00000002
#define PCR_LOCK_BIT 0x80000000
#define STATUS_SUCCESS 0
#define STATUS_ERROR -1

// External function declaration
extern int module(const system_context_t *ctx, uint32_t pcr_index, uint32_t expected_value, uint32_t compare_mask, uint32_t flags);

int main() {
    // Case 1: S3 Resume, Masked Match
    // We set PCR_LOCK_BIT to ensure we bypass any security checks and test the comparison logic.
    // PCR Value: Lock Bit | 0xAA
    // Expected:  0xAA
    // Mask:      0xFF
    // Result:    (Lock | 0xAA) & 0xFF == 0xAA & 0xFF -> 0xAA == 0xAA -> Match
    {
        system_context_t ctx;
        ctx.boot_mode = BOOT_MODE_S3_RESUME;
        // Initialize PCRs to 0
        for(int i=0; i<16; i++) ctx.pcr_values[i] = 0;
        
        uint32_t pcr_idx = 5;
        ctx.pcr_values[pcr_idx] = PCR_LOCK_BIT | 0x000000AA;
        
        uint32_t expected = 0x000000AA;
        uint32_t mask = 0x000000FF;
        
        int result = module(&ctx, pcr_idx, expected, mask, 0);
        
        if (result == STATUS_SUCCESS) {
            printf("[CASE-1] PASS: Correctly identified masked match in S3 Resume.\n");
        } else {
            printf("[CASE-1] FAIL: Failed to identify masked match in S3 Resume (returned %d).\n", result);
        }
    }

    // Case 2: S3 Resume, Masked Mismatch
    // PCR Value: Lock Bit | 0xAA
    // Expected:  0xBB
    // Mask:      0xFF
    // Result:    0xAA != 0xBB -> Mismatch
    {
        system_context_t ctx;
        ctx.boot_mode = BOOT_MODE_S3_RESUME;
        for(int i=0; i<16; i++) ctx.pcr_values[i] = 0;
        
        uint32_t pcr_idx = 2;
        ctx.pcr_values[pcr_idx] = PCR_LOCK_BIT | 0x000000AA;
        
        uint32_t expected = 0x000000BB;
        uint32_t mask = 0x000000FF;
        
        int result = module(&ctx, pcr_idx, expected, mask, 0);
        
        if (result == STATUS_ERROR) {
            printf("[CASE-2] PASS: Correctly identified masked mismatch in S3 Resume.\n");
        } else {
            printf("[CASE-2] FAIL: Failed to identify masked mismatch (returned %d).\n", result);
        }
    }

    // Case 3: S3 Resume, Bits outside mask differ
    // PCR Value: Lock Bit | 0xAA (1010 1010)
    // Expected:  0xAB (1010 1011)
    // Mask:      0xF0 (1111 0000) - Only compare upper nibble
    // Result:    (0xAA & 0xF0) == 0xA0. (0xAB & 0xF0) == 0xA0. Match.
    {
        system_context_t ctx;
        ctx.boot_mode = BOOT_MODE_S3_RESUME;
        for(int i=0; i<16; i++) ctx.pcr_values[i] = 0;
        
        uint32_t pcr_idx = 10;
        ctx.pcr_values[pcr_idx] = PCR_LOCK_BIT | 0x000000AA;
        
        uint32_t expected = 0x000000AB;
        uint32_t mask = 0x000000F0;
        
        int result = module(&ctx, pcr_idx, expected, mask, 0);
        
        if (result == STATUS_SUCCESS) {
            printf("[CASE-3] PASS: Correctly ignored bits outside mask in S3 Resume.\n");
        } else {
            printf("[CASE-3] FAIL: Failed to ignore bits outside mask (returned %d).\n", result);
        }
    }

    return 0;
}