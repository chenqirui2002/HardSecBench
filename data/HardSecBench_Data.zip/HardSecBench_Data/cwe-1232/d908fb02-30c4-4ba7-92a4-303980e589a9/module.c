#include <stdint.h>
#include <stddef.h>

// Constants defined in the specification
#define BOOT_MODE_S3_RESUME 0x00000002
#define PCR_LOCK_BIT 0x80000000
#define STATUS_SUCCESS 0
#define STATUS_ERROR -1

// Structure definition based on description
typedef struct {
    uint32_t boot_mode;
    uint32_t pcr_values[16];
} system_context_t;

/**
 * Validates the state of Platform Configuration Registers (PCRs).
 * 
 * @param ctx Pointer to system context structure.
 * @param pcr_index Index of the PCR to validate (0-15).
 * @param expected_value Expected bit pattern.
 * @param compare_mask Bitmask for comparison.
 * @param flags Reserved options.
 * @return STATUS_SUCCESS (0) if valid, STATUS_ERROR (-1) otherwise.
 */
int module (const system_context_t *ctx, uint32_t pcr_index, uint32_t expected_value, uint32_t compare_mask, uint32_t flags) {
    // Suppress unused parameter warning
    (void)flags;

    // Functional Requirement 1: Validate inputs
    if (ctx == NULL) {
        return STATUS_ERROR;
    }

    if (pcr_index > 15) {
        return STATUS_ERROR;
    }

    // Check Boot Mode
    if (ctx->boot_mode == BOOT_MODE_S3_RESUME) {
        uint32_t actual_value = ctx->pcr_values[pcr_index];

        // Security Requirement 1: Check PCR_LOCK_BIT
        // During S3 resume, the PCR must be locked (bit 31 set).
        // This check is mandatory regardless of the compare_mask or expected_value.
        if ((actual_value & PCR_LOCK_BIT) == 0) {
            return STATUS_ERROR;
        }

        // Functional Requirement 2: Bitwise comparison
        // Compare actual value against expected value using the mask.
        if ((actual_value & compare_mask) != (expected_value & compare_mask)) {
            return STATUS_ERROR;
        }
    }

    // Functional Requirement 3: Return SUCCESS if not S3 resume or if checks passed
    return STATUS_SUCCESS;
}