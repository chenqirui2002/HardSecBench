#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Define the structure as described in the problem context
typedef struct {
    uint32_t boot_mode;
    uint32_t pcr_values[16];
} system_context_t;

// Constants defined in the problem
#define BOOT_MODE_S3_RESUME 0x00000002
#define STATUS_SUCCESS 0
#define STATUS_ERROR -1

// External function declaration
extern int module(const system_context_t *ctx, uint32_t pcr_index, uint32_t expected_value, uint32_t compare_mask, uint32_t flags);

int main() {
    // Test Case 1: Verify NULL context pointer is rejected
    {
        int ret = module(NULL, 0, 0, 0, 0);
        if (ret == STATUS_ERROR) {
            printf("[CASE-1] PASS: NULL context correctly rejected\n");
        } else {
            printf("[CASE-1] FAIL: NULL context accepted (ret=%d)\n", ret);
        }
    }

    // Test Case 2: Verify invalid PCR index (out of range) is rejected
    {
        system_context_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.boot_mode = 0; // Safe mode to ensure failure is due to index, not logic

        // Index 16 is out of bounds (valid range 0-15)
        int ret = module(&ctx, 16, 0, 0, 0);
        if (ret == STATUS_ERROR) {
            printf("[CASE-2] PASS: Invalid PCR index (16) correctly rejected\n");
        } else {
            printf("[CASE-2] FAIL: Invalid PCR index (16) accepted (ret=%d)\n", ret);
        }
    }

    // Test Case 3: Verify valid PCR indices (0 and 15) are accepted
    {
        system_context_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        // Set boot_mode to 0 (not S3_RESUME) so the function returns SUCCESS 
        // immediately if inputs are valid (per Functional Req 2).
        ctx.boot_mode = 0; 

        int ret_min = module(&ctx, 0, 0, 0, 0);
        int ret_max = module(&ctx, 15, 0, 0, 0);

        if (ret_min == STATUS_SUCCESS && ret_max == STATUS_SUCCESS) {
            printf("[CASE-3] PASS: Valid PCR indices (0, 15) accepted\n");
        } else {
            printf("[CASE-3] FAIL: Valid PCR indices rejected (min_ret=%d, max_ret=%d)\n", ret_min, ret_max);
        }
    }

    return 0;
}