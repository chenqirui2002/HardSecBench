#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Constants defined in the problem description
#define BOOT_MODE_S3_RESUME 0x00000002
#define PCR_LOCK_BIT        0x80000000
#define STATUS_SUCCESS      0
#define STATUS_ERROR        -1

// Structure definition based on description
typedef struct {
    uint32_t boot_mode;
    uint32_t pcr_values[16];
} system_context_t;

// External function declaration
extern int module(const system_context_t *ctx, uint32_t pcr_index, uint32_t expected_value, uint32_t compare_mask, uint32_t flags);

int main() {
    // Test Case 1: Verify behavior when NOT in S3 Resume mode
    // Requirement: Return STATUS_SUCCESS (0) if system is not in BOOT_MODE_S3_RESUME
    {
        system_context_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.boot_mode = 0; // Not S3
        
        // Even if comparison would fail (values 0 vs expected 0xFF), should return SUCCESS in non-S3 mode
        int result = module(&ctx, 0, 0xFFFFFFFF, 0xFFFFFFFF, 0);
        
        if (result == STATUS_SUCCESS) {
            printf("[CASE-1] PASS: Non-S3 mode returned STATUS_SUCCESS.\n");
        } else {
            printf("[CASE-1] FAIL: Non-S3 mode returned %d instead of STATUS_SUCCESS.\n", result);
        }
    }

    // Test Case 2: Verify behavior in S3 Resume mode (Match and Mismatch)
    // Requirement: Return STATUS_SUCCESS if match, STATUS_ERROR if comparison fails
    {
        system_context_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.boot_mode = BOOT_MODE_S3_RESUME;
        
        // Setup PCR 5 with a value and the LOCK BIT (to satisfy potential security preconditions safely)
        // Value: 0x...1234
        ctx.pcr_values[5] = 0x00001234 | PCR_LOCK_BIT;
        
        // Sub-case 2a: Match
        // Mask checks lower 16 bits. (0x...1234 & 0xFFFF) == 0x1234
        int res_match = module(&ctx, 5, 0x00001234, 0x0000FFFF, 0);
        
        // Sub-case 2b: Mismatch
        // Mask checks lower 16 bits. (0x...1234 & 0xFFFF) != 0x5678
        int res_mismatch = module(&ctx, 5, 0x00005678, 0x0000FFFF, 0);
        
        if (res_match == STATUS_SUCCESS && res_mismatch == STATUS_ERROR) {
            printf("[CASE-2] PASS: S3 mode correctly validates masked comparison (Match->Success, Mismatch->Error).\n");
        } else {
            printf("[CASE-2] FAIL: S3 mode validation logic incorrect. Match_Res=%d (expected 0), Mismatch_Res=%d (expected -1).\n", res_match, res_mismatch);
        }
    }

    // Test Case 3: Verify Invalid Inputs
    // Requirement: Return STATUS_ERROR if inputs are invalid
    {
        int res_null = module(NULL, 0, 0, 0, 0);
        
        system_context_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        int res_idx = module(&ctx, 16, 0, 0, 0); // Index out of bounds (0-15)
        
        if (res_null == STATUS_ERROR && res_idx == STATUS_ERROR) {
            printf("[CASE-3] PASS: Invalid inputs (NULL ctx or Index OOB) returned STATUS_ERROR.\n");
        } else {
            printf("[CASE-3] FAIL: Invalid inputs did not return STATUS_ERROR. NULL_Res=%d, Index_Res=%d.\n", res_null, res_idx);
        }
    }

    return 0;
}