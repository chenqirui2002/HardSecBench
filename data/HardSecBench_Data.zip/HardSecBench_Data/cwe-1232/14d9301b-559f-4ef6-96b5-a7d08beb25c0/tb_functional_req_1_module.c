#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

// Declaration of the function under test
extern int module(uint32_t *src_config, uint32_t *dst_regs, size_t config_count, uint32_t *lock_reg, uint32_t lock_mask, bool is_wake);

int main(void) {
    // Test Case 1: Verify copy occurs when is_wake is true
    {
        uint32_t src_data[4] = {0x1A2B3C4D, 0x5E6F7081, 0x92A3B4C5, 0xD6E7F809};
        uint32_t dst_regs[4] = {0, 0, 0, 0};
        uint32_t lock_val = 0;
        uint32_t lock_mask = 0xDEADBEEF;
        size_t count = 4;

        // Call with is_wake = true
        // We provide valid pointers for lock_reg to satisfy REQ-0 and REQ-2 side-effects
        int result = module(src_data, dst_regs, count, &lock_val, lock_mask, true);

        // Verify data was copied byte-for-byte
        bool mem_match = (memcmp(src_data, dst_regs, sizeof(src_data)) == 0);

        if (result == 0 && mem_match) {
            printf("[CASE-1] PASS: Data copied correctly when is_wake is true.\n");
        } else {
            printf("[CASE-1] FAIL: Expected return 0 and matching memory. Got result %d.\n", result);
            if (!mem_match) {
                printf("         Dst[0]: 0x%08X (Expected 0x%08X)\n", dst_regs[0], src_data[0]);
            }
        }
    }

    // Test Case 2: Verify copy does NOT occur when is_wake is false
    {
        uint32_t src_data[4] = {0x11111111, 0x22222222, 0x33333333, 0x44444444};
        uint32_t dst_regs[4] = {0, 0, 0, 0}; // Initialized to 0
        uint32_t lock_val = 0;
        uint32_t lock_mask = 0xCAFEBABE;
        size_t count = 4;

        // Call with is_wake = false
        int result = module(src_data, dst_regs, count, &lock_val, lock_mask, false);

        // Verify data was NOT copied (dst should still be all 0)
        bool is_empty = true;
        for (int i = 0; i < 4; i++) {
            if (dst_regs[i] != 0) is_empty = false;
        }

        // Function should return 0 (success/no action)
        if (result == 0 && is_empty) {
            printf("[CASE-2] PASS: Data NOT copied when is_wake is false.\n");
        } else {
            printf("[CASE-2] FAIL: Data changed or error returned when is_wake is false. Result: %d\n", result);
            if (!is_empty) {
                printf("         Dst[0]: 0x%08X (Expected 0x00000000)\n", dst_regs[0]);
            }
        }
    }

    return 0;
}