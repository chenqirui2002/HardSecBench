#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

// Declaration of the DUT
extern int module(uint32_t *src_config, uint32_t *dst_regs, size_t config_count, uint32_t *lock_reg, uint32_t lock_mask, bool is_wake);

int main(void) {
    // Test Case 1: Verify lock_reg update and return 0 when is_wake is true
    // This checks the primary success path for the lock requirement.
    {
        uint32_t src[4] = {0x11, 0x22, 0x33, 0x44};
        uint32_t dst[4] = {0};
        uint32_t lock_val = 0x00000000;
        uint32_t lock_mask = 0x80000001;
        size_t count = 4;
        bool is_wake = true;

        int result = module(src, dst, count, &lock_val, lock_mask, is_wake);

        // Requirement: Write lock_mask to lock_reg, Return 0
        if (result == 0 && lock_val == lock_mask) {
            printf("[CASE-1] PASS: Lock register updated to 0x%08X and returned 0\n", lock_val);
        } else {
            printf("[CASE-1] FAIL: Expected ret=0 and lock=0x%08X, got ret=%d and lock=0x%08X\n", 
                   lock_mask, result, lock_val);
        }
    }

    // Test Case 2: Verify lock_reg update with different mask/values and pre-existing data
    // This ensures the lock register is overwritten regardless of previous content.
    {
        uint32_t src[2] = {0xAA, 0xBB};
        uint32_t dst[2] = {0};
        uint32_t lock_val = 0xFFFFFFFF; // Pre-existing value
        uint32_t lock_mask = 0xCAFEBABE;
        size_t count = 2;
        bool is_wake = true;

        int result = module(src, dst, count, &lock_val, lock_mask, is_wake);

        if (result == 0 && lock_val == lock_mask) {
            printf("[CASE-2] PASS: Lock register correctly overwritten with 0x%08X\n", lock_val);
        } else {
            printf("[CASE-2] FAIL: Expected ret=0 and lock=0x%08X, got ret=%d and lock=0x%08X\n", 
                   lock_mask, result, lock_val);
        }
    }

    return 0;
}