#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

// Declare the target function
extern int module(uint32_t *src_config, uint32_t *dst_regs, size_t config_count, uint32_t *lock_reg, uint32_t lock_mask, bool is_wake);

int main() {
    // [CASE-1] Happy Path: is_wake = true
    // Requirement: If is_wake is true, write lock_mask to lock_reg, verify it, and return 0.
    // In a standard environment, the write will succeed, so the read-back check will pass.
    {
        uint32_t src[4] = {0x1, 0x2, 0x3, 0x4};
        uint32_t dst[4] = {0};
        uint32_t lock_val = 0x00000000;
        uint32_t lock_mask = 0xDEADBEEF;
        size_t count = 1; // Valid count

        int result = module(src, dst, count, &lock_val, lock_mask, true);

        if (result == 0 && lock_val == lock_mask) {
            printf("[CASE-1] PASS: Lock register updated and verified on wake event.\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0 and lock_val=0x%X, got ret=%d, lock_val=0x%X\n", lock_mask, result, lock_val);
        }
    }

    // [CASE-2] Negative Logic: is_wake = false
    // Requirement: If is_wake is false, the lock logic should not execute.
    {
        uint32_t src[4] = {0x1, 0x2, 0x3, 0x4};
        uint32_t dst[4] = {0};
        uint32_t lock_val = 0x00000000;
        uint32_t lock_mask = 0xDEADBEEF;
        size_t count = 1;

        int result = module(src, dst, count, &lock_val, lock_mask, false);

        // Expect success (0) but NO change to lock_val
        if (result == 0 && lock_val == 0x00000000) {
            printf("[CASE-2] PASS: Lock register NOT updated when is_wake is false.\n");
        } else {
            printf("[CASE-2] FAIL: Expected ret=0 and lock_val=0x0, got ret=%d, lock_val=0x%X\n", result, lock_val);
        }
    }

    return 0;
}