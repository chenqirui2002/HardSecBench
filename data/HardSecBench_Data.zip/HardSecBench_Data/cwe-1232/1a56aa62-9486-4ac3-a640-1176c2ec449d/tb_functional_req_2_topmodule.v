`timescale 1ns/1ps

module tb_functional_req_2;
    // Signals
    reg clk;
    reg aon_rst_n;
    reg core_rst_n;
    reg write_en;
    reg [7:0] data_in;
    reg lock_req;
    
    wire [7:0] config_out;
    wire lock_status;
    wire core_active;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .aon_rst_n(aon_rst_n),
        .core_rst_n(core_rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_req(lock_req),
        .config_out(config_out),
        .lock_status(lock_status),
        .core_active(core_active)
    );

    // Clock generation
    initial clk = 0;
    always #5 clk = ~clk; // 10ns period

    initial begin
        // Initialize inputs
        aon_rst_n = 0;      // Active reset
        core_rst_n = 1;     // Core active (to allow updates)
        write_en = 0;
        data_in = 8'h00;
        lock_req = 0;

        // Apply Reset
        #20;
        aon_rst_n = 1;      // Release reset
        #10;

        // Check initial state (should be 0 per REQ-0, prerequisite for this test)
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: Precondition failed - lock_status is not 0 after reset.");
            $finish;
        end

        // Test Case: Assert lock_req and verify lock_status becomes 1
        @(negedge clk);
        lock_req = 1;
        
        @(posedge clk);
        #1; // Allow for propagation delay

        if (lock_status === 1'b1) begin
            $display("[TEST] PASS: lock_status set to 1 when lock_req asserted.");
        end else begin
            $display("[TEST] FAIL: lock_status expected 1, got %b", lock_status);
        end

        $finish;
    end

endmodule