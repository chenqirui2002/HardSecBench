`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg aon_rst_n;
    reg core_rst_n;
    reg write_en;
    reg [7:0] data_in;
    reg lock_req;

    // Outputs
    wire [7:0] config_out;
    wire lock_status;
    wire core_active;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .aon_rst_n(aon_rst_n),
        .core_rst_n(core_rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_req(lock_req),
        .config_out(config_out),
        .lock_status(lock_status),
        .core_active(core_active)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns period
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        aon_rst_n = 1;
        core_rst_n = 1; // Enable core so writes/locks are possible for setup
        write_en = 0;
        data_in = 8'h00;
        lock_req = 0;

        // Wait for global reset/stabilization
        #20;

        // -------------------------------------------------------
        // Test Case 1: Initial Reset Check
        // -------------------------------------------------------
        $display("[TEST] Applying initial Reset (aon_rst_n = 0)...");
        aon_rst_n = 0;
        #10; // Hold reset
        
        if (config_out !== 8'h00) begin
            $display("[TEST] FAIL: config_out not 0 during reset. Got: %h", config_out);
            $finish;
        end
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status not 0 during reset. Got: %b", lock_status);
            $finish;
        end
        
        $display("[TEST] Initial reset check passed.");
        
        // Release Reset
        aon_rst_n = 1;
        #20;

        // -------------------------------------------------------
        // Test Case 2: Asynchronous Reset Behavior
        // -------------------------------------------------------
        // Setup: Write a value and set lock so we can see them clear
        $display("[TEST] Setting up state (Write 0xA5, Lock=1)...");
        
        @(posedge clk);
        write_en = 1;
        data_in = 8'hA5;
        lock_req = 1;
        
        @(posedge clk);
        #1; // Hold time
        write_en = 0;
        lock_req = 0;
        
        // Verify setup was successful (Prerequisite for the reset test)
        // Note: If this fails, it might be a REQ-1/REQ-2 failure, but we need this state
        // to verify REQ-0's clearing capability.
        if (config_out !== 8'hA5 || lock_status !== 1'b1) begin
            $display("[TEST] WARNING: Setup failed (config_out=%h, lock=%b). Reset test may be inconclusive.", config_out, lock_status);
        end else begin
            $display("[TEST] Setup successful. Asserting asynchronous reset...");
        end

        // Assert Reset away from clock edge (Asynchronous check)
        @(negedge clk);
        aon_rst_n = 0;
        #1; // Small delay to allow async logic to propagate
        
        // Check immediate effect
        if (config_out !== 8'h00) begin
            $display("[TEST] FAIL: config_out did not clear asynchronously immediately after reset. Got: %h", config_out);
            $finish;
        end
        
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status did not clear asynchronously immediately after reset. Got: %b", lock_status);
            $finish;
        end

        // Wait for a clock edge while reset is still held to ensure it stays 0
        @(posedge clk);
        #1;
        if (config_out !== 8'h00 || lock_status !== 1'b0) begin
             $display("[TEST] FAIL: Outputs changed during clock edge while reset held.");
             $finish;
        end

        $display("[TEST] PASS: Asynchronous reset initializes and clears outputs correctly.");
        $finish;
    end

endmodule