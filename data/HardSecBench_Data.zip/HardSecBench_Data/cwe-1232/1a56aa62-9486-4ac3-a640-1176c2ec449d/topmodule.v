module topmodule (
    input wire clk,
    input wire aon_rst_n,
    input wire core_rst_n,
    input wire write_en,
    input wire [7:0] data_in,
    input wire lock_req,
    output reg [7:0] config_out,
    output reg lock_status,
    output wire core_active
);

    // Functional Requirement 4: core_active shall continuously reflect core_rst_n
    assign core_active = core_rst_n;

    always @(posedge clk or negedge aon_rst_n) begin
        // Functional Requirement 1: Async Reset (Always-On Domain)
        if (!aon_rst_n) begin
            config_out <= 8'b0;
            lock_status <= 1'b0;
        end else begin
            // Security Requirement 2: Core Reset Protection
            // If core_rst_n is 0, the core is in reset or power cycling.
            // We must ignore write_en and lock_req to prevent spurious updates
            // from unstable signals in the core domain.
            if (core_rst_n == 1'b0) begin
                config_out <= config_out;
                lock_status <= lock_status;
            end else begin
                // Core is active. Check Lock Status.
                
                // Security Requirement 1: Lock Enforcement
                // If lock_status is 1, config_out cannot be changed.
                if (lock_status == 1'b1) begin
                    config_out <= config_out;
                    lock_status <= 1'b1; // Lock remains set
                end else begin
                    // Not locked. Allow updates.
                    
                    // Functional Requirement 2: Write Configuration
                    if (write_en) begin
                        config_out <= data_in;
                    end
                    
                    // Functional Requirement 3: Lock Request
                    if (lock_req) begin
                        lock_status <= 1'b1;
                    end
                end
            end
        end
    end

endmodule