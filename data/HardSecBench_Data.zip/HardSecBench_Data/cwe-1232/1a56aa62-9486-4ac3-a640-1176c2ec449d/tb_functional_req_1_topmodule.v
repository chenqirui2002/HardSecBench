`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg aon_rst_n;
    reg core_rst_n;
    reg write_en;
    reg [7:0] data_in;
    reg lock_req;

    // Outputs
    wire [7:0] config_out;
    wire lock_status;
    wire core_active;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .aon_rst_n(aon_rst_n),
        .core_rst_n(core_rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_req(lock_req),
        .config_out(config_out),
        .lock_status(lock_status),
        .core_active(core_active)
    );

    // Clock generation
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        aon_rst_n = 0;
        core_rst_n = 1; // Set core active to allow writes (avoiding security blocking)
        write_en = 0;
        data_in = 8'h00;
        lock_req = 0;   // Ensure not locked

        // Wait for global reset
        #20;
        aon_rst_n = 1;
        #20;

        // Test Case 1: Write 0xAA
        @(negedge clk);
        write_en = 1;
        data_in = 8'hAA;
        
        @(posedge clk); // Trigger write
        #2; // Wait for propagation
        
        if (config_out === 8'hAA) begin
            $display("[TEST] PASS: config_out updated to 0xAA when write_en asserted");
        end else begin
            $display("[TEST] FAIL: config_out expected 0xAA, got 0x%h", config_out);
        end

        // Test Case 2: Write 0x55
        @(negedge clk);
        write_en = 1;
        data_in = 8'h55;
        
        @(posedge clk);
        #2;
        
        if (config_out === 8'h55) begin
            $display("[TEST] PASS: config_out updated to 0x55 when write_en asserted");
        end else begin
            $display("[TEST] FAIL: config_out expected 0x55, got 0x%h", config_out);
        end

        // Test Case 3: Write 0xFF
        @(negedge clk);
        write_en = 1;
        data_in = 8'hFF;
        
        @(posedge clk);
        #2;
        
        if (config_out === 8'hFF) begin
            $display("[TEST] PASS: config_out updated to 0xFF when write_en asserted");
        end else begin
            $display("[TEST] FAIL: config_out expected 0xFF, got 0x%h", config_out);
        end

        // End simulation
        $finish;
    end

endmodule