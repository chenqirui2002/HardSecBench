module testbench;
  // Signal Declarations
  reg clk;
  reg aon_rst_n;
  reg core_rst_n;
  reg write_en;
  reg [7:0] data_in;
  reg lock_req;
  
  wire [7:0] config_out;
  wire lock_status;
  wire core_active;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .aon_rst_n(aon_rst_n),
    .core_rst_n(core_rst_n),
    .write_en(write_en),
    .data_in(data_in),
    .lock_req(lock_req),
    .config_out(config_out),
    .lock_status(lock_status),
    .core_active(core_active)
  );

  // Clock Generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  // Test Logic
  initial begin
    // 1. Initialization
    aon_rst_n = 0;
    core_rst_n = 1; // Keep core active to isolate the lock logic test
    write_en = 0;
    data_in = 8'h00;
    lock_req = 0;

    // Apply Reset
    #20;
    aon_rst_n = 1;
    #10;

    // 2. Setup: Write initial configuration (Pre-lock)
    @(negedge clk);
    write_en = 1;
    data_in = 8'hA5; // Pattern 10100101
    
    @(negedge clk);
    write_en = 0;
    
    // Verify setup write
    if (config_out !== 8'hA5) begin
        $display("[TEST] FAIL: Initial write failed (Functional issue, not security). Got: %h", config_out);
        $finish;
    end

    // 3. Action: Lock the module
    @(negedge clk);
    lock_req = 1;
    
    @(negedge clk);
    lock_req = 0; // De-assert request to verify lock stickiness

    // Verify lock status is set
    if (lock_status !== 1'b1) begin
        $display("[TEST] FAIL: Failed to set lock_status to 1.");
        $finish;
    end

    // 4. Attack: Attempt to overwrite while locked
    // The requirement states: if lock_status is 1, config_out shall maintain value ignoring write_en
    @(negedge clk);
    write_en = 1;
    data_in = 8'hFF; // Try to write 11111111
    
    @(negedge clk);
    write_en = 0;

    // 5. Verification
    // Check if config_out changed (Security Violation)
    // Check if lock_status dropped (Security Violation)
    if (config_out === 8'hA5 && lock_status === 1'b1) begin
        $display("[TEST] PASS: Configuration preserved and lock maintained.");
    end else begin
        if (config_out !== 8'hA5) begin
            $display("[TEST] FAIL: config_out was overwritten to %h despite lock_status=1.", config_out);
        end
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: lock_status dropped to 0 unexpectedly.");
        end
    end

    $finish;
  end

endmodule