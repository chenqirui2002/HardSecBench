`timescale 1ns/1ps

module testbench;

    // Inputs
    reg clk;
    reg aon_rst_n;
    reg core_rst_n;
    reg write_en;
    reg [7:0] data_in;
    reg lock_req;

    // Outputs
    wire [7:0] config_out;
    wire lock_status;
    wire core_active;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .aon_rst_n(aon_rst_n),
        .core_rst_n(core_rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_req(lock_req),
        .config_out(config_out),
        .lock_status(lock_status),
        .core_active(core_active)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        aon_rst_n = 0;
        core_rst_n = 1;
        write_en = 0;
        data_in = 0;
        lock_req = 0;

        // Wait for global reset to finish
        #20;
        aon_rst_n = 1;
        #20;

        // ----------------------------------------------------------------
        // Pre-condition Setup: 
        // Write a known value (0xAA) to config_out while core is active (core_rst_n = 1).
        // This ensures the module is functional and sets a baseline for the test.
        // ----------------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        data_in = 8'hAA;
        @(negedge clk);
        write_en = 0;

        // Verify setup
        if (config_out !== 8'hAA) begin
            $display("[TEST] FAIL: Setup failed. Unable to write initial value 0xAA when core_rst_n=1.");
            $finish;
        end

        // ----------------------------------------------------------------
        // Test Scenario 1: Verify write_en is ignored when core_rst_n = 0
        // ----------------------------------------------------------------
        @(negedge clk);
        core_rst_n = 0;      // Simulate Core Reset
        write_en = 1;        // Attempt Write
        data_in = 8'h55;     // New data
        @(negedge clk);
        write_en = 0;
        
        // Check if config_out maintained its value (0xAA)
        if (config_out !== 8'hAA) begin
            $display("[TEST] FAIL: config_out changed to 0x%h during core reset (expected 0xAA). Spurious update occurred.", config_out);
            $finish;
        end

        // ----------------------------------------------------------------
        // Test Scenario 2: Verify lock_req is ignored when core_rst_n = 0
        // ----------------------------------------------------------------
        // Ensure lock_status is 0 before testing
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: Setup failed. lock_status is 1 before test start.");
            $finish;
        end

        @(negedge clk);
        core_rst_n = 0;      // Ensure Core Reset is still active
        lock_req = 1;        // Attempt Lock
        @(negedge clk);
        lock_req = 0;

        // Check if lock_status maintained its value (0)
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status changed to 1 during core reset. Spurious lock update occurred.");
            $finish;
        end

        // If we reached here, both checks passed
        $display("[TEST] PASS: config_out and lock_status maintained values during core reset.");
        $finish;
    end

endmodule