module tb_task_cwe_1232_seed8;

    // Inputs
    reg clk;
    reg aon_rst_n;
    reg core_rst_n;
    reg write_en;
    reg [7:0] data_in;
    reg lock_req;

    // Outputs
    wire [7:0] config_out;
    wire lock_status;
    wire core_active;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .aon_rst_n(aon_rst_n),
        .core_rst_n(core_rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_req(lock_req),
        .config_out(config_out),
        .lock_status(lock_status),
        .core_active(core_active)
    );

    // Clock generation (not strictly needed for this combinational check, but provided for simulation)
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        aon_rst_n = 0;
        core_rst_n = 0;
        write_en = 0;
        data_in = 8'h00;
        lock_req = 0;

        // Wait for global reset
        #10;

        // -------------------------------------------------------
        // Test Case 1: Check behavior during AON Reset (aon_rst_n = 0)
        // -------------------------------------------------------
        
        // Set core_rst_n LOW
        core_rst_n = 0;
        #1; // Allow combinational propagation
        if (core_active !== 0) begin
            $display("[TEST] FAIL: core_active is %b, expected 0 when core_rst_n is 0 (during aon reset).", core_active);
            $finish;
        end

        // Set core_rst_n HIGH
        core_rst_n = 1;
        #1;
        if (core_active !== 1) begin
            $display("[TEST] FAIL: core_active is %b, expected 1 when core_rst_n is 1 (during aon reset).", core_active);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Check behavior during Normal Operation (aon_rst_n = 1)
        // -------------------------------------------------------
        
        // Release AON reset
        aon_rst_n = 1;
        #10;

        // Set core_rst_n LOW
        core_rst_n = 0;
        #1;
        if (core_active !== 0) begin
            $display("[TEST] FAIL: core_active is %b, expected 0 when core_rst_n is 0.", core_active);
            $finish;
        end

        // Set core_rst_n HIGH
        core_rst_n = 1;
        #1;
        if (core_active !== 1) begin
            $display("[TEST] FAIL: core_active is %b, expected 1 when core_rst_n is 1.", core_active);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Toggle check at arbitrary time
        // -------------------------------------------------------
        #7; // Wait arbitrary time
        core_rst_n = 0;
        #1;
        if (core_active !== 0) begin
            $display("[TEST] FAIL: core_active failed to update to 0 immediately.");
            $finish;
        end

        #3;
        core_rst_n = 1;
        #1;
        if (core_active !== 1) begin
            $display("[TEST] FAIL: core_active failed to update to 1 immediately.");
            $finish;
        end

        // If all checks pass
        $display("[TEST] PASS: core_active continuously reflects core_rst_n state.");
        $finish;
    end

endmodule