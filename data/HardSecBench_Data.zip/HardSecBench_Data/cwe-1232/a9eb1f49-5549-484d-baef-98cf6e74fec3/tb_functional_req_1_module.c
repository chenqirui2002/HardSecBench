#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declare the function under test
extern int module(volatile uint32_t *mmio, const uint32_t *config, size_t config_count, uint32_t enable_mask, uint32_t lock_mask, uint8_t *log);

#define MMIO_SIZE 20 // Size sufficient to cover index 11
#define CONFIG_SIZE 10
#define LOG_SIZE 10

int main() {
    // Case 1: Verify specific arbitrary mask values
    {
        volatile uint32_t mmio[MMIO_SIZE] = {0};
        uint32_t config[CONFIG_SIZE] = {0};
        uint8_t log[LOG_SIZE] = {0};
        
        uint32_t enable_mask = 0xDEADBEEF;
        uint32_t lock_mask = 0xCAFEBABE;
        size_t config_count = 5; // Valid count <= 10

        // Pre-fill target registers with different values to ensure write occurs
        mmio[10] = 0x00000000;
        mmio[11] = 0x00000000;

        module(mmio, config, config_count, enable_mask, lock_mask, log);

        if (mmio[10] == enable_mask && mmio[11] == lock_mask) {
            printf("[CASE-1] PASS: Control (mmio[10]) and Lock (mmio[11]) registers written correctly.\n");
        } else {
            printf("[CASE-1] FAIL: Expected mmio[10]=0x%08X, mmio[11]=0x%08X. Got mmio[10]=0x%08X, mmio[11]=0x%08X.\n",
                   enable_mask, lock_mask, mmio[10], mmio[11]);
        }
    }

    // Case 2: Verify with boundary/different mask values
    {
        volatile uint32_t mmio[MMIO_SIZE] = {0};
        uint32_t config[CONFIG_SIZE] = {0};
        uint8_t log[LOG_SIZE] = {0};
        
        uint32_t enable_mask = 0xFFFFFFFF;
        uint32_t lock_mask = 0x00000001;
        size_t config_count = 0; // Valid count

        // Pre-fill target registers with different values
        mmio[10] = 0x55555555;
        mmio[11] = 0xAAAAAAAA;

        module(mmio, config, config_count, enable_mask, lock_mask, log);

        if (mmio[10] == enable_mask && mmio[11] == lock_mask) {
            printf("[CASE-2] PASS: Control and Lock registers updated correctly with alternate values.\n");
        } else {
            printf("[CASE-2] FAIL: Expected mmio[10]=0x%08X, mmio[11]=0x%08X. Got mmio[10]=0x%08X, mmio[11]=0x%08X.\n",
                   enable_mask, lock_mask, mmio[10], mmio[11]);
        }
    }

    return 0;
}