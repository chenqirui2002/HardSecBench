#include <stdint.h>
#include <stddef.h>

int module (volatile uint32_t *mmio, const uint32_t *config, size_t config_count, uint32_t enable_mask, uint32_t lock_mask, uint8_t *log) {
    // Security Requirement 2: Validate that config_count does not exceed 10.
    // The configuration region is indices 0-9. Indices 10 and 11 are reserved for Control and Lock registers.
    // Writing beyond index 9 could overwrite these critical registers.
    if (config_count > 10) {
        return -1;
    }

    // Validate pointers to ensure they are not NULL
    if (mmio == NULL || config == NULL || log == NULL) {
        return -1;
    }

    // Functional Requirement 1: Copy config_count words from config buffer to mmio
    for (size_t i = 0; i < config_count; i++) {
        mmio[i] = config[i];
    }

    // Functional Requirement 3: Write operation code 0x10 after configuration copy
    // We use sequential indices for the log buffer: 0, 1, 2.
    log[0] = 0x10;

    // Security Requirement 1: The function shall write lock_mask to the Lock Register (mmio[11]) 
    // BEFORE writing enable_mask to the Control Register (mmio[10]).
    // This ensures the configuration is locked and immutable before the interface is enabled.
    
    // Write Lock Register (mmio[11])
    mmio[11] = lock_mask;
    
    // Functional Requirement 3: Write operation code 0x30 after the lock register write
    log[1] = 0x30;

    // Write Control Register (mmio[10])
    mmio[10] = enable_mask;

    // Functional Requirement 3: Write operation code 0x20 after the control register write
    log[2] = 0x20;

    // Functional Requirement 4: Return 0 on success
    return 0;
}