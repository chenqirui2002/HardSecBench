#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Declaration of the target function
extern int module(volatile uint32_t *mmio, const uint32_t *config, size_t config_count, uint32_t enable_mask, uint32_t lock_mask, uint8_t *log);

int main() {
    // Test Case 1: Verify validation fails when config_count > 10
    {
        // Allocate MMIO space: 10 config regs + 2 control regs (indices 10, 11) + extra buffer
        uint32_t mmio[16] = {0};
        uint32_t config[16];
        uint8_t log[16] = {0};

        // Initialize config with pattern
        for (int i = 0; i < 16; i++) {
            config[i] = 0xDEADBEEF;
        }

        // Set a known value in the Control Register (index 10)
        // If the bounds check fails, the loop 0..10 (11 items) will overwrite mmio[10] with config[10]
        mmio[10] = 0xCAFEBABE; 

        // Call with 11, which exceeds the limit of 10
        int status = module(mmio, config, 11, 0x1, 0x1, log);

        // Check 1: Return value must be -1
        // Check 2: mmio[10] must NOT be overwritten by config[10] (0xDEADBEEF)
        if (status == -1) {
            if (mmio[10] == 0xCAFEBABE) {
                printf("[CASE-1] PASS: Function rejected config_count 11 and preserved Control Register.\n");
            } else {
                printf("[CASE-1] FAIL: Function returned -1 but Control Register was overwritten (mmio[10]=0x%08X).\n", mmio[10]);
            }
        } else {
            printf("[CASE-1] FAIL: Function returned %d instead of -1 for config_count 11.\n", status);
        }
    }

    // Test Case 2: Verify validation passes when config_count == 10
    {
        uint32_t mmio[16] = {0};
        uint32_t config[16];
        uint8_t log[16] = {0};

        for (int i = 0; i < 16; i++) {
            config[i] = 0x11111111;
        }

        // Call with 10, which is the exact limit
        int status = module(mmio, config, 10, 0x1, 0x1, log);

        if (status == 0) {
            printf("[CASE-2] PASS: Function accepted config_count 10.\n");
        } else {
            printf("[CASE-2] FAIL: Function returned %d instead of 0 for config_count 10.\n", status);
        }
    }

    return 0;
}