#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declare the function under test
extern int module(volatile uint32_t *mmio, const uint32_t *config, size_t config_count, uint32_t enable_mask, uint32_t lock_mask, uint8_t *log);

#define MMIO_SIZE 20
#define LOG_SIZE 10

int main() {
    // Test Case 1: Verify copy of 5 words
    {
        volatile uint32_t mmio[MMIO_SIZE];
        uint32_t config[10] = {0x11111111, 0x22222222, 0x33333333, 0x44444444, 0x55555555};
        uint8_t log[LOG_SIZE];
        size_t config_count = 5;
        uint32_t enable_mask = 0x1;
        uint32_t lock_mask = 0x2;

        // Initialize mmio with a known background pattern
        for (int i = 0; i < MMIO_SIZE; i++) {
            mmio[i] = 0xAAAAAAAA;
        }
        memset(log, 0, LOG_SIZE);

        // Execute function
        int status = module(mmio, config, config_count, enable_mask, lock_mask, log);

        if (status != 0) {
            printf("[CASE-1] FAIL: Function returned error code %d\n", status);
        } else {
            int mismatch = 0;
            for (size_t i = 0; i < config_count; i++) {
                if (mmio[i] != config[i]) {
                    mismatch = 1;
                    printf("[CASE-1] FAIL: Mismatch at index %zu. Expected 0x%08X, got 0x%08X\n", i, config[i], mmio[i]);
                }
            }
            if (!mismatch) {
                printf("[CASE-1] PASS: Config data copied correctly for count 5\n");
            }
        }
    }

    // Test Case 2: Verify copy of 10 words (Maximum expected valid size)
    {
        volatile uint32_t mmio[MMIO_SIZE];
        uint32_t config[10] = {
            0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 
            0x0F, 0x10, 0x11, 0x12, 0x13
        };
        uint8_t log[LOG_SIZE];
        size_t config_count = 10;
        uint32_t enable_mask = 0x1;
        uint32_t lock_mask = 0x2;

        // Initialize mmio with a known background pattern
        for (int i = 0; i < MMIO_SIZE; i++) {
            mmio[i] = 0xFFFFFFFF;
        }
        memset(log, 0, LOG_SIZE);

        // Execute function
        int status = module(mmio, config, config_count, enable_mask, lock_mask, log);

        if (status != 0) {
            printf("[CASE-2] FAIL: Function returned error code %d\n", status);
        } else {
            int mismatch = 0;
            for (size_t i = 0; i < config_count; i++) {
                if (mmio[i] != config[i]) {
                    mismatch = 1;
                    printf("[CASE-2] FAIL: Mismatch at index %zu. Expected 0x%08X, got 0x%08X\n", i, config[i], mmio[i]);
                }
            }
            if (!mismatch) {
                printf("[CASE-2] PASS: Config data copied correctly for count 10\n");
            }
        }
    }

    return 0;
}