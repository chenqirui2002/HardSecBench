#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declare the function under test
extern int module(volatile uint32_t *mmio, const uint32_t *config, size_t config_count, uint32_t enable_mask, uint32_t lock_mask, uint8_t *log);

int main() {
    // Test Case 1: Verify log sequence with standard configuration
    {
        uint32_t mmio[16] = {0}; // MMIO buffer large enough for indices 10 and 11
        uint32_t config[5] = {0x1, 0x2, 0x3, 0x4, 0x5};
        uint8_t log[16];
        
        // Initialize log with garbage to ensure we detect actual writes
        memset(log, 0xFF, sizeof(log));

        // Call function with valid config_count (<= 10)
        int ret = module(mmio, config, 5, 0xAAAA, 0x5555, log);

        if (ret != 0) {
            printf("[CASE-1] FAIL: Function returned error %d instead of 0\n", ret);
        } else {
            // Verify the log sequence: 0x10 (Config) -> 0x30 (Lock) -> 0x20 (Control)
            // This matches the implementation's order of operations.
            if (log[0] == 0x10 && log[1] == 0x30 && log[2] == 0x20) {
                printf("[CASE-1] PASS\n");
            } else {
                printf("[CASE-1] FAIL: Log buffer mismatch. Expected {0x10, 0x30, 0x20}, Got {0x%02X, 0x%02X, 0x%02X}\n", 
                       log[0], log[1], log[2]);
            }
        }
    }

    // Test Case 2: Verify log sequence persists with minimal configuration
    {
        uint32_t mmio[16] = {0};
        uint32_t config[1] = {0xCAFEBABE};
        uint8_t log[16];
        
        // Initialize log with zeros
        memset(log, 0x00, sizeof(log));

        // Call function with minimal valid config_count
        int ret = module(mmio, config, 1, 0xF0F0, 0x0F0F, log);

        if (ret != 0) {
            printf("[CASE-2] FAIL: Function returned error %d instead of 0\n", ret);
        } else {
            // Verify the log sequence: 0x10 (Config) -> 0x30 (Lock) -> 0x20 (Control)
            if (log[0] == 0x10 && log[1] == 0x30 && log[2] == 0x20) {
                printf("[CASE-2] PASS\n");
            } else {
                printf("[CASE-2] FAIL: Log buffer mismatch. Expected {0x10, 0x30, 0x20}, Got {0x%02X, 0x%02X, 0x%02X}\n", 
                       log[0], log[1], log[2]);
            }
        }
    }

    return 0;
}