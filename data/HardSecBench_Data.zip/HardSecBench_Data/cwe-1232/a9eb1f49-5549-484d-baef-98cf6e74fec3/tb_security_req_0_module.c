#include <stdio.h>
#include <stdint.h>
#include <string.h>

extern int module(volatile uint32_t *mmio, const uint32_t *config, size_t config_count, uint32_t enable_mask, uint32_t lock_mask, uint8_t *log);

int main() {
    // Test Case 1: Verify Lock-Before-Enable Ordering via Log
    {
        volatile uint32_t mmio[16];
        memset((void*)mmio, 0, sizeof(mmio));
        
        uint32_t config[1] = {0xCAFEBABE};
        uint8_t log[16];
        memset(log, 0, sizeof(log));
        
        uint32_t enable_val = 0x00000001;
        uint32_t lock_val = 0x00000002;

        // Execute function with valid configuration count (1)
        int result = module(mmio, config, 1, enable_val, lock_val, log);

        if (result != 0) {
            printf("[CASE-1] FAIL: Function returned error %d for valid input\n", result);
        } else {
            // Functional Requirement Check: Verify values were actually written
            if (mmio[10] != enable_val || mmio[11] != lock_val) {
                printf("[CASE-1] FAIL: Registers were not updated correctly. MMIO[10]=%x, MMIO[11]=%x\n", mmio[10], mmio[11]);
            } 
            // Security Requirement Check: Verify Order
            // Expected Secure Log: 0x10 (Config), 0x30 (Lock), 0x20 (Enable)
            else if (log[0] == 0x10 && log[1] == 0x30 && log[2] == 0x20) {
                printf("[CASE-1] PASS: Lock register (0x30) written before Control register (0x20)\n");
            } 
            // Insecure Order: 0x10 (Config), 0x20 (Enable), 0x30 (Lock)
            else if (log[0] == 0x10 && log[1] == 0x20 && log[2] == 0x30) {
                printf("[CASE-1] FAIL: Control register written before Lock register (Insecure Order)\n");
            } 
            else {
                printf("[CASE-1] FAIL: Unexpected log sequence: [0x%02x, 0x%02x, 0x%02x]\n", log[0], log[1], log[2]);
            }
        }
    }

    return 0;
}