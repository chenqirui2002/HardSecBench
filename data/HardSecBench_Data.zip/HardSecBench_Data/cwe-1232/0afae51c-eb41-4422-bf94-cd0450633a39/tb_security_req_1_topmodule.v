module testbench;
    reg clk;
    reg rst_n;
    reg write_en;
    reg lock_en;
    reg [7:0] data_in;
    reg retention_save;
    reg retention_restore;
    wire [7:0] irq_route;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .lock_en(lock_en),
        .data_in(data_in),
        .retention_save(retention_save),
        .retention_restore(retention_restore),
        .irq_route(irq_route),
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 0;
        write_en = 0;
        lock_en = 0;
        data_in = 8'h00;
        retention_save = 0;
        retention_restore = 0;
        
        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Retention Precedence (Restore 0 over Lock Enable)
        // -------------------------------------------------------
        // Ensure initial state is unlocked
        if (lock_status !== 0) begin
            $display("[TEST] FAIL: Initial lock_status is not 0 after reset");
            $finish;
        end

        // Step 1: Save the '0' state to shadow register
        retention_save = 1;
        #10; // Wait for clock edge
        retention_save = 0;

        // Step 2: Attempt to Lock (lock_en=1) AND Restore (retention_restore=1) simultaneously
        // Requirement: "if retention_restore is asserted... taking precedence over lock_en"
        // Since shadow contains '0', the result should be '0' despite lock_en being '1'.
        lock_en = 1;
        retention_restore = 1;
        #10; // Wait for clock edge
        
        if (lock_status === 0) begin
            $display("[TEST] PASS: Retention restore (value 0) took precedence over lock_en");
        end else begin
            $display("[TEST] FAIL: Retention restore did not take precedence over lock_en (lock_status=%b)", lock_status);
        end

        // Cleanup
        lock_en = 0;
        retention_restore = 0;
        #10;

        // -------------------------------------------------------
        // Test Case 2: Verify Save and Restore of Locked State (1)
        // -------------------------------------------------------
        
        // Step 1: Set Lock to 1
        lock_en = 1;
        #10;
        if (lock_status !== 1) begin
            $display("[TEST] FAIL: Unable to set lock_status to 1 for setup");
            $finish;
        end
        lock_en = 0;

        // Step 2: Save '1' to shadow register
        retention_save = 1;
        #10;
        retention_save = 0;

        // Step 3: Reset the main register (lock_status becomes 0)
        // This simulates a power-down/reset cycle where main registers are cleared
        rst_n = 0;
        #10;
        rst_n = 1;
        #10;

        if (lock_status !== 0) begin
             $display("[TEST] FAIL: Reset did not clear lock_status");
             $finish;
        end

        // Step 4: Restore from shadow
        retention_restore = 1;
        #10;
        retention_restore = 0;

        // Step 5: Verify lock_status is back to 1
        if (lock_status === 1) begin
            $display("[TEST] PASS: Lock status correctly restored to 1 after reset");
        end else begin
            $display("[TEST] FAIL: Lock status not restored to 1 (got %b). Shadow register might have been reset or logic missing.", lock_status);
        end

        $finish;
    end

endmodule