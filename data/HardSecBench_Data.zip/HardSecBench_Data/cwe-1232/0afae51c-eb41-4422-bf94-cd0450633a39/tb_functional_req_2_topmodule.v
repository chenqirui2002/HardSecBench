module tb_functional_req_2;
    // Signals
    reg clk;
    reg rst_n;
    reg write_en;
    reg lock_en;
    reg [7:0] data_in;
    reg retention_save;
    reg retention_restore;
    wire [7:0] irq_route;
    wire lock_status;

    // Instantiate the DUT
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .lock_en(lock_en),
        .data_in(data_in),
        .retention_save(retention_save),
        .retention_restore(retention_restore),
        .irq_route(irq_route),
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test sequence
    initial begin
        // Initialize inputs
        rst_n = 0;
        write_en = 0;
        lock_en = 0;
        data_in = 0;
        retention_save = 0;
        retention_restore = 0;

        // Reset system
        #20 rst_n = 1;

        // -------------------------------------------------------
        // Step 1: Write initial value (0xAA) to irq_route
        // -------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        data_in = 8'hAA;
        
        @(negedge clk);
        write_en = 0;
        
        // Check if write was successful
        if (irq_route !== 8'hAA) begin
            $display("[TEST] FAIL: Initial write failed. Expected 0xAA, got 0x%h", irq_route);
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Save current state (0xAA) to shadow register
        // -------------------------------------------------------
        @(negedge clk);
        retention_save = 1;
        
        @(negedge clk);
        retention_save = 0;

        // -------------------------------------------------------
        // Step 3: Modify irq_route to a new value (0x55)
        // -------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        data_in = 8'h55;
        
        @(negedge clk);
        write_en = 0;

        // Check if modification was successful
        if (irq_route !== 8'h55) begin
            $display("[TEST] FAIL: Modification write failed. Expected 0x55, got 0x%h", irq_route);
            $finish;
        end

        // -------------------------------------------------------
        // Step 4: Restore state (expect 0xAA) with write conflict (0xFF)
        // Requirement: Restore takes precedence over write_en
        // -------------------------------------------------------
        @(negedge clk);
        retention_restore = 1;
        write_en = 1;
        data_in = 8'hFF; // This should be ignored due to precedence
        
        @(negedge clk);
        retention_restore = 0;
        write_en = 0;

        // -------------------------------------------------------
        // Step 5: Verify Results
        // -------------------------------------------------------
        #1; // Wait for logic settling
        if (irq_route === 8'hAA) begin
            $display("[TEST] PASS: irq_route restored to 0xAA, overriding write_en");
        end else if (irq_route === 8'hFF) begin
            $display("[TEST] FAIL: Precedence error. irq_route updated to 0xFF (write_en took priority)");
        end else if (irq_route === 8'h55) begin
            $display("[TEST] FAIL: Restore error. irq_route remained 0x55 (restore ignored)");
        end else begin
            $display("[TEST] FAIL: Unexpected value. Expected 0xAA, got 0x%h", irq_route);
        end

        $finish;
    end

endmodule