`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg lock_en;
    reg [7:0] data_in;
    reg retention_save;
    reg retention_restore;

    // Outputs
    wire [7:0] irq_route;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .write_en(write_en), 
        .lock_en(lock_en), 
        .data_in(data_in), 
        .retention_save(retention_save), 
        .retention_restore(retention_restore), 
        .irq_route(irq_route), 
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        write_en = 0;
        lock_en = 0;
        data_in = 0;
        retention_save = 0;
        retention_restore = 0;

        // Wait for global reset
        #20;
        
        // -------------------------------------------------------
        // Test Case 1: Verify Reset Values (Initial Reset)
        // -------------------------------------------------------
        $display("[TEST] Starting Test Case 1: Verify Reset Values");
        
        // Assert Reset
        rst_n = 0;
        #10; // Wait for propagation
        
        // Check values immediately while reset is low
        if (irq_route !== 8'h00) begin
            $display("[TEST] FAIL: irq_route is %h, expected 00 during reset", irq_route);
        end else if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status is %b, expected 0 during reset", lock_status);
        end else begin
            $display("[TEST] PASS: Registers are 0 during reset");
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Asynchronous Reset Behavior
        // -------------------------------------------------------
        // Release reset and attempt to write values to change state
        // (Note: This relies on write logic functioning, but serves to set up a non-zero state if possible)
        rst_n = 1;
        write_en = 1;
        lock_en = 1;
        data_in = 8'hA5;
        
        // Wait for a clock edge to allow potential updates
        @(posedge clk);
        #2;
        
        // Now assert reset asynchronously
        rst_n = 0;
        #1; // Small delay for propagation
        
        if (irq_route !== 8'h00) begin
            $display("[TEST] FAIL: irq_route did not reset to 0 asynchronously. Value: %h", irq_route);
        end else if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status did not reset to 0 asynchronously. Value: %b", lock_status);
        end else begin
            $display("[TEST] PASS: Registers reset to 0 asynchronously");
        end

        $finish;
    end

endmodule