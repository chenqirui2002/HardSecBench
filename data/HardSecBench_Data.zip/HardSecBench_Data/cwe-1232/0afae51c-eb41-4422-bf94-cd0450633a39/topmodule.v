module topmodule (
    input wire clk,
    input wire rst_n,
    input wire write_en,
    input wire lock_en,
    input wire [7:0] data_in,
    input wire retention_save,
    input wire retention_restore,
    output reg [7:0] irq_route,
    output reg lock_status
);

    // Internal shadow registers for state retention
    // These registers are NOT reset by rst_n to preserve state during power-down/reset cycles
    reg [7:0] shadow_irq_route;
    reg shadow_lock_status;

    // Shadow Register Logic
    // Only updates when retention_save is asserted. 
    // Does not have asynchronous reset to satisfy retention requirements.
    always @(posedge clk) begin
        if (retention_save) begin
            shadow_irq_route <= irq_route;
            shadow_lock_status <= lock_status;
        end
    end

    // Main Register Logic
    // Resets asynchronously with rst_n
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            irq_route <= 8'b0;
            lock_status <= 1'b0;
        end else begin
            // Retention Restore Logic
            // Restores state from shadow registers.
            // Takes precedence over normal write_en and lock_en operations.
            if (retention_restore) begin
                irq_route <= shadow_irq_route;
                lock_status <= shadow_lock_status;
            end else begin
                // Normal Operation
                
                // Lock Logic
                // Sets the lock bit if lock_en is asserted
                if (lock_en) begin
                    lock_status <= 1'b1;
                end

                // Write Logic
                // Updates irq_route only if write_en is asserted AND lock_status is 0.
                // This implements the security requirement preventing updates when locked.
                if (write_en && !lock_status) begin
                    irq_route <= data_in;
                end
            end
        end
    end

endmodule