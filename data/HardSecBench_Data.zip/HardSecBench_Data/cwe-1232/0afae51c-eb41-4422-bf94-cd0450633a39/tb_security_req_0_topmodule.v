module tb_security_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg lock_en;
    reg [7:0] data_in;
    reg retention_save;
    reg retention_restore;

    // Outputs
    wire [7:0] irq_route;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .lock_en(lock_en),
        .data_in(data_in),
        .retention_save(retention_save),
        .retention_restore(retention_restore),
        .irq_route(irq_route),
        .lock_status(lock_status)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        write_en = 0;
        lock_en = 0;
        data_in = 8'h00;
        retention_save = 0;
        retention_restore = 0;

        // Reset the system
        #10 rst_n = 1;

        // -------------------------------------------------------
        // Step 1: Setup - Write initial value (0xAA) while unlocked
        // -------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        data_in = 8'hAA;
        
        @(negedge clk);
        write_en = 0;

        // Verify setup was successful
        if (irq_route !== 8'hAA) begin
            $display("[TEST] FAIL: Setup failed. Could not write initial value 0xAA to irq_route.");
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Lock the configuration
        // -------------------------------------------------------
        @(negedge clk);
        lock_en = 1;
        
        @(negedge clk);
        lock_en = 0;

        // Verify lock is active
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed. lock_status did not assert after lock_en.");
            $finish;
        end

        // -------------------------------------------------------
        // Step 3: Attempt Attack - Try to write 0x55 while locked
        // -------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        data_in = 8'h55;

        @(negedge clk);
        write_en = 0;

        // -------------------------------------------------------
        // Step 4: Verify Security Requirement
        // -------------------------------------------------------
        // Requirement: if lock_status is 1, irq_route shall not be updated.
        if (irq_route === 8'hAA) begin
            $display("[TEST] PASS: irq_route retained value 0xAA and ignored write attempt while locked.");
        end else if (irq_route === 8'h55) begin
            $display("[TEST] FAIL: irq_route updated to 0x55 despite lock_status being 1.");
        end else begin
            $display("[TEST] FAIL: irq_route contains unexpected value: 0x%h", irq_route);
        end

        $finish;
    end

endmodule