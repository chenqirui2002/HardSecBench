`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg lock_en;
    reg [7:0] data_in;
    reg retention_save;
    reg retention_restore;

    // Outputs
    wire [7:0] irq_route;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .lock_en(lock_en),
        .data_in(data_in),
        .retention_save(retention_save),
        .retention_restore(retention_restore),
        .irq_route(irq_route),
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        lock_en = 0;
        data_in = 0;
        retention_save = 0;
        retention_restore = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify irq_route update when write_en is asserted
        // -------------------------------------------------------
        $display("[TEST] Starting Test Case 1: Write to irq_route");
        
        data_in = 8'hA5;
        write_en = 1;
        lock_en = 0; // Ensure lock is not asserted to avoid security logic interference
        
        @(posedge clk); // Trigger update
        #1; // Wait for output to settle
        
        write_en = 0; // Deassert write_en

        if (irq_route === 8'hA5) begin
            $display("[TEST] PASS: irq_route updated to 0xA5 as expected.");
        end else begin
            $display("[TEST] FAIL: irq_route mismatch. Expected 0xA5, got 0x%h", irq_route);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Verify lock_status update when lock_en is asserted
        // -------------------------------------------------------
        $display("[TEST] Starting Test Case 2: Set lock_status");
        
        lock_en = 1;
        
        @(posedge clk); // Trigger update
        #1; // Wait for output to settle
        
        lock_en = 0; // Deassert lock_en

        if (lock_status === 1'b1) begin
            $display("[TEST] PASS: lock_status set to 1 as expected.");
        end else begin
            $display("[TEST] FAIL: lock_status mismatch. Expected 1, got %b", lock_status);
            $finish;
        end

        // End of tests
        $display("[TEST] All checks passed for FUNCTIONAL-REQ-1.");
        $finish;
    end

endmodule