module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg wake_request;
    reg sleep_request;
    reg lock_set;
    reg config_wr;
    reg [3:0] config_in;

    // Outputs
    wire pmu_state;
    wire lock_status;
    wire [3:0] config_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .wake_request(wake_request),
        .sleep_request(sleep_request),
        .lock_set(lock_set),
        .config_wr(config_wr),
        .config_in(config_in),
        .pmu_state(pmu_state),
        .lock_status(lock_status),
        .config_out(config_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        wake_request = 0;
        sleep_request = 0;
        lock_set = 0;
        config_wr = 0;
        config_in = 4'b0000;

        // Wait for global reset
        #100;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Step 1: Verify Initial State is ACTIVE (0)
        // -------------------------------------------------------
        if (pmu_state !== 1'b0) begin
            $display("[TEST] FAIL: Initial state is not ACTIVE (0) after reset");
            $finish;
        end

        // -------------------------------------------------------
        // Test Step 2: Transition ACTIVE -> SLEEP
        // -------------------------------------------------------
        @(negedge clk);
        sleep_request = 1;
        
        @(posedge clk); // Trigger transition
        #1; // Allow for propagation delay
        
        if (pmu_state !== 1'b1) begin
            $display("[TEST] FAIL: pmu_state did not transition to SLEEP (1) when sleep_request was high");
            $finish;
        end else begin
            $display("[TEST] PASS: Transition to SLEEP successful");
        end

        // Deassert sleep_request to prepare for next test
        sleep_request = 0;
        @(posedge clk); 
        #1;
        
        // Verify state remains SLEEP if no wake request
        if (pmu_state !== 1'b1) begin
             $display("[TEST] FAIL: pmu_state changed from SLEEP unexpectedly");
             $finish;
        end

        // -------------------------------------------------------
        // Test Step 3: Transition SLEEP -> ACTIVE
        // -------------------------------------------------------
        @(negedge clk);
        wake_request = 1;

        @(posedge clk); // Trigger transition
        #1; // Allow for propagation delay

        if (pmu_state !== 1'b0) begin
            $display("[TEST] FAIL: pmu_state did not transition to ACTIVE (0) when wake_request was high");
            $finish;
        end else begin
            $display("[TEST] PASS: Transition to ACTIVE successful");
        end

        // Cleanup
        wake_request = 0;
        @(posedge clk);
        
        $display("[TEST] PASS: All state transitions verified successfully");
        $finish;
    end

endmodule