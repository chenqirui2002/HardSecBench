module tb_task_cwe_1232_seed14;

    // Inputs
    reg clk;
    reg rst_n;
    reg wake_request;
    reg sleep_request;
    reg lock_set;
    reg config_wr;
    reg [3:0] config_in;

    // Outputs
    wire pmu_state;
    wire lock_status;
    wire [3:0] config_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .wake_request(wake_request),
        .sleep_request(sleep_request),
        .lock_set(lock_set),
        .config_wr(config_wr),
        .config_in(config_in),
        .pmu_state(pmu_state),
        .lock_status(lock_status),
        .config_out(config_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        wake_request = 0;
        sleep_request = 0;
        lock_set = 0;
        config_wr = 0;
        config_in = 4'b0000;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // Check Initial State (REQ-0 context for REQ-2)
        if (pmu_state !== 0) begin
            $display("[TEST] FAIL: Precondition failed. pmu_state is not 0 (ACTIVE) after reset.");
            $finish;
        end
        if (lock_status !== 0) begin
            $display("[TEST] FAIL: Precondition failed. lock_status is not 0 after reset.");
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 1: Verify config update when Unlocked
        // Requirement: "If lock_status is 0 and config_wr is high, update config_out"
        // ---------------------------------------------------------------------
        $display("[TEST] Step 1: Testing Config Update when Unlocked...");
        config_in = 4'hA;
        config_wr = 1;
        lock_set = 0;

        @(posedge clk);
        #1; // Allow for propagation

        if (config_out !== 4'hA) begin
            $display("[TEST] FAIL: config_out did not update to 4'hA when unlocked. Got: %h", config_out);
            $finish;
        end else begin
            $display("[TEST] PASS: config_out updated correctly when unlocked.");
        end

        // Deassert write
        config_wr = 0;
        @(posedge clk);

        // ---------------------------------------------------------------------
        // Test Case 2: Verify Lock Setting
        // Requirement: "if lock_set is high, set lock_status to 1"
        // ---------------------------------------------------------------------
        $display("[TEST] Step 2: Testing Lock Set...");
        lock_set = 1;

        @(posedge clk);
        #1;

        if (lock_status !== 1) begin
            $display("[TEST] FAIL: lock_status did not set to 1 after lock_set assertion.");
            $finish;
        end else begin
            $display("[TEST] PASS: lock_status set to 1.");
        end

        // Deassert lock_set, lock should persist (sticky bit implied by register behavior)
        lock_set = 0;
        @(posedge clk);
        #1;
        
        if (lock_status !== 1) begin
             $display("[TEST] FAIL: lock_status cleared unexpectedly without reset.");
             $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 3: Verify Config Update Inhibited when Locked
        // Requirement: "If lock_status is 0... update" (Implies if 1, do not update)
        // ---------------------------------------------------------------------
        $display("[TEST] Step 3: Testing Config Write Inhibited when Locked...");
        config_in = 4'h5;
        config_wr = 1;

        @(posedge clk);
        #1;

        if (config_out === 4'h5) begin
            $display("[TEST] FAIL: config_out updated to 4'h5 despite lock_status being 1.");
            $finish;
        end else if (config_out === 4'hA) begin
            $display("[TEST] PASS: config_out retained value 4'hA when locked.");
        end else begin
            $display("[TEST] FAIL: config_out changed to unexpected value %h when locked.", config_out);
            $finish;
        end

        // Final Success
        $display("[TEST] PASS: All checks for Functional Requirement 2 passed.");
        $finish;
    end

endmodule