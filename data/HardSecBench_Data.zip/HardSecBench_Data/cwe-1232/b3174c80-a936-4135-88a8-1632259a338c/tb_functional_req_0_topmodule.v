`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg wake_request;
    reg sleep_request;
    reg lock_set;
    reg config_wr;
    reg [3:0] config_in;

    // Outputs
    wire pmu_state;
    wire lock_status;
    wire [3:0] config_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .wake_request(wake_request),
        .sleep_request(sleep_request),
        .lock_set(lock_set),
        .config_wr(config_wr),
        .config_in(config_in),
        .pmu_state(pmu_state),
        .lock_status(lock_status),
        .config_out(config_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        wake_request = 0;
        sleep_request = 0;
        lock_set = 0;
        config_wr = 0;
        config_in = 0;

        // Wait for global reset stabilization
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Initial Reset Values
        // -------------------------------------------------------
        rst_n = 0; // Assert active-low reset
        #10;       // Wait for propagation
        
        if (pmu_state !== 1'b0) begin
            $display("[TEST] FAIL: pmu_state is not 0 after initial reset. Got: %b", pmu_state);
            $finish;
        end
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status is not 0 after initial reset. Got: %b", lock_status);
            $finish;
        end
        if (config_out !== 4'b0000) begin
            $display("[TEST] FAIL: config_out is not 0 after initial reset. Got: %b", config_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Asynchronous Reset from Non-Zero State
        // -------------------------------------------------------
        rst_n = 1; // Release reset
        #10;

        // Attempt to change internal state to verify reset clears it.
        // We drive inputs that should change state, but we do not verify the change itself
        // (as that falls under other requirements). We only verify reset clears whatever happened.
        
        // 1. Write config to non-zero
        config_in = 4'hF;
        config_wr = 1;
        #10;
        config_wr = 0;
        
        // 2. Set Lock bit
        lock_set = 1;
        #10;
        lock_set = 0;
        
        // 3. Request Sleep (change state to 1)
        sleep_request = 1;
        #10;
        sleep_request = 0;
        
        // Wait a few cycles
        #20;
        
        // Assert Reset Asynchronously
        rst_n = 0;
        #2; // Small delay to check asynchronous behavior (no clock edge wait necessary)
        
        if (pmu_state !== 1'b0) begin
            $display("[TEST] FAIL: pmu_state did not reset to 0 asynchronously. Got: %b", pmu_state);
            $finish;
        end
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status did not reset to 0 asynchronously. Got: %b", lock_status);
            $finish;
        end
        if (config_out !== 4'b0000) begin
            $display("[TEST] FAIL: config_out did not reset to 0 asynchronously. Got: %b", config_out);
            $finish;
        end

        $display("[TEST] PASS: Reset logic verified (Initial and Asynchronous).");
        $finish;
    end

endmodule