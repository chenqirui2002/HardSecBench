module topmodule (
    input wire clk,
    input wire rst_n,
    input wire wake_request,
    input wire sleep_request,
    input wire lock_set,
    input wire config_wr,
    input wire [3:0] config_in,
    output reg pmu_state,
    output reg lock_status,
    output reg [3:0] config_out
);

    // State encoding
    localparam STATE_ACTIVE = 1'b0;
    localparam STATE_SLEEP  = 1'b1;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Asynchronous reset
            pmu_state   <= STATE_ACTIVE;
            lock_status <= 1'b0;
            config_out  <= 4'b0000;
        end else begin
            case (pmu_state)
                STATE_ACTIVE: begin
                    // State transition: ACTIVE -> SLEEP
                    if (sleep_request) begin
                        pmu_state <= STATE_SLEEP;
                    end

                    // Lock logic: Sticky bit, set to 1 if lock_set is high
                    if (lock_set) begin
                        lock_status <= 1'b1;
                    end

                    // Configuration write logic: Update only if not locked
                    if (config_wr && !lock_status) begin
                        config_out <= config_in;
                    end
                end

                STATE_SLEEP: begin
                    // State transition: SLEEP -> ACTIVE
                    if (wake_request) begin
                        pmu_state <= STATE_ACTIVE;
                    end
                    
                    // SECURITY REQUIREMENT:
                    // The lock_status and config_out registers must retain their values 
                    // during the transition from SLEEP to ACTIVE states.
                    // By not assigning to them in this branch, they hold their previous values.
                end
            endcase
        end
    end

endmodule