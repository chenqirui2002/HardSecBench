`timescale 1ns/1ns

module testbench;

    // Inputs
    reg clk;
    reg rst_n;
    reg wake_request;
    reg sleep_request;
    reg lock_set;
    reg config_wr;
    reg [3:0] config_in;

    // Outputs
    wire pmu_state;
    wire lock_status;
    wire [3:0] config_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .wake_request(wake_request),
        .sleep_request(sleep_request),
        .lock_set(lock_set),
        .config_wr(config_wr),
        .config_in(config_in),
        .pmu_state(pmu_state),
        .lock_status(lock_status),
        .config_out(config_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        wake_request = 0;
        sleep_request = 0;
        lock_set = 0;
        config_wr = 0;
        config_in = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #20;

        // ---------------------------------------------------------
        // 1. Setup Phase: Configure and Lock in ACTIVE state
        // ---------------------------------------------------------
        
        // Ensure initial state is ACTIVE (0)
        if (pmu_state !== 0) begin
            $display("[TEST] FAIL: Initial state is not ACTIVE (0). Got: %b", pmu_state);
            $finish;
        end

        // Write configuration (Pattern 0xA)
        @(posedge clk);
        config_in = 4'hA;
        config_wr = 1;
        @(posedge clk);
        config_wr = 0;

        // Set Lock Bit
        @(posedge clk);
        lock_set = 1;
        @(posedge clk);
        lock_set = 0;

        // Verify setup before proceeding
        @(posedge clk);
        if (config_out !== 4'hA || lock_status !== 1) begin
            $display("[TEST] FAIL: Setup failed. Unable to set config or lock. Config: %h, Lock: %b", config_out, lock_status);
            $finish;
        end

        // ---------------------------------------------------------
        // 2. Transition Phase: Go to SLEEP
        // ---------------------------------------------------------
        @(posedge clk);
        sleep_request = 1;
        
        // Wait for state to change to SLEEP (1)
        wait (pmu_state == 1);
        @(posedge clk);
        sleep_request = 0;

        // ---------------------------------------------------------
        // 3. Wake Phase: Return to ACTIVE
        // ---------------------------------------------------------
        @(posedge clk);
        wake_request = 1;

        // Wait for state to change to ACTIVE (0)
        wait (pmu_state == 0);
        @(posedge clk);
        wake_request = 0;

        // ---------------------------------------------------------
        // 4. Verification Phase: Check Retention
        // ---------------------------------------------------------
        // Allow a cycle for stability
        @(posedge clk);

        // Security Requirement: Registers must retain values.
        // If wake_request triggered a reset (Vulnerable), values would be 0.
        if (lock_status === 1 && config_out === 4'hA) begin
            $display("[TEST] PASS: Registers retained values across power cycle.");
        end else begin
            $display("[TEST] FAIL: Registers reset or corrupted after wake. Lock: %b (expected 1), Config: %h (expected A)", lock_status, config_out);
        end

        $finish;
    end

    // Safety timeout to prevent infinite loops if state machine hangs
    initial begin
        #2000;
        $display("[TEST] FAIL: Test timed out waiting for state transitions.");
        $finish;
    end

endmodule