`timescale 1ns/1ps

module tb_module_task_cwe_1232_seed2;

    // Inputs
    reg clk;
    reg rst_n;
    reg warm_rst_n;
    reg write_en;
    reg data_in;
    reg lock_req;

    // Outputs
    wire debug_en;
    wire locked;
    wire [1:0] current_state;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .warm_rst_n(warm_rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_req(lock_req),
        .debug_en(debug_en),
        .locked(locked),
        .current_state(current_state)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        warm_rst_n = 1;
        write_en = 0;
        data_in = 0;
        lock_req = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Write to debug_en when locked is 0
        // -------------------------------------------------------
        // Expectation: locked is initially 0 (from cold reset).
        // We will write 0 to debug_en (default is 1).
        
        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: Initial locked state is not 0 after reset.");
            $finish;
        end

        @(negedge clk);
        write_en = 1;
        data_in = 0;
        lock_req = 0;
        
        @(posedge clk); // Trigger update
        #1; // Allow propagation
        
        if (debug_en !== 1'b0) begin
            $display("[TEST] FAIL: debug_en did not update to 0 when locked=0 and write_en=1.");
        end else begin
            $display("[TEST] PASS: debug_en updated to 0 when unlocked.");
        end

        // Write 1 back
        @(negedge clk);
        write_en = 1;
        data_in = 1;
        
        @(posedge clk);
        #1;
        
        if (debug_en !== 1'b1) begin
            $display("[TEST] FAIL: debug_en did not update to 1 when locked=0 and write_en=1.");
        end else begin
            $display("[TEST] PASS: debug_en updated to 1 when unlocked.");
        end

        // -------------------------------------------------------
        // Test Case 2: Simultaneous Write and Lock Request
        // -------------------------------------------------------
        // Requirement: "if locked is 0... debug_en shall be updated"
        // AND "Independently, if lock_req is high, locked shall be set to 1"
        
        @(negedge clk);
        write_en = 1;
        data_in = 0; // Try to change debug_en to 0
        lock_req = 1; // And lock it at the same time
        
        @(posedge clk);
        #1;

        // Check 1: debug_en should have updated because locked WAS 0 at the rising edge
        if (debug_en !== 1'b0) begin
            $display("[TEST] FAIL: debug_en failed to update during simultaneous lock request.");
        end else begin
            $display("[TEST] PASS: debug_en updated during simultaneous lock request.");
        end

        // Check 2: locked should now be 1
        if (locked !== 1'b1) begin
            $display("[TEST] FAIL: locked did not assert when lock_req was high.");
        end else begin
            $display("[TEST] PASS: locked asserted high.");
        end

        // -------------------------------------------------------
        // Test Case 3: Attempt Write when Locked
        // -------------------------------------------------------
        // Requirement condition: "if locked is 0..."
        // Implication: If locked is 1, update should not happen (functional lock behavior).
        
        @(negedge clk);
        write_en = 1;
        data_in = 1; // Try to change debug_en back to 1
        lock_req = 0;
        
        @(posedge clk);
        #1;

        if (debug_en !== 1'b0) begin
            $display("[TEST] FAIL: debug_en updated while locked=1.");
        end else begin
            $display("[TEST] PASS: debug_en did not update while locked=1.");
        end

        // -------------------------------------------------------
        // Test Case 4: Lock Request when already locked (Stability)
        // -------------------------------------------------------
        @(negedge clk);
        lock_req = 1;
        write_en = 0;
        
        @(posedge clk);
        #1;
        
        if (locked !== 1'b1) begin
            $display("[TEST] FAIL: locked dropped to 0 unexpectedly.");
        end else begin
            $display("[TEST] PASS: locked remained 1.");
        end

        $finish;
    end

endmodule