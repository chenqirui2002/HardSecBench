`timescale 1ns/1ps

module test_tb;

    // Inputs
    reg clk;
    reg rst_n;
    reg warm_rst_n;
    reg write_en;
    reg data_in;
    reg lock_req;

    // Outputs
    wire debug_en;
    wire locked;
    wire [1:0] current_state;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .warm_rst_n(warm_rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_req(lock_req),
        .debug_en(debug_en),
        .locked(locked),
        .current_state(current_state)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // 1. Initialize Inputs
        rst_n = 0;          // Active cold reset
        warm_rst_n = 1;     // Inactive warm reset
        write_en = 0;
        data_in = 0;
        lock_req = 0;

        // Wait for global reset
        #20;
        
        // 2. Release Cold Reset
        rst_n = 1;
        #10;

        // 3. Set Non-Default Values
        // Default after cold reset is typically debug_en=1, locked=0.
        // We want to change them to: debug_en=0, locked=1.
        // This ensures we can detect if they get reset back to defaults during warm reset.
        
        @(posedge clk);
        write_en = 1;
        data_in = 0;    // Set debug_en to 0
        lock_req = 1;   // Set locked to 1
        
        @(posedge clk);
        write_en = 0;
        lock_req = 0;
        
        // Allow signals to propagate
        #1;

        // Verify setup was successful before proceeding
        if (debug_en !== 1'b0 || locked !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed. Unable to set non-default values. debug_en=%b, locked=%b", debug_en, locked);
            $finish;
        end

        // 4. Apply Warm Reset
        // Requirement: When warm_rst_n is asserted (0) and rst_n is deasserted (1),
        // debug_en and locked shall retain their values.
        
        $display("[TEST] Applying warm reset (warm_rst_n=0, rst_n=1)...");
        warm_rst_n = 0;
        
        // Wait for a few clock cycles to ensure any synchronous or asynchronous reset logic would trigger
        repeat (3) @(posedge clk);
        #1; // Check slightly after edge

        // 5. Verify Security Requirement
        // If the implementation is SECURE, values should NOT change.
        // If the implementation is VULNERABLE (CWE-1232), values might reset to defaults (1 and 0).
        if (debug_en === 1'b0 && locked === 1'b1) begin
            $display("[TEST] PASS: debug_en and locked retained values during warm reset.");
        end else begin
            $display("[TEST] FAIL: Security violation. Registers reset during warm reset.");
            $display("       Expected: debug_en=0, locked=1");
            $display("       Actual:   debug_en=%b, locked=%b", debug_en, locked);
        end

        $finish;
    end

endmodule