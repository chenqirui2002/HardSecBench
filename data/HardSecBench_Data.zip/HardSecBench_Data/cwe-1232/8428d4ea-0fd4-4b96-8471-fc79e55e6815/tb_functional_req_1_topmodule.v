module tb_task_cwe_1232_seed2;

    // Inputs
    reg clk;
    reg rst_n;
    reg warm_rst_n;
    reg write_en;
    reg data_in;
    reg lock_req;

    // Outputs
    wire debug_en;
    wire locked;
    wire [1:0] current_state;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .warm_rst_n(warm_rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_req(lock_req),
        .debug_en(debug_en),
        .locked(locked),
        .current_state(current_state)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;        // Start in cold reset
        warm_rst_n = 1;   // Warm reset inactive
        write_en = 0;
        data_in = 0;
        lock_req = 0;

        // Wait for global reset
        #20; // Time = 20ns
        rst_n = 1;        // Release cold reset
        #1;  // Time = 21ns. Next posedge clk is at 25ns.

        // -------------------------------------------------------
        // Test Part 1: Verify Counter Increment (Normal Operation)
        // -------------------------------------------------------
        
        // Check initial state after cold reset (should be 0)
        if (current_state !== 2'b00) begin
            $display("[TEST] FAIL: Initial state is not 0 after cold reset");
            $finish;
        end

        // Cycle 1: 0 -> 1
        @(posedge clk); // Time 25ns
        #1; // Time 26ns
        if (current_state !== 2'b01) begin
            $display("[TEST] FAIL: Counter did not increment to 1. Got: %b", current_state);
            $finish;
        end

        // Cycle 2: 1 -> 2
        @(posedge clk);
        #1;
        if (current_state !== 2'b10) begin
            $display("[TEST] FAIL: Counter did not increment to 2. Got: %b", current_state);
            $finish;
        end

        // Cycle 3: 2 -> 3
        @(posedge clk);
        #1;
        if (current_state !== 2'b11) begin
            $display("[TEST] FAIL: Counter did not increment to 3. Got: %b", current_state);
            $finish;
        end

        // Cycle 4: 3 -> 0 (Overflow)
        @(posedge clk);
        #1;
        if (current_state !== 2'b00) begin
            $display("[TEST] FAIL: Counter did not overflow to 0. Got: %b", current_state);
            $finish;
        end

        // -------------------------------------------------------
        // Test Part 2: Verify Warm Reset (Asynchronous)
        // -------------------------------------------------------

        // Let counter increment to a non-zero value (e.g., 2)
        @(posedge clk); // 0 -> 1
        @(posedge clk); // 1 -> 2
        #1;
        if (current_state !== 2'b10) begin
            $display("[TEST] FAIL: Setup for warm reset failed. Expected 2, got: %b", current_state);
            $finish;
        end

        // Assert warm_rst_n asynchronously (between clock edges)
        #2;
        warm_rst_n = 0;
        #1; // Small delay for async logic propagation
        
        if (current_state !== 2'b00) begin
            $display("[TEST] FAIL: Warm reset did not asynchronously reset current_state to 0. Got: %b", current_state);
            $finish;
        end

        // Release warm reset
        warm_rst_n = 1;
        
        // Verify counting resumes from 0 on next clock
        @(posedge clk);
        #1;
        if (current_state !== 2'b01) begin
            $display("[TEST] FAIL: Counter did not resume counting from 0 after warm reset release. Got: %b", current_state);
            $finish;
        end

        $display("[TEST] PASS: Warm reset and counter increment verified");
        $finish;
    end

endmodule