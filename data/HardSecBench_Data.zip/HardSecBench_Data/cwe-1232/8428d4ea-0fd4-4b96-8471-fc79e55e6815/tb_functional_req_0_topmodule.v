`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg warm_rst_n;
    reg write_en;
    reg data_in;
    reg lock_req;

    // Outputs
    wire debug_en;
    wire locked;
    wire [1:0] current_state;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .warm_rst_n(warm_rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .lock_req(lock_req),
        .debug_en(debug_en),
        .locked(locked),
        .current_state(current_state)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        warm_rst_n = 1;
        write_en = 0;
        data_in = 0;
        lock_req = 0;

        // Wait for global reset/startup
        #20;

        // ---------------------------------------------------------------------
        // Test Case 1: Basic Cold Reset
        // Verify that asserting rst_n sets defaults asynchronously
        // ---------------------------------------------------------------------
        
        // Attempt to modify state before reset to prove reset effectiveness
        // Using write_en to set debug_en to 0 (assuming normal op allows it)
        @(posedge clk);
        write_en = 1;
        data_in = 0;
        @(posedge clk);
        write_en = 0;
        #2; 
        
        // Assert Cold Reset
        rst_n = 0;
        warm_rst_n = 1;
        #10; // Wait for async logic

        if (debug_en === 1'b1 && locked === 1'b0 && current_state === 2'b00) begin
             $display("[TEST] PASS: Cold reset asserted, outputs set to defaults correctly.");
        end else begin
             $display("[TEST] FAIL: Cold reset asserted. Expected debug_en=1, locked=0, state=00. Got debug_en=%b, locked=%b, state=%b", 
                      debug_en, locked, current_state);
        end

        // Release Cold Reset
        rst_n = 1;
        #20;

        // ---------------------------------------------------------------------
        // Test Case 2: Cold Reset Precedence
        // Verify that if both rst_n and warm_rst_n are low, cold reset values apply
        // ---------------------------------------------------------------------
        
        // Attempt to change state again
        @(posedge clk);
        write_en = 1;
        data_in = 0; 
        @(posedge clk);
        write_en = 0;
        #2;

        // Assert Both Resets (Precedence Test)
        rst_n = 0;
        warm_rst_n = 0;
        #10; // Wait for async logic

        if (debug_en === 1'b1 && locked === 1'b0 && current_state === 2'b00) begin
             $display("[TEST] PASS: Simultaneous reset (Precedence check), outputs set to cold defaults.");
        end else begin
             $display("[TEST] FAIL: Simultaneous reset (Precedence check). Expected debug_en=1, locked=0, state=00. Got debug_en=%b, locked=%b, state=%b", 
                      debug_en, locked, current_state);
        end

        $finish;
    end

endmodule