module topmodule (
    input wire clk,
    input wire rst_n,
    input wire warm_rst_n,
    input wire write_en,
    input wire data_in,
    input wire lock_req,
    output reg debug_en,
    output reg locked,
    output reg [1:0] current_state
);

    // Security Critical Registers: debug_en, locked
    // Functional Req 1: Cold reset (rst_n) sets defaults asynchronously.
    // Security Req 1: Warm reset (warm_rst_n) must NOT reset these registers.
    // Therefore, warm_rst_n is excluded from the sensitivity list and reset logic here.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            debug_en <= 1'b1;
            locked   <= 1'b0;
        end else begin
            // Functional Req 3: Normal Operation
            // Independent update logic
            if (lock_req) begin
                locked <= 1'b1;
            end
            
            if (!locked && write_en) begin
                debug_en <= data_in;
            end
        end
    end

    // State Counter: current_state
    // Functional Req 1 & 2: Resets on both cold (rst_n) and warm (warm_rst_n) reset.
    // Functional Req 1: Cold reset takes precedence over warm reset.
    always @(posedge clk or negedge rst_n or negedge warm_rst_n) begin
        if (!rst_n) begin
            current_state <= 2'b00;
        end else if (!warm_rst_n) begin
            current_state <= 2'b00;
        end else begin
            // Functional Req 2: Increment on rising edge of clk
            current_state <= current_state + 1;
        end
    end

endmodule