module tb_module_task_cwe_1232_seed4;
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] pll_data_in;
    reg lock_set;
    reg low_power_mode;
    wire [7:0] pll_config_out;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .pll_data_in(pll_data_in),
        .lock_set(lock_set),
        .low_power_mode(low_power_mode),
        .pll_config_out(pll_config_out),
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 0;
        write_en = 0;
        pll_data_in = 0;
        lock_set = 0;
        low_power_mode = 0;

        // Apply reset
        #10 rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Setup Phase: Establish initial state
        // Write 0xAA to pll_config_out while NOT in low power mode
        // and NOT locked.
        // -------------------------------------------------------
        @(posedge clk);
        low_power_mode = 0;
        write_en = 1;
        pll_data_in = 8'hAA;
        lock_set = 0;
        @(posedge clk);
        write_en = 0; // Deassert write
        #1; // Wait for propagation

        if (pll_config_out !== 8'hAA) begin
            $display("[TEST] FAIL: Setup failed. Expected 0xAA, got 0x%h", pll_config_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 1: Verify write_en is ignored when low_power_mode = 1
        // -------------------------------------------------------
        @(posedge clk);
        low_power_mode = 1;
        write_en = 1;        // Attempt to write
        pll_data_in = 8'h55; // New data
        lock_set = 0;
        @(posedge clk);
        write_en = 0;
        #1;

        if (pll_config_out === 8'hAA) begin
            $display("[TEST] PASS: pll_config_out retained 0xAA when low_power_mode=1");
        end else begin
            $display("[TEST] FAIL: pll_config_out changed to 0x%h when low_power_mode=1", pll_config_out);
        end

        // -------------------------------------------------------
        // Test Case 2: Verify lock_set is ignored when low_power_mode = 1
        // -------------------------------------------------------
        // Ensure we are currently unlocked (sanity check)
        if (lock_status !== 0) begin
            $display("[TEST] FAIL: Precondition failed, lock_status is 1 before test");
            $finish;
        end

        @(posedge clk);
        low_power_mode = 1;
        write_en = 0;
        lock_set = 1; // Attempt to lock
        @(posedge clk);
        lock_set = 0;
        #1;

        if (lock_status === 0) begin
            $display("[TEST] PASS: lock_status remained 0 (lock_set ignored) when low_power_mode=1");
        end else begin
            $display("[TEST] FAIL: lock_status changed to 1 when low_power_mode=1");
        end

        $finish;
    end

endmodule