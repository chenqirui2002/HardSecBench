module testbench;
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] pll_data_in;
    reg lock_set;
    reg low_power_mode;
    wire [7:0] pll_config_out;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .pll_data_in(pll_data_in),
        .lock_set(lock_set),
        .low_power_mode(low_power_mode),
        .pll_config_out(pll_config_out),
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 0;
        write_en = 0;
        pll_data_in = 8'h00;
        lock_set = 0;
        low_power_mode = 0;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // 1. Establish Lock
        // Assert lock_set to set lock_status to 1
        lock_set = 1;
        #10;
        lock_set = 0;
        #10;

        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Unable to set lock_status initially.");
            $finish;
        end

        // 2. Simulate Power State Transition
        // Enter Low Power Mode
        low_power_mode = 1;
        #20;

        // Check if lock is preserved during low power
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: lock_status cleared when entering low_power_mode.");
            $finish;
        end

        // Exit Low Power Mode
        low_power_mode = 0;
        #20;

        // Check if lock is preserved after exiting low power (transition complete)
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: lock_status cleared after exiting low_power_mode (Power State Transition).");
            $finish;
        end

        // 3. Verify Reset Authority
        // Only rst_n should clear the lock
        rst_n = 0;
        #10;

        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: rst_n failed to clear lock_status.");
            $finish;
        end

        // If we reached here, the lock persisted across power transitions and cleared on reset
        $display("[TEST] PASS: lock_status persisted across power state transition and was cleared by rst_n.");
        $finish;
    end

endmodule