module topmodule (
    input wire clk,
    input wire rst_n,
    input wire write_en,
    input wire [7:0] pll_data_in,
    input wire lock_set,
    input wire low_power_mode,
    output reg [7:0] pll_config_out,
    output reg lock_status
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pll_config_out <= 8'd0;
            lock_status <= 1'b0;
        end else begin
            // Functional Requirement 4: When low_power_mode is 1, ignore write_en and lock_set.
            // Security Requirement 1: lock_status shall not be cleared/modified by low_power_mode.
            // By checking !low_power_mode, we ensure that if it is high, we simply retain state.
            if (!low_power_mode) begin
                // Functional Requirement 3: When lock_status is 1, retain values.
                if (!lock_status) begin
                    // Functional Requirement 2: Update logic when unlocked and not in low power.
                    if (write_en) begin
                        pll_config_out <= pll_data_in;
                    end
                    if (lock_set) begin
                        lock_status <= 1'b1;
                    end
                end
            end
            // Security Requirement 2: Only rst_n clears lock_status.
            // The else branches (implicit) retain the current value of lock_status (1 or 0).
            // There is no logic path to set lock_status to 0 other than the reset block.
        end
    end

endmodule