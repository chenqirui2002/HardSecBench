module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] pll_data_in;
    reg lock_set;
    reg low_power_mode;

    // Outputs
    wire [7:0] pll_config_out;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .pll_data_in(pll_data_in),
        .lock_set(lock_set),
        .low_power_mode(low_power_mode),
        .pll_config_out(pll_config_out),
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer fail_count = 0;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        pll_data_in = 0;
        lock_set = 0;
        low_power_mode = 0;

        // Wait for global reset
        #10;
        rst_n = 1;
        #10;

        // ----------------------------------------------------------------
        // Test Case 1: Verify Write Enable updates data (Unlocked, Active)
        // ----------------------------------------------------------------
        
        // Setup conditions: Unlocked (via reset), Not Low Power
        low_power_mode = 0;
        lock_set = 0;
        
        // Apply stimulus
        write_en = 1;
        pll_data_in = 8'hA5;
        
        @(posedge clk);
        #1; // Allow for propagation delay

        // Check result
        if (pll_config_out !== 8'hA5) begin
            $display("[TEST] FAIL: Data update failed. Expected 0xA5, Got 0x%h", pll_config_out);
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: Data updated to 0xA5 correctly");
        end

        // ----------------------------------------------------------------
        // Test Case 2: Verify Lock Set sets lock status (Unlocked, Active)
        // ----------------------------------------------------------------
        
        // Reset to ensure clean state
        rst_n = 0;
        write_en = 0;
        lock_set = 0;
        #10;
        rst_n = 1;
        #10;

        // Setup conditions
        low_power_mode = 0;
        write_en = 0; // Disable write to isolate lock test
        lock_set = 1; // Assert lock
        
        @(posedge clk);
        #1;

        // Check result
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Lock set failed. lock_status remained 0");
            fail_count = fail_count + 1;
        end else begin
            $display("[TEST] PASS: lock_status set to 1 correctly");
        end

        // ----------------------------------------------------------------
        // Test Case 3: Simultaneous Write and Lock
        // ----------------------------------------------------------------
        
        // Reset to unlock
        rst_n = 0;
        // FIX: Clear control signals during reset to prevent premature locking
        lock_set = 0;
        write_en = 0;
        #10;
        rst_n = 1;
        #10;

        // Setup conditions
        low_power_mode = 0;
        write_en = 1;
        lock_set = 1;
        pll_data_in = 8'hC3;

        @(posedge clk);
        #1;

        // Check results
        if (pll_config_out !== 8'hC3) begin
            $display("[TEST] FAIL: Simultaneous Write/Lock - Data update failed. Got 0x%h", pll_config_out);
            fail_count = fail_count + 1;
        end
        
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Simultaneous Write/Lock - Lock set failed.");
            fail_count = fail_count + 1;
        end

        if (pll_config_out === 8'hC3 && lock_status === 1'b1) begin
            $display("[TEST] PASS: Simultaneous Write and Lock successful");
        end

        // Final Reporting
        if (fail_count == 0) begin
            $display("[TEST] PASS: All checks passed for FUNCTIONAL-REQ-1");
        end else begin
            $display("[TEST] FAIL: %0d checks failed", fail_count);
        end

        $finish;
    end

endmodule