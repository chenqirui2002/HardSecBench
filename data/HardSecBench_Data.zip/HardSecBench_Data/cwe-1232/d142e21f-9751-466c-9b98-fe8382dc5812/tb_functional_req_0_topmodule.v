`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] pll_data_in;
    reg lock_set;
    reg low_power_mode;

    // Outputs
    wire [7:0] pll_config_out;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .pll_data_in(pll_data_in),
        .lock_set(lock_set),
        .low_power_mode(low_power_mode),
        .pll_config_out(pll_config_out),
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 1;
        write_en = 0;
        pll_data_in = 8'h00;
        lock_set = 0;
        low_power_mode = 0;

        // Wait for global reset/startup
        #10;

        // -------------------------------------------------------
        // Test Case 1: Initial Reset
        // -------------------------------------------------------
        $display("[TEST] Applying initial reset...");
        rst_n = 0; // Assert reset
        
        // Wait for a clock edge to capture reset
        @(posedge clk);
        #1; // Small delay to allow output propagation

        if (pll_config_out !== 8'h00) begin
            $display("[TEST] FAIL: pll_config_out is %h, expected 00 after reset.", pll_config_out);
            $finish;
        end
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status is %b, expected 0 after reset.", lock_status);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Reset from "Dirty" State
        // -------------------------------------------------------
        // Release reset and attempt to write values to change state
        // Note: We assume REQ-1 functionality here just to set up a non-zero state.
        // If REQ-1 is not implemented, outputs remain 0, and reset check is still valid (0->0).
        rst_n = 1;
        write_en = 1;
        pll_data_in = 8'hA5;
        lock_set = 1;
        
        @(posedge clk);
        #1;
        
        // Now assert reset again while inputs are still active
        $display("[TEST] Applying reset during active operation...");
        rst_n = 0;
        
        @(posedge clk);
        #1; // Propagation delay

        // Check if outputs are cleared
        if (pll_config_out !== 8'h00) begin
            $display("[TEST] FAIL: pll_config_out is %h, expected 00 after second reset.", pll_config_out);
            $finish;
        end
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status is %b, expected 0 after second reset.", lock_status);
            $finish;
        end

        // -------------------------------------------------------
        // Conclusion
        // -------------------------------------------------------
        $display("[TEST] PASS: Reset functionality verified.");
        $finish;
    end

endmodule