module testbench;
  // Inputs
  reg clk;
  reg rst_n;
  reg write_en;
  reg [7:0] pll_data_in;
  reg lock_set;
  reg low_power_mode;

  // Outputs
  wire [7:0] pll_config_out;
  wire lock_status;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .write_en(write_en),
    .pll_data_in(pll_data_in),
    .lock_set(lock_set),
    .low_power_mode(low_power_mode),
    .pll_config_out(pll_config_out),
    .lock_status(lock_status)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  initial begin
    // Initialize Inputs
    rst_n = 0;
    write_en = 0;
    pll_data_in = 8'hAA; // Arbitrary data
    lock_set = 0;
    low_power_mode = 0;

    // Apply Reset
    #10;
    rst_n = 1;
    #10;

    // ---------------------------------------------------------
    // Step 1: Engage Lock
    // ---------------------------------------------------------
    lock_set = 1;
    #10; // Wait for clock edge
    lock_set = 0;

    // Verify lock is engaged
    if (lock_status !== 1'b1) begin
      $display("[TEST] FAIL: Setup failed - Unable to set lock_status to 1.");
      $finish;
    end

    // ---------------------------------------------------------
    // Step 2: Enter Low Power Mode (Assertion)
    // ---------------------------------------------------------
    low_power_mode = 1;
    #10; // Wait for clock edge

    // Check if lock is still present
    if (lock_status !== 1'b1) begin
      $display("[TEST] FAIL: lock_status was cleared (reset to 0) upon entering low_power_mode.");
      $finish;
    end

    // ---------------------------------------------------------
    // Step 3: Exit Low Power Mode (De-assertion)
    // ---------------------------------------------------------
    low_power_mode = 0;
    #10; // Wait for clock edge

    // Check if lock is still present
    if (lock_status !== 1'b1) begin
      $display("[TEST] FAIL: lock_status was cleared (reset to 0) upon exiting low_power_mode.");
      $finish;
    end

    // ---------------------------------------------------------
    // Final Verification
    // ---------------------------------------------------------
    // If we reached here, the lock persisted through the transition
    $display("[TEST] PASS: lock_status remained asserted throughout low_power_mode transitions.");
    $finish;
  end

endmodule