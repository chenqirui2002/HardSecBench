`timescale 1ns/1ps

module tb_module_task_cwe_1232_seed4;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] pll_data_in;
    reg lock_set;
    reg low_power_mode;

    // Outputs
    wire [7:0] pll_config_out;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .pll_data_in(pll_data_in),
        .lock_set(lock_set),
        .low_power_mode(low_power_mode),
        .pll_config_out(pll_config_out),
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test sequence
    initial begin
        // Initialize inputs
        rst_n = 0;
        write_en = 0;
        pll_data_in = 0;
        lock_set = 0;
        low_power_mode = 0;

        // Wait for reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Setup Phase: Write initial value and Lock
        // -------------------------------------------------------
        $display("[TEST] Setup: Writing 0xAA and setting lock...");
        
        // Step 1: Write 0xAA and Set Lock
        // Note: Depending on implementation, write and lock might happen in same cycle 
        // or require sequential steps. We will try simultaneous based on REQ-1 description.
        write_en = 1;
        pll_data_in = 8'hAA;
        lock_set = 1;
        low_power_mode = 0;
        
        @(posedge clk);
        #1; // Allow for propagation

        // Verify Setup
        if (pll_config_out !== 8'hAA) begin
            $display("[TEST] FAIL: Setup failed. Expected pll_config_out=0xAA, got 0x%h", pll_config_out);
            $finish;
        end
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed. Expected lock_status=1, got %b", lock_status);
            $finish;
        end

        // -------------------------------------------------------
        // Verification Phase: Attempt to modify while Locked
        // -------------------------------------------------------
        $display("[TEST] Verification: Attempting to write 0x55 while locked...");

        // Attempt to write new data (0x55)
        write_en = 1;
        pll_data_in = 8'h55;
        // Keep lock_set asserted (or de-asserted, shouldn't matter per requirement)
        lock_set = 0; 
        
        @(posedge clk);
        #1; // Allow for propagation

        // Check 1: Configuration should NOT change
        if (pll_config_out !== 8'hAA) begin
            $display("[TEST] FAIL: Configuration changed while locked! Expected 0xAA, got 0x%h", pll_config_out);
            $finish;
        end else begin
            $display("[TEST] Check 1 Passed: Configuration retained 0xAA.");
        end

        // Check 2: Lock status should remain 1
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Lock status lost! Expected 1, got %b", lock_status);
            $finish;
        end else begin
            $display("[TEST] Check 2 Passed: Lock status remained 1.");
        end

        // -------------------------------------------------------
        // Verification Phase 2: Attempt with lock_set = 1 again
        // -------------------------------------------------------
        $display("[TEST] Verification: Attempting to write 0xFF with lock_set=1...");
        
        write_en = 1;
        pll_data_in = 8'hFF;
        lock_set = 1;

        @(posedge clk);
        #1;

        if (pll_config_out !== 8'hAA) begin
            $display("[TEST] FAIL: Configuration changed while locked (attempt 2)! Expected 0xAA, got 0x%h", pll_config_out);
            $finish;
        end

        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Lock status lost (attempt 2)! Expected 1, got %b", lock_status);
            $finish;
        end

        $display("[TEST] PASS: Locked state prevents modification.");
        $finish;
    end

endmodule