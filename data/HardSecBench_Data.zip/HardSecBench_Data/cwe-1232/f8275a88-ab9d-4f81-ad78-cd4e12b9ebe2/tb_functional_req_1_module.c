#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

// Declaration of the function to be tested
extern int module(uint32_t *regs, size_t reg_count, size_t bar_idx, size_t lock_idx, uint32_t bar_val, uint32_t lock_mask);

int main() {
    // Test Case 1: Basic Mask Application
    // Verifies that the lock_mask is applied to the register at lock_idx.
    {
        uint32_t regs[10] = {0};
        size_t reg_count = 10;
        size_t bar_idx = 0; // Valid index
        size_t lock_idx = 5; // Valid index
        uint32_t bar_val = 0xDEADBEEF; // Arbitrary value
        uint32_t lock_mask = 0x0000FFFF;
        
        // Pre-condition: Ensure target register is 0
        regs[lock_idx] = 0x00000000;

        // Call function
        int result = module(regs, reg_count, bar_idx, lock_idx, bar_val, lock_mask);

        // Check if the register at lock_idx was updated with the mask
        // Since initial was 0, result should be equal to mask
        if (regs[lock_idx] == lock_mask) {
            printf("[CASE-1] PASS: Register at lock_idx updated with lock_mask.\n");
        } else {
            printf("[CASE-1] FAIL: Register at lock_idx mismatch. Expected 0x%08X, got 0x%08X\n", lock_mask, regs[lock_idx]);
        }
    }

    // Test Case 2: Bitwise OR Logic
    // Verifies that the operation is a bitwise OR (preserves existing bits).
    {
        uint32_t regs[10] = {0};
        size_t reg_count = 10;
        size_t bar_idx = 1; // Valid index
        size_t lock_idx = 8; // Valid index
        uint32_t bar_val = 0xCAFEBABE;
        
        // Initial value has high bits set
        uint32_t initial_val = 0xF0F00000;
        // Mask has low bits set
        uint32_t lock_mask   = 0x0000F0F0;
        // Expected result is the combination
        uint32_t expected_val = initial_val | lock_mask;

        regs[lock_idx] = initial_val;

        // Call function
        module(regs, reg_count, bar_idx, lock_idx, bar_val, lock_mask);

        if (regs[lock_idx] == expected_val) {
            printf("[CASE-2] PASS: Register updated using bitwise OR logic.\n");
        } else {
            printf("[CASE-2] FAIL: Bitwise OR logic failed. Expected 0x%08X, got 0x%08X\n", expected_val, regs[lock_idx]);
        }
    }

    return 0;
}