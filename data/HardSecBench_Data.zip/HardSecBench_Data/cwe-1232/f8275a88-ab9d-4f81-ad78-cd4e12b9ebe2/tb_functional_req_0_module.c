#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

// Declaration of the function to be tested
extern int module(uint32_t *regs, size_t reg_count, size_t bar_idx, size_t lock_idx, uint32_t bar_val, uint32_t lock_mask);

int main() {
    // Test Case 1: Verify BAR register update at a specific index
    {
        uint32_t regs[10] = {0};
        size_t reg_count = 10;
        size_t bar_idx = 2;
        size_t lock_idx = 5; // Distinct from bar_idx to isolate REQ-0 verification
        uint32_t bar_val = 0xDEADBEEF;
        uint32_t lock_mask = 0x1;

        // Execute function
        int res = module(regs, reg_count, bar_idx, lock_idx, bar_val, lock_mask);

        // Check REQ-0: regs[bar_idx] must equal bar_val
        // We also check res == 0 to ensure the function completed the sequence successfully
        if (regs[bar_idx] == bar_val && res == 0) {
            printf("[CASE-1] PASS: regs[%zu] updated correctly to 0x%X\n", bar_idx, bar_val);
        } else {
            printf("[CASE-1] FAIL: Expected regs[%zu]=0x%X (got 0x%X), res=0 (got %d)\n", 
                   bar_idx, bar_val, regs[bar_idx], res);
        }
    }

    // Test Case 2: Verify BAR register update at index 0 with pre-existing data
    {
        uint32_t regs[5] = {0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF};
        size_t reg_count = 5;
        size_t bar_idx = 0;
        size_t lock_idx = 1;
        uint32_t bar_val = 0xA5A5A5A5;
        uint32_t lock_mask = 0x2;

        int res = module(regs, reg_count, bar_idx, lock_idx, bar_val, lock_mask);

        if (regs[bar_idx] == bar_val && res == 0) {
            printf("[CASE-2] PASS: regs[%zu] updated correctly to 0x%X\n", bar_idx, bar_val);
        } else {
            printf("[CASE-2] FAIL: Expected regs[%zu]=0x%X (got 0x%X), res=0 (got %d)\n", 
                   bar_idx, bar_val, regs[bar_idx], res);
        }
    }

    return 0;
}