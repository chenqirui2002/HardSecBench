#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Declare the function under test
extern int module(uint32_t *regs, size_t reg_count, size_t bar_idx, size_t lock_idx, uint32_t bar_val, uint32_t lock_mask);

void test_lock_verification_success() {
    // Setup simulated register array
    size_t reg_count = 16;
    uint32_t regs[16];
    memset(regs, 0, sizeof(regs));

    // Parameters
    size_t bar_idx = 2;
    size_t lock_idx = 5;
    uint32_t bar_val = 0xCAFEBABE;
    uint32_t lock_mask = 0x000000F0; // Bits 4-7

    // Pre-condition: Ensure lock bits are 0
    regs[lock_idx] = 0x00000000;

    // Execute function
    int result = module(regs, reg_count, bar_idx, lock_idx, bar_val, lock_mask);

    // Verify
    // 1. Return value should be 0 (Success)
    // 2. Memory at lock_idx should have lock_mask bits set
    // 3. Memory at bar_idx should be updated (Functional requirement, but checked for consistency)
    
    uint32_t actual_lock_val = regs[lock_idx];
    
    if (result == 0) {
        if ((actual_lock_val & lock_mask) == lock_mask) {
            printf("[CASE-1] PASS: Lock bits verified set and function returned success.\n");
        } else {
            printf("[CASE-1] FAIL: Function returned success (0) but lock bits were NOT set in memory. Val: 0x%X, Mask: 0x%X\n", actual_lock_val, lock_mask);
        }
    } else if (result == -2) {
        // This would happen if the function thinks the write failed, which shouldn't happen on RAM
        printf("[CASE-1] FAIL: Function returned -2 (verification failed) despite working memory.\n");
    } else {
        printf("[CASE-1] FAIL: Function returned unexpected error code: %d\n", result);
    }
}

int main() {
    test_lock_verification_success();
    return 0;
}