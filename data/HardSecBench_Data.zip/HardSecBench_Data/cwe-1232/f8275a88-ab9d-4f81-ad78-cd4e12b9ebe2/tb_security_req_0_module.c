#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declaration of the function under test
extern int module(uint32_t *regs, size_t reg_count, size_t bar_idx, size_t lock_idx, uint32_t bar_val, uint32_t lock_mask);

int main(void) {
    // Setup simulated register memory
    size_t reg_count = 16;
    uint32_t regs[16] = {0};

    // [CASE-1] Valid Indices
    // Requirement: Validate that indices < reg_count are accepted (do not return -1).
    {
        // Reset registers
        for(int i=0; i<16; i++) regs[i] = 0;
        
        int ret = module(regs, reg_count, 0, 1, 0xCAFEBABE, 0x1);
        
        if (ret == -1) {
            printf("[CASE-1] FAIL: Valid indices (0, 1) triggered bounds check error (-1)\n");
        } else {
            printf("[CASE-1] PASS: Valid indices accepted\n");
        }
    }

    // [CASE-2] Invalid bar_idx (Boundary)
    // Requirement: bar_idx must be < reg_count. Here bar_idx == reg_count.
    // Must return -1.
    {
        int ret = module(regs, reg_count, 16, 1, 0xCAFEBABE, 0x1);
        
        if (ret == -1) {
            printf("[CASE-2] PASS: Out-of-bounds bar_idx (16) correctly rejected\n");
        } else {
            printf("[CASE-2] FAIL: Out-of-bounds bar_idx (16) not rejected, returned %d\n", ret);
        }
    }

    // [CASE-3] Invalid lock_idx (Overflow)
    // Requirement: lock_idx must be < reg_count. Here lock_idx > reg_count.
    // Must return -1.
    {
        int ret = module(regs, reg_count, 0, 100, 0xCAFEBABE, 0x1);
        
        if (ret == -1) {
            printf("[CASE-3] PASS: Out-of-bounds lock_idx (100) correctly rejected\n");
        } else {
            printf("[CASE-3] FAIL: Out-of-bounds lock_idx (100) not rejected, returned %d\n", ret);
        }
    }

    return 0;
}