#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// -----------------------------------------------------------------------------
// Mock Environment for Critical Sections
// -----------------------------------------------------------------------------
// We define counters to track if critical sections are entered and exited.
static int g_crit_enter_count = 0;
static int g_crit_exit_count = 0;

// Mocks for common interrupt disabling/enabling and critical section functions.
// We provide multiple names to cover standard embedded APIs (CMSIS, FreeRTOS, generic).
void __disable_irq(void) { g_crit_enter_count++; }
void __enable_irq(void) { g_crit_exit_count++; }

void disable_irq(void) { g_crit_enter_count++; }
void enable_irq(void) { g_crit_exit_count++; }

void disable_interrupts(void) { g_crit_enter_count++; }
void enable_interrupts(void) { g_crit_exit_count++; }

void enter_critical(void) { g_crit_enter_count++; }
void exit_critical(void) { g_crit_exit_count++; }

void vTaskEnterCritical(void) { g_crit_enter_count++; }
void vTaskExitCritical(void) { g_crit_exit_count++; }

// -----------------------------------------------------------------------------
// Target Function Declaration
// -----------------------------------------------------------------------------
extern int module(volatile uint32_t *data_reg, volatile uint32_t *ctrl_reg, uint32_t data_val, uint32_t active_mask, uint32_t *status_out);

// -----------------------------------------------------------------------------
// Main Test Logic
// -----------------------------------------------------------------------------
int main() {
    // Test Case 1: Successful Configuration (Security Check)
    // Verifies that a valid write sequence is protected by a critical section.
    {
        volatile uint32_t data_reg = 0;
        volatile uint32_t ctrl_reg = 0;
        uint32_t status_out = 0;
        uint32_t data_val = 0x12345678;
        uint32_t active_mask = 0x2; // Bit 1

        // Reset counters
        g_crit_enter_count = 0;
        g_crit_exit_count = 0;

        int ret = module(&data_reg, &ctrl_reg, data_val, active_mask, &status_out);

        if (ret != 0) {
            printf("[CASE-1] FAIL: Function returned error %d unexpectedly\n", ret);
        } else if (g_crit_enter_count == 0) {
            // If no critical section was entered, the security requirement is missing.
            printf("[CASE-1] FAIL: No critical section entered (interrupts not disabled)\n");
        } else if (g_crit_enter_count != g_crit_exit_count) {
            printf("[CASE-1] FAIL: Unbalanced critical section (Enter: %d, Exit: %d)\n", g_crit_enter_count, g_crit_exit_count);
        } else {
            // Verify functional correctness as well
            if (data_reg == data_val && (ctrl_reg & active_mask)) {
                printf("[CASE-1] PASS: Critical section used and function executed correctly\n");
            } else {
                printf("[CASE-1] FAIL: Functional logic failed despite critical section usage\n");
            }
        }
    }

    // Test Case 2: Aborted Configuration (Race Condition Prevention Check)
    // Verifies that the initial check is also performed within the critical section.
    // The requirement states "The sequence of operations (check, ...) shall be performed within a critical section".
    {
        volatile uint32_t data_reg = 0;
        volatile uint32_t ctrl_reg = 0x2; // Bit 1 already set (active)
        uint32_t status_out = 0;
        uint32_t data_val = 0x87654321;
        uint32_t active_mask = 0x2; // Bit 1

        // Reset counters
        g_crit_enter_count = 0;
        g_crit_exit_count = 0;

        int ret = module(&data_reg, &ctrl_reg, data_val, active_mask, &status_out);

        if (ret != -1) {
            printf("[CASE-2] FAIL: Function should have returned -1, got %d\n", ret);
        } else {
            if (g_crit_enter_count == 0) {
                printf("[CASE-2] FAIL: Critical section not entered during check phase\n");
            } else if (g_crit_enter_count != g_crit_exit_count) {
                printf("[CASE-2] FAIL: Unbalanced critical section on failure path\n");
            } else {
                printf("[CASE-2] PASS: Critical section used during check phase\n");
            }
        }
    }

    return 0;
}