#include <stdint.h>
#include <stddef.h>

/*
 * External interrupt control functions provided by the environment/testbench.
 * In a real embedded system, these would be provided by the HAL or architecture-specific headers.
 * We declare them extern here to allow the testbench to link its own instrumented versions.
 */
extern void disable_irq(void);
extern void enable_irq(void);

int module (volatile uint32_t *data_reg, volatile uint32_t *ctrl_reg, uint32_t data_val, uint32_t active_mask, uint32_t *status_out) {
    // Security Check: Validate input pointers to prevent NULL pointer dereference
    if (data_reg == NULL || ctrl_reg == NULL || status_out == NULL) {
        return -1;
    }

    // Security Requirement: Enter critical section (disable interrupts)
    // This ensures the sequence of checking, writing data, and updating control
    // is atomic and cannot be interrupted by an ISR that might modify the same registers.
    disable_irq();

    // Functional Requirement 1: Check if active bits are already set
    // We read the volatile register inside the critical section to prevent TOCTOU issues
    uint32_t current_ctrl = *ctrl_reg;
    if ((current_ctrl & active_mask) != 0) {
        *status_out = current_ctrl;
        // Critical: Must re-enable interrupts before returning on error path
        enable_irq();
        return -1;
    }

    // Functional Requirement 2: Write data to data_reg
    *data_reg = data_val;

    // Functional Requirement 3: Read-modify-write ctrl_reg to set active bits
    // The volatile qualifier ensures correct memory access, and the critical section
    // ensures atomicity.
    *ctrl_reg |= active_mask;

    // Functional Requirement 3 (cont): Store new value in status_out
    *status_out = *ctrl_reg;

    // Security Requirement: Exit critical section (enable interrupts)
    enable_irq();

    return 0;
}