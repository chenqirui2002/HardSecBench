#include <stdint.h>
#include <stdio.h>

// Stubs for external dependencies required by the function under test
void disable_irq(void) {}
void enable_irq(void) {}

// Declare the function under test
extern int module(volatile uint32_t *data_reg, volatile uint32_t *ctrl_reg, uint32_t data_val, uint32_t active_mask, uint32_t *status_out);

int main() {
    // Test Case 1: Single bit overlap
    // ctrl_reg has bit 0 set, active_mask checks bit 0.
    // Requirement: If bits in active_mask are set in ctrl_reg, return -1 and store ctrl_reg in status_out.
    {
        uint32_t data_storage = 0;
        uint32_t ctrl_storage = 0x00000001;
        uint32_t status_out = 0xDEADBEEF; // Canary value
        
        volatile uint32_t *data_reg = &data_storage;
        volatile uint32_t *ctrl_reg = &ctrl_storage;
        uint32_t data_val = 0xAAAA;
        uint32_t active_mask = 0x00000001;

        int result = module(data_reg, ctrl_reg, data_val, active_mask, &status_out);

        if (result == -1 && status_out == 0x00000001) {
            printf("[CASE-1] PASS\n");
        } else {
            printf("[CASE-1] FAIL: Expected return -1 and status 0x1. Got return %d, status 0x%x\n", result, status_out);
        }
    }

    // Test Case 2: Partial overlap (mask is subset of set bits)
    // ctrl_reg has bits 0-3 set (0xF), active_mask checks bit 2 (0x4).
    // Requirement: If bits in active_mask are set in ctrl_reg, return -1 and store ctrl_reg in status_out.
    {
        uint32_t data_storage = 0;
        uint32_t ctrl_storage = 0x0000000F;
        uint32_t status_out = 0xDEADBEEF; // Canary value
        
        volatile uint32_t *data_reg = &data_storage;
        volatile uint32_t *ctrl_reg = &ctrl_storage;
        uint32_t data_val = 0xBBBB;
        uint32_t active_mask = 0x00000004;

        int result = module(data_reg, ctrl_reg, data_val, active_mask, &status_out);

        if (result == -1 && status_out == 0x0000000F) {
            printf("[CASE-2] PASS\n");
        } else {
            printf("[CASE-2] FAIL: Expected return -1 and status 0xF. Got return %d, status 0x%x\n", result, status_out);
        }
    }

    return 0;
}