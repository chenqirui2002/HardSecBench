#include <stdio.h>
#include <stdint.h>

/* Declare the function under test */
extern int module(volatile uint32_t *data_reg, volatile uint32_t *ctrl_reg, uint32_t data_val, uint32_t active_mask, uint32_t *status_out);

/* Stub functions to satisfy linker dependencies */
void disable_irq(void) {}
void enable_irq(void) {}

int main(void) {
    /* Test Case 1: Basic data write verification */
    {
        volatile uint32_t data_reg = 0x00000000;
        volatile uint32_t ctrl_reg = 0x00000000; /* No active bits set, check should pass */
        uint32_t status_out = 0;
        uint32_t data_val = 0xDEADBEEF;
        uint32_t active_mask = 0x00000001;

        /* Call function */
        int result = module(&data_reg, &ctrl_reg, data_val, active_mask, &status_out);

        /* Verify that data_reg was updated to data_val and return is 0 */
        if (data_reg == data_val && result == 0) {
            printf("[CASE-1] PASS\n");
        } else {
            printf("[CASE-1] FAIL: Expected data_reg=0x%08X, got 0x%08X; Expected result=0, got %d\n", 
                   data_val, data_reg, result);
        }
    }

    /* Test Case 2: Verify write with different values and initial state */
    {
        volatile uint32_t data_reg = 0xFFFFFFFF; /* Initialize with non-zero */
        volatile uint32_t ctrl_reg = 0x00000000; /* Check passes */
        uint32_t status_out = 0;
        uint32_t data_val = 0xCAFEBABE;
        uint32_t active_mask = 0x000000F0;

        /* Call function */
        int result = module(&data_reg, &ctrl_reg, data_val, active_mask, &status_out);

        /* Verify that data_reg was updated to data_val and return is 0 */
        if (data_reg == data_val && result == 0) {
            printf("[CASE-2] PASS\n");
        } else {
            printf("[CASE-2] FAIL: Expected data_reg=0x%08X, got 0x%08X; Expected result=0, got %d\n", 
                   data_val, data_reg, result);
        }
    }

    return 0;
}