#include <stdio.h>
#include <stdint.h>

// Stubs required for linking as the UUT calls these
void disable_irq(void) {}
void enable_irq(void) {}

extern int module(volatile uint32_t *data_reg, volatile uint32_t *ctrl_reg, uint32_t data_val, uint32_t active_mask, uint32_t *status_out);

int main() {
    // Test Case 1: Basic Activation
    // Verifies that when ctrl_reg is clear, the function sets the active_mask bits,
    // updates status_out, and returns 0.
    {
        volatile uint32_t data_reg = 0;
        volatile uint32_t ctrl_reg = 0;
        uint32_t data_val = 0xAAAA5555;
        uint32_t active_mask = 0x0000000F;
        uint32_t status_out = 0xFFFFFFFF; // Initialize with garbage

        int result = module(&data_reg, &ctrl_reg, data_val, active_mask, &status_out);

        if (result == 0 && ctrl_reg == 0x0000000F && status_out == 0x0000000F) {
            printf("[CASE-1] PASS\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0, ctrl=0xF, status=0xF. Got ret=%d, ctrl=0x%x, status=0x%x\n", 
                   result, ctrl_reg, status_out);
        }
    }

    // Test Case 2: Read-Modify-Write Preservation
    // Verifies that existing bits in ctrl_reg (that are not in active_mask) are preserved
    // during the update (bitwise OR logic).
    {
        volatile uint32_t data_reg = 0;
        volatile uint32_t ctrl_reg = 0x0000F000; // Existing bits set
        uint32_t data_val = 0x12345678;
        uint32_t active_mask = 0x00000001; // Non-overlapping mask
        uint32_t status_out = 0;

        // Note: We ensure (ctrl_reg & active_mask) == 0 to pass the initial check (REQ-0)
        int result = module(&data_reg, &ctrl_reg, data_val, active_mask, &status_out);

        // Expected: 0xF000 | 0x1 = 0xF001
        if (result == 0 && ctrl_reg == 0x0000F001 && status_out == 0x0000F001) {
            printf("[CASE-2] PASS\n");
        } else {
            printf("[CASE-2] FAIL: Expected ret=0, ctrl=0xF001, status=0xF001. Got ret=%d, ctrl=0x%x, status=0x%x\n", 
                   result, ctrl_reg, status_out);
        }
    }

    return 0;
}