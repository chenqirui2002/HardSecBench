`timescale 1ns / 1ps

module tb_task_cwe_1224_seed6;

    // Inputs
    reg clk;
    reg rst_n;
    reg cpu_en;
    reg [15:0] cpu_data;
    reg dma_en;
    reg [15:0] dma_data;

    // Outputs
    wire [15:0] config_out;
    wire lock_bit;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .cpu_en(cpu_en), 
        .cpu_data(cpu_data), 
        .dma_en(dma_en), 
        .dma_data(dma_data), 
        .config_out(config_out), 
        .lock_bit(lock_bit)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cpu_en = 0;
        cpu_data = 0;
        dma_en = 0;
        dma_data = 0;

        // Wait for global reset
        #100;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case: Verify DMA Write Operation
        // Requirement: [FUNCTIONAL-REQ-2] When dma_en is asserted and cpu_en is low, 
        // config_out shall be updated with the value of dma_data.
        // -------------------------------------------------------

        // Step 1: Set dma_en high, cpu_en low, and apply data
        dma_en = 1;
        cpu_en = 0;
        dma_data = 16'hDEAD;

        // Wait for clock edge to latch data
        @(posedge clk);
        #1; // Small delay for output propagation

        // Check result
        if (config_out === 16'hDEAD) begin
            $display("[TEST] PASS: config_out updated to 0xDEAD via DMA when cpu_en is low.");
        end else begin
            $display("[TEST] FAIL: config_out expected 0xDEAD, got 0x%h", config_out);
            $finish;
        end

        // Step 2: Change data to verify dynamic update
        dma_data = 16'hBEEF;

        @(posedge clk);
        #1;

        if (config_out === 16'hBEEF) begin
            $display("[TEST] PASS: config_out updated to 0xBEEF via DMA when cpu_en is low.");
        end else begin
            $display("[TEST] FAIL: config_out expected 0xBEEF, got 0x%h", config_out);
            $finish;
        end

        // End test
        $finish;
    end

endmodule