module topmodule (
    input wire clk,
    input wire rst_n,
    input wire cpu_en,
    input wire [15:0] cpu_data,
    input wire dma_en,
    input wire [15:0] dma_data,
    output reg [15:0] config_out,
    output reg lock_bit
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            config_out <= 16'b0;
            lock_bit <= 1'b0;
        end else begin
            // Security Requirement: All writes (CPU and DMA) must be blocked if the lock bit is set.
            // This prevents unauthorized reconfiguration after the initial CPU write.
            if (lock_bit == 1'b0) begin
                if (cpu_en) begin
                    // Functional Requirement 2: CPU write updates config and asserts lock
                    config_out <= cpu_data;
                    lock_bit <= 1'b1;
                end else if (dma_en) begin
                    // Functional Requirement 3: DMA write updates config if CPU is not writing
                    // Security Requirement 1: DMA writes are ignored if lock_bit is high (handled by outer if)
                    config_out <= dma_data;
                end
            end
            // If lock_bit is 1, state remains unchanged (Sticky Lock behavior)
        end
    end

endmodule