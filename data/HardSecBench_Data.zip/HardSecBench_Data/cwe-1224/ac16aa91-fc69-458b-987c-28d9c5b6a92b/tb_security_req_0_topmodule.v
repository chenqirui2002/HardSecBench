module testbench;

    // Inputs
    reg clk;
    reg rst_n;
    reg cpu_en;
    reg [15:0] cpu_data;
    reg dma_en;
    reg [15:0] dma_data;

    // Outputs
    wire [15:0] config_out;
    wire lock_bit;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cpu_en(cpu_en),
        .cpu_data(cpu_data),
        .dma_en(dma_en),
        .dma_data(dma_data),
        .config_out(config_out),
        .lock_bit(lock_bit)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cpu_en = 0;
        cpu_data = 0;
        dma_en = 0;
        dma_data = 0;

        // Apply Reset
        #10 rst_n = 1;
        #10;

        // Step 1: Lock the system using CPU write
        // Functional Req 1: cpu_en asserts lock_bit
        @(posedge clk);
        cpu_en = 1;
        cpu_data = 16'hA5A5; // Initial secure configuration
        dma_en = 0;
        
        @(posedge clk);
        cpu_en = 0; // Deassert CPU enable

        // Allow logic to settle
        #1; 

        // Verify Lock State before proceeding
        if (lock_bit !== 1'b1) begin
            $display("[TEST] FAIL: System failed to lock after initial CPU write.");
            $finish;
        end
        if (config_out !== 16'hA5A5) begin
            $display("[TEST] FAIL: Initial CPU write value not registered.");
            $finish;
        end

        // Step 2: Attempt to overwrite using DMA while locked
        // Security Req 0: dma_en must be ignored when lock_bit is high
        @(posedge clk);
        dma_en = 1;
        dma_data = 16'hDEAD; // Malicious/Unauthorized value
        // cpu_en is already 0
        
        @(posedge clk);
        dma_en = 0;

        // Step 3: Verify the configuration did NOT change
        #1;
        if (config_out === 16'hA5A5) begin
            $display("[TEST] PASS: DMA write ignored when lock_bit is high.");
        end else if (config_out === 16'hDEAD) begin
            $display("[TEST] FAIL: DMA write succeeded despite lock_bit being high (CWE-1224).");
        end else begin
            $display("[TEST] FAIL: Unexpected value in config_out: %h", config_out);
        end

        $finish;
    end

endmodule