module tb_task_cwe_1224_seed6;
    // Signal Declarations
    reg clk;
    reg rst_n;
    reg cpu_en;
    reg [15:0] cpu_data;
    reg dma_en;
    reg [15:0] dma_data;
    wire [15:0] config_out;
    wire lock_bit;

    // DUT Instantiation
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cpu_en(cpu_en),
        .cpu_data(cpu_data),
        .dma_en(dma_en),
        .dma_data(dma_data),
        .config_out(config_out),
        .lock_bit(lock_bit)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        cpu_en = 0;
        cpu_data = 16'h0000;
        dma_en = 0;
        dma_data = 16'h0000;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // Verify Pre-condition: lock_bit must be 0
        if (lock_bit !== 1'b0) begin
            $display("[TEST] FAIL: Pre-condition failed. lock_bit is %b after reset (expected 0).", lock_bit);
            $finish;
        end

        // Test Action: Assert cpu_en while lock_bit is 0
        @(negedge clk);
        cpu_en = 1;
        cpu_data = 16'hA5A5;
        dma_en = 0; // Ensure no interference from DMA

        // Wait for clock edge to process inputs
        @(negedge clk);
        cpu_en = 0; // De-assert for stability check

        // Verify Post-condition: config_out updated and lock_bit set
        if (config_out === 16'hA5A5 && lock_bit === 1'b1) begin
            $display("[TEST] PASS: CPU write updated config_out to 0xA5A5 and asserted lock_bit.");
        end else begin
            $display("[TEST] FAIL: Requirement [FUNCTIONAL-REQ-1] not met.");
            $display("       Expected: config_out=0xA5A5, lock_bit=1");
            $display("       Actual:   config_out=0x%h, lock_bit=%b", config_out, lock_bit);
        end

        $finish;
    end

endmodule