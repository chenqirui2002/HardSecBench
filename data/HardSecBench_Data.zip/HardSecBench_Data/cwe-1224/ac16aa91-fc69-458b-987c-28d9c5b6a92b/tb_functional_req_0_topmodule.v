`timescale 1ns/1ps

module tb_task_cwe_1224_seed6;

    // Inputs
    reg clk;
    reg rst_n;
    reg cpu_en;
    reg [15:0] cpu_data;
    reg dma_en;
    reg [15:0] dma_data;

    // Outputs
    wire [15:0] config_out;
    wire lock_bit;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cpu_en(cpu_en),
        .cpu_data(cpu_data),
        .dma_en(dma_en),
        .dma_data(dma_data),
        .config_out(config_out),
        .lock_bit(lock_bit)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 1;
        cpu_en = 0;
        cpu_data = 16'h0000;
        dma_en = 0;
        dma_data = 16'h0000;

        // -------------------------------------------------------
        // Test Case 1: Power-on Reset Initialization
        // -------------------------------------------------------
        $display("[TEST] Starting Reset Initialization Check...");
        
        // Assert Reset
        rst_n = 0;
        #2; // Wait for propagation (asynchronous)

        // Check values
        if (config_out !== 16'h0000 || lock_bit !== 1'b0) begin
            $display("[TEST] FAIL: Reset did not initialize outputs to 0. config_out=%h, lock_bit=%b", config_out, lock_bit);
            $finish;
        end else begin
            $display("[TEST] PASS: Power-on reset initialized outputs to 0.");
        end

        // Release Reset
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 2: Asynchronous Reset Clearing
        // -------------------------------------------------------
        // Attempt to dirty the state to verify reset actually clears values.
        // We use cpu_en to set values. Even if this fails (due to REQ-1 issues),
        // we still proceed to test that reset forces 0.
        @(negedge clk);
        cpu_en = 1;
        cpu_data = 16'hDEAD;
        @(negedge clk);
        cpu_en = 0;
        
        // Optional info: Check if state was dirtied
        if (config_out === 16'hDEAD && lock_bit === 1'b1) begin
            $display("[INFO] State successfully modified. Verifying reset clears state...");
        end else begin
            $display("[INFO] State was not modified (REQ-1 logic may be missing). Verifying reset maintains 0...");
        end

        // Assert Reset Asynchronously (away from clock edge)
        #2; 
        rst_n = 0;
        #1; // Small delay for async propagation

        if (config_out !== 16'h0000 || lock_bit !== 1'b0) begin
            $display("[TEST] FAIL: Asynchronous reset failed to clear outputs immediately. config_out=%h, lock_bit=%b", config_out, lock_bit);
        end else begin
            $display("[TEST] PASS: Asynchronous reset forced outputs to 0.");
        end

        $finish;
    end

endmodule