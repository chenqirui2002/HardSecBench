#include <stdio.h>
#include <stdint.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

// Declare the target function
extern int module(volatile uint32_t *mmio_base, uint32_t config_lower, uint32_t config_upper, uint8_t lock_req);

// Thread data structure
typedef struct {
    volatile uint32_t *target_reg;
    volatile int keep_running;
} jammer_args_t;

// Interference thread: constantly clears the lock bit
// This simulates hardware where the bit fails to transition to 1
void* lock_jammer(void* arg) {
    jammer_args_t *args = (jammer_args_t*)arg;
    while (args->keep_running) {
        // Force bit 0 to 0. 
        // We use a bitwise AND to be specific, though assignment works too.
        // This attempts to win the race between the function's write and its read-back.
        *args->target_reg &= ~0x1; 
    }
    return NULL;
}

int main() {
    // [CASE-1] Verify [SECURITY-REQ-2]: Return -1 if lock bit read-back fails
    // Requirement: If the value read from the register at index 0 has Bit 0 == 0, return -1.
    // Strategy: Use a thread to force the bit to 0 immediately after the function writes 1.
    {
        volatile uint32_t mmio[3] = {0, 0, 0};
        
        jammer_args_t args;
        args.target_reg = &mmio[0];
        args.keep_running = 1;

        pthread_t tid;
        if (pthread_create(&tid, NULL, lock_jammer, &args) != 0) {
            printf("[CASE-1] FAIL: Thread creation failed\n");
            return 1;
        }

        int detected_failure = 0;
        int iterations = 2000000; // High iteration count to ensure race condition triggers

        for (int i = 0; i < iterations; i++) {
            // Ensure lock is clear before call so we don't trigger SECURITY-REQ-0 (return -2)
            mmio[0] = 0;

            // Call function with lock_req = 1
            // Expected sequence inside function:
            // 1. Check mmio[0] (is 0) -> proceed
            // 2. Write mmio[0] = 1
            // 3. Read mmio[0] -> check if 1
            // 4. If 0, return -1
            int ret = module(mmio, 0x100, 0x200, 1);

            if (ret == -1) {
                // The jammer thread successfully cleared the bit between step 2 and 3,
                // and the function correctly detected it.
                detected_failure = 1;
                break;
            }
            
            // If ret == 0: The function wrote 1, read 1 (jammer was too slow), and succeeded.
            // If ret == -2: The function read 1 at step 1 (jammer was too slow to clear previous state).
        }

        args.keep_running = 0;
        pthread_join(tid, NULL);

        if (detected_failure) {
            printf("[CASE-1] PASS\n");
        } else {
            // If we never saw -1, it implies the check is missing.
            // (Or extremely unlikely: the race condition never triggered in 2M tries)
            printf("[CASE-1] FAIL: Function never returned -1 (Read-back check missing or race condition failed)\n");
        }
    }

    return 0;
}