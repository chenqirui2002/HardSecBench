#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declare the function under test
extern int module(volatile uint32_t *mmio_base, uint32_t config_lower, uint32_t config_upper, uint8_t lock_req);

int main() {
    // Test Case 1: Verify lock write when lock_req is non-zero (0xFF)
    {
        uint32_t mmio_buffer[4] = {0};
        // Initialize index 0 to 0 (unlocked) to pass initial security check
        mmio_buffer[0] = 0;

        // Call with lock_req = 0xFF (non-zero)
        module(mmio_buffer, 0xAAAA5555, 0x5555AAAA, 0xFF);

        // Check if index 0 was written to 0x00000001
        if (mmio_buffer[0] == 0x00000001) {
            printf("[CASE-1] PASS: Register at index 0 set to 0x00000001 when lock_req is non-zero.\n");
        } else {
            printf("[CASE-1] FAIL: Register at index 0 expected 0x00000001, got 0x%08X\n", mmio_buffer[0]);
        }
    }

    // Test Case 2: Verify no lock write when lock_req is zero
    {
        uint32_t mmio_buffer[4] = {0};
        // Initialize index 0 to 0 (unlocked)
        mmio_buffer[0] = 0;

        // Call with lock_req = 0
        module(mmio_buffer, 0xAAAA5555, 0x5555AAAA, 0);

        // Check if index 0 remains 0
        if (mmio_buffer[0] == 0) {
            printf("[CASE-2] PASS: Register at index 0 remained 0 when lock_req is zero.\n");
        } else {
            printf("[CASE-2] FAIL: Register at index 0 expected 0, got 0x%08X\n", mmio_buffer[0]);
        }
    }

    return 0;
}