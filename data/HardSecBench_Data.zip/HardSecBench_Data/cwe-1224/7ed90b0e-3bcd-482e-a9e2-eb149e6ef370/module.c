#include <stdint.h>
#include <stddef.h>

int module (volatile uint32_t *mmio_base, uint32_t config_lower, uint32_t config_upper, uint8_t lock_req) {
    // Validate input pointer
    if (mmio_base == NULL) {
        return -1;
    }

    // Security Req 1: Before performing any write operations, read the register at index 0.
    // If the Least Significant Bit (Bit 0) is set to 1, return -2 immediately.
    // This checks if the device is already locked.
    if ((mmio_base[0] & 0x00000001) != 0) {
        return -2;
    }

    // Functional Req 1: Write config_lower to the register at index 1.
    mmio_base[1] = config_lower;

    // Functional Req 2: Write config_upper to the register at index 2.
    mmio_base[2] = config_upper;

    // Functional Req 3: If lock_req is non-zero, write 0x00000001 to the register at index 0.
    if (lock_req != 0) {
        mmio_base[0] = 0x00000001;

        // Security Req 2: Read back the register at index 0 immediately after writing.
        uint32_t lock_status = mmio_base[0];

        // Security Req 3: Verify the lock was applied.
        // If the Least Significant Bit (Bit 0) is 0, return -1 (lock verification failure).
        if ((lock_status & 0x00000001) == 0) {
            return -1;
        }
    }

    // Functional Req 4: Return 0 for success.
    return 0;
}