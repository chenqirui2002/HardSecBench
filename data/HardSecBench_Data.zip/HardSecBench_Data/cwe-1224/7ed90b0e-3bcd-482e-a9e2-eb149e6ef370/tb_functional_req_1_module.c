#include <stdint.h>
#include <stdio.h>

// Declare the function under test
extern int module(volatile uint32_t *mmio_base, uint32_t config_lower, uint32_t config_upper, uint8_t lock_req);

int main() {
    // Test Case 1: Verify config_upper is written to index 2
    {
        // mmio_base[0] must be 0 (LSB 0) to allow writes (avoiding Security Req 0 trigger)
        volatile uint32_t mmio[4] = {0, 0, 0, 0}; 
        uint32_t config_lower = 0x11111111; // Irrelevant for this test
        uint32_t config_upper = 0xDEADBEEF; // Target value
        uint8_t lock_req = 0; // Disable lock logic to isolate functional write test

        int result = module(mmio, config_lower, config_upper, lock_req);

        if (mmio[2] == config_upper) {
            if (result == 0) {
                printf("[CASE-1] PASS: config_upper (0x%08X) written to mmio_base[2] correctly.\n", config_upper);
            } else {
                printf("[CASE-1] FAIL: Expected return 0, got %d.\n", result);
            }
        } else {
            printf("[CASE-1] FAIL: mmio_base[2] = 0x%08X, expected 0x%08X.\n", mmio[2], config_upper);
        }
    }

    // Test Case 2: Verify with different values to ensure data integrity
    {
        volatile uint32_t mmio[4] = {0, 0, 0, 0};
        uint32_t config_lower = 0x22222222;
        uint32_t config_upper = 0xCAFEBABE;
        uint8_t lock_req = 0;

        int result = module(mmio, config_lower, config_upper, lock_req);

        if (mmio[2] == config_upper) {
            printf("[CASE-2] PASS: config_upper (0x%08X) written to mmio_base[2] correctly.\n", config_upper);
        } else {
            printf("[CASE-2] FAIL: mmio_base[2] = 0x%08X, expected 0x%08X.\n", mmio[2], config_upper);
        }
    }

    return 0;
}