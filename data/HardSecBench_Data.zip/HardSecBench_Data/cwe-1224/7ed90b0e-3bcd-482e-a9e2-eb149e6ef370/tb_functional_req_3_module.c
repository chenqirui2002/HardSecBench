#include <stdio.h>
#include <stdint.h>

extern int module(volatile uint32_t *mmio_base, uint32_t config_lower, uint32_t config_upper, uint8_t lock_req);

int main() {
    // Test Case 1: Verify return 0 when lock_req is 0 (no lock requested)
    // Pre-condition: mmio_base[0] must be 0 (unlocked) to avoid returning -2.
    // Expected: Return 0, config written, lock bit (index 0) remains 0.
    {
        volatile uint32_t mmio[3] = {0, 0, 0};
        uint32_t lower = 0xAAAA5555;
        uint32_t upper = 0x5555AAAA;
        uint8_t lock = 0;

        int ret = module(mmio, lower, upper, lock);

        if (ret == 0 && mmio[1] == lower && mmio[2] == upper && mmio[0] == 0) {
            printf("[CASE-1] PASS: Function returned 0 and performed expected writes for lock_req=0\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0, mmio[1]=0x%x, mmio[2]=0x%x, mmio[0]=0. Got ret=%d, mmio={0x%x, 0x%x, 0x%x}\n",
                   lower, upper, ret, mmio[0], mmio[1], mmio[2]);
        }
    }

    // Test Case 2: Verify return 0 when lock_req is 1 (lock requested)
    // Pre-condition: mmio_base[0] must be 0 (unlocked) initially.
    // Expected: Return 0, config written, lock bit (index 0) set to 1.
    // Note: Since mmio is standard RAM here, the write to mmio[0] persists, satisfying the internal read-back check.
    {
        volatile uint32_t mmio[3] = {0, 0, 0};
        uint32_t lower = 0x12345678;
        uint32_t upper = 0x87654321;
        uint8_t lock = 1;

        int ret = module(mmio, lower, upper, lock);

        if (ret == 0 && mmio[1] == lower && mmio[2] == upper && mmio[0] == 1) {
            printf("[CASE-2] PASS: Function returned 0 and performed expected writes for lock_req=1\n");
        } else {
            printf("[CASE-2] FAIL: Expected ret=0, mmio[1]=0x%x, mmio[2]=0x%x, mmio[0]=1. Got ret=%d, mmio={0x%x, 0x%x, 0x%x}\n",
                   lower, upper, ret, mmio[0], mmio[1], mmio[2]);
        }
    }

    return 0;
}