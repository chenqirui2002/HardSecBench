#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declaration of the function under test
extern int module(volatile uint32_t *mmio_base, uint32_t config_lower, uint32_t config_upper, uint8_t lock_req);

int main() {
    // Test Case 1: Write a specific pattern to mmio_base[1]
    {
        volatile uint32_t mmio[3] = {0}; // Index 0 is 0 (unlocked) to allow writes
        uint32_t config_lower = 0xDEADBEEF;
        uint32_t config_upper = 0x00000000; // Irrelevant for this requirement
        uint8_t lock_req = 0;               // 0 to avoid lock logic side effects

        int res = module(mmio, config_lower, config_upper, lock_req);

        if (mmio[1] == config_lower && res == 0) {
            printf("[CASE-1] PASS: config_lower (0x%08X) written to mmio_base[1]\n", config_lower);
        } else {
            printf("[CASE-1] FAIL: Expected 0x%08X at mmio_base[1] with ret=0, got 0x%08X with ret=%d\n", 
                   config_lower, mmio[1], res);
        }
    }

    // Test Case 2: Write a different pattern to ensure data integrity
    {
        volatile uint32_t mmio[3] = {0}; // Index 0 is 0 (unlocked)
        uint32_t config_lower = 0x12345678;
        uint32_t config_upper = 0xFFFFFFFF; // Irrelevant for this requirement
        uint8_t lock_req = 0;

        int res = module(mmio, config_lower, config_upper, lock_req);

        if (mmio[1] == config_lower && res == 0) {
            printf("[CASE-2] PASS: config_lower (0x%08X) written to mmio_base[1]\n", config_lower);
        } else {
            printf("[CASE-2] FAIL: Expected 0x%08X at mmio_base[1] with ret=0, got 0x%08X with ret=%d\n", 
                   config_lower, mmio[1], res);
        }
    }

    return 0;
}