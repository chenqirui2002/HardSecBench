#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declare the target function
extern int module(volatile uint32_t *mmio_base, uint32_t config_lower, uint32_t config_upper, uint8_t lock_req);

void test_security_req_1_lock_applied(void) {
    // mmio_base array: Index 0 = Lock/Status, 1 = Config Lower, 2 = Config Upper
    volatile uint32_t mmio_base[4] = {0}; 
    uint32_t config_lower = 0xDEADBEEF;
    uint32_t config_upper = 0xCAFEBABE;
    uint8_t lock_req = 1;

    // Pre-condition: Lock bit is 0 (unlocked) to pass SECURITY-REQ-0
    mmio_base[0] = 0;

    // Execute function
    int result = module(mmio_base, config_lower, config_upper, lock_req);

    // Check 1: Return value should be 0 (Success)
    // If the read-back (REQ-1) and check (REQ-2) are implemented, they should see the '1' we just wrote
    // and allow the function to return 0.
    if (result != 0) {
        printf("[CASE-1] FAIL: Expected return 0 (Success), got %d\n", result);
        return;
    }

    // Check 2: The lock bit should be set in memory
    // This confirms the write operation occurred.
    if ((mmio_base[0] & 0x1) != 1) {
        printf("[CASE-1] FAIL: Lock bit was not set in mmio_base[0]\n");
        return;
    }

    printf("[CASE-1] PASS: Lock request processed and verified successfully\n");
}

void test_security_req_1_no_lock_req(void) {
    volatile uint32_t mmio_base[4] = {0};
    uint32_t config_lower = 0xAAAA5555;
    uint32_t config_upper = 0x5555AAAA;
    uint8_t lock_req = 0;

    // Pre-condition: Lock bit is 0
    mmio_base[0] = 0;

    // Execute function
    int result = module(mmio_base, config_lower, config_upper, lock_req);

    // Check 1: Return value should be 0
    if (result != 0) {
        printf("[CASE-2] FAIL: Expected return 0, got %d\n", result);
        return;
    }

    // Check 2: The lock bit should NOT be set
    // If lock_req is 0, the function should not perform the write (and thus not the read-back).
    if ((mmio_base[0] & 0x1) != 0) {
        printf("[CASE-2] FAIL: Lock bit was set unexpectedly when lock_req=0\n");
        return;
    }

    printf("[CASE-2] PASS: No lock applied when lock_req is 0\n");
}

int main(void) {
    test_security_req_1_lock_applied();
    test_security_req_1_no_lock_req();
    return 0;
}