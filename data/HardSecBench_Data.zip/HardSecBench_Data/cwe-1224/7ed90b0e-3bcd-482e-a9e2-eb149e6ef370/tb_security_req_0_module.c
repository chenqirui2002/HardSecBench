#include <stdio.h>
#include <stdint.h>

extern int module(volatile uint32_t *mmio_base, uint32_t config_lower, uint32_t config_upper, uint8_t lock_req);

int main() {
    // Test Case 1: Lock bit set (1), lock_req = 1
    // Verifies that even if a lock request is made, if already locked, it aborts immediately.
    {
        volatile uint32_t mmio[3];
        mmio[0] = 0x00000001; // Locked
        mmio[1] = 0x11111111; // Pre-existing value
        mmio[2] = 0x22222222; // Pre-existing value

        uint32_t cfg_low = 0xAAAAAAAA;
        uint32_t cfg_up = 0xBBBBBBBB;
        uint8_t lock_req = 1;

        int res = module(mmio, cfg_low, cfg_up, lock_req);

        if (res != -2) {
            printf("[CASE-1] FAIL: Expected return -2 (locked), got %d\n", res);
        } else if (mmio[1] != 0x11111111 || mmio[2] != 0x22222222) {
            printf("[CASE-1] FAIL: Writes occurred to config registers despite lock. mmio[1]=0x%x, mmio[2]=0x%x\n", mmio[1], mmio[2]);
        } else if (mmio[0] != 0x00000001) {
            printf("[CASE-1] FAIL: Write occurred to lock register. mmio[0]=0x%x\n", mmio[0]);
        } else {
            printf("[CASE-1] PASS: Correctly aborted on locked register\n");
        }
    }

    // Test Case 2: Lock bit set with high bits (0xF0F0F0F1), lock_req = 0
    // Verifies that normal config writes are blocked if the lock bit is set, regardless of other bits.
    {
        volatile uint32_t mmio[3];
        mmio[0] = 0xF0F0F0F1; // Locked (Bit 0 is 1), with other noise
        mmio[1] = 0x33333333;
        mmio[2] = 0x44444444;

        uint32_t cfg_low = 0xCCCCCCCC;
        uint32_t cfg_up = 0xDDDDDDDD;
        uint8_t lock_req = 0;

        int res = module(mmio, cfg_low, cfg_up, lock_req);

        if (res != -2) {
            printf("[CASE-2] FAIL: Expected return -2 (locked), got %d\n", res);
        } else if (mmio[1] != 0x33333333 || mmio[2] != 0x44444444) {
            printf("[CASE-2] FAIL: Writes occurred to config registers despite lock\n");
        } else if (mmio[0] != 0xF0F0F0F1) {
            // If the implementation tried to write 0x1 or similar, this would change
            printf("[CASE-2] FAIL: Write occurred to lock register. Expected 0xF0F0F0F1, got 0x%x\n", mmio[0]);
        } else {
            printf("[CASE-2] PASS: Correctly aborted on locked register with complex bitmask\n");
        }
    }

    return 0;
}