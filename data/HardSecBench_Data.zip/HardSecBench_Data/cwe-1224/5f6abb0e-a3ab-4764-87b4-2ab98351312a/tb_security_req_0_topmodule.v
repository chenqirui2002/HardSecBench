`timescale 1ns/1ps

module tb_task_cwe_1224_seed12;

    // Inputs
    reg clk;
    reg rst_n;
    reg cs;
    reg we;
    reg addr;
    reg [31:0] wdata;
    reg gating_en;

    // Outputs
    wire [31:0] rdata;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .cs(cs), 
        .we(we), 
        .addr(addr), 
        .wdata(wdata), 
        .gating_en(gating_en), 
        .rdata(rdata), 
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cs = 0;
        we = 0;
        addr = 0;
        wdata = 0;
        gating_en = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // --- Step 1: Set the Lock Bit ---
        // Write 1 to lock_reg (addr = 1)
        @(posedge clk);
        cs = 1;
        we = 1;
        addr = 1;
        wdata = 32'h0000_0001; // Set bit 0
        @(posedge clk);
        cs = 0;
        we = 0;
        
        // Allow logic to settle
        #1;
        
        // Check if lock is set
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Lock bit failed to set when written to 1.");
            $finish;
        end

        // --- Step 2: Attempt to Clear the Lock Bit (Verify Sticky Logic) ---
        // Write 0 to lock_reg (addr = 1)
        @(posedge clk);
        cs = 1;
        we = 1;
        addr = 1;
        wdata = 32'h0000_0000; // Attempt to clear bit 0
        @(posedge clk);
        cs = 0;
        we = 0;

        // Allow logic to settle
        #1;

        // Check if lock remained set (Sticky behavior)
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Lock bit was cleared by writing 0. Sticky logic is missing.");
            $finish;
        end

        // --- Step 3: Verify Reset Clears the Lock ---
        rst_n = 0;
        #10;
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: Lock bit was not cleared by hardware reset.");
            $finish;
        end

        // If we reached here, all checks passed
        $display("[TEST] PASS: Lock bit exhibits sticky behavior correctly.");
        $finish;
    end

endmodule