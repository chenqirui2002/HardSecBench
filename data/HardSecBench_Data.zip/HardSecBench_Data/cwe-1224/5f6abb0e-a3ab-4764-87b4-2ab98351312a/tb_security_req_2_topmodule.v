`timescale 1ns / 1ps

module tb_security_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg cs;
    reg we;
    reg addr;
    reg [31:0] wdata;
    reg gating_en;

    // Outputs
    wire [31:0] rdata;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .cs(cs), 
        .we(we), 
        .addr(addr), 
        .wdata(wdata), 
        .gating_en(gating_en), 
        .rdata(rdata), 
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cs = 0;
        we = 0;
        addr = 0;
        wdata = 0;
        gating_en = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // Check initial state
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: Initial lock_status should be 0 after reset");
            $finish;
        end

        // ----------------------------------------------------------------
        // Test Sequence: Attempt to Lock while Gating is Enabled
        // ----------------------------------------------------------------
        $display("Test Case: Attempting to set lock_reg while gating_en is HIGH");

        // 1. Enable power gating (should only affect data_reg, not lock_reg)
        gating_en = 1;
        #10;

        // 2. Attempt to write '1' to lock_reg (addr = 1)
        cs = 1;
        we = 1;
        addr = 1;       // Address 1 is lock register
        wdata = 32'h1;  // Write 1 to set the sticky bit
        #10;            // Clock edge occurs here

        // 3. Deassert write controls
        cs = 0;
        we = 0;
        addr = 0;
        wdata = 0;
        #10;

        // 4. Verify lock_status
        // If gating_en incorrectly gated the lock logic, lock_status will still be 0.
        if (lock_status === 1'b1) begin
            $display("[TEST] PASS: Lock bit set successfully despite gating_en being active.");
        end else begin
            $display("[TEST] FAIL: Lock bit failed to set when gating_en was active. Lock logic is likely dependent on gating signal.");
        end

        $finish;
    end

endmodule