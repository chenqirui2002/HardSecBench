module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg cs;
    reg we;
    reg addr;
    reg [31:0] wdata;
    reg gating_en;

    // Outputs
    wire [31:0] rdata;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cs(cs),
        .we(we),
        .addr(addr),
        .wdata(wdata),
        .gating_en(gating_en),
        .rdata(rdata),
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cs = 0;
        we = 0;
        addr = 0;
        wdata = 0;
        gating_en = 0; // Ensure gating is OFF to allow writes

        // Apply Reset
        #20;
        rst_n = 1;
        #20;

        // ---------------------------------------------------------
        // Test Case 1: Verify Data Register (Address 0)
        // ---------------------------------------------------------
        $display("[TEST] Checking Data Register (Addr 0)...");
        
        // Write pattern
        @(posedge clk);
        cs = 1; we = 1; addr = 0; wdata = 32'hA5A55A5A;
        @(posedge clk);
        cs = 0; we = 0; wdata = 0;
        
        // Read back
        @(posedge clk);
        addr = 0;
        #1; // Allow for combinational read delay
        
        if (rdata !== 32'hA5A55A5A) begin
            $display("[TEST] FAIL: Data Register mismatch. Expected 0xA5A55A5A, got 0x%h", rdata);
            $finish;
        end else begin
            $display("[TEST] Data Register Read/Write Verified.");
        end

        // ---------------------------------------------------------
        // Test Case 2: Verify Lock Register (Address 1)
        // ---------------------------------------------------------
        $display("[TEST] Checking Lock Register (Addr 1)...");

        // Write 1 to lock bit (using wdata[0])
        @(posedge clk);
        cs = 1; we = 1; addr = 1; wdata = 32'h00000001;
        @(posedge clk);
        cs = 0; we = 0; wdata = 0;

        // Read back
        @(posedge clk);
        addr = 1;
        #1; // Allow for combinational read delay

        // Check if bit 0 is set. 
        // Note: We only care about bit 0 as per requirement "accessible... using wdata[0]".
        if (rdata[0] !== 1'b1) begin
            $display("[TEST] FAIL: Lock Register mismatch. Expected bit 0 = 1, got 0x%h", rdata);
            $finish;
        end else begin
            $display("[TEST] Lock Register Read/Write Verified.");
        end

        // ---------------------------------------------------------
        // Final Result
        // ---------------------------------------------------------
        $display("[TEST] PASS: Registers accessible correctly.");
        $finish;
    end

endmodule