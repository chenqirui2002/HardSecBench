`timescale 1ns/1ps

module tb_security_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg cs;
    reg we;
    reg addr;
    reg [31:0] wdata;
    reg gating_en;

    // Outputs
    wire [31:0] rdata;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cs(cs),
        .we(we),
        .addr(addr),
        .wdata(wdata),
        .gating_en(gating_en),
        .rdata(rdata),
        .lock_status(lock_status)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cs = 0;
        we = 0;
        addr = 0;
        wdata = 0;
        gating_en = 0; // Disable gating to ensure writes are allowed functionally

        // Reset the system
        #10 rst_n = 1;
        #10;

        // 1. Write initial data (0xAAAA_AAAA) to data_reg (addr 0)
        // This establishes the "before" state.
        cs = 1;
        we = 1;
        addr = 0;
        wdata = 32'hAAAA_AAAA;
        #10; // Wait for clock edge
        cs = 0;
        we = 0;
        #10;

        // Verify initial write succeeded
        cs = 1; we = 0; addr = 0;
        #10;
        if (rdata !== 32'hAAAA_AAAA) begin
            $display("[TEST] FAIL: Setup failed - could not write initial data to data_reg.");
            $finish;
        end
        cs = 0;
        #10;

        // 2. Set the lock bit (addr 1)
        cs = 1;
        we = 1;
        addr = 1;
        wdata = 32'h0000_0001; // Set bit 0 to 1
        #10;
        cs = 0;
        we = 0;
        #10;

        // Verify lock is active via output pin
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed - lock_status did not assert after writing to lock_reg.");
            $finish;
        end

        // 3. Attempt to overwrite data_reg with 0x5555_5555
        // If security is implemented, this write should be ignored.
        cs = 1;
        we = 1;
        addr = 0;
        wdata = 32'h5555_5555;
        #10;
        cs = 0;
        we = 0;
        #10;

        // 4. Read back data_reg to verify integrity
        cs = 1;
        we = 0;
        addr = 0;
        #10;

        if (rdata === 32'hAAAA_AAAA) begin
            $display("[TEST] PASS: data_reg write ignored while locked.");
        end else if (rdata === 32'h5555_5555) begin
            $display("[TEST] FAIL: data_reg was overwritten despite lock being set.");
        end else begin
            $display("[TEST] FAIL: Unexpected value in data_reg: %h (Expected: AAAAAAAA)", rdata);
        end

        $finish;
    end

endmodule