module tb_functional_req_0;
    reg clk;
    reg rst_n;
    reg cs;
    reg we;
    reg addr;
    reg [31:0] wdata;
    reg gating_en;
    wire [31:0] rdata;
    wire lock_status;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cs(cs),
        .we(we),
        .addr(addr),
        .wdata(wdata),
        .gating_en(gating_en),
        .rdata(rdata),
        .lock_status(lock_status)
    );

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        cs = 0;
        we = 0;
        addr = 0;
        wdata = 0;
        gating_en = 0;

        // Wait for global reset
        #10 rst_n = 1;
        #10;

        // -------------------------------------------------------------
        // Step 1: Pre-load registers with non-zero values
        // -------------------------------------------------------------
        
        // Write 0xFFFFFFFF to data_reg (Address 0)
        cs = 1; we = 1; addr = 0; wdata = 32'hFFFFFFFF;
        #5 clk = 1; #5 clk = 0; // Clock pulse

        // Verify data_reg write
        cs = 1; we = 0; addr = 0;
        #1;
        if (rdata !== 32'hFFFFFFFF) begin
            $display("[TEST] FAIL: Setup failed - Unable to write to data_reg. Expected FFFFFFFF, got %h", rdata);
            $finish;
        end

        // Write 1 to lock_reg (Address 1)
        cs = 1; we = 1; addr = 1; wdata = 32'h1;
        #5 clk = 1; #5 clk = 0; // Clock pulse

        // Verify lock_reg write via lock_status output
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed - Unable to set lock_reg. lock_status is %b", lock_status);
            $finish;
        end

        // -------------------------------------------------------------
        // Step 2: Test Asynchronous Reset
        // -------------------------------------------------------------
        
        // Assert Reset (Active Low) while Clock is Low (no edge)
        rst_n = 0;
        #2; // Allow small propagation delay

        // Check lock_status immediately (should be 0)
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status did not clear asynchronously upon reset assertion.");
            $finish;
        end

        // Check data_reg immediately (should be 0)
        // Ensure we are reading address 0
        cs = 1; we = 0; addr = 0;
        #2;
        if (rdata !== 32'h0) begin
            $display("[TEST] FAIL: data_reg did not clear asynchronously upon reset assertion. rdata=%h", rdata);
            $finish;
        end

        // -------------------------------------------------------------
        // Step 3: Verify State after Reset Release
        // -------------------------------------------------------------
        
        // Release Reset
        rst_n = 1;
        #5;

        // Verify registers remain 0
        if (rdata !== 32'h0) begin
            $display("[TEST] FAIL: data_reg is not 0 after reset release.");
            $finish;
        end
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: lock_status is not 0 after reset release.");
            $finish;
        end

        $display("[TEST] PASS: Asynchronous reset correctly clears all internal registers.");
        $finish;
    end

endmodule