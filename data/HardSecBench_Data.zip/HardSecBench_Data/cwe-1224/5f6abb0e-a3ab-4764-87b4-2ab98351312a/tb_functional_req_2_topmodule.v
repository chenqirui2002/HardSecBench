`timescale 1ns/1ps

module tb_functional_req_2;

  // Signals
  reg clk;
  reg rst_n;
  reg cs;
  reg we;
  reg addr;
  reg [31:0] wdata;
  reg gating_en;
  wire [31:0] rdata;
  wire lock_status;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .cs(cs),
    .we(we),
    .addr(addr),
    .wdata(wdata),
    .gating_en(gating_en),
    .rdata(rdata),
    .lock_status(lock_status)
  );

  // Clock generation
  initial clk = 0;
  always #5 clk = ~clk;

  initial begin
    // Initialize inputs
    rst_n = 0;
    cs = 0;
    we = 0;
    addr = 0;
    wdata = 0;
    gating_en = 0;

    // Apply Reset
    #20;
    rst_n = 1;
    #10;

    // -------------------------------------------------------
    // Step 1: Write baseline value with gating_en = 0
    // -------------------------------------------------------
    $display("Step 1: Writing baseline 0xAAAAAAAA with gating_en=0");
    cs = 1;
    we = 1;
    addr = 0; // Address 0 for data_reg
    wdata = 32'hAAAAAAAA;
    gating_en = 0;
    #10; // Wait for clock edge
    
    // Deassert controls
    cs = 0;
    we = 0;
    #10;

    // Verify baseline write
    cs = 1;
    we = 0;
    #10; // Wait for read
    if (rdata !== 32'hAAAAAAAA) begin
      $display("[TEST] FAIL: Baseline write failed. Expected 0xAAAAAAAA, got 0x%h", rdata);
      $finish;
    end
    cs = 0;
    #10;

    // -------------------------------------------------------
    // Step 2: Attempt to write new value with gating_en = 1
    // -------------------------------------------------------
    $display("Step 2: Attempting to write 0x55555555 with gating_en=1");
    cs = 1;
    we = 1;
    addr = 0;
    wdata = 32'h55555555;
    gating_en = 1; // Assert gating
    #10; // Wait for clock edge
    
    // Deassert controls
    cs = 0;
    we = 0;
    gating_en = 0; // Turn off gating for read (though read shouldn't be gated, just to be clean)
    #10;

    // -------------------------------------------------------
    // Step 3: Verify data_reg did NOT change
    // -------------------------------------------------------
    cs = 1;
    we = 0;
    addr = 0;
    #10; // Wait for read

    if (rdata === 32'hAAAAAAAA) begin
      $display("[TEST] PASS: Data register update suspended when gating_en is high.");
    end else if (rdata === 32'h55555555) begin
      $display("[TEST] FAIL: Data register updated despite gating_en=1.");
    end else begin
      $display("[TEST] FAIL: Data register contains unexpected value 0x%h", rdata);
    end

    $finish;
  end

endmodule