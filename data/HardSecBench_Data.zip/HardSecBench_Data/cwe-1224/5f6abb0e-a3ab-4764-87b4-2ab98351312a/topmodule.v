module topmodule (
    input wire clk,
    input wire rst_n,
    input wire cs,
    input wire we,
    input wire addr,
    input wire [31:0] wdata,
    input wire gating_en,
    output reg [31:0] rdata,
    output wire lock_status
);

    // Internal registers
    reg [31:0] data_reg;
    reg lock_reg;

    // Output assignment for lock status
    assign lock_status = lock_reg;

    // Read Logic
    // rdata outputs the value of the addressed register
    always @(*) begin
        if (addr == 1'b0) begin
            rdata = data_reg;
        end else begin
            // Address 1 returns lock_reg (padded with 0s)
            rdata = {31'b0, lock_reg};
        end
    end

    // Write Logic
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_reg <= 32'b0;
            lock_reg <= 1'b0;
        end else begin
            if (cs && we) begin
                if (addr == 1'b1) begin
                    // Address 1: Lock Register
                    // Security Requirement 1: Sticky bit logic. Once written to 1, it remains 1.
                    // Security Requirement 3: Control logic must be independent of gating_en.
                    // We check wdata[0] to set the lock. We do not check gating_en here.
                    if (wdata[0]) begin
                        lock_reg <= 1'b1;
                    end
                end else begin
                    // Address 0: Data Register
                    // Security Requirement 2: Read-only if lock_reg is 1.
                    // Functional Requirement 3: Updates suspended if gating_en is asserted.
                    if (!lock_reg && !gating_en) begin
                        data_reg <= wdata;
                    end
                end
            end
        end
    end

endmodule