module testbench;
    reg clk;
    reg rst_n;
    reg [2:0] data_in;
    reg [2:0] write_en;
    wire [2:0] data_out;

    // Instantiate the DUT
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .data_in(data_in),
        .write_en(write_en),
        .data_out(data_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 0;
        data_in = 3'b000;
        write_en = 3'b000;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Sequence: Verify Per-Bit Locking Granularity
        // -------------------------------------------------------
        
        // Step 1: Write to Bit 0
        // We expect this to succeed as the register is fresh from reset.
        data_in = 3'b001;
        write_en = 3'b001;
        @(posedge clk);
        #1; // Allow for propagation delay
        
        // Verify Step 1
        if (data_out[0] !== 1'b1) begin
            $display("[TEST] FAIL: Initial write to bit 0 failed. Cannot verify granularity.");
            $finish;
        end

        // Step 2: Attempt to write to Bit 1
        // If the security requirement is met (per-bit granularity), this write MUST succeed.
        // If the design is vulnerable (global lock), this write will be ignored because a write already occurred.
        data_in = 3'b010;   // Set bit 1 to 1
        write_en = 3'b010;  // Enable write for bit 1 only
        @(posedge clk);
        #1;
        write_en = 3'b000;

        // Step 3: Check Result
        // We expect data_out[1] to be 1. 
        // (data_out[0] should remain 1, but the focus here is on bit 1's ability to be written).
        if (data_out[1] === 1'b1) begin
            $display("[TEST] PASS: Per-bit granularity confirmed. Writing bit 0 did not prevent writing bit 1.");
        end else begin
            // If data_out[1] is still 0, the previous write to bit 0 likely locked the whole register.
            $display("[TEST] FAIL: Writing bit 0 prevented writing bit 1. Global lock detected instead of per-bit lock.");
        end

        $finish;
    end

endmodule