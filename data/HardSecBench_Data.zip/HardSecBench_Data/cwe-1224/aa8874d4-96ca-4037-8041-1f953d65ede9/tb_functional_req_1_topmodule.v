`timescale 1ns/1ps

module tb_functional_req_1;
    // Signal Declarations
    reg clk;
    reg rst_n;
    reg [2:0] data_in;
    reg [2:0] write_en;
    wire [2:0] data_out;

    // Module Instantiation
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .data_in(data_in),
        .write_en(write_en),
        .data_out(data_out)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        data_in = 3'b000;
        write_en = 3'b000;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Write to Bit 0 (First time write)
        // -------------------------------------------------------
        // Requirement: Update data_out bits corresponding to active write_en
        data_in = 3'b001;
        write_en = 3'b001;
        
        @(posedge clk); // Trigger write
        #1; // Allow propagation
        write_en = 3'b000; // Deassert write enable

        if (data_out === 3'b001) begin
            $display("[TEST] PASS: Bit 0 updated correctly on first write.");
        end else begin
            $display("[TEST] FAIL: Bit 0 failed to update. Expected 3'b001, Got 3'b%b", data_out);
        end

        // -------------------------------------------------------
        // Test Case 2: Write to Bit 1 (Sequential write to unwritten bit)
        // -------------------------------------------------------
        // Requirement: Update data_out bits... provided specific bit not previously written
        // Bit 0 was written, but Bit 1 has not been written yet.
        #10;
        data_in = 3'b010;
        write_en = 3'b010;

        @(posedge clk);
        #1;
        write_en = 3'b000;

        // Expect Bit 0 to remain 1 (from previous) and Bit 1 to become 1
        if (data_out === 3'b011) begin
            $display("[TEST] PASS: Bit 1 updated correctly in subsequent cycle.");
        end else begin
            $display("[TEST] FAIL: Bit 1 failed to update. Expected 3'b011, Got 3'b%b", data_out);
        end

        // -------------------------------------------------------
        // Test Case 3: Verify Reset Clears "Previously Written" State
        // -------------------------------------------------------
        // Requirement: ...provided... not previously written since the last reset.
        // We reset now, which should allow us to write Bit 1 again (even though we just wrote it).
        
        rst_n = 0;
        #20;
        rst_n = 1;
        #10;

        // Write Bit 1 again
        data_in = 3'b010;
        write_en = 3'b010;

        @(posedge clk);
        #1;
        write_en = 3'b000;

        if (data_out === 3'b010) begin
            $display("[TEST] PASS: Bit 1 updated successfully after reset (write history cleared).");
        end else begin
            $display("[TEST] FAIL: Bit 1 failed to update after reset. Expected 3'b010, Got 3'b%b", data_out);
        end

        $finish;
    end

endmodule