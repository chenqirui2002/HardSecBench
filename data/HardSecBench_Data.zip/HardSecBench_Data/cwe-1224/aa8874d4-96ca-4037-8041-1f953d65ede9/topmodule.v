module topmodule (
    input wire clk,
    input wire rst_n,
    input wire [2:0] data_in,
    input wire [2:0] write_en,
    output reg [2:0] data_out
);

    // Internal register to track the lock status of each bit individually.
    // 0: Unlocked (not written since reset)
    // 1: Locked (written)
    reg [2:0] lock_status;
    
    integer i;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Asynchronous reset: clear data and unlock all bits
            data_out <= 3'b000;
            lock_status <= 3'b000;
        end else begin
            // Iterate through each bit to handle per-bit granularity
            for (i = 0; i < 3; i = i + 1) begin
                // Check if write is enabled for this bit AND it hasn't been locked yet
                if (write_en[i] && !lock_status[i]) begin
                    data_out[i] <= data_in[i];
                    lock_status[i] <= 1'b1; // Lock this specific bit
                end
                // If locked or write_en is low, the register retains its value (implicit)
            end
        end
    end

endmodule