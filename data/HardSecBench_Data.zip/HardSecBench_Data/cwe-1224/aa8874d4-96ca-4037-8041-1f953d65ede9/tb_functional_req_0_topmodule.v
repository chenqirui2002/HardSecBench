`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg [2:0] data_in;
    reg [2:0] write_en;

    // Outputs
    wire [2:0] data_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .data_in(data_in),
        .write_en(write_en),
        .data_out(data_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        data_in = 0;
        write_en = 0;

        // Wait for global reset
        #10;
        
        // -------------------------------------------------------
        // Check 1: Initial Reset State
        // -------------------------------------------------------
        if (data_out !== 3'b000) begin
            $display("[TEST] FAIL: Initial reset did not set data_out to 000. Got: %b", data_out);
            $finish;
        end else begin
            $display("[TEST] PASS: Initial reset set data_out to 000.");
        end

        // Release reset
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Check 2: Asynchronous Reset Assertion
        // -------------------------------------------------------
        // Attempt to write all 1s to set a state and lock bits
        // This sets up the condition to test if reset clears the data
        data_in = 3'b111;
        write_en = 3'b111;
        @(posedge clk); 
        #1; // Hold time
        write_en = 3'b000; // Disable write
        
        // Wait a bit
        #5;

        // Note: If data_out is still 000 here, writes might be broken (REQ-1), 
        // but we proceed to test if reset forces/maintains 000.
        if (data_out === 3'b000) begin
            $display("[TEST] INFO: Write operation did not change output (possibly REQ-1 issue). Proceeding with reset check.");
        end

        // Assert reset asynchronously (away from clock edge)
        #2; 
        rst_n = 0;
        #1; // Small delay for propagation

        if (data_out !== 3'b000) begin
            $display("[TEST] FAIL: Asynchronous reset did not clear data_out immediately. Got: %b", data_out);
            $finish;
        end else begin
            $display("[TEST] PASS: Asynchronous reset cleared data_out.");
        end

        // -------------------------------------------------------
        // Check 3: Reset Dominance
        // -------------------------------------------------------
        // While reset is held low, attempt to write. Output should remain 0.
        data_in = 3'b111;
        write_en = 3'b111;
        @(posedge clk);
        #1;
        if (data_out !== 3'b000) begin
             $display("[TEST] FAIL: data_out changed while rst_n was asserted (Reset Dominance). Got: %b", data_out);
             $finish;
        end
        write_en = 3'b000;

        // -------------------------------------------------------
        // Check 4: Resetting the write-once sequence
        // -------------------------------------------------------
        // Release reset
        rst_n = 1;
        #10;
        
        // Try to write a new value (different from the first attempt if possible, or just a pattern).
        // If the sequence was reset, this should work.
        data_in = 3'b101;
        write_en = 3'b101; // Write to bit 0 and 2
        @(posedge clk);
        #1;
        write_en = 3'b000;
        
        if (data_out !== 3'b101) begin
             $display("[TEST] FAIL: After reset, unable to write new values. Lock sequence might not have been reset. Expected 101, Got: %b", data_out);
             $finish;
        end else begin
             $display("[TEST] PASS: Reset successfully cleared write-once sequence, allowing new writes.");
        end

        $display("[TEST] PASS: All REQ-0 checks passed.");
        $finish;
    end

endmodule