module tb_task_cwe_1224_seed10;

    // Inputs
    reg clk;
    reg rst_n;
    reg [2:0] data_in;
    reg [2:0] write_en;

    // Outputs
    wire [2:0] data_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .data_in(data_in),
        .write_en(write_en),
        .data_out(data_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        data_in = 0;
        write_en = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Scenario 1: Write 1s, then attempt to overwrite with 0s
        // -------------------------------------------------------
        
        // Step 1: Write 3'b111
        data_in = 3'b111;
        write_en = 3'b111;
        @(posedge clk); // Trigger write
        #1; // Wait for propagation

        // Verify initial write success (Pre-condition)
        if (data_out !== 3'b111) begin
            $display("[TEST] FAIL: Pre-condition failed. Could not write initial 111. Got: %b", data_out);
        end else begin
            // Step 2: Attempt to overwrite with 3'b000
            data_in = 3'b000;
            write_en = 3'b111; // Enable is active, but should be ignored due to lock
            @(posedge clk);
            #1;

            // Step 3: Verify value is still 3'b111
            if (data_out === 3'b111) begin
                $display("[TEST] PASS: Data maintained 3'b111 after attempted overwrite.");
            end else begin
                $display("[TEST] FAIL: Data changed to %b after lock (Expected 3'b111).", data_out);
            end
        end

        // -------------------------------------------------------
        // Scenario 2: Reset, Write 0s, then attempt to overwrite with 1s
        // -------------------------------------------------------
        
        // Reset to clear locks
        rst_n = 0;
        #10;
        rst_n = 1;
        #10;

        // Step 1: Write 3'b000 (Locking bits to 0)
        data_in = 3'b000;
        write_en = 3'b111;
        @(posedge clk);
        #1;

        // Step 2: Attempt to overwrite with 3'b111
        data_in = 3'b111;
        write_en = 3'b111;
        @(posedge clk);
        #1;

        // Step 3: Verify value is still 3'b000
        if (data_out === 3'b000) begin
            $display("[TEST] PASS: Data maintained 3'b000 after attempted overwrite.");
        end else begin
            $display("[TEST] FAIL: Data changed to %b after lock (Expected 3'b000).", data_out);
        end

        $finish;
    end

endmodule