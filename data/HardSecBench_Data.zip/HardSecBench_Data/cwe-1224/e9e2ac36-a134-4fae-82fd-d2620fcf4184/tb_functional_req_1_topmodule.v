`timescale 1ns/1ps

module tb_functional_req1;

    // Inputs
    reg clk;
    reg rst_n;
    reg addr;
    reg wr_en;
    reg [7:0] wdata;

    // Outputs
    wire [7:0] rdata;
    wire [7:0] reg0_out;
    wire [7:0] reg1_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .wr_en(wr_en),
        .wdata(wdata),
        .rdata(rdata),
        .reg0_out(reg0_out),
        .reg1_out(reg1_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        wr_en = 0;
        wdata = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Step 1: Write known values to registers to prepare for read test.
        // We avoid setting reg1[0] to 1 to prevent locking logic from interfering.
        // -------------------------------------------------------
        
        // Write 0xAA to Reg0
        @(posedge clk);
        addr = 0;
        wr_en = 1;
        wdata = 8'hAA;
        @(posedge clk);
        wr_en = 0;

        // Write 0x54 to Reg1 (LSB is 0)
        @(posedge clk);
        addr = 1;
        wr_en = 1;
        wdata = 8'h54;
        @(posedge clk);
        wr_en = 0;
        
        // Allow signals to settle
        #1; 

        // -------------------------------------------------------
        // Step 2: Verify Continuous Outputs (reg0_out, reg1_out)
        // -------------------------------------------------------
        if (reg0_out !== 8'hAA) begin
            $display("[TEST] FAIL: reg0_out expected 8'hAA, got 8'h%h", reg0_out);
            $finish;
        end

        if (reg1_out !== 8'h54) begin
            $display("[TEST] FAIL: reg1_out expected 8'h54, got 8'h%h", reg1_out);
            $finish;
        end

        // -------------------------------------------------------
        // Step 3: Verify rdata muxing based on addr
        // -------------------------------------------------------
        
        // Case A: addr = 0, expect rdata = reg0 (0xAA)
        addr = 0;
        #5; // Wait for combinational logic
        if (rdata !== 8'hAA) begin
            $display("[TEST] FAIL: With addr=0, rdata expected 8'hAA, got 8'h%h", rdata);
            $finish;
        end

        // Case B: addr = 1, expect rdata = reg1 (0x54)
        addr = 1;
        #5; // Wait for combinational logic
        if (rdata !== 8'h54) begin
            $display("[TEST] FAIL: With addr=1, rdata expected 8'h54, got 8'h%h", rdata);
            $finish;
        end

        // Case C: Switch back to addr = 0
        addr = 0;
        #5;
        if (rdata !== 8'hAA) begin
            $display("[TEST] FAIL: After switching back to addr=0, rdata expected 8'hAA, got 8'h%h", rdata);
            $finish;
        end

        // -------------------------------------------------------
        // Step 4: Update values and verify continuous update
        // -------------------------------------------------------
        
        // Update Reg0 to 0xCC
        @(posedge clk);
        addr = 0;
        wr_en = 1;
        wdata = 8'hCC;
        @(posedge clk);
        wr_en = 0;
        
        #1;
        
        // Check reg0_out updated
        if (reg0_out !== 8'hCC) begin
            $display("[TEST] FAIL: After update, reg0_out expected 8'hCC, got 8'h%h", reg0_out);
            $finish;
        end
        
        // Check rdata updated (since addr is 0)
        if (rdata !== 8'hCC) begin
            $display("[TEST] FAIL: After update with addr=0, rdata expected 8'hCC, got 8'h%h", rdata);
            $finish;
        end

        $display("[TEST] PASS: Registers output correctly on dedicated ports and rdata bus");
        $finish;
    end

endmodule