`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg addr;
    reg wr_en;
    reg [7:0] wdata;

    // Outputs
    wire [7:0] rdata;
    wire [7:0] reg0_out;
    wire [7:0] reg1_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .addr(addr), 
        .wr_en(wr_en), 
        .wdata(wdata), 
        .rdata(rdata), 
        .reg0_out(reg0_out), 
        .reg1_out(reg1_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        addr = 0;
        wr_en = 0;
        wdata = 0;

        // Wait for global reset
        #20;
        
        // -------------------------------------------------------
        // Test Case 1: Verify Initial Reset State
        // -------------------------------------------------------
        rst_n = 0; // Assert Reset
        #10;       // Wait for async reset
        
        if (reg0_out !== 8'h00 || reg1_out !== 8'h00) begin
            $display("[TEST] FAIL: Registers did not reset to 0x00 initially. reg0=%h, reg1=%h", reg0_out, reg1_out);
        end else begin
            $display("[TEST] PASS: Initial reset check passed.");
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Reset Clears Modified State
        // -------------------------------------------------------
        rst_n = 1; // De-assert Reset
        #20;

        // Attempt to write non-zero values to registers to verify reset clears them.
        // We write 0xAA to reg0 and 0x02 to reg1.
        // IMPORTANT: We write 0x02 (00000010) to reg1 to keep bit 0 low.
        // This prevents triggering the security lock (Security REQ-0/1), which is outside the scope of this test.
        
        // Write 0xAA to reg0
        @(posedge clk);
        addr = 0;
        wr_en = 1;
        wdata = 8'hAA;
        @(posedge clk);
        wr_en = 0;

        // Write 0x02 to reg1
        @(posedge clk);
        addr = 1;
        wr_en = 1;
        wdata = 8'h02;
        @(posedge clk);
        wr_en = 0;

        #10;
        
        // Assert Reset again
        rst_n = 0;
        #10; // Async wait

        if (reg0_out !== 8'h00) begin
            $display("[TEST] FAIL: reg0 did not reset to 0x00 from non-zero state. Got: %h", reg0_out);
        end else if (reg1_out !== 8'h00) begin
            $display("[TEST] FAIL: reg1 did not reset to 0x00 from non-zero state. Got: %h", reg1_out);
        end else begin
            $display("[TEST] PASS: Registers correctly reset to 0x00 from non-zero state.");
        end

        $finish;
    end

endmodule