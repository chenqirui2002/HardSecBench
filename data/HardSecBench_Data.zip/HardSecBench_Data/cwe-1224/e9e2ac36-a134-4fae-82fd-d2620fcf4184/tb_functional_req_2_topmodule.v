module tb_task_cwe_1224_seed8;
    // Testbench signals
    reg clk;
    reg rst_n;
    reg addr;
    reg wr_en;
    reg [7:0] wdata;
    
    // Outputs from UUT
    wire [7:0] rdata;
    wire [7:0] reg0_out;
    wire [7:0] reg1_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .addr(addr),
        .wr_en(wr_en),
        .wdata(wdata),
        .rdata(rdata),
        .reg0_out(reg0_out),
        .reg1_out(reg1_out)
    );

    // Clock generation: 10 time units period
    always #5 clk = ~clk;

    initial begin
        // Initialize inputs
        clk = 0;
        rst_n = 0;
        addr = 0;
        wr_en = 0;
        wdata = 8'h00;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Write to reg0 (Address 0)
        // -------------------------------------------------------
        // Note: After reset, reg1 is 0x00, so reg0 is writable.
        $display("[TEST] Writing 0xA5 to reg0 (addr=0)...");
        
        addr = 1'b0;
        wdata = 8'hA5;
        wr_en = 1'b1;
        
        // Wait for clock edge to trigger write
        @(posedge clk);
        #1; // Hold time
        wr_en = 1'b0; // Deassert write enable
        
        // Check result
        #5;
        if (reg0_out === 8'hA5) begin
            $display("[TEST] PASS: reg0 updated to 0xA5 as expected.");
        end else begin
            $display("[TEST] FAIL: reg0 failed to update. Expected 0xA5, Got 0x%h", reg0_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Write to reg1 (Address 1)
        // -------------------------------------------------------
        $display("[TEST] Writing 0x5A to reg1 (addr=1)...");
        
        addr = 1'b1;
        wdata = 8'h5A; // Bit 0 is 0, keeping things simple regarding specific write behavior
        wr_en = 1'b1;
        
        // Wait for clock edge to trigger write
        @(posedge clk);
        #1; // Hold time
        wr_en = 1'b0;
        
        // Check result
        #5;
        if (reg1_out === 8'h5A) begin
            $display("[TEST] PASS: reg1 updated to 0x5A as expected.");
        end else begin
            $display("[TEST] FAIL: reg1 failed to update. Expected 0x5A, Got 0x%h", reg1_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Verify reg1 update with different value
        // -------------------------------------------------------
        // This ensures the previous success wasn't a fluke or stuck value
        $display("[TEST] Writing 0xCC to reg1 (addr=1)...");
        
        addr = 1'b1;
        wdata = 8'hCC; 
        wr_en = 1'b1;
        
        @(posedge clk);
        #1;
        wr_en = 1'b0;
        
        #5;
        // Note: Specific write behavior for reg1[0] is Write-1-Once (OR logic).
        // Previous reg1 was 0x5A (01011010). New wdata is 0xCC (11001100).
        // Expected reg1[0] = old[0] | new[0] = 0 | 0 = 0.
        // Expected reg1[7:1] = new[7:1].
        // So result should be 0xCC.
        if (reg1_out === 8'hCC) begin
            $display("[TEST] PASS: reg1 updated to 0xCC as expected.");
        end else begin
            $display("[TEST] FAIL: reg1 failed to update. Expected 0xCC, Got 0x%h", reg1_out);
            $finish;
        end

        $display("[TEST] All functional write tests passed.");
        $finish;
    end

endmodule