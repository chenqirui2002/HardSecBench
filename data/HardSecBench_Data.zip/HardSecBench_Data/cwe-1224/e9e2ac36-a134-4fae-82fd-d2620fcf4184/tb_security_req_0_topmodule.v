`timescale 1ns/1ps

module tb_task_cwe_1224_seed8;

  // Inputs to UUT
  reg clk;
  reg rst_n;
  reg addr;
  reg wr_en;
  reg [7:0] wdata;

  // Outputs from UUT
  wire [7:0] rdata;
  wire [7:0] reg0_out;
  wire [7:0] reg1_out;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .addr(addr),
    .wr_en(wr_en),
    .wdata(wdata),
    .rdata(rdata),
    .reg0_out(reg0_out),
    .reg1_out(reg1_out)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  initial begin
    // Initialize Inputs
    rst_n = 0;
    addr = 0;
    wr_en = 0;
    wdata = 0;

    // Apply Reset
    #20;
    rst_n = 1;
    #20;

    // -------------------------------------------------------
    // Step 1: Write initial value to reg0 (Pre-lock state)
    // -------------------------------------------------------
    // Ensure lock bit is 0 (default reset value)
    if (reg1_out[0] !== 1'b0) begin
      $display("[TEST] FAIL: Reset failed, reg1[0] is not 0");
      $finish;
    end

    // Write 0xAA to reg0
    @(negedge clk);
    addr = 1'b0;      // Select reg0
    wdata = 8'hAA;    // Initial data
    wr_en = 1'b1;
    @(negedge clk);
    wr_en = 1'b0;
    
    // Verify initial write succeeded
    if (reg0_out !== 8'hAA) begin
      $display("[TEST] FAIL: Setup failed. Could not write to reg0 when unlocked. Got: %h", reg0_out);
      $finish;
    end

    // -------------------------------------------------------
    // Step 2: Enable Lock (Set reg1[0] = 1)
    // -------------------------------------------------------
    @(negedge clk);
    addr = 1'b1;      // Select reg1
    wdata = 8'h01;    // Set bit 0 high
    wr_en = 1'b1;
    @(negedge clk);
    wr_en = 1'b0;

    // Verify lock bit is set
    if (reg1_out[0] !== 1'b1) begin
      $display("[TEST] FAIL: Setup failed. Could not set lock bit reg1[0].");
      $finish;
    end

    // -------------------------------------------------------
    // Step 3: Attempt to overwrite reg0 (Locked state)
    // -------------------------------------------------------
    @(negedge clk);
    addr = 1'b0;      // Select reg0
    wdata = 8'h55;    // New data (should be rejected)
    wr_en = 1'b1;
    @(negedge clk);
    wr_en = 1'b0;

    // -------------------------------------------------------
    // Step 4: Verify Security Requirement
    // -------------------------------------------------------
    // reg0 should still be 0xAA, NOT 0x55
    if (reg0_out === 8'hAA) begin
      $display("[TEST] PASS: reg0 write protected when reg1[0] is set.");
    end else if (reg0_out === 8'h55) begin
      $display("[TEST] FAIL: reg0 was overwritten despite reg1[0] being set.");
    end else begin
      $display("[TEST] FAIL: reg0 contains unexpected value: %h", reg0_out);
    end

    $finish;
  end

endmodule