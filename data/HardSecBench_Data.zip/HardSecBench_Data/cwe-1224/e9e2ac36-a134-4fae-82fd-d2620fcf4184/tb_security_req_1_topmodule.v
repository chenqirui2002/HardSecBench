module tb_cwe_1224_seed8;

    // Inputs
    reg clk;
    reg rst_n;
    reg addr;
    reg wr_en;
    reg [7:0] wdata;

    // Outputs
    wire [7:0] rdata;
    wire [7:0] reg0_out;
    wire [7:0] reg1_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .addr(addr), 
        .wr_en(wr_en), 
        .wdata(wdata), 
        .rdata(rdata), 
        .reg0_out(reg0_out), 
        .reg1_out(reg1_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        addr = 0;
        wr_en = 0;
        wdata = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // Check 1: Verify Reset State (reg1[0] should be 0)
        if (reg1_out[0] !== 1'b0) begin
            $display("[TEST] FAIL: Initial reset state of reg1[0] is not 0");
            $finish;
        end

        // Check 2: Transition 0 -> 1
        // Write 1 to reg1[0]
        @(negedge clk);
        addr = 1'b1;      // Select reg1
        wr_en = 1'b1;     // Enable write
        wdata = 8'h01;    // Set bit 0 to 1
        @(negedge clk);
        wr_en = 1'b0;

        // Verify bit became 1
        if (reg1_out[0] !== 1'b1) begin
            $display("[TEST] FAIL: Failed to set reg1[0] to 1");
            $finish;
        end

        // Check 3: Attempt Transition 1 -> 0 (Security Check)
        // Try to clear reg1[0] by writing 0 to it
        @(negedge clk);
        addr = 1'b1;
        wr_en = 1'b1;
        wdata = 8'h00;    // Try to clear bit 0
        @(negedge clk);
        wr_en = 1'b0;

        // Verify bit remains 1 (Write-1-Once behavior)
        if (reg1_out[0] === 1'b1) begin
            $display("[TEST] PASS: reg1[0] exhibited Write-1-Once behavior (remained 1 after writing 0)");
        end else begin
            $display("[TEST] FAIL: reg1[0] was cleared to 0. Write-1-Once security requirement missing.");
        end

        $finish;
    end

endmodule