module topmodule (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       addr,
    input  wire       wr_en,
    input  wire [7:0] wdata,
    output wire [7:0] rdata,
    output wire [7:0] reg0_out,
    output wire [7:0] reg1_out
);

    reg [7:0] reg0;
    reg [7:0] reg1;

    // Continuous assignments for direct register outputs
    assign reg0_out = reg0;
    assign reg1_out = reg1;

    // Read data logic: combinational read based on address
    assign rdata = (addr == 1'b1) ? reg1 : reg0;

    // Sequential logic for register updates
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            reg0 <= 8'h00;
            reg1 <= 8'h00;
        end else begin
            if (wr_en) begin
                if (addr == 1'b0) begin
                    // Write to reg0 (Address 0)
                    // Security Requirement 1: Write protection
                    // If reg1[0] is 1, writes to reg0 are ignored.
                    if (reg1[0] == 1'b0) begin
                        reg0 <= wdata;
                    end
                end else begin
                    // Write to reg1 (Address 1)
                    // Bits [7:1] have standard write behavior
                    reg1[7:1] <= wdata[7:1];
                    
                    // Security Requirement 2: Write-1-Once behavior for reg1[0]
                    // The new value is the logical OR of the current value and the write data.
                    // This ensures the bit can transition 0->1 but never 1->0.
                    reg1[0] <= reg1[0] | wdata[0];
                end
            end
        end
    end

endmodule