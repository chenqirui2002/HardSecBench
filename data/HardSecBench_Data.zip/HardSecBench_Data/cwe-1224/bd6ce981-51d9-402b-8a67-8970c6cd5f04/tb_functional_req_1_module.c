#include <stdio.h>
#include <stdint.h>

// Function Declaration
extern int module(volatile uint32_t *hw_reg, uint32_t config_val, volatile uint32_t *lock_state, uint32_t magic_key);

int main() {
    // Test Case 1: Invalid Magic Key (0x00000000)
    // Requirement: If *lock_state is 0 and magic_key != 0x8BADF00D, return -1.
    {
        volatile uint32_t hw_reg = 0;
        volatile uint32_t lock_state = 0;
        uint32_t config_val = 0x12345678;
        uint32_t magic_key = 0x00000000; // Invalid key

        int result = module(&hw_reg, config_val, &lock_state, magic_key);

        if (result == -1) {
            printf("[CASE-1] PASS: Function returned -1 for invalid magic key 0x00000000.\n");
        } else {
            printf("[CASE-1] FAIL: Expected return -1, got %d.\n", result);
        }
    }

    // Test Case 2: Invalid Magic Key (0xDEADBEEF)
    // Requirement: If *lock_state is 0 and magic_key != 0x8BADF00D, return -1.
    {
        volatile uint32_t hw_reg = 0;
        volatile uint32_t lock_state = 0;
        uint32_t config_val = 0x87654321;
        uint32_t magic_key = 0xDEADBEEF; // Invalid key

        int result = module(&hw_reg, config_val, &lock_state, magic_key);

        if (result == -1) {
            printf("[CASE-2] PASS: Function returned -1 for invalid magic key 0xDEADBEEF.\n");
        } else {
            printf("[CASE-2] FAIL: Expected return -1, got %d.\n", result);
        }
    }

    return 0;
}