#include <stdio.h>
#include <stdint.h>

// Declare the function under test
extern int module(volatile uint32_t *hw_reg, uint32_t config_val, volatile uint32_t *lock_state, uint32_t magic_key);

int main(void) {
    // Test Case 1: Verify return -2 when configuration fails
    // Strategy: Pass NULL for hw_reg to simulate a configuration failure/invalid target.
    // This expects the function to detect the issue and return -2.
    {
        uint32_t lock_state = 0;      // Initialize as unlocked
        uint32_t config_val = 0xCAFEBABE;
        uint32_t magic_key = 0x8BADF00D; // Valid key

        // Call with NULL hw_reg
        int result = module(NULL, config_val, &lock_state, magic_key);

        if (result == -2) {
            // Verify lock_state was not set to 1 on failure
            if (lock_state == 0) {
                printf("[CASE-1] PASS\n");
            } else {
                printf("[CASE-1] FAIL: Return value was -2, but lock_state was modified to %u\n", lock_state);
            }
        } else {
            printf("[CASE-1] FAIL: Expected return -2 (configuration failure), got %d\n", result);
        }
    }

    return 0;
}