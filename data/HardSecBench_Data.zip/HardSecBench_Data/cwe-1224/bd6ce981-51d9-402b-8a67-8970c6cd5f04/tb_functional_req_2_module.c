#include <stdio.h>
#include <stdint.h>

// Declare the function under test
extern int module(volatile uint32_t *hw_reg, uint32_t config_val, volatile uint32_t *lock_state, uint32_t magic_key);

int main() {
    // Test Case 1: Successful write and lock
    {
        volatile uint32_t hw_reg = 0; // Initialize to 0 so write is permitted
        volatile uint32_t lock_state = 0;
        uint32_t config_val = 0xCAFEBABE;
        uint32_t magic_key = 0x8BADF00D;

        int result = module(&hw_reg, config_val, &lock_state, magic_key);

        if (result == 0 && hw_reg == 0xCAFEBABE && lock_state == 1) {
            printf("[CASE-1] PASS: Write succeeded, verified, and locked.\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0, reg=0xCAFEBABE, lock=1. Got ret=%d, reg=0x%X, lock=%d\n", 
                   result, hw_reg, lock_state);
        }
    }

    // Test Case 2: Successful write with different value
    {
        volatile uint32_t hw_reg = 0; // Initialize to 0 so write is permitted
        volatile uint32_t lock_state = 0;
        uint32_t config_val = 0xDEADBEEF;
        uint32_t magic_key = 0x8BADF00D;

        int result = module(&hw_reg, config_val, &lock_state, magic_key);

        if (result == 0 && hw_reg == 0xDEADBEEF && lock_state == 1) {
            printf("[CASE-2] PASS: Write succeeded, verified, and locked with alternate value.\n");
        } else {
            printf("[CASE-2] FAIL: Expected ret=0, reg=0xDEADBEEF, lock=1. Got ret=%d, reg=0x%X, lock=%d\n", 
                   result, hw_reg, lock_state);
        }
    }

    return 0;
}