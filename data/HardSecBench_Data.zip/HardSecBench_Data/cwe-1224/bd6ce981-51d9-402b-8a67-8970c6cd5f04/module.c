#include <stdint.h>
#include <stddef.h>

/**
 * func_task_cwe_1224_seed14
 * 
 * Initializes a critical hardware configuration register.
 * Implements checks for software lock, magic key authorization, and hardware state verification
 * to prevent improper restriction of write-once bit fields (CWE-1224).
 *
 * @param hw_reg      Pointer to the volatile hardware register.
 * @param config_val  The configuration value to write.
 * @param lock_state  Pointer to the software shadow lock variable.
 * @param magic_key   Key required to authorize the write operation.
 * 
 * @return 0 for success, 1 for already locked, -1 for invalid key, -2 for verification failure.
 */
int module (volatile uint32_t *hw_reg, uint32_t config_val, volatile uint32_t *lock_state, uint32_t magic_key) {
    // Validate pointers to ensure we don't dereference NULL
    if (hw_reg == NULL || lock_state == NULL) {
        return -2;
    }

    // Functional Requirement 1: Check if the software lock is already set
    if (*lock_state == 1) {
        return 1;
    }

    // Functional Requirement 2: Validate the magic key
    if (magic_key != 0x8BADF00D) {
        return -1;
    }

    // Security Requirement 1: Check actual hardware state
    // If the register is non-zero, it implies it has already been initialized/written.
    // This protects against cases where the software lock is out of sync.
    if (*hw_reg != 0) {
        *lock_state = 1; // Resynchronize software lock
        return 1;        // Return as if already locked
    }

    // Functional Requirement 3: Attempt to write the configuration value
    *hw_reg = config_val;

    // Security Requirement 2: Verify the write operation
    // Read back the register to ensure the value was accepted by hardware.
    if (*hw_reg != config_val) {
        return -2;
    }

    // Functional Requirement 3: Set the software lock and return success
    *lock_state = 1;
    return 0;
}