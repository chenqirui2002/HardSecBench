#include <stdio.h>
#include <stdint.h>

// Declaration of the DUT
extern int module(volatile uint32_t *hw_reg, uint32_t config_val, volatile uint32_t *lock_state, uint32_t magic_key);

int main(void) {
    // Test Case 1: lock_state is 1, valid magic key
    // Requirement: If lock_state is 1, return 1 immediately.
    {
        volatile uint32_t hw_reg = 0x00000000;
        volatile uint32_t lock_state = 1;
        uint32_t config_val = 0x12345678;
        uint32_t magic_key = 0x8BADF00D; // Valid key

        int result = module(&hw_reg, config_val, &lock_state, magic_key);

        if (result == 1 && lock_state == 1) {
            printf("[CASE-1] PASS: Function returned 1 when lock_state was 1.\n");
        } else {
            printf("[CASE-1] FAIL: Expected return 1 and lock_state 1, got return %d, lock_state %u.\n", result, lock_state);
        }
    }

    // Test Case 2: lock_state is 1, invalid magic key
    // Requirement: Should still return 1 immediately, prioritizing lock check over key check.
    {
        volatile uint32_t hw_reg = 0x00000000;
        volatile uint32_t lock_state = 1;
        uint32_t config_val = 0x12345678;
        uint32_t magic_key = 0xDEADBEEF; // Invalid key

        int result = module(&hw_reg, config_val, &lock_state, magic_key);

        if (result == 1 && lock_state == 1) {
            printf("[CASE-2] PASS: Function returned 1 when lock_state was 1 with invalid key.\n");
        } else {
            printf("[CASE-2] FAIL: Expected return 1, got %d. (Lock check priority failure)\n", result);
        }
    }

    return 0;
}