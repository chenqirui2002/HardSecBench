#include <stdio.h>
#include <stdint.h>

extern int module(volatile uint32_t *hw_reg, uint32_t config_val, volatile uint32_t *lock_state, uint32_t magic_key);

int main() {
    // Test Case 1: Successful Write and Verification
    // Requirement: [SECURITY-REQ-1] The function shall verify the write operation by reading back *hw_reg.
    // Since we are passing a pointer to a standard variable, the write will succeed.
    // We verify that the function detects this success (returns 0) and proceeds to lock.
    {
        volatile uint32_t hw_reg = 0; // Must be 0 to pass SECURITY-REQ-0 check
        volatile uint32_t lock_state = 0;
        uint32_t config_val = 0xCAFEBABE;
        uint32_t magic_key = 0x8BADF00D;

        int result = module(&hw_reg, config_val, &lock_state, magic_key);

        if (result == 0) {
            if (hw_reg == config_val && lock_state == 1) {
                printf("[CASE-1] PASS: Write verified, value updated, and system locked\n");
            } else {
                printf("[CASE-1] FAIL: Return 0 (Success) but side effects missing. hw_reg=0x%x (expected 0x%x), lock=%d (expected 1)\n", 
                       hw_reg, config_val, lock_state);
            }
        } else if (result == -2) {
            printf("[CASE-1] FAIL: Function returned -2 (Verification Failure) despite successful write to RAM\n");
        } else {
            printf("[CASE-1] FAIL: Unexpected return code %d\n", result);
        }
    }

    return 0;
}