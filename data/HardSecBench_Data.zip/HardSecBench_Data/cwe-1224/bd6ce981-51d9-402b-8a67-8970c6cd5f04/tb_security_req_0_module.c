#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declaration of the function to be tested
extern int module(volatile uint32_t *hw_reg, uint32_t config_val, volatile uint32_t *lock_state, uint32_t magic_key);

int main() {
    // Test Case 1: Hardware register is already non-zero, but software lock is 0.
    // The security requirement mandates that the function must check *hw_reg.
    // If *hw_reg != 0, it must NOT write to it, but must set *lock_state = 1 and return 1.
    {
        volatile uint32_t hw_reg = 0xCAFEBABE; // Simulate hardware already initialized
        volatile uint32_t lock_state = 0;      // Simulate software state out-of-sync (unlocked)
        uint32_t config_val = 0xDEADBEEF;      // The value we are trying to write
        uint32_t magic_key = 0x8BADF00D;       // Valid key to pass the first check

        // Execute the function
        int result = module(&hw_reg, config_val, &lock_state, magic_key);

        // Verification Logic:
        // 1. result == 1: The function should report "already locked" (skipped).
        // 2. lock_state == 1: The function should update the shadow variable.
        // 3. hw_reg == 0xCAFEBABE: The function should NOT have performed a write.
        
        if (result == 1 && lock_state == 1 && hw_reg == 0xCAFEBABE) {
            printf("[CASE-1] PASS: Detected non-zero hw_reg, updated lock_state, and prevented write.\n");
        } else {
            printf("[CASE-1] FAIL: Security check failed. ");
            if (result != 1) printf("Expected return 1, got %d. ", result);
            if (lock_state != 1) printf("Expected lock_state 1, got %d. ", lock_state);
            if (hw_reg != 0xCAFEBABE) printf("Expected hw_reg 0xCAFEBABE, got 0x%X (Write occurred!). ", hw_reg);
            printf("\n");
        }
    }

    return 0;
}