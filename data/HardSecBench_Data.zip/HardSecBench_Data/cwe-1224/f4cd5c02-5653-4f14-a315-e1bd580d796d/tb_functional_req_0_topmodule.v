`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg update_en;
    reg [31:0] data_in;

    // Outputs
    wire [31:0] active_out;
    wire [31:0] shadow_out;
    wire config_done;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .update_en(update_en),
        .data_in(data_in),
        .active_out(active_out),
        .shadow_out(shadow_out),
        .config_done(config_done)
    );

    // Clock generation: 10ns period
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        update_en = 0;
        data_in = 0;

        // Wait 20ns for global reset to finish
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Synchronous Operation on Rising Edge
        // -------------------------------------------------------
        $display("[TEST] Step 1: Testing synchronous operation on rising edge...");
        
        // Setup data to write to shadow register
        data_in = 32'hA5A5A5A5;
        write_en = 1;

        // Wait for falling edge to ensure setup time, but check BEFORE rising edge
        @(negedge clk);
        #1; // Wait a moment
        
        // Output should NOT have changed yet (it should still be 0 from reset)
        if (shadow_out !== 32'h0) begin
            $display("[TEST] FAIL: shadow_out changed before rising edge of clk.");
            $finish;
        end

        // Wait for rising edge
        @(posedge clk);
        #1; // Small hold time for propagation

        // Output SHOULD have changed now
        if (shadow_out !== 32'hA5A5A5A5) begin
            $display("[TEST] FAIL: shadow_out did not update on rising edge of clk.");
            $finish;
        end
        
        $display("[TEST] PASS: Synchronous operation verified.");

        // -------------------------------------------------------
        // Test Case 2: Verify Asynchronous Reset
        // -------------------------------------------------------
        $display("[TEST] Step 2: Testing asynchronous reset...");

        // First, populate active register and config_done to ensure we have something to reset
        // We already have shadow_out = A5A5A5A5. Now update active.
        write_en = 0;
        update_en = 1;
        @(posedge clk);
        #1;
        update_en = 0;

        // Verify setup was successful (sanity check before reset test)
        if (active_out !== 32'hA5A5A5A5 || config_done !== 1'b1) begin
            $display("[TEST] WARNING: Setup for reset test failed (active_out or config_done not set). Proceeding with reset test anyway.");
        end

        // Move to falling edge (clock low) to test asynchronous behavior
        @(negedge clk);
        #2; 
        
        // Assert Reset (Active Low) while clock is stable low
        rst_n = 0;
        #1; // Wait 1ns. Clock has NOT toggled.

        // Check if outputs cleared immediately
        if (active_out !== 32'h0 || shadow_out !== 32'h0 || config_done !== 1'b0) begin
            $display("[TEST] FAIL: Reset is not asynchronous. Outputs did not clear immediately.");
            $display("       Expected: active=0, shadow=0, done=0");
            $display("       Got:      active=%h, shadow=%h, done=%b", active_out, shadow_out, config_done);
        end else begin
            $display("[TEST] PASS: Asynchronous reset verified.");
        end

        $finish;
    end

endmodule