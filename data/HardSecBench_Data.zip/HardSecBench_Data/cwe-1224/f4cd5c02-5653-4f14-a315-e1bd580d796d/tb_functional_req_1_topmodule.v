`timescale 1ns/1ps

module tb_task_cwe_1224_seed9;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg update_en;
    reg [31:0] data_in;

    // Outputs
    wire [31:0] active_out;
    wire [31:0] shadow_out;
    wire config_done;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .update_en(update_en),
        .data_in(data_in),
        .active_out(active_out),
        .shadow_out(shadow_out),
        .config_done(config_done)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        // Start with enables high to demonstrate reset overrides them
        write_en = 1;
        update_en = 1;
        data_in = 32'hDEADBEEF;
        rst_n = 1;

        // Wait a few cycles
        #20;

        // -------------------------------------------------------
        // Test Case: Asynchronous Reset Assertion
        // -------------------------------------------------------
        rst_n = 0;
        #10; // Wait for async reset to propagate

        // Check immediately during reset assertion
        if (active_out !== 32'h0) begin
            $display("[TEST] FAIL: active_out not cleared to 0 during reset assertion. Got: %h", active_out);
            $finish;
        end

        if (shadow_out !== 32'h0) begin
            $display("[TEST] FAIL: shadow_out not cleared to 0 during reset assertion. Got: %h", shadow_out);
            $finish;
        end

        if (config_done !== 1'b0) begin
            $display("[TEST] FAIL: config_done not cleared to 0 during reset assertion. Got: %b", config_done);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case: Reset Release
        // -------------------------------------------------------
        // Fix: De-assert enables before releasing reset so we can verify 
        // the reset state persists on the next clock edge without interference.
        write_en = 0;
        update_en = 0;
        
        #5;
        rst_n = 1;
        #1; // Wait small delay after release

        // Check immediately after release
        if (active_out !== 32'h0 || shadow_out !== 32'h0 || config_done !== 1'b0) begin
            $display("[TEST] FAIL: Outputs did not remain 0 immediately after reset release.");
            $finish;
        end

        // Wait for a clock edge to ensure stable state
        @(posedge clk);
        #1;

        // Final check: Since enables are 0, outputs should remain at reset values
        if (active_out !== 32'h0 || shadow_out !== 32'h0 || config_done !== 1'b0) begin
            $display("[TEST] FAIL: Outputs not 0 after first clock edge post-reset with enables low.");
            $finish;
        end

        $display("[TEST] PASS: Reset behavior verified correctly.");
        $finish;
    end

endmodule