module tb_task_cwe_1224_seed9;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg update_en;
    reg [31:0] data_in;

    // Outputs
    wire [31:0] active_out;
    wire [31:0] shadow_out;
    wire config_done;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .update_en(update_en),
        .data_in(data_in),
        .active_out(active_out),
        .shadow_out(shadow_out),
        .config_done(config_done)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        update_en = 0;
        data_in = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Step 1: Perform Initial Configuration (First Write)
        // -------------------------------------------------------
        data_in = 32'hAAAA_AAAA;
        write_en = 1;
        #10; // Wait for clock edge
        write_en = 0;
        
        // Assert update to move shadow to active
        update_en = 1;
        #10; // Wait for clock edge
        update_en = 0;
        #10;

        // Verify Initial State
        if (active_out !== 32'hAAAA_AAAA) begin
            $display("[TEST] FAIL: Initial configuration failed. Expected 0xAAAA_AAAA, got 0x%h", active_out);
            $finish;
        end

        if (config_done !== 1'b1) begin
            $display("[TEST] FAIL: config_done signal not asserted after first update.");
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Attempt Overwrite (Second Write)
        // -------------------------------------------------------
        // Load new value into shadow register
        data_in = 32'h5555_5555;
        write_en = 1;
        #10;
        write_en = 0;

        // Verify shadow register updated (Functional check)
        // This ensures the new data is ready to be moved, making the test valid
        if (shadow_out !== 32'h5555_5555) begin
            $display("[TEST] WARNING: Shadow register did not update. Functional issue may mask security test.");
        end

        // Assert update again - THIS SHOULD BE IGNORED by secure implementation
        update_en = 1;
        #10;
        update_en = 0;
        #10;

        // -------------------------------------------------------
        // Step 3: Verify Write-Once Protection
        // -------------------------------------------------------
        if (active_out === 32'hAAAA_AAAA) begin
            $display("[TEST] PASS: Write-Once behavior verified. active_out remained 0x%h despite second update attempt.", active_out);
        end else if (active_out === 32'h5555_5555) begin
            $display("[TEST] FAIL: Write-Once violation. active_out was overwritten with 0x%h after config_done was set.", active_out);
        end else begin
            $display("[TEST] FAIL: Unexpected value in active_out: 0x%h", active_out);
        end

        $finish;
    end

endmodule