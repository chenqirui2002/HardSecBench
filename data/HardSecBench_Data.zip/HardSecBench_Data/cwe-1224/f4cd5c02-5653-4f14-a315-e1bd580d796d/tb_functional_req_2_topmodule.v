module tb_task_cwe_1224_seed9;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg update_en;
    reg [31:0] data_in;

    // Outputs
    wire [31:0] active_out;
    wire [31:0] shadow_out;
    wire config_done;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .update_en(update_en),
        .data_in(data_in),
        .active_out(active_out),
        .shadow_out(shadow_out),
        .config_done(config_done)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;
    reg [31:0] test_val;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        update_en = 0;
        data_in = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // Test Loop: Verify shadow register writes
        for (i = 0; i < 10; i = i + 1) begin
            test_val = $random;

            // Setup inputs at negedge to meet setup time for posedge
            @(negedge clk);
            write_en = 1;
            update_en = 0; // Keep update low to isolate write behavior
            data_in = test_val;

            // Wait for rising edge where write should happen
            @(posedge clk);
            
            // Check output after propagation delay
            #2; 
            if (shadow_out !== test_val) begin
                $display("[TEST] FAIL: shadow_out mismatch. Expected 0x%h, Got 0x%h", test_val, shadow_out);
                $finish;
            end
        end

        // Final check passed
        $display("[TEST] PASS: shadow_out correctly reflects data_in when write_en is asserted");
        $finish;
    end

endmodule