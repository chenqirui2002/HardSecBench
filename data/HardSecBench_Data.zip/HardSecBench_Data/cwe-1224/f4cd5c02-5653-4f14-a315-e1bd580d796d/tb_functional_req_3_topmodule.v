`timescale 1ns / 1ps

module tb_task_cwe_1224_seed9;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg update_en;
    reg [31:0] data_in;

    // Outputs
    wire [31:0] active_out;
    wire [31:0] shadow_out;
    wire config_done;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .update_en(update_en),
        .data_in(data_in),
        .active_out(active_out),
        .shadow_out(shadow_out),
        .config_done(config_done)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        update_en = 0;
        data_in = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // --- Step 1: Setup Shadow Register ---
        // Write a test value to the shadow register so we can verify the copy operation.
        data_in = 32'hDEADBEEF;
        write_en = 1;
        @(posedge clk);
        #1; // Hold time
        write_en = 0;
        
        // Verify precondition (shadow register loaded)
        if (shadow_out !== 32'hDEADBEEF) begin
            $display("[TEST] FAIL: Precondition failed - shadow_out did not capture data_in.");
            $finish;
        end

        // --- Step 2: Trigger Update ---
        // Assert update_en to trigger the copy from shadow to active
        update_en = 1;
        @(posedge clk);
        #1; // Hold time
        update_en = 0;

        // --- Step 3: Verify Requirement ---
        // Check if active_out matches shadow value and config_done is high
        if (active_out === 32'hDEADBEEF && config_done === 1'b1) begin
            $display("[TEST] PASS: active_out updated to 0x%h and config_done asserted.", active_out);
        end else begin
            $display("[TEST] FAIL: Update behavior incorrect. Expected active_out=0xDEADBEEF, config_done=1. Got active_out=0x%h, config_done=%b", active_out, config_done);
        end

        $finish;
    end

endmodule