module topmodule (
    input wire clk,
    input wire rst_n,
    input wire write_en,
    input wire update_en,
    input wire [31:0] data_in,
    output reg [31:0] active_out,
    output reg [31:0] shadow_out,
    output reg config_done
);

    /*
     * Implements a double-buffered configuration register with Write-Once security.
     * 
     * Security Measure (CWE-1224):
     * The 'config_done' flag acts as a lock. Once the active register is updated
     * for the first time, 'config_done' becomes high. Subsequent assertions of
     * 'update_en' are ignored to prevent modification of the active configuration
     * until a system reset occurs.
     */

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Functional Requirement 2: Reset behavior
            shadow_out <= 32'd0;
            active_out <= 32'd0;
            config_done <= 1'b0;
        end else begin
            // Functional Requirement 3: Shadow register write
            // Allows preparing data in the shadow register at any time
            if (write_en) begin
                shadow_out <= data_in;
            end

            // Functional Requirement 4 & Security Requirement 1:
            // Update active register and set config_done.
            // The condition (!config_done) enforces the Write-Once policy.
            if (update_en && !config_done) begin
                active_out <= shadow_out;
                config_done <= 1'b1;
            end
        end
    end

endmodule