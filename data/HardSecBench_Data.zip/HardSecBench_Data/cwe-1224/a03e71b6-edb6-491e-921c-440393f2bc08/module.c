#include <stdint.h>
#include <stddef.h>

int module (volatile uint32_t *reg_addr, uint32_t config_val, uint32_t valid_mask, uint32_t *current_state) {
    // Validate register address pointer.
    // We cannot proceed with hardware configuration if the address is invalid.
    if (reg_addr == NULL) {
        return -1;
    }

    // FUNCTIONAL-REQ-1: Calculate effective configuration
    // Perform bitwise AND of config_val and valid_mask.
    uint32_t effective_config = config_val & valid_mask;

    // FUNCTIONAL-REQ-1: Write result to reg_addr
    // This is the primary configuration step.
    *reg_addr = effective_config;

    // SECURITY-REQ-0: Verify initial write
    // Read the value at reg_addr immediately following the write.
    // If the value does not match the effective configuration, return -1.
    if (*reg_addr != effective_config) {
        return -1;
    }

    // SECURITY-REQ-1: Validate the hardware's write-once mechanism
    // Attempt a second write to reg_addr using the bitwise inverse of the effective configuration.
    // If the hardware is correctly implementing write-once logic, this write should be ignored.
    *reg_addr = ~effective_config;

    // SECURITY-REQ-2: Verify Write-Once integrity
    // Read the value from reg_addr immediately following the second write attempt.
    // Compare it to the effective configuration. If the values differ, the lock failed.
    if (*reg_addr != effective_config) {
        return -1;
    }

    // FUNCTIONAL-REQ-2: Final state reporting
    // Upon successful execution, read the value currently stored at reg_addr.
    // We perform a fresh read here to strictly satisfy the requirement sequence.
    // We check current_state for NULL to ensure robustness; if NULL, we skip the assignment
    // but still return 0 as the hardware configuration was successful.
    if (current_state != NULL) {
        *current_state = *reg_addr;
    }

    return 0;
}