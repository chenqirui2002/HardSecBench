#include <stdio.h>
#include <stdint.h>

// Declare the function under test
extern int module(volatile uint32_t *reg_addr, uint32_t config_val, uint32_t valid_mask, uint32_t *current_state);

void test_functional_req_1() {
    // Case 1: Verify bitwise AND calculation and write sequence
    {
        volatile uint32_t reg = 0xAAAAAAAA; // Initial garbage value
        uint32_t current_state = 0;
        uint32_t config = 0x12345678;
        uint32_t mask = 0x0000FFFF;
        uint32_t effective = config & mask; // 0x00005678
        // Since we are testing on RAM, the function's security check (SECURITY-REQ-1)
        // will successfully overwrite the register with ~effective.
        uint32_t expected_ram_val = ~effective; // 0xFFFFA987

        // Call function
        // Expect -1 because RAM allows the 2nd write, causing the integrity check (SECURITY-REQ-2) to fail
        int ret = module(&reg, config, mask, &current_state);

        // Verify the register holds the inverted value (proving effective was calculated and used)
        // and return value is -1 (proving the function executed the check)
        if (reg == expected_ram_val && ret == -1) {
            printf("[CASE-1] PASS\n");
        } else {
            printf("[CASE-1] FAIL: reg=0x%08X (expected ~0x%08X), ret=%d\n", reg, effective, ret);
        }
    }

    // Case 2: Verify zero mask calculation
    {
        volatile uint32_t reg = 0xAAAAAAAA; // Initial garbage value
        uint32_t current_state = 0;
        uint32_t config = 0xDEADBEEF;
        uint32_t mask = 0x00000000;
        uint32_t effective = 0x00000000;
        uint32_t expected_ram_val = ~effective; // 0xFFFFFFFF

        int ret = module(&reg, config, mask, &current_state);

        if (reg == expected_ram_val && ret == -1) {
            printf("[CASE-2] PASS\n");
        } else {
            printf("[CASE-2] FAIL: reg=0x%08X (expected ~0x%08X), ret=%d\n", reg, effective, ret);
        }
    }
}

int main() {
    test_functional_req_1();
    return 0;
}