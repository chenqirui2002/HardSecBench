#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <signal.h>
#include <unistd.h>
#include <ucontext.h>

// Declaration of the function under test
extern int module(volatile uint32_t *reg_addr, uint32_t config_val, uint32_t valid_mask, uint32_t *current_state);

// Global state for signal handlers (must be global to be accessible in handler)
static volatile uint32_t *g_sim_page = NULL;
static uint32_t g_expected_val = 0;
static int g_write_count = 0;
static size_t g_page_size = 0;

// Signal handler to simulate Write-Once memory behavior
void write_once_handler(int sig, siginfo_t *si, void *ptr) {
    ucontext_t *ctx = (ucontext_t *)ptr;
    
    if (sig == SIGSEGV) {
        // A write occurred on the protected page.
        // Unprotect to allow the instruction to execute.
        mprotect((void *)g_sim_page, g_page_size, PROT_READ | PROT_WRITE);
        
        // Enable Single Step (Trap Flag) to catch completion of the instruction.
        // x86_64 specific: EFLAGS register index is REG_EFL, TF bit is 0x100.
        #ifdef __x86_64__
        ctx->uc_mcontext.gregs[REG_EFL] |= 0x100;
        #endif
        
        g_write_count++;
    } 
    else if (sig == SIGTRAP) {
        // The instruction has finished executing.
        
        // If this was the second write (the integrity check ~val), revert it to the locked value.
        // This simulates the hardware ignoring the second write.
        if (g_write_count == 2) {
            *g_sim_page = g_expected_val;
        }
        
        // Re-protect the page to Read-Only for the next cycle
        mprotect((void *)g_sim_page, g_page_size, PROT_READ);
        
        // Disable Single Step
        #ifdef __x86_64__
        ctx->uc_mcontext.gregs[REG_EFL] &= ~0x100;
        #endif
    }
}

void test_req2_write_once_simulation(void) {
    // 1. Setup Signal Handlers
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = write_once_handler;
    if (sigaction(SIGSEGV, &sa, NULL) < 0 || sigaction(SIGTRAP, &sa, NULL) < 0) {
        printf("[CASE-1] FAIL: sigaction setup failed\n");
        return;
    }

    // 2. Setup Memory Page
    g_page_size = sysconf(_SC_PAGESIZE);
    // Map an anonymous page. Initially PROT_READ to trap the first write.
    g_sim_page = (volatile uint32_t *)mmap(NULL, g_page_size, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    
    if (g_sim_page == MAP_FAILED) {
        printf("[CASE-1] FAIL: mmap failed\n");
        return;
    }

    // 3. Prepare Test Data
    uint32_t config = 0xCAFEBABE;
    uint32_t mask = 0xFFFFFFFF;
    uint32_t current_state = 0x00000000;
    g_expected_val = config & mask; // The value that should be locked in the register
    g_write_count = 0;

    // 4. Execute Function
    // The signal handler will intervene to enforce Write-Once semantics
    int result = module(g_sim_page, config, mask, &current_state);

    // 5. Verify [FUNCTIONAL-REQ-2]
    if (result == 0) {
        // Check if current_state was updated to the register value
        if (current_state == g_expected_val) {
            printf("[CASE-1] PASS\n");
        } else {
            printf("[CASE-1] FAIL: Return 0 but current_state (0x%08X) != expected (0x%08X)\n", current_state, g_expected_val);
        }
    } else {
        #ifndef __x86_64__
        printf("[CASE-1] FAIL: Function returned %d (Note: Test requires x86_64 for TF manipulation)\n", result);
        #else
        printf("[CASE-1] FAIL: Function returned %d (Write-Once simulation failed)\n", result);
        #endif
    }

    // Cleanup
    munmap((void *)g_sim_page, g_page_size);
}

int main(void) {
    test_req2_write_once_simulation();
    return 0;
}