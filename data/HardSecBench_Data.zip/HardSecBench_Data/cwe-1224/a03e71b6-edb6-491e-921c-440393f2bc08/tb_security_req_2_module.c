#include <stdio.h>
#include <stdint.h>

// Declaration of the function under test
extern int module(volatile uint32_t *reg_addr, uint32_t config_val, uint32_t valid_mask, uint32_t *current_state);

int main() {
    // Test Case 1: Verify detection of Write-Once violation using standard RAM
    // Rationale: Standard RAM allows overwrites. If the function correctly implements
    // the check after the second write (REQ-2), it should see the value has changed
    // and return -1.
    {
        uint32_t pseudo_reg = 0;
        uint32_t current_state = 0;
        uint32_t config_val = 0xA5A5A5A5;
        uint32_t valid_mask = 0xFFFFFFFF;
        
        // Expected effective config: 0xA5A5A5A5
        // Inverted config (2nd write): 0x5A5A5A5A
        
        int result = module(&pseudo_reg, config_val, valid_mask, &current_state);
        
        // If secure:
        // 1. Write 0xA5A5A5A5.
        // 2. Write 0x5A5A5A5A.
        // 3. Read 0x5A5A5A5A.
        // 4. Compare 0x5A5A5A5A != 0xA5A5A5A5 -> Return -1.
        
        if (result == -1) {
            printf("[CASE-1] PASS: Function correctly detected that the register value changed (simulated hardware failure).\n");
        } else {
            // If insecure, it likely ignored the change and returned success (0)
            printf("[CASE-1] FAIL: Function returned %d (expected -1). The function failed to validate the Write-Once mechanism after the second write.\n", result);
        }
    }

    // Test Case 2: Verify with different bit pattern to ensure no data dependency issues
    {
        uint32_t pseudo_reg = 0;
        uint32_t current_state = 0;
        uint32_t config_val = 0x12345678;
        uint32_t valid_mask = 0x0000FFFF; // Effective: 0x00005678
        
        int result = module(&pseudo_reg, config_val, valid_mask, &current_state);
        
        if (result == -1) {
            printf("[CASE-2] PASS: Function correctly detected register overwrite with masked value.\n");
        } else {
            printf("[CASE-2] FAIL: Function returned %d (expected -1). Failed to detect overwrite.\n", result);
        }
    }

    return 0;
}