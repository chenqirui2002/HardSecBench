#include <stdio.h>
#include <stdint.h>

// Declare the function under test
extern int module(volatile uint32_t *reg_addr, uint32_t config_val, uint32_t valid_mask, uint32_t *current_state);

int main() {
    // Test Case 1: Verify Inverted Write Attempt on Standard RAM
    // Since we pass a pointer to a standard variable, it is Read-Write, not Write-Once.
    // The function should:
    // 1. Write effective_config (0xAAAAAAAA)
    // 2. Write ~effective_config (0x55555555) -> This is SECURITY-REQ-1
    // 3. Read back 0x55555555, compare with 0xAAAAAAAA, fail, and return -1.
    {
        uint32_t mock_reg = 0;
        uint32_t current_state = 0;
        uint32_t config_val = 0xAAAAAAAA;
        uint32_t valid_mask = 0xFFFFFFFF;
        
        // Effective config = 0xAAAAAAAA
        // Expected Inverted write = ~0xAAAAAAAA = 0x55555555
        
        int ret = module(&mock_reg, config_val, valid_mask, &current_state);
        
        // We check if the register holds the inverted value. This confirms SECURITY-REQ-1 was executed.
        if (mock_reg == 0x55555555) {
            // We also check if the function correctly identified the failure (SECURITY-REQ-2 context),
            // but the primary goal here is ensuring the write happened.
            if (ret == -1) {
                printf("[CASE-1] PASS: Inverted write attempted and integrity failure reported.\n");
            } else {
                printf("[CASE-1] FAIL: Inverted write occurred, but function returned success (0) despite hardware integrity failure.\n");
            }
        } else if (mock_reg == 0xAAAAAAAA) {
            printf("[CASE-1] FAIL: Register contains initial config. The inverted write check (SECURITY-REQ-1) was likely skipped.\n");
        } else {
            printf("[CASE-1] FAIL: Register contains unexpected value 0x%08X.\n", mock_reg);
        }
    }

    // Test Case 2: Verify Inverted Write with Partial Mask
    {
        uint32_t mock_reg = 0;
        uint32_t current_state = 0;
        uint32_t config_val = 0xFFFFFFFF;
        uint32_t valid_mask = 0x000000FF; 
        
        // Effective = config & mask = 0x000000FF
        // Inverted = ~0x000000FF = 0xFFFFFF00
        
        int ret = module(&mock_reg, config_val, valid_mask, &current_state);
        
        if (mock_reg == 0xFFFFFF00) {
            if (ret == -1) {
                printf("[CASE-2] PASS: Inverted write with mask verified.\n");
            } else {
                printf("[CASE-2] FAIL: Inverted write occurred, but returned success (0).\n");
            }
        } else {
            printf("[CASE-2] FAIL: Register state 0x%08X does not match expected inverted value 0xFFFFFF00.\n", mock_reg);
        }
    }

    return 0;
}