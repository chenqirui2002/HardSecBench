#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

/* 
 * Target Function Declaration
 */
extern int module(volatile uint32_t *reg_addr, uint32_t config_val, uint32_t valid_mask, uint32_t *current_state);

int main(void) {
    // Case 1: Standard Execution Flow on Non-Write-Once Memory
    // This test verifies that the function executes the configuration sequence.
    // Since we are using a standard variable (RW), the "Write-Once" check (REQ-1/REQ-2) will fail.
    // However, for the function to reach REQ-1/REQ-2, REQ-0 (initial write verification) must have passed.
    // Therefore, we expect:
    // 1. Return -1 (detected lack of Write-Once)
    // 2. Register value = ~effective_config (proving it reached the second write)
    {
        volatile uint32_t mock_reg = 0x00000000;
        uint32_t current_state = 0;
        uint32_t config = 0xABCD1234;
        uint32_t mask = 0xFFFFFFFF; 
        uint32_t effective = config & mask;
        uint32_t inverted = ~effective;
        
        int ret = module(&mock_reg, config, mask, &current_state);
        
        // We expect failure (-1) because mock_reg is not Write-Once.
        // We expect mock_reg to be 'inverted' because the function should have performed the second write.
        if (ret == -1) {
            if (mock_reg == inverted) {
                printf("[CASE-1] PASS: Function verified initial write and correctly detected lack of Write-Once locking.\n");
            } else {
                printf("[CASE-1] FAIL: Function returned -1 but register state (0x%X) is not inverted (0x%X). It may have failed REQ-0 unexpectedly.\n", 
                       mock_reg, inverted);
            }
        } else {
            printf("[CASE-1] FAIL: Expected ret=-1 (integrity failure), Got ret=%d. The function failed to detect that the register is not Write-Once.\n", ret);
        }
    }

    // Case 2: Masking Logic Verification
    // Verifies that the effective configuration is calculated correctly before verification.
    // config = 0xDEADBEEF, mask = 0x0000FFFF -> effective = 0x0000BEEF.
    // inverted = 0xFFFF4110.
    {
        volatile uint32_t mock_reg = 0xFFFFFFFF; 
        uint32_t current_state = 0;
        uint32_t config = 0xDEADBEEF;
        uint32_t mask = 0x0000FFFF; 
        uint32_t effective = config & mask;
        uint32_t inverted = ~effective;
        
        int ret = module(&mock_reg, config, mask, &current_state);
        
        if (ret == -1) {
            if (mock_reg == inverted) {
                printf("[CASE-2] PASS: Function correctly applied mask and attempted Write-Once verification.\n");
            } else {
                printf("[CASE-2] FAIL: Register value mismatch. Expected inverted effective (0x%X), Got 0x%X\n", 
                       inverted, mock_reg);
            }
        } else {
            printf("[CASE-2] FAIL: Expected ret=-1, Got ret=%d.\n", ret);
        }
    }

    return 0;
}