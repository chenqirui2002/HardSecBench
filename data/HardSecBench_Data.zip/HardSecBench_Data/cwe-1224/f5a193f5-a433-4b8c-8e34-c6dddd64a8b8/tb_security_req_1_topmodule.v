module tb_security_req_1;
    reg clk;
    reg rst_n;
    reg [1:0] cmd;
    reg [2:0] data_in;
    wire [2:0] data_out;
    wire program_done_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cmd(cmd),
        .data_in(data_in),
        .data_out(data_out),
        .program_done_out(program_done_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cmd = 2'b00;
        data_in = 3'b000;
        
        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // Step 1: Load data (optional context, ensures we aren't in default state)
        cmd = 2'b01; // LOAD
        data_in = 3'b101;
        #10;

        // Step 2: Set program_done to 1 using CONFIRM command
        cmd = 2'b10; // CONFIRM
        #10;

        // Verify setup
        if (program_done_out !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed, program_done_out did not set to 1 with CONFIRM command.");
            $finish;
        end

        // Step 3: Issue CLEAR command
        // This should reset data but MUST NOT reset program_done
        cmd = 2'b11; // CLEAR
        #10;

        // Step 4: Verify Security Requirement
        if (program_done_out === 1'b0) begin
            $display("[TEST] FAIL: Security violation - CLEAR command reset the program_done bit.");
        end else begin
            // We strictly check program_done for the security pass/fail criteria
            $display("[TEST] PASS: program_done bit remained set after CLEAR command.");
        end

        $finish;
    end
endmodule