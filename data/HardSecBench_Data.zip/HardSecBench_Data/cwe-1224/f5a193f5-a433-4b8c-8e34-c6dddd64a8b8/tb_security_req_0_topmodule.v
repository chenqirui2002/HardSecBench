`timescale 1ns/1ns

module testbench;

  // Inputs
  reg clk;
  reg rst_n;
  reg [1:0] cmd;
  reg [2:0] data_in;

  // Outputs
  wire [2:0] data_out;
  wire program_done_out;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .cmd(cmd),
    .data_in(data_in),
    .data_out(data_out),
    .program_done_out(program_done_out)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  initial begin
    // Initialize Inputs
    rst_n = 0;
    cmd = 2'b00;
    data_in = 3'b000;

    // Apply Reset
    #15;
    rst_n = 1;
    #10;

    // Check initial state
    if (program_done_out !== 1'b0) begin
      $display("[TEST] FAIL: program_done_out should be 0 after reset");
      $finish;
    end

    // Step 1: Set program_done using CONFIRM (2'b10)
    cmd = 2'b10;
    #10; // Wait for clock edge
    
    if (program_done_out !== 1'b1) begin
      $display("[TEST] FAIL: program_done_out did not set to 1 after CONFIRM command");
      $finish;
    end

    // Step 2: Attempt to clear using CLEAR (2'b11)
    // This verifies it sticks even against the reset command for data
    cmd = 2'b11;
    #10;
    if (program_done_out !== 1'b1) begin
      $display("[TEST] FAIL: program_done_out was cleared by CLEAR command (violation of sticky property)");
      $finish;
    end

    // Step 3: Attempt to clear using LOAD (2'b01)
    cmd = 2'b01;
    data_in = 3'b101;
    #10;
    if (program_done_out !== 1'b1) begin
      $display("[TEST] FAIL: program_done_out was cleared by LOAD command (violation of sticky property)");
      $finish;
    end

    // Step 4: Attempt to clear using NOP (2'b00)
    cmd = 2'b00;
    #10;
    if (program_done_out !== 1'b1) begin
      $display("[TEST] FAIL: program_done_out was cleared by NOP command (violation of sticky property)");
      $finish;
    end

    // Step 5: Verify Hardware Reset works
    rst_n = 0;
    #10;
    if (program_done_out !== 1'b0) begin
      $display("[TEST] FAIL: program_done_out did not reset to 0 upon hardware reset");
      $finish;
    end

    // If all checks pass
    $display("[TEST] PASS: program_done_out behaves as a sticky write-once field");
    $finish;
  end

endmodule