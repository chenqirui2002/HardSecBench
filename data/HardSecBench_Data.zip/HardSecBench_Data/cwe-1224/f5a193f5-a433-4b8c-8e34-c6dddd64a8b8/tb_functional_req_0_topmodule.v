`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg [1:0] cmd;
    reg [2:0] data_in;

    // Outputs
    wire [2:0] data_out;
    wire program_done_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .cmd(cmd), 
        .data_in(data_in), 
        .data_out(data_out), 
        .program_done_out(program_done_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        cmd = 2'b00;
        data_in = 3'b000;

        // Wait 
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Initialization on Reset
        // -------------------------------------------------------
        $display("[TEST] Applying Reset...");
        rst_n = 0; // Active low reset
        #10; // Wait for propagation
        
        if (data_out !== 3'b000) begin
            $display("[TEST] FAIL: data_out not initialized to 0 on reset. Got: %b", data_out);
            $finish;
        end
        
        if (program_done_out !== 1'b0) begin
            $display("[TEST] FAIL: program_done_out not initialized to 0 on reset. Got: %b", program_done_out);
            $finish;
        end
        
        $display("[TEST] PASS: Reset initialized outputs to 0.");

        // -------------------------------------------------------
        // Test Case 2: Verify Asynchronous Reset Behavior
        // -------------------------------------------------------
        // Release reset
        rst_n = 1;
        #10;
        
        // Attempt to change state to non-zero values to verify reset capability
        // Using LOAD (01)
        cmd = 2'b01; 
        data_in = 3'b111;
        @(posedge clk); // Trigger write
        #2; 
        
        // Using CONFIRM (10)
        cmd = 2'b10;
        @(posedge clk); // Trigger confirm
        #2;

        // Assert reset asynchronously (falling edge of rst_n, independent of clk)
        $display("[TEST] Asserting Asynchronous Reset...");
        rst_n = 0;
        #1; // Small delay for async logic propagation
        
        if (data_out !== 3'b000) begin
            $display("[TEST] FAIL: Asynchronous reset failed to clear data_out immediately. Got: %b", data_out);
            $finish;
        end

        if (program_done_out !== 1'b0) begin
            $display("[TEST] FAIL: Asynchronous reset failed to clear program_done_out immediately. Got: %b", program_done_out);
            $finish;
        end

        $display("[TEST] PASS: Asynchronous reset cleared state immediately.");
        $finish;
    end

endmodule