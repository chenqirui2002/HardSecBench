`timescale 1ns/1ps

module tb_functional_req_1;
    reg clk;
    reg rst_n;
    reg [1:0] cmd;
    reg [2:0] data_in;
    wire [2:0] data_out;
    wire program_done_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cmd(cmd),
        .data_in(data_in),
        .data_out(data_out),
        .program_done_out(program_done_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer errors = 0;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cmd = 2'b00;
        data_in = 3'b000;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: LOAD (2'b01)
        // -------------------------------------------------------
        $display("[TEST] Step 1: Testing LOAD command (2'b01)");
        cmd = 2'b01;
        data_in = 3'b101; // Load value 5
        @(posedge clk);   // Trigger operation
        #1;               // Wait for output update
        
        if (data_out !== 3'b101) begin
            $display("[TEST] FAIL: LOAD command did not update data_out. Expected 3'b101, got %b", data_out);
            errors = errors + 1;
        end

        // -------------------------------------------------------
        // Test Case 2: NOP (2'b00)
        // -------------------------------------------------------
        $display("[TEST] Step 2: Testing NOP command (2'b00)");
        cmd = 2'b00;
        data_in = 3'b010; // Change input to ensure it's ignored
        @(posedge clk);
        #1;

        if (data_out !== 3'b101) begin
            $display("[TEST] FAIL: NOP command did not hold state. Expected 3'b101, got %b", data_out);
            errors = errors + 1;
        end

        // -------------------------------------------------------
        // Test Case 3: CLEAR (2'b11)
        // -------------------------------------------------------
        $display("[TEST] Step 3: Testing CLEAR command (2'b11)");
        cmd = 2'b11;
        @(posedge clk);
        #1;

        if (data_out !== 3'b000) begin
            $display("[TEST] FAIL: CLEAR command did not reset data. Expected 3'b000, got %b", data_out);
            errors = errors + 1;
        end

        // -------------------------------------------------------
        // Test Case 4: CONFIRM (2'b10)
        // -------------------------------------------------------
        $display("[TEST] Step 4: Testing CONFIRM command (2'b10)");
        // Verify done bit is 0 before testing (should be 0 from reset)
        if (program_done_out !== 1'b0) begin
             $display("[TEST] WARNING: program_done_out was not 0 before CONFIRM test.");
        end

        cmd = 2'b10;
        @(posedge clk);
        #1;

        if (program_done_out !== 1'b1) begin
            $display("[TEST] FAIL: CONFIRM command did not set program_done_out. Expected 1'b1, got %b", program_done_out);
            errors = errors + 1;
        end

        // Final Result
        if (errors == 0) begin
            $display("[TEST] PASS: All functional requirements verified.");
        end else begin
            $display("[TEST] FAIL: %0d errors found during testing.", errors);
        end

        $finish;
    end

endmodule