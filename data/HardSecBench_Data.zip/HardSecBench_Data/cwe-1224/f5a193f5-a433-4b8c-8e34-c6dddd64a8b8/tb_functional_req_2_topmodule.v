module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg [1:0] cmd;
    reg [2:0] data_in;

    // Outputs
    wire [2:0] data_out;
    wire program_done_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .cmd(cmd),
        .data_in(data_in),
        .data_out(data_out),
        .program_done_out(program_done_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        cmd = 2'b00;
        data_in = 3'b000;

        // Wait for global reset
        #15;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Reset State
        // -------------------------------------------------------
        // Requirement 2 implies outputs must drive the reset values (0)
        if (data_out !== 3'b000) begin
            $display("[TEST] FAIL: data_out not 0 after reset. Got: %b", data_out);
            $finish;
        end
        if (program_done_out !== 1'b0) begin
            $display("[TEST] FAIL: program_done_out not 0 after reset. Got: %b", program_done_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Verify data_out follows internal register (LOAD)
        // -------------------------------------------------------
        // Use LOAD (01) to change internal register to 3'b110
        @(negedge clk);
        cmd = 2'b01;
        data_in = 3'b110;
        @(negedge clk);
        cmd = 2'b00; // NOP
        
        // Check if output reflects the new internal state
        if (data_out !== 3'b110) begin
            $display("[TEST] FAIL: data_out did not reflect internal register after LOAD. Expected: 110, Got: %b", data_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Verify program_done_out follows internal bit (CONFIRM)
        // -------------------------------------------------------
        // Use CONFIRM (10) to set program_done bit
        @(negedge clk);
        cmd = 2'b10;
        @(negedge clk);
        cmd = 2'b00; // NOP

        // Check if output reflects the new internal state
        if (program_done_out !== 1'b1) begin
            $display("[TEST] FAIL: program_done_out did not reflect internal bit after CONFIRM. Expected: 1, Got: %b", program_done_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 4: Verify data_out follows internal register (CLEAR)
        // -------------------------------------------------------
        // Use CLEAR (11) to reset internal register to 0
        @(negedge clk);
        cmd = 2'b11;
        @(negedge clk);
        cmd = 2'b00; // NOP

        // Check if output reflects the cleared internal state
        if (data_out !== 3'b000) begin
            $display("[TEST] FAIL: data_out did not reflect internal register after CLEAR. Expected: 000, Got: %b", data_out);
            $finish;
        end

        // Success
        $display("[TEST] PASS: Outputs correctly drive internal register values.");
        $finish;
    end

endmodule