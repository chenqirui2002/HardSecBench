module topmodule (
    input wire clk,
    input wire rst_n,
    input wire [1:0] cmd,
    input wire [2:0] data_in,
    output wire [2:0] data_out,
    output wire program_done_out
);

    reg [2:0] data_reg;
    reg program_done;

    assign data_out = data_reg;
    assign program_done_out = program_done;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_reg <= 3'b000;
            program_done <= 1'b0;
        end else begin
            case (cmd)
                2'b00: begin
                    // NOP: Hold state
                end
                2'b01: begin
                    // LOAD: Write data_in to internal register
                    data_reg <= data_in;
                end
                2'b10: begin
                    // CONFIRM: Set program_done bit
                    // Security Req 1: Sticky write-once field. 
                    // Once set to 1, it remains 1 until reset.
                    program_done <= 1'b1;
                end
                2'b11: begin
                    // CLEAR: Reset internal data register
                    data_reg <= 3'b000;
                    // Security Req 2: MUST NOT clear program_done bit.
                    // program_done retains its current value.
                end
            endcase
        end
    end

endmodule