module tb_functional_req2;
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] data_in;
    
    wire [7:0] data_out;
    wire locked;
    wire write_ack;
    wire ready;

    // Instantiate the Unit Under Test (UUT)
    // Note: 'locked' is mapped to the requirement's 'config_set' signal 
    // based on the interface description "Active-high status indicating register is written".
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .locked(locked),
        .write_ack(write_ack),
        .ready(ready)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test sequence
    initial begin
        // Initialize inputs
        rst_n = 0;
        write_en = 0;
        data_in = 8'h00;

        // Apply Reset
        #20;
        
        // 1. Verify Initial State (Reset active)
        // REQ-0 requires outputs cleared to 0 on reset
        // REQ-2 implies config_set (locked) is low if not written
        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: locked (config_set) should be 0 during reset");
            $finish;
        end

        // Release reset
        @(negedge clk);
        rst_n = 1;
        #1;
        
        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: locked (config_set) should be 0 after reset release before write");
            $finish;
        end

        // 2. Perform Write Operation
        // REQ-1: Load data on rising edge if write_en is high and locked is low
        @(negedge clk);
        write_en = 1;
        data_in = 8'hAA;
        
        @(negedge clk); // Wait for the rising edge to occur
        write_en = 0;
        
        // 3. Verify config_set (locked) assertion
        // REQ-2: Output shall be asserted high to indicate register written to at least once
        #1; 
        if (locked !== 1'b1) begin
            $display("[TEST] FAIL: locked (config_set) did not assert high after write operation");
            $finish;
        end

        // 4. Verify Persistence
        // "Written to at least once" implies it stays high
        @(negedge clk);
        if (locked !== 1'b1) begin
            $display("[TEST] FAIL: locked (config_set) dropped low unexpectedly");
            $finish;
        end

        // 5. Verify Synchronous Reset Clears the signal
        rst_n = 0;
        // Wait for rising edge for synchronous reset to take effect
        @(posedge clk);
        #1;
        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: locked (config_set) did not clear after synchronous reset");
            $finish;
        end

        $display("[TEST] PASS: config_set (locked) behavior verified");
        $finish;
    end

endmodule