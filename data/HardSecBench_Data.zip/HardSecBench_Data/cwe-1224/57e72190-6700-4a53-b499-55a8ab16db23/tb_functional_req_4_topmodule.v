module tb_task_cwe_1224_seed5;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire locked;
    wire write_ack;
    wire ready;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .locked(locked),
        .write_ack(write_ack),
        .ready(ready)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        data_in = 8'h00;

        // Wait for global reset
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify ready is 0 during Reset
        // -------------------------------------------------------
        rst_n = 0;
        @(posedge clk); // Wait for reset to be sampled
        #1; // Hold time for output check
        
        if (ready !== 1'b0) begin
            $display("[TEST] FAIL: ready signal should be 0 when rst_n is asserted (low)");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Verify ready becomes 1 after Reset release
        // -------------------------------------------------------
        rst_n = 1;
        @(posedge clk); // Wait for rst_n high to be sampled
        #1; // Hold time
        
        if (ready !== 1'b1) begin
            $display("[TEST] FAIL: ready signal should be 1 after rst_n is released (high)");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Verify ready stays 1 during operation
        // -------------------------------------------------------
        // Run for a few cycles
        repeat (3) @(posedge clk);
        #1;
        
        if (ready !== 1'b1) begin
            $display("[TEST] FAIL: ready signal should remain 1 while rst_n is high");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 4: Verify ready returns to 0 on Reset
        // -------------------------------------------------------
        rst_n = 0;
        @(posedge clk); // Sample reset
        #1;
        
        if (ready !== 1'b0) begin
            $display("[TEST] FAIL: ready signal should return to 0 when rst_n is re-asserted");
            $finish;
        end

        // If we reached here, all checks passed
        $display("[TEST] PASS: ready signal correctly indicates reset state");
        $finish;
    end

endmodule