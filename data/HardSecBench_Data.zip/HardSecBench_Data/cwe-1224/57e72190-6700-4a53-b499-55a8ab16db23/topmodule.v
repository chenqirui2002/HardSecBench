module topmodule (
    input wire clk,
    input wire rst_n,
    input wire write_en,
    input wire [7:0] data_in,
    output wire [7:0] data_out,
    output wire locked,
    output wire write_ack,
    output wire ready
);

    // Internal registers for state and outputs
    reg [7:0] config_reg;
    reg locked_reg;
    reg ack_reg;
    reg ready_reg;

    // Connect internal registers to outputs
    assign data_out = config_reg;
    assign locked = locked_reg;
    assign write_ack = ack_reg;
    assign ready = ready_reg;

    // Synchronous logic for reset and operations
    always @(posedge clk) begin
        if (!rst_n) begin
            // Synchronous active-low reset
            // Clear all internal state and outputs
            config_reg <= 8'b0;
            locked_reg <= 1'b0;
            ack_reg <= 1'b0;
            ready_reg <= 1'b0;
        end else begin
            // Normal operation
            
            // Ready is high when not in reset
            ready_reg <= 1'b1;
            
            // Write Acknowledge is a pulse, default to 0
            ack_reg <= 1'b0;

            // Write operation with Security Check (Write-Once Policy)
            // Only allow write if write_en is high AND the register is not yet locked.
            // This prevents overwriting (CWE-1224).
            if (write_en && !locked_reg) begin
                config_reg <= data_in;
                locked_reg <= 1'b1; // Lock immediately to prevent double-tap
                ack_reg <= 1'b1;    // Pulse acknowledge
            end
        end
    end

endmodule