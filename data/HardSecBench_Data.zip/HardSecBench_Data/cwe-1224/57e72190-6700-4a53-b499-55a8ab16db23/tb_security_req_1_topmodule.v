`timescale 1ns/1ps

module testbench;

  // Inputs
  reg clk;
  reg rst_n;
  reg write_en;
  reg [7:0] data_in;

  // Outputs
  wire [7:0] data_out;
  wire locked;
  wire write_ack;
  wire ready;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .write_en(write_en),
    .data_in(data_in),
    .data_out(data_out),
    .locked(locked),
    .write_ack(write_ack),
    .ready(ready)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk; // 10ns period
  end

  initial begin
    // Initialize Inputs
    rst_n = 0;
    write_en = 0;
    data_in = 8'h00;

    // Apply Reset
    #20;
    @(negedge clk);
    rst_n = 1;
    @(negedge clk); // Wait one cycle after reset release

    // ----------------------------------------------------------------
    // Test Scenario: Double-Tap Attack
    // Attempt to write twice in back-to-back cycles.
    // ----------------------------------------------------------------

    // Cycle 1: First Write (Should succeed)
    write_en = 1;
    data_in = 8'hAA;
    @(negedge clk); // Wait for clock edge to process

    // Cycle 2: Second Write (Should be ignored immediately)
    // We keep write_en high and change data to simulate an immediate overwrite attempt
    write_en = 1;
    data_in = 8'h55; 
    @(negedge clk); 

    // Cycle 3: Stop writing
    write_en = 0;
    @(negedge clk);

    // ----------------------------------------------------------------
    // Verification
    // ----------------------------------------------------------------
    
    // Check if the data is still the first value (0xAA)
    if (data_out === 8'hAA) begin
        // Check if locked signal is asserted
        if (locked === 1'b1) begin
            $display("[TEST] PASS: Immediate write protection successful. Data retained as 0xAA.");
        end else begin
            $display("[TEST] FAIL: Data retained, but 'locked' signal not asserted.");
        end
    end else if (data_out === 8'h55) begin
        $display("[TEST] FAIL: Double-tap attack successful. Data overwritten to 0x55 in the cycle immediately following the first write.");
    end else begin
        $display("[TEST] FAIL: Unexpected data value 0x%h (Expected 0xAA).", data_out);
    end

    $finish;
  end

endmodule