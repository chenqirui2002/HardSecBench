`timescale 1ns/1ps

module tb_module_task_cwe_1224_seed5;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire locked;
    wire write_ack;
    wire ready;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .locked(locked),
        .write_ack(write_ack),
        .ready(ready)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        data_in = 8'h00;

        // Apply Reset
        #20;
        @(negedge clk);
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Step 1: Perform Initial Write (Valid)
        // -------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        data_in = 8'hAA; // Initial configuration
        @(negedge clk);
        write_en = 0;
        
        // Wait for update
        @(negedge clk);

        // Check if initial write succeeded
        if (data_out !== 8'hAA) begin
            $display("[TEST] FAIL: Initial write failed. Expected 0xAA, got 0x%h", data_out);
            $finish;
        end
        
        // -------------------------------------------------------
        // Step 2: Attempt Second Write (Should be Ignored)
        // -------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        data_in = 8'h55; // Malicious overwrite attempt
        @(negedge clk);
        write_en = 0;

        // Wait for potential update
        @(negedge clk);

        // Check if data changed
        if (data_out === 8'h55) begin
            $display("[TEST] FAIL: Write-Once policy violated. Register overwritten by second write.");
            $finish;
        end else if (data_out !== 8'hAA) begin
            $display("[TEST] FAIL: Data corrupted after second write attempt. Got 0x%h", data_out);
            $finish;
        end

        // -------------------------------------------------------
        // Step 3: Attempt Third Write (Should be Ignored)
        // -------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        data_in = 8'hFF; // Another overwrite attempt
        @(negedge clk);
        write_en = 0;

        // Wait for potential update
        @(negedge clk);

        // Final Verification
        if (data_out === 8'hAA) begin
            $display("[TEST] PASS: Write-Once policy enforced. Data remained 0xAA despite subsequent writes.");
        end else begin
            $display("[TEST] FAIL: Data changed after third write attempt. Got 0x%h", data_out);
        end

        $finish;
    end

endmodule