module tb_functional_req_0;
    // Signal Declarations
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] data_in;
    
    wire [7:0] data_out;
    wire locked;
    wire write_ack;
    wire ready;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .locked(locked),
        .write_ack(write_ack),
        .ready(ready)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize inputs
        rst_n = 1;
        write_en = 0;
        data_in = 8'h00;

        // Wait for stabilization
        #10;

        // -------------------------------------------------------
        // Test Case: Synchronous Reset Assertion
        // -------------------------------------------------------
        
        // Assert active-low reset
        rst_n = 0;
        
        // Drive inputs to non-zero values to ensure reset takes precedence
        // and clears outputs regardless of input state.
        write_en = 1;
        data_in = 8'hFF;

        // Wait for the rising edge of the clock (Synchronous check)
        @(posedge clk);
        
        // Wait for propagation delay
        #1;

        // Check if all outputs are cleared to 0 as per REQ-0
        if (data_out !== 8'h00) begin
            $display("[TEST] FAIL: data_out not cleared to 0 on reset. Got: %h", data_out);
            $finish;
        end
        
        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: locked not cleared to 0 on reset. Got: %b", locked);
            $finish;
        end

        if (write_ack !== 1'b0) begin
            $display("[TEST] FAIL: write_ack not cleared to 0 on reset. Got: %b", write_ack);
            $finish;
        end

        if (ready !== 1'b0) begin
            $display("[TEST] FAIL: ready not cleared to 0 on reset. Got: %b", ready);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case: Reset Hold Verification
        // -------------------------------------------------------
        // Ensure outputs remain 0 if reset continues to be held
        @(posedge clk);
        #1;

        if (data_out !== 8'h00 || locked !== 1'b0 || write_ack !== 1'b0 || ready !== 1'b0) begin
            $display("[TEST] FAIL: Outputs did not remain 0 while reset held low.");
            $finish;
        end

        // If we reached here, the requirement is satisfied
        $display("[TEST] PASS: All outputs synchronously cleared to 0.");
        $finish;
    end

endmodule