`timescale 1ns/1ps

module tb_module_task_cwe_1224_seed5;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire locked;
    wire write_ack;
    wire ready;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .locked(locked),
        .write_ack(write_ack),
        .ready(ready)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        data_in = 0;

        // Wait for global reset
        #100;
        
        // -------------------------------------------------------
        // Test Case 1: Verify write operation with pattern 0xAA
        // -------------------------------------------------------
        
        // Apply synchronous reset
        rst_n = 0;
        @(posedge clk); // Sample reset low
        rst_n = 1;
        @(posedge clk); // Allow one cycle for reset release and state stabilization

        // Pre-condition Check: Locked must be low for the write requirement to apply
        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: Pre-condition failed. 'locked' signal is high after reset, cannot test write.");
            $finish;
        end

        // Action: Assert write_en with specific data
        data_in = 8'hAA;
        write_en = 1;
        @(posedge clk); // Trigger write on rising edge
        
        // Deassert write_en and check result
        #1;
        write_en = 0;

        // Verification: Check if data_out reflects data_in
        if (data_out === 8'hAA) begin
            $display("[TEST] PASS: Data 0xAA loaded successfully when locked was low.");
        end else begin
            $display("[TEST] FAIL: Expected 0xAA, got 0x%h", data_out);
        end

        // -------------------------------------------------------
        // Test Case 2: Verify write operation with pattern 0x55
        // -------------------------------------------------------
        
        // Reset again to ensure we are in a clean state (locked=0)
        @(posedge clk);
        rst_n = 0;
        @(posedge clk);
        rst_n = 1;
        @(posedge clk);

        if (locked !== 1'b0) begin
            $display("[TEST] FAIL: Pre-condition failed on second reset.");
            $finish;
        end

        // Action: Write different pattern
        data_in = 8'h55;
        write_en = 1;
        @(posedge clk);
        
        #1;
        write_en = 0;

        // Verification
        if (data_out === 8'h55) begin
            $display("[TEST] PASS: Data 0x55 loaded successfully when locked was low.");
        end else begin
            $display("[TEST] FAIL: Expected 0x55, got 0x%h", data_out);
        end

        $finish;
    end

endmodule