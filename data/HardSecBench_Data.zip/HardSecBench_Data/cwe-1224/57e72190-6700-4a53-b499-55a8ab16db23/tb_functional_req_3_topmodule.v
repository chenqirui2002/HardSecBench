module tb_functional_req_3;
    reg clk;
    reg rst_n;
    reg write_en;
    reg [7:0] data_in;
    
    // Outputs
    wire [7:0] data_out;
    wire locked;
    wire write_ack;
    wire ready;

    // Instantiate the DUT
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .locked(locked),
        .write_ack(write_ack),
        .ready(ready)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        data_in = 8'h00;

        // 1. Apply Reset and verify write_ack is low
        repeat (2) @(posedge clk);
        #1; // Sample shortly after edge
        if (write_ack !== 1'b0) begin
            $display("[TEST] FAIL: write_ack should be 0 during reset.");
            $finish;
        end

        // 2. Release Reset
        rst_n = 1;
        @(posedge clk); // Wait one cycle for reset release to propagate
        #1;

        // Verify module is not locked (pre-condition for successful write)
        if (locked === 1'b1) begin
            $display("[TEST] FAIL: Module is locked immediately after reset; cannot perform write test.");
            $finish;
        end

        // 3. Perform Write Operation
        write_en = 1;
        data_in = 8'hA5;
        
        // Wait for the clock edge where write is sampled
        @(posedge clk);
        
        // 4. Verify write_ack asserts (Pulse Start)
        #1; // Check output after propagation delay
        if (write_ack !== 1'b1) begin
            $display("[TEST] FAIL: write_ack did not assert high after write operation.");
            $finish;
        end

        // De-assert write_en to ensure we are testing the pulse duration
        write_en = 0;

        // 5. Wait one clock cycle (Pulse Duration)
        @(posedge clk);

        // 6. Verify write_ack de-asserts (Pulse End)
        #1;
        if (write_ack !== 1'b0) begin
            $display("[TEST] FAIL: write_ack did not de-assert after one clock cycle.");
            $finish;
        end

        $display("[TEST] PASS: write_ack pulsed high for one cycle upon successful write.");
        $finish;
    end

endmodule