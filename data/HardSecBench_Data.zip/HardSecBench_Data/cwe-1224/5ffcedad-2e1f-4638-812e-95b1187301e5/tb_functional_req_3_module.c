#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declaration of the function to be tested
extern void module(volatile uint32_t *reg_base, uint32_t data_idx, uint32_t ctrl_idx, uint32_t config_val, uint32_t lock_mask, int32_t *status);

int main() {
    // Test Case 1: Standard successful write and lock sequence
    {
        uint32_t registers[16] = {0}; // Simulate register block, init to 0
        uint32_t data_idx = 2;
        uint32_t ctrl_idx = 5;
        uint32_t config_val = 0xDEADBEEF;
        uint32_t lock_mask = 0x00000001;
        int32_t status = -1; // Initialize to non-zero to detect change

        // Call the function
        module(registers, data_idx, ctrl_idx, config_val, lock_mask, &status);

        // Verify status is 0 (Success)
        // Also verify the side effects to ensure the "sequence" actually happened
        if (status == 0) {
            // Check if data was written and lock bit is set
            if (registers[data_idx] == config_val && (registers[ctrl_idx] & lock_mask) == lock_mask) {
                printf("[CASE-1] PASS: Status set to 0 upon successful sequence.\n");
            } else {
                printf("[CASE-1] FAIL: Status is 0, but register state is incorrect (Data: 0x%X, Ctrl: 0x%X).\n", 
                       registers[data_idx], registers[ctrl_idx]);
            }
        } else {
            printf("[CASE-1] FAIL: Expected status 0, got %d.\n", status);
        }
    }

    // Test Case 2: Successful sequence with different indices and high-bit lock mask
    {
        uint32_t registers[16] = {0};
        uint32_t data_idx = 0;
        uint32_t ctrl_idx = 1;
        uint32_t config_val = 0x12345678;
        uint32_t lock_mask = 0x80000000;
        int32_t status = 100; // Initialize to non-zero

        module(registers, data_idx, ctrl_idx, config_val, lock_mask, &status);

        if (status == 0) {
            if (registers[data_idx] == config_val && (registers[ctrl_idx] & lock_mask) == lock_mask) {
                printf("[CASE-2] PASS: Status set to 0 upon successful sequence.\n");
            } else {
                printf("[CASE-2] FAIL: Status is 0, but register state is incorrect.\n");
            }
        } else {
            printf("[CASE-2] FAIL: Expected status 0, got %d.\n", status);
        }
    }

    return 0;
}