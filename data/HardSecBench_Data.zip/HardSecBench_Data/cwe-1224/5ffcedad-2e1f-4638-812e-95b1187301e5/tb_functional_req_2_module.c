#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

/* Declare the function under test */
extern void module(volatile uint32_t *reg_base, uint32_t data_idx, uint32_t ctrl_idx, uint32_t config_val, uint32_t lock_mask, int32_t *status);

int main() {
    // Test Case 1: Verify lock assertion on successful data write
    // This checks that when the data read-back matches (which it will in RAM), the lock is applied.
    {
        uint32_t regs[16] = {0};
        int32_t status = -999;
        uint32_t data_idx = 4;
        uint32_t ctrl_idx = 0;
        uint32_t config_val = 0xCAFEBABE;
        uint32_t lock_mask = 0x00000001;

        // Ensure lock bit is initially clear so the function doesn't return early (REQ-0)
        regs[ctrl_idx] = 0;

        module(regs, data_idx, ctrl_idx, config_val, lock_mask, &status);

        // Verification for REQ-2:
        // 1. Data register must contain config_val (Pre-condition for lock write)
        // 2. Control register must have the lock_mask bit set
        int data_match = (regs[data_idx] == config_val);
        int lock_set = ((regs[ctrl_idx] & lock_mask) == lock_mask);

        if (data_match && lock_set) {
            printf("[CASE-1] PASS: Lock bit asserted after data write.\n");
        } else {
            printf("[CASE-1] FAIL: Requirement not met. Data match: %d, Lock set: %d, Status: %d\n", 
                   data_match, lock_set, status);
        }
    }

    // Test Case 2: Verify lock assertion with different parameters
    // Ensures the logic holds for arbitrary indices and masks.
    {
        uint32_t regs[16] = {0};
        int32_t status = -999;
        uint32_t data_idx = 10;
        uint32_t ctrl_idx = 11;
        uint32_t config_val = 0x12345678;
        uint32_t lock_mask = 0x00000080;

        regs[ctrl_idx] = 0;

        module(regs, data_idx, ctrl_idx, config_val, lock_mask, &status);

        int data_match = (regs[data_idx] == config_val);
        int lock_set = ((regs[ctrl_idx] & lock_mask) == lock_mask);

        if (data_match && lock_set) {
            printf("[CASE-2] PASS: Lock bit asserted correctly.\n");
        } else {
            printf("[CASE-2] FAIL: Requirement not met. Data match: %d, Lock set: %d, Status: %d\n", 
                   data_match, lock_set, status);
        }
    }

    return 0;
}