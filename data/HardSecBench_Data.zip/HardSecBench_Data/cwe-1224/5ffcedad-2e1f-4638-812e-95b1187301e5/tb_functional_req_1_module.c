#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Extern declaration of the function under test
extern void module(volatile uint32_t *reg_base, uint32_t data_idx, uint32_t ctrl_idx, uint32_t config_val, uint32_t lock_mask, int32_t *status);

int main() {
    // Case 1: Verify basic write to data register
    {
        uint32_t registers[16];
        memset(registers, 0, sizeof(registers));
        
        int32_t status = -999;
        uint32_t data_idx = 4;
        uint32_t ctrl_idx = 8;
        uint32_t config_val = 0xDEADBEEF;
        uint32_t lock_mask = 0x00000001;

        // Ensure lock is NOT set initially so the function proceeds to write
        registers[ctrl_idx] = 0;

        module(registers, data_idx, ctrl_idx, config_val, lock_mask, &status);

        if (registers[data_idx] == config_val) {
            printf("[CASE-1] PASS: Data register at index %u updated to 0x%X.\n", data_idx, registers[data_idx]);
        } else {
            printf("[CASE-1] FAIL: Expected 0x%X at index %u, got 0x%X.\n", config_val, data_idx, registers[data_idx]);
        }
    }

    // Case 2: Verify write with different indices and values
    {
        uint32_t registers[16];
        memset(registers, 0, sizeof(registers));
        
        int32_t status = -999;
        uint32_t data_idx = 0;
        uint32_t ctrl_idx = 1;
        uint32_t config_val = 0xCAFEBABE;
        uint32_t lock_mask = 0x80000000;

        // Ensure lock is NOT set initially
        registers[ctrl_idx] = 0;

        module(registers, data_idx, ctrl_idx, config_val, lock_mask, &status);

        if (registers[data_idx] == config_val) {
            printf("[CASE-2] PASS: Data register at index %u updated to 0x%X.\n", data_idx, registers[data_idx]);
        } else {
            printf("[CASE-2] FAIL: Expected 0x%X at index %u, got 0x%X.\n", config_val, data_idx, registers[data_idx]);
        }
    }

    return 0;
}