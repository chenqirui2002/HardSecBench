#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Declaration of the function under test
extern void module(volatile uint32_t *reg_base, uint32_t data_idx, uint32_t ctrl_idx, uint32_t config_val, uint32_t lock_mask, int32_t *status);

int main() {
    // Test Case 1: Lock bit is already set (Bit 4)
    // Verifies that status becomes 1 and the function returns without writing to data_idx
    {
        uint32_t regs[16] = {0};
        uint32_t data_idx = 2;
        uint32_t ctrl_idx = 5;
        uint32_t config_val = 0xAAAA5555;
        uint32_t lock_mask = 0x10; // Bit 4
        int32_t status = 0;

        // Pre-condition: Set the lock bit in the control register
        regs[ctrl_idx] = 0x10; 
        // Pre-condition: Set data register to an initial value
        regs[data_idx] = 0xFFFFFFFF;

        module((volatile uint32_t *)regs, data_idx, ctrl_idx, config_val, lock_mask, &status);

        if (status == 1) {
            // Check if returned immediately (data register should NOT be config_val)
            if (regs[data_idx] == 0xFFFFFFFF) {
                printf("[CASE-1] PASS: Status set to 1 and data register preserved (lock active).\n");
            } else {
                printf("[CASE-1] FAIL: Status is 1, but data register was overwritten (did not return immediately).\n");
            }
        } else {
            printf("[CASE-1] FAIL: Expected status 1 when lock is set, got %d.\n", status);
        }
    }

    // Test Case 2: Lock bit is set (Bit 0) amidst other bits
    // Verifies correct masking and immediate return behavior
    {
        uint32_t regs[16] = {0};
        uint32_t data_idx = 10;
        uint32_t ctrl_idx = 11;
        uint32_t config_val = 0x12345678;
        uint32_t lock_mask = 0x01; // Bit 0
        int32_t status = -1; // Initialize to non-zero

        // Pre-condition: Control register has all bits set (including bit 0)
        regs[ctrl_idx] = 0xFFFFFFFF;
        // Pre-condition: Data register is 0
        regs[data_idx] = 0x0;

        module((volatile uint32_t *)regs, data_idx, ctrl_idx, config_val, lock_mask, &status);

        if (status == 1) {
            // Check if returned immediately
            if (regs[data_idx] == 0x0) {
                printf("[CASE-2] PASS: Status set to 1 and data register preserved with noisy control reg.\n");
            } else {
                printf("[CASE-2] FAIL: Status is 1, but data register was overwritten.\n");
            }
        } else {
            printf("[CASE-2] FAIL: Expected status 1 when lock is set, got %d.\n", status);
        }
    }

    return 0;
}