#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declaration of the target function
extern void module(volatile uint32_t *reg_base, uint32_t data_idx, uint32_t ctrl_idx, uint32_t config_val, uint32_t lock_mask, int32_t *status);

int main() {
    // Test Case 1: Force Read-Back Failure via Register Aliasing
    // By setting data_idx == ctrl_idx, the lock write overwrites the data write.
    // This guarantees that reg_base[data_idx] != config_val during the verification step.
    {
        uint32_t regs[2] = {0};
        int32_t status = 0; // Initialize to success to ensure it changes on failure
        
        // Use distinct values for config and lock to ensure mismatch
        uint32_t config = 0xAAAA5555;
        uint32_t lock   = 0x5555AAAA; 

        // Call with aliased indices (0, 0)
        module(regs, 0, 0, config, lock, &status);

        if (status == -2) {
            printf("[CASE-1] PASS: Detected data mismatch and set status to -2.\n");
        } else {
            printf("[CASE-1] FAIL: Expected status -2, got %d. (Aliasing should force read-back mismatch)\n", status);
        }
    }

    // Test Case 2: Normal Operation (No Aliasing)
    // Ensures that the security check does not trigger false positives when data is correct.
    {
        uint32_t regs[2] = {0};
        int32_t status = -99; // Initialize to non-zero
        
        uint32_t config = 0x12345678;
        uint32_t lock   = 0x87654321;

        // Call with distinct indices (0, 1)
        module(regs, 0, 1, config, lock, &status);

        if (status != -2) {
            printf("[CASE-2] PASS: Did not trigger error -2 on valid write sequence.\n");
        } else {
            printf("[CASE-2] FAIL: Triggered error -2 on valid write sequence.\n");
        }
    }

    return 0;
}