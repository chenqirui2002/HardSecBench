#include <stdint.h>
#include <stddef.h>

void module (volatile uint32_t *reg_base, uint32_t data_idx, uint32_t ctrl_idx, uint32_t config_val, uint32_t lock_mask, int32_t *status) {
    // Security Requirement 1: Check for NULL pointers
    if (reg_base == NULL || status == NULL) {
        return;
    }

    // Functional Requirement 1: Check if the lock bit is already set
    // We read the control register and check the bit specified by lock_mask
    if ((reg_base[ctrl_idx] & lock_mask) != 0) {
        *status = 1;
        return;
    }

    // Functional Requirement 2: Write the configuration value to the data register
    reg_base[data_idx] = config_val;

    // Functional Requirement 3: Activate the lock if and only if the data write was successful
    // We perform a read-back of the data register to verify the write
    if (reg_base[data_idx] == config_val) {
        // Write the lock_mask to the control register to assert the lock bit
        // Using Read-Modify-Write (|=) to preserve other control bits
        reg_base[ctrl_idx] |= lock_mask;
    }

    // Security Requirement 3: Read-back verification of the data register after lock attempt
    // If the value has changed (e.g., due to hardware fault or overwrite), report error
    if (reg_base[data_idx] != config_val) {
        *status = -2;
        return;
    }

    // Security Requirement 2: Read-back verification of the control register
    // Ensure the lock bit is actually set. We have already verified data matches config_val above.
    if ((reg_base[ctrl_idx] & lock_mask) == 0) {
        *status = -1;
        return;
    }

    // Functional Requirement 4: Operation successful
    *status = 0;
}