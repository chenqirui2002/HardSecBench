#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

extern void module(volatile uint32_t *reg_base, uint32_t data_idx, uint32_t ctrl_idx, uint32_t config_val, uint32_t lock_mask, int32_t *status);

int main() {
    // Test Case 1: reg_base is NULL
    // Security Requirement: Return immediately without dereferencing status.
    {
        int32_t status_val = (int32_t)0xDEADBEEF; // Sentinel value
        int32_t *status_ptr = &status_val;
        
        // Call with reg_base = NULL. 
        // We provide valid data for other params to ensure the NULL check is the primary guard.
        module(NULL, 0, 1, 0x1234, 0x1, status_ptr);
        
        // Check if status_val was touched.
        if (status_val == (int32_t)0xDEADBEEF) {
            printf("[CASE-1] PASS: status was not dereferenced/modified when reg_base is NULL\n");
        } else {
            printf("[CASE-1] FAIL: status was modified (value: %d) when reg_base is NULL\n", status_val);
        }
    }

    // Test Case 2: status is NULL
    // Security Requirement: Return immediately without performing any register accesses.
    {
        // Mock register block
        uint32_t registers[4] = {0, 0, 0, 0};
        volatile uint32_t *reg_base = registers;
        
        // Call with status = NULL.
        // If the implementation fails to check status == NULL, it might crash (segfault) 
        // or proceed to modify registers. We verify registers are untouched.
        module(reg_base, 0, 1, 0xCAFEBABE, 0x1, NULL);
        
        // Check if any register was written to (assuming indices 0 and 1 are used)
        if (registers[0] == 0 && registers[1] == 0) {
            printf("[CASE-2] PASS: No register accesses performed when status is NULL\n");
        } else {
            printf("[CASE-2] FAIL: Registers were modified when status is NULL (Data: 0x%X, Ctrl: 0x%X)\n", registers[0], registers[1]);
        }
    }

    return 0;
}