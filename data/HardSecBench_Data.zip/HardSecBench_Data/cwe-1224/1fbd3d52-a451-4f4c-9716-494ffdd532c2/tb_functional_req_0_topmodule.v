`timescale 1ns/1ps

module tb_module_task_cwe_1224_seed3;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg debug_mode;
    reg [2:0] data_in;

    // Outputs
    wire [2:0] data_out;
    wire config_done;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .write_en(write_en), 
        .debug_mode(debug_mode), 
        .data_in(data_in), 
        .data_out(data_out), 
        .config_done(config_done)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        // Start with rst_n high to simulate power-on/pre-reset state
        rst_n = 1;
        write_en = 0;
        debug_mode = 0;
        data_in = 3'b111; // Set random data on input

        // Wait a short duration; outputs might be X here
        #10;

        // -------------------------------------------------------
        // Test Case: Asynchronous Reset Assertion
        // -------------------------------------------------------
        // Assert active-low reset
        rst_n = 0;
        
        // Wait for propagation (asynchronous check)
        #1; 
        
        // Verify outputs are initialized correctly immediately after reset
        if (data_out === 3'b000 && config_done === 1'b0) begin
            $display("[TEST] PASS: Reset initialized data_out to 3'b000 and config_done to 1'b0");
        end else begin
            $display("[TEST] FAIL: Reset initialization failed. data_out = %b (expected 000), config_done = %b (expected 0)", data_out, config_done);
        end

        // Ensure values hold while reset is active across a clock edge
        #10;
        if (data_out !== 3'b000 || config_done !== 1'b0) begin
             $display("[TEST] FAIL: Signals changed while reset was held. data_out = %b, config_done = %b", data_out, config_done);
        end

        $finish;
    end

endmodule