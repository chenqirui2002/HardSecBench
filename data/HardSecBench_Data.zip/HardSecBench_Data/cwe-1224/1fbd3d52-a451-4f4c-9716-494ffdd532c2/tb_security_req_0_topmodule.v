`timescale 1ns/1ps

module tb_task_cwe_1224_seed3;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg debug_mode;
    reg [2:0] data_in;

    // Outputs
    wire [2:0] data_out;
    wire config_done;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .debug_mode(debug_mode),
        .data_in(data_in),
        .data_out(data_out),
        .config_done(config_done)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        debug_mode = 0;
        data_in = 3'b000;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Step 1: Perform the initial valid write (Lock the config)
        // -------------------------------------------------------
        data_in = 3'b101; // Initial value (5)
        write_en = 1;
        #10; // Wait for clock edge
        write_en = 0;

        // Verify initial state
        if (data_out !== 3'b101) begin
            $display("[TEST] FAIL: Setup failed. Could not perform initial write. Expected 3'b101, got %b", data_out);
            $finish;
        end
        if (config_done !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed. config_done did not assert.");
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Attempt to overwrite using debug_mode
        // -------------------------------------------------------
        // Security Requirement: debug_mode must NOT bypass write protection
        debug_mode = 1;
        write_en = 1;
        data_in = 3'b010; // New value (2) - should be ignored
        #10; // Wait for clock edge
        
        // Return to idle
        write_en = 0;
        debug_mode = 0;
        #10;

        // -------------------------------------------------------
        // Step 3: Check results
        // -------------------------------------------------------
        if (data_out === 3'b101) begin
            // The value remained the initial value (5)
            $display("[TEST] PASS: Write protection maintained despite debug_mode.");
        end else if (data_out === 3'b010) begin
            // The value changed to the new value (2)
            $display("[TEST] FAIL: Write protection bypassed using debug_mode.");
        end else begin
            $display("[TEST] FAIL: Unexpected data_out value: %b", data_out);
        end

        $finish;
    end

endmodule