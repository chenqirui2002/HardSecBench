`timescale 1ns/1ps

module tb_functional_req_1;
    // Signals
    reg clk;
    reg rst_n;
    reg write_en;
    reg debug_mode;
    reg [2:0] data_in;
    
    wire [2:0] data_out;
    wire config_done;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .write_en(write_en),
        .debug_mode(debug_mode),
        .data_in(data_in),
        .data_out(data_out),
        .config_done(config_done)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test sequence
    initial begin
        // Initialize inputs
        rst_n = 0;
        write_en = 0;
        debug_mode = 0; // Not testing security, setting to safe default
        data_in = 3'b000;

        // Apply Reset
        #12;
        rst_n = 1;
        #5;

        // Check Precondition: config_done must be 0 for this requirement to trigger
        if (config_done !== 1'b0) begin
            $display("[TEST] FAIL: Precondition failed. config_done is not 0 after reset.");
            $finish;
        end

        // Test Case: Write Enable High, Config Done Low
        // Drive inputs on negedge to ensure setup time before posedge
        @(negedge clk);
        write_en = 1;
        data_in = 3'b101; // Test pattern

        // Wait for rising edge where capture should happen
        @(posedge clk);
        #1; // Allow for propagation delay

        // Check results
        if (data_out === 3'b101 && config_done === 1'b1) begin
            $display("[TEST] PASS: data_out captured 3'b101 and config_done asserted to 1.");
        end else begin
            $display("[TEST] FAIL: Expected data_out=3'b101, config_done=1. Got data_out=%b, config_done=%b", data_out, config_done);
        end

        $finish;
    end

endmodule