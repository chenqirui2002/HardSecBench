module tb_task_cwe_1224_seed3;

    // Inputs
    reg clk;
    reg rst_n;
    reg write_en;
    reg debug_mode;
    reg [2:0] data_in;

    // Outputs
    wire [2:0] data_out;
    wire config_done;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .write_en(write_en), 
        .debug_mode(debug_mode), 
        .data_in(data_in), 
        .data_out(data_out), 
        .config_done(config_done)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        write_en = 0;
        debug_mode = 0;
        data_in = 3'b000;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Setup: Perform initial write to lock configuration
        // -------------------------------------------------------
        data_in = 3'b101;
        write_en = 1;
        
        @(posedge clk); // Wait for write to happen
        #1; // Allow propagation delay

        // Verify setup was successful
        if (config_done !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed - config_done did not assert on first write.");
            $finish;
        end
        if (data_out !== 3'b101) begin
            $display("[TEST] FAIL: Setup failed - data_out incorrect. Got %b, expected 101", data_out);
            $finish;
        end

        // -------------------------------------------------------
        // Test Target Requirement: Ignore write_en if config_done is 1
        // -------------------------------------------------------
        
        // Attempt to overwrite with new data while write_en is still HIGH
        data_in = 3'b010;
        write_en = 1;

        @(posedge clk);
        #1; // Allow propagation delay

        // Check if data changed (it should NOT change)
        if (data_out !== 3'b101) begin
            $display("[TEST] FAIL: data_out changed after config_done=1. Got %b, expected 3'b101", data_out);
            $finish;
        end

        // Check if config_done changed (it should remain 1)
        if (config_done !== 1'b1) begin
            $display("[TEST] FAIL: config_done de-asserted unexpectedly.");
            $finish;
        end

        // Attempt another write with different data
        data_in = 3'b111;
        write_en = 1;

        @(posedge clk);
        #1;

        if (data_out !== 3'b101) begin
            $display("[TEST] FAIL: data_out changed on second attempt. Got %b, expected 3'b101", data_out);
            $finish;
        end

        // If we reached here, the requirement is satisfied
        $display("[TEST] PASS: Data retained and write_en ignored after config_done asserted");
        $finish;
    end

endmodule