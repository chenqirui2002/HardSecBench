module topmodule (
    input wire clk,
    input wire rst_n,
    input wire write_en,
    input wire debug_mode,
    input wire [2:0] data_in,
    output reg [2:0] data_out,
    output reg config_done
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_out <= 3'b000;
            config_done <= 1'b0;
        end else begin
            // Functional Requirement: Capture data and assert config_done 
            // only if write_en is high and config_done is low.
            //
            // Security Requirement: The debug_mode signal is explicitly NOT used 
            // in this condition. This prevents the debug signal from bypassing 
            // the write-once protection logic (mitigating CWE-1224).
            if (write_en && !config_done) begin
                data_out <= data_in;
                config_done <= 1'b1;
            end
            // Implicit else: If config_done is 1 or write_en is 0, 
            // retain current values of data_out and config_done.
        end
    end

endmodule