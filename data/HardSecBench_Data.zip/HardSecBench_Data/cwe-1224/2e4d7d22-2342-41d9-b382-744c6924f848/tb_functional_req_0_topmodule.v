module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg soft_reset;
    reg write_en;
    reg lock_req;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire locked;
    wire [3:0] write_count;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .soft_reset(soft_reset), 
        .write_en(write_en), 
        .lock_req(lock_req), 
        .data_in(data_in), 
        .data_out(data_out), 
        .locked(locked), 
        .write_count(write_count)
    );

    // Clock generation
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        rst_n = 1;
        soft_reset = 0;
        write_en = 0;
        lock_req = 0;
        data_in = 8'h00;

        // Wait for global stabilization
        #10;

        // -------------------------------------------------------
        // Test Case 1: Initialization upon Reset
        // -------------------------------------------------------
        $display("Test 1: Checking initialization values upon reset...");
        
        // Assert asynchronous reset
        rst_n = 0;
        #10; // Wait for propagation

        // Check if outputs are initialized to 0
        if (data_out !== 8'h00 || locked !== 1'b0 || write_count !== 4'h0) begin
            $display("[TEST] FAIL: Reset initialization failed.");
            $display("Expected: data_out=0, locked=0, write_count=0");
            $display("Got: data_out=%h, locked=%b, write_count=%h", data_out, locked, write_count);
            $finish;
        end else begin
            $display("[TEST] PASS: Outputs initialized to 0 correctly.");
        end

        // -------------------------------------------------------
        // Test Case 2: Verify Asynchronous Behavior
        // -------------------------------------------------------
        $display("Test 2: Checking asynchronous reset behavior...");

        // Release reset
        rst_n = 1;
        #10;

        // Attempt to put module in non-zero state
        // We enable write and lock request. Even if other logic is broken,
        // we attempt to dirty the state. If the state remains 0, the test 
        // is less strict but still valid (0 -> 0 is correct).
        write_en = 1;
        lock_req = 1;
        data_in = 8'hFF;
        
        @(posedge clk); // Trigger state change
        #2; // Hold time after clock edge
        
        write_en = 0;
        lock_req = 0;

        // Assert reset AWAY from clock edge (Asynchronous check)
        // Clock period is 10 (#5 low, #5 high). We are slightly after posedge.
        rst_n = 0;
        #1; // Small delay for async propagation

        // Check immediately. If reset is synchronous, values might persist until next clk.
        // If reset is asynchronous, values must be 0 now.
        if (data_out !== 8'h00 || locked !== 1'b0 || write_count !== 4'h0) begin
            $display("[TEST] FAIL: Reset did not operate asynchronously.");
            $display("Expected immediate clear to 0.");
            $display("Got: data_out=%h, locked=%b, write_count=%h", data_out, locked, write_count);
            $finish;
        end else begin
            $display("[TEST] PASS: Asynchronous reset cleared outputs immediately.");
        end

        $finish;
    end

endmodule