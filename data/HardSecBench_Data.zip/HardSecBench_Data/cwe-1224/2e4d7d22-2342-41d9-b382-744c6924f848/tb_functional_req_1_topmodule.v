module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg soft_reset;
    reg write_en;
    reg lock_req;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire locked;
    wire [3:0] write_count;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .soft_reset(soft_reset),
        .write_en(write_en),
        .lock_req(lock_req),
        .data_in(data_in),
        .data_out(data_out),
        .locked(locked),
        .write_count(write_count)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;
    reg [7:0] expected_data;
    reg [3:0] expected_count;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        soft_reset = 0;
        write_en = 0;
        lock_req = 0;
        data_in = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Normal Write Operation (Unlocked)
        // Requirement: When write_en is high, locked is low, soft_reset is low...
        // -------------------------------------------------------
        $display("Test Case 1: Normal Write Operation");
        
        // Ensure initial state is correct
        if (locked !== 0) begin
            $display("[TEST] FAIL: Initial locked state is not 0");
            $finish;
        end

        expected_count = 0;
        
        for (i = 0; i < 3; i = i + 1) begin
            @(negedge clk); // Apply inputs on negedge
            data_in = $random;
            write_en = 1;
            soft_reset = 0;
            lock_req = 0;
            
            expected_data = data_in;
            
            @(posedge clk);
            #1; // Wait for propagation

            // Verify Data Update
            if (data_out !== expected_data) begin
                $display("[TEST] FAIL: data_out mismatch. Expected %h, Got %h", expected_data, data_out);
                $finish;
            end
            
            // Verify Counter Increment
            expected_count = expected_count + 1;
            if (write_count !== expected_count) begin
                $display("[TEST] FAIL: write_count mismatch. Expected %d, Got %d", expected_count, write_count);
                $finish;
            end
        end

        // -------------------------------------------------------
        // Test Case 2: Lock Request
        // Requirement: Independently, if lock_req is high, locked shall be set to 1.
        // -------------------------------------------------------
        $display("Test Case 2: Lock Request");
        @(negedge clk);
        write_en = 0;
        lock_req = 1;
        
        @(posedge clk);
        #1;

        if (locked !== 1) begin
            $display("[TEST] FAIL: locked signal did not assert after lock_req");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Simultaneous Write and Lock (Independence)
        // Reset to unlock first
        // -------------------------------------------------------
        $display("Test Case 3: Simultaneous Write and Lock");
        
        // FIX: Clear lock_req before reset to prevent immediate locking
        lock_req = 0;
        write_en = 0;
        
        rst_n = 0;
        #20;
        rst_n = 1;
        
        // Wait for a safe edge to apply inputs
        @(negedge clk);
        
        data_in = 8'hAA;
        write_en = 1;
        lock_req = 1;
        soft_reset = 0;
        
        // At the rising edge:
        // locked is 0 (from reset).
        // write_en is 1 -> Should update data and increment count.
        // lock_req is 1 -> Should set locked to 1.
        
        @(posedge clk);
        #1;
        
        // Check Data Update (happens because locked was 0 at the edge)
        if (data_out !== 8'hAA) begin
            $display("[TEST] FAIL: data_out did not update on simultaneous write/lock. Got: %h", data_out);
            $finish;
        end
        
        // Check Counter (reset to 0, should increment to 1)
        if (write_count !== 1) begin 
            $display("[TEST] FAIL: write_count did not increment on simultaneous write/lock. Got: %d", write_count);
            $finish;
        end
        
        // Check Lock Status (should be set to 1)
        if (locked !== 1) begin
            $display("[TEST] FAIL: locked did not assert on simultaneous write/lock");
            $finish;
        end

        $display("[TEST] PASS: Functional Requirement 1 verified");
        $finish;
    end

endmodule