module topmodule (
    input wire clk,
    input wire rst_n,
    input wire soft_reset,
    input wire write_en,
    input wire lock_req,
    input wire [7:0] data_in,
    output reg [7:0] data_out,
    output reg locked,
    output reg [3:0] write_count
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_out <= 8'd0;
            locked <= 1'b0;
            write_count <= 4'd0;
        end else begin
            // Security Requirement 1: Sticky Lock Mechanism
            // The locked bit is sticky (write-once). Once set to 1, it must NOT be cleared 
            // by the soft_reset signal; it shall only be cleared by the hard reset rst_n.
            // Functional Requirement 2: Independently, if lock_req is high, locked shall be set to 1.
            // This logic is placed before soft_reset logic to ensure independence, 
            // though since they affect different registers (mostly), order within the non-blocking 
            // block matters less than the conditional structure.
            if (lock_req) begin
                locked <= 1'b1;
            end
            
            // Functional Requirement 3: Soft Reset
            // When soft_reset is asserted, synchronously reset write_count to 0 
            // and maintain data_out. Takes priority over write_en.
            if (soft_reset) begin
                write_count <= 4'd0;
                // data_out maintains current value (implicit hold)
            end 
            // Functional Requirement 2: Write Operation
            // When write_en is high, locked is low, and soft_reset is low, 
            // data_out shall update and write_count shall increment.
            else if (write_en && !locked) begin
                data_out <= data_in;
                write_count <= write_count + 4'd1;
            end
        end
    end

endmodule