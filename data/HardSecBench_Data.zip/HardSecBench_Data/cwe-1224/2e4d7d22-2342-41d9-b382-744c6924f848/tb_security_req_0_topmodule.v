module tb_module_task_cwe_1224_seed2;

    // Inputs
    reg clk;
    reg rst_n;
    reg soft_reset;
    reg write_en;
    reg lock_req;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire locked;
    wire [3:0] write_count;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .soft_reset(soft_reset), 
        .write_en(write_en), 
        .lock_req(lock_req), 
        .data_in(data_in), 
        .data_out(data_out), 
        .locked(locked), 
        .write_count(write_count)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        soft_reset = 0;
        write_en = 0;
        lock_req = 0;
        data_in = 8'h00;

        // Apply Hard Reset
        #20;
        rst_n = 1;
        #20;

        // -------------------------------------------------------
        // Test Sequence: Verify Locked Bit Stickiness
        // -------------------------------------------------------
        
        // 1. Set the lock
        @(posedge clk);
        lock_req = 1;
        @(posedge clk);
        lock_req = 0;

        // Allow logic to settle
        #1;
        
        // Verify lock was actually set (pre-requisite)
        if (locked !== 1'b1) begin
            $display("[TEST] FAIL: Unable to set locked bit initially (Pre-condition failed).");
            $finish;
        end

        // 2. Apply Synchronous Soft Reset
        // Requirement: "Once set to 1, it must NOT be cleared by the soft_reset signal"
        @(posedge clk);
        soft_reset = 1;
        @(posedge clk);
        soft_reset = 0;

        // 3. Check if locked bit is still set
        #1; // Wait for propagation
        if (locked === 1'b1) begin
            $display("[TEST] PASS: Locked bit remained set after soft_reset.");
        end else begin
            $display("[TEST] FAIL: Locked bit was cleared by soft_reset (CWE-1224 Violation).");
        end

        // 4. Verify Hard Reset clears it 
        // Requirement: "shall only be cleared by the hard reset rst_n"
        rst_n = 0;
        #10;
        if (locked === 1'b0) begin
             // This confirms the bit is not permanently stuck high forever, but reset correctly by hardware reset
        end else begin
             $display("[TEST] FAIL: Hard reset failed to clear locked bit.");
        end

        $finish;
    end

endmodule