module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg soft_reset;
    reg write_en;
    reg lock_req;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire locked;
    wire [3:0] write_count;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .soft_reset(soft_reset),
        .write_en(write_en),
        .lock_req(lock_req),
        .data_in(data_in),
        .data_out(data_out),
        .locked(locked),
        .write_count(write_count)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        soft_reset = 0;
        write_en = 0;
        lock_req = 0;
        data_in = 8'h00;

        // Apply Hard Reset
        #20;
        rst_n = 1;
        #10;

        // ---------------------------------------------------------
        // Pre-condition: Modify state (write_count > 0, data_out != 0)
        // ---------------------------------------------------------
        @(negedge clk);
        write_en = 1;
        data_in = 8'hAA;
        @(negedge clk);
        data_in = 8'hBB;
        @(negedge clk);
        write_en = 0;

        // Check pre-condition
        if (write_count !== 2 || data_out !== 8'hBB) begin
            $display("[TEST] FAIL: Pre-condition setup failed. write_count=%d, data_out=%h", write_count, data_out);
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 1: Basic Soft Reset
        // Requirement: Reset write_count to 0, maintain data_out
        // ---------------------------------------------------------
        @(negedge clk);
        soft_reset = 1;
        write_en = 0;
        
        @(negedge clk); // Wait for rising edge effect
        soft_reset = 0;

        if (write_count !== 0) begin
            $display("[TEST] FAIL: soft_reset failed to clear write_count. Got: %d", write_count);
            $finish;
        end

        if (data_out !== 8'hBB) begin
            $display("[TEST] FAIL: soft_reset changed data_out. Got: %h, Expected: BB", data_out);
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 2: Soft Reset Priority over Write Enable
        // Requirement: Priority over write_en (no data update, reset count)
        // ---------------------------------------------------------
        // Step 2a: Increment count again to ensure we see a reset
        @(negedge clk);
        write_en = 1;
        data_in = 8'hCC;
        @(negedge clk);
        // Current state: data_out = CC, write_count = 1
        
        // Step 2b: Assert soft_reset AND write_en with new data
        soft_reset = 1;
        write_en = 1;
        data_in = 8'hFF; // This value should be ignored
        
        @(negedge clk);
        soft_reset = 0;
        write_en = 0;

        // Verification
        if (write_count !== 0) begin
            $display("[TEST] FAIL: soft_reset priority check failed. write_count not reset. Got: %d", write_count);
            $finish;
        end

        // data_out should remain 8'hCC (from Step 2a), NOT update to 8'hFF
        if (data_out !== 8'hCC) begin
            $display("[TEST] FAIL: soft_reset priority check failed. data_out updated despite reset. Got: %h, Expected: CC", data_out);
            $finish;
        end

        $display("[TEST] PASS: soft_reset functionality and priority verified");
        $finish;
    end

endmodule