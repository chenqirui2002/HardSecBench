module topmodule (
    input wire clk,
    input wire reset_n,
    input wire chip_select,
    input wire write_en,
    input wire [15:0] data_in,
    output wire [15:0] data_out,
    output wire lock_status,
    output reg access_fault
);

    // Internal register to store the 16-bit configuration
    // Bit 0 is the lock bit.
    reg [15:0] config_reg;

    // Connect internal register to data output
    assign data_out = config_reg;
    
    // Connect lock bit to lock_status output
    assign lock_status = config_reg[0];

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            // Reset register to 0x0000 (Unlocked)
            config_reg <= 16'h0000;
            access_fault <= 1'b0;
        end else begin
            // Default access_fault to 0; it pulses high only on failed write attempts
            access_fault <= 1'b0;

            if (chip_select && write_en) begin
                // Check the lock bit (Bit 0)
                if (config_reg[0] == 1'b0) begin
                    // UNLOCKED: Perform Write
                    
                    // Functional Requirement: Update upper 15 bits
                    config_reg[15:1] <= data_in[15:1];
                    
                    // Security Requirement 1 & 2: 
                    // Force the lock bit (Bit 0) to '1' immediately upon a valid write.
                    // This ignores data_in[0] and ensures the register becomes Write-Once.
                    config_reg[0] <= 1'b1;
                end else begin
                    // LOCKED: Block Write
                    
                    // Functional Requirement: Assert access_fault for one clock cycle
                    // Register value remains unchanged
                    access_fault <= 1'b1;
                end
            end
        end
    end

endmodule