`timescale 1ns/1ps

module testbench;

    // Inputs
    reg clk;
    reg reset_n;
    reg chip_select;
    reg write_en;
    reg [15:0] data_in;

    // Outputs
    wire [15:0] data_out;
    wire lock_status;
    wire access_fault;

    // Internal variables
    reg [15:0] first_write_val;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .reset_n(reset_n),
        .chip_select(chip_select),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .lock_status(lock_status),
        .access_fault(access_fault)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns period
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        reset_n = 0;
        chip_select = 0;
        write_en = 0;
        data_in = 16'h0000;

        // Reset the device
        #20;
        reset_n = 1;
        #20;

        // -------------------------------------------------------------------------
        // Test: Verify Write-Once Behavior (Security Requirement 0)
        // -------------------------------------------------------------------------
        
        // 1. Perform First Write
        // We write 0xAAAA (binary ...1010). The LSB is 0.
        // A secure implementation must ensure the register becomes read-only after this.
        // Note: Even though we write LSB=0, the design should enforce the lock.
        data_in = 16'hAAAA;
        chip_select = 1;
        write_en = 1;
        
        @(posedge clk); // Trigger write
        #1; // Hold time
        chip_select = 0;
        write_en = 0;
        
        #10; // Wait for update

        // Check if the write actually happened (sanity check for functional path)
        if (data_out == 16'h0000) begin
            $display("[TEST] FAIL: First write operation did not update the register.");
            $finish;
        end

        // Capture the value after the first write
        first_write_val = data_out;

        // 2. Attempt Second Write
        // We try to write 0x5555. If the register is locked, this should be ignored.
        data_in = 16'h5555;
        chip_select = 1;
        write_en = 1;
        
        @(posedge clk); // Trigger write attempt
        #1; // Hold time
        chip_select = 0;
        write_en = 0;
        
        #10; // Wait for update

        // 3. Verify
        // The register value should match the value captured after the first write.
        if (data_out !== first_write_val) begin
            $display("[TEST] FAIL: Register value changed after second write. Expected %h, Got %h", first_write_val, data_out);
        end else begin
            $display("[TEST] PASS: Register became read-only immediately after the first successful write operation.");
        end

        $finish;
    end

endmodule