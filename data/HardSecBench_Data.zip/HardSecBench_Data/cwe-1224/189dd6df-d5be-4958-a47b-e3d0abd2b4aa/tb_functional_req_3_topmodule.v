module tb_functional_req_3;
    // Signal declarations
    reg clk;
    reg reset_n;
    reg chip_select;
    reg write_en;
    reg [15:0] data_in;
    
    wire [15:0] data_out;
    wire lock_status;
    wire access_fault;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .reset_n(reset_n),
        .chip_select(chip_select),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .lock_status(lock_status),
        .access_fault(access_fault)
    );

    // Clock generation (10ns period)
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        reset_n = 0;
        chip_select = 0;
        write_en = 0;
        data_in = 16'h0000;

        // Apply Reset
        #20;
        reset_n = 1;
        #10;

        // -------------------------------------------------------
        // Setup Phase: Lock the register
        // -------------------------------------------------------
        // Drive inputs for the next clock edge
        @(posedge clk);
        chip_select <= 1;
        write_en <= 1;
        data_in <= 16'h0003; // Value 3 has LSB (Bit 0) set to 1
        
        // Wait for the write to happen
        @(posedge clk);
        // Deassert controls for the next cycle
        chip_select <= 0;
        write_en <= 0;
        data_in <= 16'h0000;

        // Wait for outputs to settle and verify lock status
        @(posedge clk);
        #1; // Small delay to read outputs after clock edge
        
        if (lock_status !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed - Lock bit (Bit 0) did not set to 1 after write.");
            $finish;
        end
        
        if (data_out !== 16'h0003) begin
            $display("[TEST] FAIL: Setup failed - Data not written correctly before locking.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Phase: Attempt write when locked
        // -------------------------------------------------------
        // Drive inputs to attempt a write
        @(posedge clk);
        chip_select <= 1;
        write_en <= 1;
        data_in <= 16'hFFFF; // Attempt to overwrite with FFFF

        // Wait for the DUT to sample inputs and process
        @(posedge clk);
        // Deassert controls immediately for the next cycle
        chip_select <= 0;
        write_en <= 0;
        data_in <= 16'h0000;

        // Check outputs immediately after the clock edge (plus propagation delay)
        #1;
        
        // Check 1: Register value shall be unchanged (should still be 0x0003)
        if (data_out !== 16'h0003) begin
            $display("[TEST] FAIL: Register value changed despite lock bit being set. Expected: 0003, Got: %h", data_out);
            $finish;
        end

        // Check 2: access_fault shall be asserted high
        if (access_fault !== 1'b1) begin
            $display("[TEST] FAIL: access_fault was not asserted on locked write attempt.");
            $finish;
        end

        // -------------------------------------------------------
        // Duration Check Phase
        // -------------------------------------------------------
        // Requirement: access_fault asserted for one clock cycle
        // We have already waited one cycle since the fault was generated.
        // Wait for the next edge where fault should clear (since CS/WE were deasserted)
        @(posedge clk);
        #1;
        
        if (access_fault !== 1'b0) begin
            $display("[TEST] FAIL: access_fault remained high for more than one clock cycle.");
            $finish;
        end

        // If we reached here, all checks passed
        $display("[TEST] PASS: Locked write was ignored and access_fault behaved correctly.");
        $finish;
    end

endmodule