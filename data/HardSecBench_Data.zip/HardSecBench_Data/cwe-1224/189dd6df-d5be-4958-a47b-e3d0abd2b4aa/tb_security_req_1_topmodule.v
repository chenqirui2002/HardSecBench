`timescale 1ns/1ns

module tb_task_cwe_1224_seed0;

    // Inputs
    reg clk;
    reg reset_n;
    reg chip_select;
    reg write_en;
    reg [15:0] data_in;

    // Outputs
    wire [15:0] data_out;
    wire lock_status;
    wire access_fault;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .reset_n(reset_n),
        .chip_select(chip_select),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .lock_status(lock_status),
        .access_fault(access_fault)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        reset_n = 0;
        chip_select = 0;
        write_en = 0;
        data_in = 16'h0000;

        // Apply Reset
        #20;
        reset_n = 1;
        #10;

        // --- Test Scenario: Attempt to write with LSB = 0 ---
        // We try to write 16'hAAAA (binary ...1010). The LSB is 0.
        // If the security requirement is implemented, the hardware must force LSB to 1.
        // Expected stored value: 16'hAAAB.
        
        data_in = 16'hAAAA; 
        chip_select = 1;
        write_en = 1;

        @(posedge clk); // Trigger write on rising edge
        #1; // Hold time
        
        chip_select = 0;
        write_en = 0;

        // Wait for logic to settle
        #10;

        // Check the LSB of the output data and the lock_status signal
        if (data_out[0] === 1'b1 && lock_status === 1'b1) begin
            // Check if the upper bits were written correctly as well
            if (data_out[15:1] === data_in[15:1]) begin
                $display("[TEST] PASS: Lock bit forced to 1 (Secure). Input LSB=0 was overridden.");
            end else begin
                $display("[TEST] FAIL: Lock bit forced, but data corruption in upper bits. data_out=%h", data_out);
            end
        end else if (data_out[0] === 1'b0) begin
            $display("[TEST] FAIL: Lock bit NOT forced to 1 (Vulnerable). User successfully wrote 0 to LSB.");
        end else begin
            $display("[TEST] FAIL: Unexpected state. data_out=%h, lock_status=%b", data_out, lock_status);
        end

        $finish;
    end

endmodule