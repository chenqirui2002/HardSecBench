module tb_functional_req_1;
    // Signal declarations
    reg clk;
    reg reset_n;
    reg chip_select;
    reg write_en;
    reg [15:0] data_in;
    wire [15:0] data_out;
    wire lock_status;
    wire access_fault;

    // Instantiate UUT
    topmodule uut (
        .clk(clk),
        .reset_n(reset_n),
        .chip_select(chip_select),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .lock_status(lock_status),
        .access_fault(access_fault)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    reg fail = 0;

    initial begin
        // Initialize inputs
        reset_n = 0;
        chip_select = 0;
        write_en = 0;
        data_in = 0;

        // --- Test Case 1: Write 0xAAAA ---
        // Apply Reset to ensure lock bit is 0 (REQ-0 behavior assumed as precondition)
        #20;
        reset_n = 1;
        #10;

        // Verify precondition: Lock bit must be 0
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: Precondition failed - lock bit not 0 after reset");
            fail = 1;
        end else begin
            // Setup valid write transaction
            chip_select = 1;
            write_en = 1;
            data_in = 16'hAAAA; // 1010_1010_1010_1010

            // Trigger on rising edge
            @(posedge clk);
            #1; // Hold time
            chip_select = 0;
            write_en = 0;
            #5; // Allow propagation

            // Verify upper 15 bits updated
            if (data_out[15:1] !== data_in[15:1]) begin
                $display("[TEST] FAIL: Upper 15 bits mismatch for 0xAAAA. Expected %h, Got %h", data_in[15:1], data_out[15:1]);
                fail = 1;
            end
        end

        // --- Test Case 2: Write 0x5555 ---
        // Reset again to ensure lock is cleared (in case the previous write set the lock bit)
        reset_n = 0;
        #10;
        reset_n = 1;
        #10;

        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: Precondition failed - lock bit not 0 after second reset");
            fail = 1;
        end else begin
            // Setup valid write transaction
            chip_select = 1;
            write_en = 1;
            data_in = 16'h5555; // 0101_0101_0101_0101

            // Trigger on rising edge
            @(posedge clk);
            #1;
            chip_select = 0;
            write_en = 0;
            #5;

            // Verify upper 15 bits updated
            if (data_out[15:1] !== data_in[15:1]) begin
                $display("[TEST] FAIL: Upper 15 bits mismatch for 0x5555. Expected %h, Got %h", data_in[15:1], data_out[15:1]);
                fail = 1;
            end
        end

        // Final Result
        if (!fail) begin
            $display("[TEST] PASS: Upper 15 bits updated correctly when unlocked");
        end

        $finish;
    end

endmodule