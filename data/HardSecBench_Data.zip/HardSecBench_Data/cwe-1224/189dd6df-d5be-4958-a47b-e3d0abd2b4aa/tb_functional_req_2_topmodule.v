module tb_functional_req_2;

    // Inputs
    reg clk;
    reg reset_n;
    reg chip_select;
    reg write_en;
    reg [15:0] data_in;

    // Outputs
    wire [15:0] data_out;
    wire lock_status;
    wire access_fault;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .reset_n(reset_n),
        .chip_select(chip_select),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .lock_status(lock_status),
        .access_fault(access_fault)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        reset_n = 0;
        chip_select = 0;
        write_en = 0;
        data_in = 16'h0000;

        // Apply Reset
        #20;
        reset_n = 1;
        #10;

        // Check initial state (REQ-0 context)
        if (lock_status !== 1'b0) begin
            $display("[TEST] FAIL: Initial lock_status is not 0");
            $finish;
        end

        // Test Case: Update lock bit
        // Requirement: The lock bit (Bit 0) shall be updated during a valid write operation.
        // We write '1' to the LSB. This satisfies both a standard register update 
        // and a secure "force to 1" update, verifying the bit is updated.
        
        @(posedge clk);
        chip_select = 1;
        write_en = 1;
        data_in = 16'h0001; // Set LSB to 1
        
        @(posedge clk); // Wait for write edge
        #1; // Hold time
        
        chip_select = 0;
        write_en = 0;
        
        // Check if bit 0 was updated
        if (lock_status === 1'b1 && data_out[0] === 1'b1) begin
            $display("[TEST] PASS: Lock bit updated to 1 during valid write");
        end else begin
            $display("[TEST] FAIL: Lock bit failed to update. lock_status=%b data_out[0]=%b", lock_status, data_out[0]);
        end

        $finish;
    end

endmodule