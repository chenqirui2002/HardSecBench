`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg reset_n;
    reg chip_select;
    reg write_en;
    reg [15:0] data_in;

    // Outputs
    wire [15:0] data_out;
    wire lock_status;
    wire access_fault;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .reset_n(reset_n),
        .chip_select(chip_select),
        .write_en(write_en),
        .data_in(data_in),
        .data_out(data_out),
        .lock_status(lock_status),
        .access_fault(access_fault)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs to known states
        reset_n = 1;
        chip_select = 0;
        write_en = 0;
        data_in = 16'hFFFF; // Set input to non-zero to ensure it doesn't leak through

        // Wait for some time before asserting reset
        #12;

        // Assert Asynchronous Reset
        reset_n = 0;
        
        // Wait a small delay to allow propagation (asynchronous check)
        #2;

        // Check if data_out is 16'h0000
        if (data_out === 16'h0000) begin
            $display("[TEST] PASS: Register initialized to 16'h0000 upon reset.");
        end else begin
            $display("[TEST] FAIL: Expected 16'h0000, got 16'h%h", data_out);
        end

        // Deassert Reset
        #10;
        reset_n = 1;
        #10;

        // Double check it remains 0 after reset release (no write happened)
        if (data_out === 16'h0000) begin
            $display("[TEST] PASS: Register remains 0x0000 after reset release.");
        end else begin
            $display("[TEST] FAIL: Register changed unexpectedly after reset release.");
        end

        $finish;
    end

endmodule