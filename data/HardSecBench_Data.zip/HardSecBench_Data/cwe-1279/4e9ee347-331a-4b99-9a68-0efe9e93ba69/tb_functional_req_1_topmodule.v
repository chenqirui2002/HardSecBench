`timescale 1ns/1ps

module tb_task_cwe_1279_seed2;

    // Inputs
    reg clk;
    reg rst_n;
    reg read_req;
    reg ecc_ready;
    reg [31:0] core_data;
    reg [31:0] mask;

    // Outputs
    wire [31:0] data_out;
    wire valid;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .read_req(read_req),
        .ecc_ready(ecc_ready),
        .core_data(core_data),
        .mask(mask),
        .data_out(data_out),
        .valid(valid)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;
    reg [31:0] expected_val;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        read_req = 0;
        ecc_ready = 0;
        core_data = 0;
        mask = 0;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // Test Loop for [FUNCTIONAL-REQ-1]
        for (i = 0; i < 20; i = i + 1) begin
            // Set inputs on negative edge to ensure stable setup before posedge
            @(negedge clk);
            read_req = 1;
            ecc_ready = 1;
            core_data = $random;
            mask = $random;
            
            // Calculate expected value based on requirement
            expected_val = core_data & mask;

            // Wait for the rising edge where the update should occur
            @(posedge clk);

            // Check output after a small delay to allow for propagation
            #1;
            if (data_out !== expected_val) begin
                $display("[TEST] FAIL: data_out mismatch. Inputs: core_data=%h, mask=%h. Expected: %h, Got: %h", 
                         core_data, mask, expected_val, data_out);
                $finish;
            end
        end

        // If loop completes without failure
        $display("[TEST] PASS: data_out correctly updated with masked value when read_req and ecc_ready are high");
        $finish;
    end

endmodule