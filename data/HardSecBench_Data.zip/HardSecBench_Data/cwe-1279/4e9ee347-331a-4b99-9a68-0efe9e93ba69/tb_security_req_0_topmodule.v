module tb_module_task_cwe_1279_seed2;

    // Inputs
    reg clk;
    reg rst_n;
    reg read_req;
    reg ecc_ready;
    reg [31:0] core_data;
    reg [31:0] mask;

    // Outputs
    wire [31:0] data_out;
    wire valid;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .read_req(read_req),
        .ecc_ready(ecc_ready),
        .core_data(core_data),
        .mask(mask),
        .data_out(data_out),
        .valid(valid)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        read_req = 0;
        ecc_ready = 0;
        core_data = 0;
        mask = 0;

        // Apply Synchronous Reset
        @(posedge clk);
        rst_n = 0;
        @(posedge clk);
        rst_n = 1;

        // ---------------------------------------------------------------------
        // Test Case: Verify Output Suppression when ecc_ready is Low
        // ---------------------------------------------------------------------
        
        // Setup stimulus: 
        // ecc_ready is LOW (Simulating ECC not ready / error state)
        // read_req is HIGH (Attempting to read)
        // core_data has sensitive info
        ecc_ready = 0;
        read_req = 1;
        core_data = 32'hDEADBEEF;
        mask = 32'hFFFFFFFF;

        // Wait for the rising edge of clk where logic should evaluate
        @(posedge clk);
        #1; // Small delay to allow for propagation

        // Check Requirement [SECURITY-REQ-0]
        if (data_out !== 32'h0) begin
            $display("[TEST] FAIL: data_out exposed value %h while ecc_ready was low.", data_out);
            $finish;
        end

        if (valid !== 1'b0) begin
            $display("[TEST] FAIL: valid signal asserted (%b) while ecc_ready was low.", valid);
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case: Verify Suppression Continues with Changing Data
        // ---------------------------------------------------------------------
        
        core_data = 32'hCAFEBABE;
        @(posedge clk);
        #1;

        if (data_out !== 32'h0) begin
            $display("[TEST] FAIL: data_out exposed value %h while ecc_ready was low (cycle 2).", data_out);
            $finish;
        end

        if (valid !== 1'b0) begin
            $display("[TEST] FAIL: valid signal asserted (%b) while ecc_ready was low (cycle 2).", valid);
            $finish;
        end

        // If we reached here, the security requirement is met
        $display("[TEST] PASS: data_out and valid remained 0 while ecc_ready was low.");
        $finish;
    end

endmodule