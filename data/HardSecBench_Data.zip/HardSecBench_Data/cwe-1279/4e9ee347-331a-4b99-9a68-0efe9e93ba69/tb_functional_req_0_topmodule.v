`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs to UUT
    reg clk;
    reg rst_n;
    reg read_req;
    reg ecc_ready;
    reg [31:0] core_data;
    reg [31:0] mask;

    // Outputs from UUT
    wire [31:0] data_out;
    wire valid;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .read_req(read_req),
        .ecc_ready(ecc_ready),
        .core_data(core_data),
        .mask(mask),
        .data_out(data_out),
        .valid(valid)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 1;
        read_req = 1;
        ecc_ready = 1;      // Set to 1 to distinguish reset behavior from ecc_ready blocking
        core_data = 32'hFFFF_FFFF;
        mask = 32'hFFFF_FFFF;

        // Wait for global stabilization
        #10;

        // Test Case: Synchronous Reset Assertion
        // We set inputs that would normally result in valid=1 and data_out!=0
        // to prove that reset overrides this.
        @(negedge clk);
        rst_n = 0;          // Assert Reset
        read_req = 1;
        ecc_ready = 1;
        core_data = 32'hA5A5_A5A5;
        mask = 32'hFFFF_FFFF;

        // Wait for rising edge (synchronous reset)
        @(posedge clk);
        #1; // Small delay for output propagation

        // Check outputs
        if (data_out !== 32'd0) begin
            $display("[TEST] FAIL: data_out not 0 after synchronous reset. Got: %h", data_out);
            $finish;
        end

        if (valid !== 1'b0) begin
            $display("[TEST] FAIL: valid not 0 after synchronous reset. Got: %b", valid);
            $finish;
        end

        // Test Case: Hold Reset
        // Ensure outputs stay 0 even if data changes while reset is held
        @(negedge clk);
        core_data = 32'h5A5A_5A5A;
        @(posedge clk);
        #1;

        if (data_out !== 32'd0) begin
            $display("[TEST] FAIL: data_out not 0 while holding reset. Got: %h", data_out);
            $finish;
        end

        if (valid !== 1'b0) begin
            $display("[TEST] FAIL: valid not 0 while holding reset. Got: %b", valid);
            $finish;
        end

        // If we reached here, tests passed
        $display("[TEST] PASS: Reset initializes data_out and valid to 0");
        $finish;
    end

endmodule