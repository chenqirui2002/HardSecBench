module testbench_security_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg read_req;
    reg ecc_ready;
    reg [31:0] core_data;
    reg [31:0] mask;

    // Outputs
    wire [31:0] data_out;
    wire valid;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .read_req(read_req),
        .ecc_ready(ecc_ready),
        .core_data(core_data),
        .mask(mask),
        .data_out(data_out),
        .valid(valid)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        read_req = 0;
        ecc_ready = 0;
        core_data = 0;
        mask = 0;

        // Apply Reset
        repeat (2) @(negedge clk);
        rst_n = 1;

        // ---------------------------------------------------------------------
        // Test Case 1: read_req = 1, ecc_ready = 0
        // Security Requirement: maintain data_out at 0 and valid at 0
        // ---------------------------------------------------------------------
        @(negedge clk);
        read_req = 1;
        ecc_ready = 0;
        core_data = 32'hDEADBEEF; // Sensitive data
        mask = 32'hFFFFFFFF;      // Mask allows all bits

        @(negedge clk); // Wait for rising edge logic to settle
        
        if (data_out !== 32'h0) begin
            $display("[TEST] FAIL: data_out leaked sensitive data when ecc_ready=0. Expected 0, Got %h", data_out);
            $finish;
        end
        
        if (valid !== 1'b0) begin
            $display("[TEST] FAIL: valid signal asserted when ecc_ready=0. Expected 0, Got %b", valid);
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 2: read_req = 0, ecc_ready = 0
        // Security Requirement: maintain data_out at 0 and valid at 0
        // ---------------------------------------------------------------------
        @(negedge clk);
        read_req = 0;
        ecc_ready = 0;
        core_data = 32'hCAFEBABE; // Different sensitive data
        mask = 32'hFFFFFFFF;

        @(negedge clk); // Wait for rising edge logic to settle

        if (data_out !== 32'h0) begin
            $display("[TEST] FAIL: data_out not zero when ecc_ready=0 (read_req=0). Expected 0, Got %h", data_out);
            $finish;
        end

        if (valid !== 1'b0) begin
            $display("[TEST] FAIL: valid signal asserted when ecc_ready=0 (read_req=0). Expected 0, Got %b", valid);
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 3: Verify with restrictive mask (sanity check)
        // ---------------------------------------------------------------------
        @(negedge clk);
        read_req = 1;
        ecc_ready = 0;
        core_data = 32'hFFFFFFFF;
        mask = 32'h00000000;

        @(negedge clk);

        if (data_out !== 32'h0 || valid !== 1'b0) begin
            $display("[TEST] FAIL: Output non-zero or valid high during masked test with ecc_ready=0.");
            $finish;
        end

        // If all checks pass
        $display("[TEST] PASS: Security requirement [SECURITY-REQ-1] verified. No data leakage when ecc_ready is low.");
        $finish;
    end

endmodule