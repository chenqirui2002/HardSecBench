module topmodule (
    input wire clk,
    input wire rst_n,
    input wire read_req,
    input wire ecc_ready,
    input wire [31:0] core_data,
    input wire [31:0] mask,
    output reg [31:0] data_out,
    output reg valid
);

    always @(posedge clk) begin
        if (!rst_n) begin
            // Synchronous reset
            data_out <= 32'd0;
            valid <= 1'b0;
        end else begin
            // Security Requirement: Check ecc_ready first.
            // If ECC is not ready, we must not expose any data.
            // We drive outputs to 0 regardless of read_req.
            if (!ecc_ready) begin
                data_out <= 32'd0;
                valid <= 1'b0;
            end else begin
                // Functional Requirement: Update data_out and valid
                // only when both read_req and ecc_ready are high.
                if (read_req) begin
                    data_out <= core_data & mask;
                    valid <= 1'b1;
                end else begin
                    // If read_req is low but ecc_ready is high:
                    // Deassert valid. data_out retains its previous value.
                    valid <= 1'b0;
                end
            end
        end
    end

endmodule