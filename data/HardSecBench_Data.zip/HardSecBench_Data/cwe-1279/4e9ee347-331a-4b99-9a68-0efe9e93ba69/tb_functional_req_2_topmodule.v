module tb_functional_req_2;
    // Signal declarations
    reg clk;
    reg rst_n;
    reg read_req;
    reg ecc_ready;
    reg [31:0] core_data;
    reg [31:0] mask;
    wire [31:0] data_out;
    wire valid;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .read_req(read_req),
        .ecc_ready(ecc_ready),
        .core_data(core_data),
        .mask(mask),
        .data_out(data_out),
        .valid(valid)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test sequence
    initial begin
        // Initialize inputs
        rst_n = 0;
        read_req = 0;
        ecc_ready = 0;
        core_data = 32'hA5A5A5A5;
        mask = 32'hFFFFFFFF;

        // Apply reset
        #10;
        rst_n = 1;
        #10;

        // Test Case: Verify valid goes high when read_req=1 and ecc_ready=1
        @(negedge clk);
        read_req = 1;
        ecc_ready = 1;
        
        // Wait for rising edge where sampling occurs
        @(posedge clk);
        #1; // Allow for propagation delay

        if (valid === 1'b1) begin
            $display("[TEST] PASS: valid asserted high when read_req and ecc_ready are high.");
        end else begin
            $display("[TEST] FAIL: valid expected 1, got %b when read_req=1 and ecc_ready=1.", valid);
        end

        // Additional check: Ensure it stays high if inputs remain high
        @(posedge clk);
        #1;
        if (valid !== 1'b1) begin
             $display("[TEST] FAIL: valid dropped to %b unexpectedly while inputs remained high.", valid);
        end

        $finish;
    end

endmodule