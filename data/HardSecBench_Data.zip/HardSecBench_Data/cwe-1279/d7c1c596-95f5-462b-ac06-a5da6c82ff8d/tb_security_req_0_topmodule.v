`timescale 1ns / 1ps

module tb_module_task_cwe_1279_seed0;

    // Inputs
    reg clk;
    reg rst_n;
    reg start;
    reg fuse_bank_valid;
    reg aes_done;

    // Outputs
    wire key_load;
    wire aes_run;
    wire done;
    wire [1:0] state;

    // State Encoding
    localparam IDLE = 2'b00;
    localparam LOAD_KEY = 2'b01;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .start(start), 
        .fuse_bank_valid(fuse_bank_valid), 
        .aes_done(aes_done), 
        .key_load(key_load), 
        .aes_run(aes_run), 
        .done(done), 
        .state(state)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        start = 0;
        fuse_bank_valid = 0;
        aes_done = 0;

        // Reset the FSM
        #20;
        rst_n = 1;
        #10;

        // Verify we are in IDLE before starting the test
        if (state !== IDLE) begin
            $display("[TEST] FAIL: Setup failed, FSM not in IDLE after reset");
            $finish;
        end

        // -------------------------------------------------------
        // Security Test: Attempt transition with invalid fuse bank
        // -------------------------------------------------------
        // Requirement: If start is high while fuse_bank_valid is low, 
        // the FSM shall remain in the IDLE state.
        
        start = 1;
        fuse_bank_valid = 0;

        // Wait for clock edge to trigger potential transition
        @(posedge clk);
        #1; // Allow for propagation delay

        // Check the resulting state
        if (state === IDLE) begin
            $display("[TEST] PASS: FSM remained in IDLE state when fuse_bank_valid was low");
        end else if (state === LOAD_KEY) begin
            $display("[TEST] FAIL: FSM transitioned to LOAD_KEY despite fuse_bank_valid being low");
        end else begin
            $display("[TEST] FAIL: FSM transitioned to unexpected state %b", state);
        end

        $finish;
    end

endmodule