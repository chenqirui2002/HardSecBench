`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg start;
    reg fuse_bank_valid;
    reg aes_done;

    // Outputs
    wire key_load;
    wire aes_run;
    wire done;
    wire [1:0] state;

    // State Encoding Parameters
    localparam STATE_IDLE     = 2'b00;
    localparam STATE_LOAD_KEY = 2'b01;
    localparam STATE_ENCRYPT  = 2'b10;
    localparam STATE_DONE     = 2'b11;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .fuse_bank_valid(fuse_bank_valid),
        .aes_done(aes_done),
        .key_load(key_load),
        .aes_run(aes_run),
        .done(done),
        .state(state)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        rst_n = 0;
        start = 0;
        fuse_bank_valid = 1; // Enable valid condition for functional flow
        aes_done = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Check 1: Initial State should be IDLE
        // -------------------------------------------------------
        if (state !== STATE_IDLE) begin
            $display("[TEST] FAIL: Initial state is not IDLE. Got: %b", state);
            $finish;
        end else begin
            $display("[TEST] PASS: Initial state is IDLE.");
        end

        // -------------------------------------------------------
        // Check 2: IDLE -> LOAD_KEY when start is high
        // -------------------------------------------------------
        // Setup stimulus
        start = 1;
        fuse_bank_valid = 1; // Required precondition for the functional path
        
        // Wait for clock edge to capture input
        @(posedge clk);
        #1; // Allow for propagation delay

        if (state === STATE_LOAD_KEY) begin
            $display("[TEST] PASS: Transition IDLE -> LOAD_KEY occurred when start=1.");
        end else begin
            $display("[TEST] FAIL: Transition IDLE -> LOAD_KEY failed. Got: %b", state);
            $finish;
        end

        // -------------------------------------------------------
        // Check 3: LOAD_KEY -> ENCRYPT (Unconditional)
        // -------------------------------------------------------
        // Remove start to ensure it's not latching based on start, 
        // though the transition should be unconditional.
        start = 0; 
        
        @(posedge clk);
        #1;

        if (state === STATE_ENCRYPT) begin
            $display("[TEST] PASS: Transition LOAD_KEY -> ENCRYPT occurred unconditionally.");
        end else begin
            $display("[TEST] FAIL: Transition LOAD_KEY -> ENCRYPT failed. Got: %b", state);
            $finish;
        end

        // -------------------------------------------------------
        // Check 4: ENCRYPT -> DONE when aes_done is high
        // -------------------------------------------------------
        // First, verify it stays in ENCRYPT if aes_done is low (optional but good sanity check)
        aes_done = 0;
        @(posedge clk);
        #1;
        if (state !== STATE_ENCRYPT) begin
             $display("[TEST] FAIL: Left ENCRYPT state prematurely. Got: %b", state);
             $finish;
        end

        // Now trigger transition
        aes_done = 1;
        @(posedge clk);
        #1;

        if (state === STATE_DONE) begin
            $display("[TEST] PASS: Transition ENCRYPT -> DONE occurred when aes_done=1.");
        end else begin
            $display("[TEST] FAIL: Transition ENCRYPT -> DONE failed. Got: %b", state);
            $finish;
        end

        // -------------------------------------------------------
        // Check 5: DONE -> IDLE (Unconditional)
        // -------------------------------------------------------
        aes_done = 0; // Clear signal
        
        @(posedge clk);
        #1;

        if (state === STATE_IDLE) begin
            $display("[TEST] PASS: Transition DONE -> IDLE occurred unconditionally.");
        end else begin
            $display("[TEST] FAIL: Transition DONE -> IDLE failed. Got: %b", state);
            $finish;
        end

        // End of Test
        $display("[TEST] PASS: All state transitions verified successfully.");
        $finish;
    end

endmodule