`timescale 1ns/1ps

module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg start;
    reg fuse_bank_valid;
    reg aes_done;

    // Outputs
    wire key_load;
    wire aes_run;
    wire done;
    wire [1:0] state;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .fuse_bank_valid(fuse_bank_valid),
        .aes_done(aes_done),
        .key_load(key_load),
        .aes_run(aes_run),
        .done(done),
        .state(state)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // State Encodings
    localparam IDLE     = 2'b00;
    localparam LOAD_KEY = 2'b01;
    localparam ENCRYPT  = 2'b10;
    localparam DONE     = 2'b11;

    integer errors = 0;

    // Task to verify outputs for a specific state
    task verify_state_outputs;
        input [1:0] expected_state;
        begin
            // 1. Check state output reflects register value
            if (state !== expected_state) begin
                $display("[TEST] FAIL: Expected state %b, got %b", expected_state, state);
                errors = errors + 1;
            end

            // 2. Check key_load (High ONLY in LOAD_KEY)
            if (expected_state == LOAD_KEY) begin
                if (key_load !== 1'b1) begin
                    $display("[TEST] FAIL: In LOAD_KEY, key_load should be 1, got %b", key_load);
                    errors = errors + 1;
                end
            end else begin
                if (key_load !== 1'b0) begin
                    $display("[TEST] FAIL: In state %b, key_load should be 0, got %b", expected_state, key_load);
                    errors = errors + 1;
                end
            end

            // 3. Check aes_run (High ONLY in ENCRYPT)
            if (expected_state == ENCRYPT) begin
                if (aes_run !== 1'b1) begin
                    $display("[TEST] FAIL: In ENCRYPT, aes_run should be 1, got %b", aes_run);
                    errors = errors + 1;
                end
            end else begin
                if (aes_run !== 1'b0) begin
                    $display("[TEST] FAIL: In state %b, aes_run should be 0, got %b", expected_state, aes_run);
                    errors = errors + 1;
                end
            end

            // 4. Check done (High ONLY in DONE)
            if (expected_state == DONE) begin
                if (done !== 1'b1) begin
                    $display("[TEST] FAIL: In DONE, done should be 1, got %b", done);
                    errors = errors + 1;
                end
            end else begin
                if (done !== 1'b0) begin
                    $display("[TEST] FAIL: In state %b, done should be 0, got %b", expected_state, done);
                    errors = errors + 1;
                end
            end
        end
    endtask

    initial begin
        // Initialize Inputs
        rst_n = 0;
        start = 0;
        fuse_bank_valid = 0;
        aes_done = 0;

        // Wait for global reset
        #100;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // 1. Verify IDLE State Outputs
        // -------------------------------------------------------
        // Should be in IDLE after reset
        verify_state_outputs(IDLE);

        // -------------------------------------------------------
        // 2. Verify LOAD_KEY State Outputs
        // -------------------------------------------------------
        // Trigger transition: start=1, fuse_bank_valid=1
        @(negedge clk);
        start = 1;
        fuse_bank_valid = 1;
        @(posedge clk);
        #1; // Allow propagation
        verify_state_outputs(LOAD_KEY);

        // -------------------------------------------------------
        // 3. Verify ENCRYPT State Outputs
        // -------------------------------------------------------
        // Transition is unconditional next cycle
        @(negedge clk);
        start = 0; // Clean up input
        fuse_bank_valid = 0;
        @(posedge clk);
        #1;
        verify_state_outputs(ENCRYPT);

        // -------------------------------------------------------
        // 4. Verify DONE State Outputs
        // -------------------------------------------------------
        // Trigger transition: aes_done=1
        @(negedge clk);
        aes_done = 1;
        @(posedge clk);
        #1;
        verify_state_outputs(DONE);

        // -------------------------------------------------------
        // 5. Verify Return to IDLE
        // -------------------------------------------------------
        // Transition is unconditional next cycle
        @(negedge clk);
        aes_done = 0;
        @(posedge clk);
        #1;
        verify_state_outputs(IDLE);

        // Final Result
        if (errors == 0)
            $display("[TEST] PASS: All state outputs verified correctly.");
        else
            $display("[TEST] FAIL: Found %0d errors in output logic.", errors);
        
        $finish;
    end

endmodule