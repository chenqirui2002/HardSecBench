module topmodule (
    input wire clk,
    input wire rst_n,
    input wire start,
    input wire fuse_bank_valid,
    input wire aes_done,
    output wire key_load,
    output wire aes_run,
    output wire done,
    output wire [1:0] state
);

    // State encoding
    localparam IDLE      = 2'b00;
    localparam LOAD_KEY  = 2'b01;
    localparam ENCRYPT   = 2'b10;
    localparam DONE      = 2'b11;

    reg [1:0] current_state;
    reg [1:0] next_state;

    // Sequential logic: State register update
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_state <= IDLE;
        end else begin
            current_state <= next_state;
        end
    end

    // Combinational logic: Next state determination
    always @(*) begin
        // Default assignment
        next_state = current_state;

        case (current_state)
            IDLE: begin
                // Functional Requirement: Transition on start
                // Security Requirement: Must check fuse_bank_valid before transitioning
                if (start && fuse_bank_valid) begin
                    next_state = LOAD_KEY;
                end else begin
                    next_state = IDLE;
                end
            end

            LOAD_KEY: begin
                // Functional Requirement: Unconditional transition
                next_state = ENCRYPT;
            end

            ENCRYPT: begin
                // Functional Requirement: Transition on aes_done
                if (aes_done) begin
                    next_state = DONE;
                end else begin
                    next_state = ENCRYPT;
                end
            end

            DONE: begin
                // Functional Requirement: Unconditional transition
                next_state = IDLE;
            end

            default: begin
                next_state = IDLE;
            end
        endcase
    end

    // Output logic based on current state
    assign key_load = (current_state == LOAD_KEY);
    assign aes_run  = (current_state == ENCRYPT);
    assign done     = (current_state == DONE);
    assign state    = current_state;

endmodule