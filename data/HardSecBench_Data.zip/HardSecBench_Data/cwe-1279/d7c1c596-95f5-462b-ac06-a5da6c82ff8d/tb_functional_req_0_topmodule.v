module tb_module_task_cwe_1279_seed0;

    // Inputs
    reg clk;
    reg rst_n;
    reg start;
    reg fuse_bank_valid;
    reg aes_done;

    // Outputs
    wire key_load;
    wire aes_run;
    wire done;
    wire [1:0] state;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .fuse_bank_valid(fuse_bank_valid),
        .aes_done(aes_done),
        .key_load(key_load),
        .aes_run(aes_run),
        .done(done),
        .state(state)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 1;
        start = 0;
        fuse_bank_valid = 1; // Set high to ensure transitions are allowed
        aes_done = 0;

        // Wait for global reset
        #10;

        // -------------------------------------------------------
        // Test Case 1: Asynchronous Reset to IDLE (2'b00)
        // -------------------------------------------------------
        rst_n = 0;
        #2; // Wait small delay to verify async nature (no clock edge required)
        
        if (state !== 2'b00) begin
            $display("[TEST] FAIL: Reset did not set state to IDLE (00). Got: %b", state);
        end else begin
            $display("[TEST] PASS: Reset set state to IDLE (00).");
        end

        // Release reset
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 2: Verify State Encodings
        // -------------------------------------------------------
        
        // 2a. Transition to LOAD_KEY (2'b01)
        // Requirement: IDLE -> LOAD_KEY when start is high
        @(posedge clk);
        start = 1;
        @(posedge clk); // Wait for transition
        #1; // Check after clock edge
        
        if (state !== 2'b01) begin
            $display("[TEST] FAIL: Expected LOAD_KEY (01) after start=1. Got: %b", state);
        end else begin
            $display("[TEST] PASS: State encoding LOAD_KEY is 01.");
        end

        // 2b. Transition to ENCRYPT (2'b10)
        // Requirement: LOAD_KEY -> ENCRYPT unconditionally next cycle
        start = 0;
        @(posedge clk);
        #1;

        if (state !== 2'b10) begin
            $display("[TEST] FAIL: Expected ENCRYPT (10) after LOAD_KEY. Got: %b", state);
        end else begin
            $display("[TEST] PASS: State encoding ENCRYPT is 10.");
        end

        // 2c. Transition to DONE (2'b11)
        // Requirement: ENCRYPT -> DONE when aes_done is high
        aes_done = 1;
        @(posedge clk);
        #1;

        if (state !== 2'b11) begin
            $display("[TEST] FAIL: Expected DONE (11) after aes_done=1. Got: %b", state);
        end else begin
            $display("[TEST] PASS: State encoding DONE is 11.");
        end

        // -------------------------------------------------------
        // Test Case 3: Asynchronous Reset from non-IDLE state
        // -------------------------------------------------------
        // Currently in DONE state (11). Assert reset asynchronously.
        #2; 
        rst_n = 0;
        #2; // Check immediately without waiting for clock

        if (state !== 2'b00) begin
            $display("[TEST] FAIL: Async reset from DONE did not return to IDLE. Got: %b", state);
        end else begin
            $display("[TEST] PASS: Async reset from DONE returned to IDLE.");
        end

        $finish;
    end

endmodule