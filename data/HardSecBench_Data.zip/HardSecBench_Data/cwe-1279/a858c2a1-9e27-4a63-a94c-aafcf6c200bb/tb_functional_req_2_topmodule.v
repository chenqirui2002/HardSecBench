module tb_module_task_cwe_1279_seed8;

    // Inputs
    reg clk;
    reg rst_n;
    reg power_good;
    reg read_req;
    reg [127:0] hw_key_in;

    // Outputs
    wire [127:0] key_out;
    wire key_valid;
    wire storage_en;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .power_good(power_good),
        .read_req(read_req),
        .hw_key_in(hw_key_in),
        .key_out(key_out),
        .key_valid(key_valid),
        .storage_en(storage_en)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        power_good = 1; // Enable power to test functional logic specifically
        read_req = 0;
        hw_key_in = 128'hAABBCCDDEEFF00112233445566778899;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // Test Case 1: Initial state check (read_req is 0)
        // Requirement: When read_req is deasserted, outputs shall be 0
        if (key_out !== 128'h0 || key_valid !== 1'b0 || storage_en !== 1'b0) begin
            $display("[TEST] FAIL: Outputs not 0 at reset with read_req=0. key_out=%h, valid=%b, en=%b", 
                     key_out, key_valid, storage_en);
        end else begin
            $display("[TEST] PASS: Outputs are 0 when read_req=0 (initial state).");
        end

        // Test Case 2: Transition check
        // Assert read_req to potentially change outputs, then deassert to verify they return to 0
        
        // Assert read_req
        @(negedge clk);
        read_req = 1;
        @(posedge clk);
        #1; // Wait for output propagation
        
        // Deassert read_req
        @(negedge clk);
        read_req = 0;
        @(posedge clk);
        #1; // Wait for output propagation

        // Verify outputs are cleared
        if (key_out !== 128'h0) begin
            $display("[TEST] FAIL: key_out not driven to 0 after read_req deassertion. Got: %h", key_out);
        end else if (key_valid !== 1'b0) begin
            $display("[TEST] FAIL: key_valid not driven to 0 after read_req deassertion. Got: %b", key_valid);
        end else if (storage_en !== 1'b0) begin
            $display("[TEST] FAIL: storage_en not driven to 0 after read_req deassertion. Got: %b", storage_en);
        end else begin
            $display("[TEST] PASS: All outputs correctly driven to 0 after read_req deassertion.");
        end

        $finish;
    end

endmodule