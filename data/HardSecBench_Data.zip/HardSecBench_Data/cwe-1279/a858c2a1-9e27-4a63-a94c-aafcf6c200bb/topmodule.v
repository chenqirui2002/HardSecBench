module topmodule (
    input wire clk,
    input wire rst_n,
    input wire power_good,
    input wire read_req,
    input wire [127:0] hw_key_in,
    output reg [127:0] key_out,
    output reg key_valid,
    output reg storage_en
);

    // Synchronous logic with asynchronous reset
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Reset state: all outputs to 0
            key_out <= 128'd0;
            key_valid <= 1'b0;
            storage_en <= 1'b0;
        end else begin
            // Security Requirement: Check power_good.
            // Functional Requirement: Check read_req.
            // Only when both are asserted do we enable storage and expose the key.
            if (power_good && read_req) begin
                key_out <= hw_key_in;
                key_valid <= 1'b1;
                storage_en <= 1'b1;
            end else begin
                // If power is not good OR read is not requested, drive everything to 0.
                // This satisfies the security requirement to zero outputs when power_good is 0.
                // This satisfies the functional requirement to zero outputs when read_req is 0.
                key_out <= 128'd0;
                key_valid <= 1'b0;
                storage_en <= 1'b0;
            end
        end
    end

endmodule