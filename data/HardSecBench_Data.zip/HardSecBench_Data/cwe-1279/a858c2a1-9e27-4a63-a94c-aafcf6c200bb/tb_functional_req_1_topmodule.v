`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg power_good;
    reg read_req;
    reg [127:0] hw_key_in;

    // Outputs
    wire [127:0] key_out;
    wire key_valid;
    wire storage_en;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .power_good(power_good),
        .read_req(read_req),
        .hw_key_in(hw_key_in),
        .key_out(key_out),
        .key_valid(key_valid),
        .storage_en(storage_en)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        power_good = 0;
        read_req = 0;
        hw_key_in = 128'h0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Assert read_req and power_good
        // Requirement: When read_req is asserted and power_good is asserted, 
        // the module shall assert storage_en, assert key_valid, and drive key_out with hw_key_in.
        // -------------------------------------------------------
        
        $display("Starting Test for FUNCTIONAL-REQ-1...");

        // Stimulus
        read_req = 1;
        power_good = 1;
        hw_key_in = 128'hDEAD_BEEF_CAFE_BABE_0123_4567_89AB_CDEF;

        // Wait for clock edge for synchronous update (per Req 0 context)
        @(posedge clk);
        #1; // Allow for propagation delay

        // Check outputs
        if (storage_en !== 1'b1) begin
            $display("[TEST] FAIL: storage_en is %b, expected 1 when read_req=1 and power_good=1", storage_en);
            $finish;
        end

        if (key_valid !== 1'b1) begin
            $display("[TEST] FAIL: key_valid is %b, expected 1 when read_req=1 and power_good=1", key_valid);
            $finish;
        end

        if (key_out !== hw_key_in) begin
            $display("[TEST] FAIL: key_out is %h, expected %h", key_out, hw_key_in);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Change key input while maintaining enable signals
        // -------------------------------------------------------
        @(posedge clk); // Setup next value
        hw_key_in = 128'hFFFF_0000_AAAA_5555_1111_2222_3333_4444;
        
        @(posedge clk); // Clock it in
        #1; // Prop delay

        if (key_out !== hw_key_in) begin
            $display("[TEST] FAIL: key_out did not update. Got %h, expected %h", key_out, hw_key_in);
            $finish;
        end
        
        // Ensure control signals remain asserted
        if (storage_en !== 1'b1 || key_valid !== 1'b1) begin
            $display("[TEST] FAIL: Control signals dropped unexpectedly during data change.");
            $finish;
        end

        $display("[TEST] PASS: FUNCTIONAL-REQ-1 verified correctly.");
        $finish;
    end

endmodule