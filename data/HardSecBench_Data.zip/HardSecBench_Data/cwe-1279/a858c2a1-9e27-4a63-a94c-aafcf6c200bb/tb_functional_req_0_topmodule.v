module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg power_good;
    reg read_req;
    reg [127:0] hw_key_in;

    // Outputs
    wire [127:0] key_out;
    wire key_valid;
    wire storage_en;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .power_good(power_good),
        .read_req(read_req),
        .hw_key_in(hw_key_in),
        .key_out(key_out),
        .key_valid(key_valid),
        .storage_en(storage_en)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        power_good = 0;
        read_req = 0;
        hw_key_in = 128'hDEADBEEF_DEADBEEF_DEADBEEF_DEADBEEF;

        // Wait for global reset
        #10;
        rst_n = 1;

        // -------------------------------------------------------
        // Step 1: Establish a valid state (Outputs High)
        // -------------------------------------------------------
        @(posedge clk);
        power_good = 1;
        read_req = 1;
        
        // Wait for outputs to settle (assuming 1 cycle latency or less)
        @(posedge clk);
        #1; 

        // Check pre-condition: Outputs must be high to meaningfully test Reset
        if (key_valid === 0 || storage_en === 0) begin
            $display("[TEST] FAIL: Pre-condition failed. Outputs did not go high with valid inputs, cannot test reset.");
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Test Asynchronous Reset
        // -------------------------------------------------------
        // Assert reset away from clock edge (e.g., on negedge)
        @(negedge clk);
        rst_n = 0;
        #1; // Small delay to allow async logic to propagate

        // Verify outputs cleared immediately
        if (key_valid !== 0 || storage_en !== 0 || key_out !== 128'd0) begin
            $display("[TEST] FAIL: Asynchronous reset failed. Outputs did not clear immediately upon rst_n assertion.");
            $finish;
        end

        // -------------------------------------------------------
        // Step 3: Test Synchronous Recovery (Clock Edge Operation)
        // -------------------------------------------------------
        rst_n = 1;
        #1;
        
        // Outputs should still be 0 because we haven't hit a posedge clk yet
        // This verifies the "operate on positive edge of clk" aspect
        if (key_valid !== 0 || storage_en !== 0) begin
            $display("[TEST] FAIL: Outputs changed before positive clock edge (Async set violation).");
            $finish;
        end

        // Wait for clock edge
        @(posedge clk);
        #1;

        // Now outputs should recover to valid state
        if (key_valid !== 1 || storage_en !== 1) begin
            $display("[TEST] FAIL: Module did not recover operation after reset on positive clock edge.");
            $finish;
        end

        $display("[TEST] PASS: Asynchronous reset and clock edge operation verified.");
        $finish;
    end

endmodule