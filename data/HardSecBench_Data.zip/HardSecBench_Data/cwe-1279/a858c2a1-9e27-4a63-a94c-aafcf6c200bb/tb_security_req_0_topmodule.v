`timescale 1ns/1ps

module testbench;

  // Inputs
  reg clk;
  reg rst_n;
  reg power_good;
  reg read_req;
  reg [127:0] hw_key_in;

  // Outputs
  wire [127:0] key_out;
  wire key_valid;
  wire storage_en;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .power_good(power_good),
    .read_req(read_req),
    .hw_key_in(hw_key_in),
    .key_out(key_out),
    .key_valid(key_valid),
    .storage_en(storage_en)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  initial begin
    // Initialize Inputs
    rst_n = 0;
    power_good = 1;
    read_req = 0;
    hw_key_in = 128'hDEADBEEFDEADBEEFDEADBEEFDEADBEEF;

    // Reset sequence
    #10;
    rst_n = 1;
    #10;

    // ---------------------------------------------------------
    // Test Case: power_good = 0, read_req = 1
    // ---------------------------------------------------------
    // The security requirement states that if power_good is 0,
    // outputs must be 0 regardless of read_req.
    
    @(posedge clk);
    power_good = 0;
    read_req = 1;
    hw_key_in = 128'hFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF; // Set key to all 1s to easily detect leakage
    
    @(posedge clk); 
    #1; // Allow for propagation delay after clock edge

    if (key_out !== 128'h0 || key_valid !== 1'b0 || storage_en !== 1'b0) begin
      $display("[TEST] FAIL: Security violation. Outputs active while power_good is 0.");
      $display("       Inputs: power_good=%b, read_req=%b", power_good, read_req);
      $display("       Outputs: key_out=%h (expected 0)", key_out);
      $display("                key_valid=%b (expected 0)", key_valid);
      $display("                storage_en=%b (expected 0)", storage_en);
    end else begin
      $display("[TEST] PASS: Outputs remain 0 when power_good is deasserted.");
    end

    $finish;
  end

endmodule