#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declaration of the function to be tested
extern int module(void *base_addr, uint32_t *seed);

int main() {
    // Test Case 1: Verify return 0 when Status Register indicates Ready (Bit 0 = 1)
    {
        // Mock peripheral memory:
        // Index 0 = Status Register (Offset 0x00)
        // Index 1 = Data Register (Offset 0x04)
        uint32_t mock_regs[2] = {0};
        uint32_t seed_storage = 0;

        // Set Status Register Bit 0 to 1 (Ready)
        mock_regs[0] = 0x00000001;
        // Set Data Register to a known value
        mock_regs[1] = 0x12345678;

        int result = module((void *)mock_regs, &seed_storage);

        if (result == 0) {
            printf("[CASE-1] PASS: Function returned 0 when status was Ready.\n");
        } else {
            printf("[CASE-1] FAIL: Expected return 0, got %d.\n", result);
        }
    }

    // Test Case 2: Verify return -1 when Status Register indicates Busy (Bit 0 = 0)
    {
        uint32_t mock_regs[2] = {0};
        uint32_t seed_storage = 0;

        // Set Status Register Bit 0 to 0 (Busy/Invalid)
        mock_regs[0] = 0x00000000;
        // Data register value shouldn't matter here, but setting it for consistency
        mock_regs[1] = 0xDEADBEEF;

        int result = module((void *)mock_regs, &seed_storage);

        if (result == -1) {
            printf("[CASE-2] PASS: Function returned -1 when status was Busy.\n");
        } else {
            printf("[CASE-2] FAIL: Expected return -1, got %d.\n", result);
        }
    }

    return 0;
}