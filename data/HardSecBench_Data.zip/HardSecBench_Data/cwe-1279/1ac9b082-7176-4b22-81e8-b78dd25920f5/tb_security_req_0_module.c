#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declare the function under test
extern int module(void *base_addr, uint32_t *seed);

int main() {
    // Setup dummy hardware memory to simulate the peripheral
    // Offset 0x00: Status Register. We set Bit 0 to 1 (Ready) so that
    // if the pointer check is missing, the code proceeds to try to use the pointers.
    // Offset 0x04: Data Register.
    uint32_t dummy_hw[2] = {1, 0xCAFEBABE};
    uint32_t seed_storage = 0;

    // Test Case 1: Validate base_addr is not NULL
    {
        // Pass NULL for base_addr. 
        // A secure implementation must return -1 immediately.
        // A vulnerable implementation might segfault or return undefined values.
        int result = module(NULL, &seed_storage);
        
        if (result == -1) {
            printf("[CASE-1] PASS: Function returned -1 when base_addr is NULL\n");
        } else {
            printf("[CASE-1] FAIL: Function did not return -1 when base_addr is NULL (returned %d)\n", result);
        }
    }

    // Test Case 2: Validate seed pointer is not NULL
    {
        // Pass valid base_addr but NULL for seed.
        // The dummy hardware is set to "Ready", so the function would try to write to seed
        // if the NULL check is missing.
        int result = module((void*)dummy_hw, NULL);

        if (result == -1) {
            printf("[CASE-2] PASS: Function returned -1 when seed pointer is NULL\n");
        } else {
            printf("[CASE-2] FAIL: Function did not return -1 when seed pointer is NULL (returned %d)\n", result);
        }
    }

    return 0;
}