#include <stdint.h>
#include <stddef.h>

int module (void *base_addr, uint32_t *seed) {
    // Security Requirement 1: Validate that the input pointers are not NULL.
    if (base_addr == NULL || seed == NULL) {
        return -1;
    }

    // Functional Requirement 1: Cast base_addr to access registers as volatile uint32_t.
    // Using volatile ensures the compiler does not optimize away reads/writes to the hardware addresses.
    volatile uint32_t *regs = (volatile uint32_t *)base_addr;

    // Security Requirement 2: Check the Status Register Bit 0 (Ready flag) before reading the Data Register.
    // The Status Register is at offset 0x00, which corresponds to index 0 of the uint32_t pointer.
    uint32_t status = regs[0];

    // Check if Bit 0 is set (1 = Valid/Ready, 0 = Invalid/Busy).
    if ((status & 1) == 0) {
        // Security Requirement 3: If the Ready flag is 0, return -1 immediately.
        // Do NOT read the Data Register to prevent using invalid entropy.
        return -1;
    }

    // Functional Requirement 2: Retrieve a 32-bit value from the Data Register.
    // The Data Register is at offset 0x04, which corresponds to index 1 of the uint32_t pointer (4 bytes offset).
    *seed = regs[1];

    // Functional Requirement 3: Return 0 if the seed is successfully retrieved.
    return 0;
}