#include <stdio.h>
#include <stdint.h>

// Declare the function under test as per rules
extern int module(void *base_addr, uint32_t *seed);

int main() {
    // Test Case 1: Verify correct access to Status (offset 0x00) and Data (offset 0x04)
    // This validates that base_addr is treated as a pointer to 32-bit registers.
    {
        // Use uint32_t array to ensure alignment and easy setup of 32-bit values
        uint32_t mock_registers[2];
        uint32_t seed_val = 0;
        int ret;

        // Set Status Register (offset 0) to 1 (Ready)
        // This simulates the hardware being ready with valid data
        mock_registers[0] = 0x00000001;
        
        // Set Data Register (offset 4) to a known pattern
        mock_registers[1] = 0x8BADF00D;

        ret = module((void*)mock_registers, &seed_val);

        // If the function casts correctly to uint32_t*, it reads index 0 and index 1.
        // We verify both the return code (indicating status read success) and the data value.
        if (ret == 0 && seed_val == 0x8BADF00D) {
            printf("[CASE-1] PASS: Correctly accessed Status and Data registers.\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0, seed=0x8BADF00D. Got ret=%d, seed=0x%08X\n", ret, seed_val);
        }
    }

    // Test Case 2: Verify Status Register interpretation at offset 0
    // This validates that the function reads the Status register at the correct offset.
    {
        uint32_t mock_registers[2];
        uint32_t seed_val = 0;
        int ret;

        // Set Status Register to 0 (Not Ready)
        mock_registers[0] = 0x00000000;
        // Data register content shouldn't matter if status is checked correctly
        mock_registers[1] = 0x8BADF00D;

        ret = module((void*)mock_registers, &seed_val);

        // If the function reads offset 0 correctly, it sees 0 (Busy) and returns -1
        if (ret == -1) {
            printf("[CASE-2] PASS: Correctly identified Status Not Ready.\n");
        } else {
            printf("[CASE-2] FAIL: Expected ret=-1. Got ret=%d\n", ret);
        }
    }

    return 0;
}