#include <stdio.h>
#include <stdint.h>

// Declare the target function
extern int module(void *base_addr, uint32_t *seed);

int main() {
    // Test Case 1: Status Register Bit 0 is 0 (Not Ready)
    // The function should return -1 and NOT update the seed variable.
    {
        // Simulate peripheral memory: 
        // [0] = Status Register (Offset 0x00)
        // [1] = Data Register (Offset 0x04)
        uint32_t virtual_peripheral[2];
        
        // Set Status to 0 (Bit 0 is 0 -> Not Ready)
        virtual_peripheral[0] = 0x00000000;
        
        // Set Data Register to a known "invalid" value
        virtual_peripheral[1] = 0xDEADBEEF;
        
        // Initialize seed with a canary value to detect modification
        uint32_t seed_val = 0xCAFEBABE;
        
        int result = module((void*)virtual_peripheral, &seed_val);
        
        if (result == -1) {
            // Check if seed_val was modified. It should remain 0xCAFEBABE.
            if (seed_val == 0xCAFEBABE) {
                printf("[CASE-1] PASS: Function returned -1 and preserved seed value when status was Not Ready.\n");
            } else {
                printf("[CASE-1] FAIL: Function returned -1 but modified the seed variable (Data Register was accessed).\n");
            }
        } else {
            printf("[CASE-1] FAIL: Function returned %d instead of -1 when status was Not Ready.\n", result);
        }
    }

    // Test Case 2: Status Register Bit 0 is 0, but other bits are set
    // This verifies the function specifically checks Bit 0 and ignores others.
    {
        uint32_t virtual_peripheral[2];
        
        // Set Status to all 1s EXCEPT Bit 0 (Still Not Ready)
        virtual_peripheral[0] = 0xFFFFFFFE; 
        
        // Set Data Register
        virtual_peripheral[1] = 0x12345678;
        
        // Canary value
        uint32_t seed_val = 0x55555555;
        
        int result = module((void*)virtual_peripheral, &seed_val);
        
        if (result == -1) {
            if (seed_val == 0x55555555) {
                printf("[CASE-2] PASS: Function correctly identified Not Ready state with high bits set.\n");
            } else {
                printf("[CASE-2] FAIL: Function returned -1 but modified the seed variable.\n");
            }
        } else {
            printf("[CASE-2] FAIL: Function returned %d instead of -1 when Bit 0 was 0.\n", result);
        }
    }

    return 0;
}