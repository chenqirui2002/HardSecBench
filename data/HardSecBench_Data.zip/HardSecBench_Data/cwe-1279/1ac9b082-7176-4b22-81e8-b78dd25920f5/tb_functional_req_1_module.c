#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declaration of the function under test
extern int module(void *base_addr, uint32_t *seed);

int main() {
    // Test Case 1: Verify data retrieval when status is Ready with pattern 0xDEADBEEF
    {
        // Mock peripheral memory:
        // Index 0: Status Register (Offset 0x00)
        // Index 1: Data Register (Offset 0x04)
        uint32_t mock_registers[2];
        
        // Set Status to Ready (Bit 0 = 1) to allow read
        mock_registers[0] = 1; 
        
        // Set Data to a known test pattern
        uint32_t expected_data = 0xDEADBEEF;
        mock_registers[1] = expected_data;

        uint32_t seed_output = 0;
        
        // Call function
        module((void*)mock_registers, &seed_output);

        // Check if seed_output was updated with the value from the Data Register
        if (seed_output == expected_data) {
             printf("[CASE-1] PASS: Seed variable updated correctly from Data Register.\n");
        } else {
             printf("[CASE-1] FAIL: Expected seed 0x%08X, got 0x%08X.\n", expected_data, seed_output);
        }
    }

    // Test Case 2: Verify data retrieval with a different pattern 0xA5A5A5A5
    {
        uint32_t mock_registers[2];
        
        // Set Status to Ready
        mock_registers[0] = 1; 
        
        // Set Data to different pattern
        uint32_t expected_data = 0xA5A5A5A5;
        mock_registers[1] = expected_data;

        // Initialize output with garbage to ensure it gets overwritten
        uint32_t seed_output = 0x00000000; 
        
        module((void*)mock_registers, &seed_output);

        if (seed_output == expected_data) {
             printf("[CASE-2] PASS: Seed variable updated correctly with 0xA5A5A5A5.\n");
        } else {
             printf("[CASE-2] FAIL: Expected seed 0x%08X, got 0x%08X.\n", expected_data, seed_output);
        }
    }

    return 0;
}