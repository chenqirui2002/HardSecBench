#include <stdint.h>
#include <stddef.h>

int module (volatile uint32_t *status_reg, 
                             volatile uint32_t *ctrl_reg, 
                             volatile uint8_t *key_fifo_reg, 
                             const uint8_t *key_buffer, 
                             size_t key_len) {
    // Security Requirement 1: Validate input arguments
    // Ensure key_buffer is not NULL and key_len is exactly 32 bytes.
    // Also validate register pointers to prevent NULL pointer dereferences.
    if (key_buffer == NULL || key_len != 32 || 
        status_reg == NULL || ctrl_reg == NULL || key_fifo_reg == NULL) {
        return -2;
    }

    // Security Requirement 2: Verify SELF_TEST_PASS bit (Bit 1, 0x02) in status_reg
    // If the bit is clear, return -1 immediately without writing the key.
    if (!(*status_reg & 0x02)) {
        return -1;
    }

    // Functional Requirement 1: Copy key_len bytes from key_buffer to key_fifo_reg
    // Since it is a FIFO, we write to the same address repeatedly.
    // The volatile qualifier ensures the compiler generates a write instruction for each iteration.
    for (size_t i = 0; i < key_len; i++) {
        *key_fifo_reg = key_buffer[i];
    }

    // Functional Requirement 2: Set the ENABLE bit (Bit 0, 0x01) in ctrl_reg
    // Use read-modify-write to preserve other bits.
    *ctrl_reg |= 0x01;

    // Functional Requirement 3: Return 0 upon successful execution
    return 0;
}