#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declare the function under test
extern int module(
    volatile uint32_t *status_reg,
    volatile uint32_t *ctrl_reg,
    volatile uint8_t *key_fifo_reg,
    const uint8_t *key_buffer,
    size_t key_len
);

int main(void) {
    // Test Case 1: SELF_TEST_PASS bit (0x02) is CLEAR
    // Security Requirement: Return -1 immediately, do NOT write to fifo
    {
        volatile uint32_t status = 0x00; // Bit 1 is 0
        volatile uint32_t ctrl = 0x00;
        uint8_t fifo_buffer[32];
        uint8_t key[32];
        size_t key_len = 32;

        // Initialize FIFO to 0xFF (sentinel) and Key to 0xAA
        memset(fifo_buffer, 0xFF, sizeof(fifo_buffer));
        memset(key, 0xAA, sizeof(key));

        int result = module(&status, &ctrl, fifo_buffer, key, key_len);

        // Check if any byte in the FIFO buffer was modified
        int fifo_modified = 0;
        for(int i = 0; i < 32; i++) {
            if(fifo_buffer[i] != 0xFF) {
                fifo_modified = 1;
                break;
            }
        }

        if (result == -1 && fifo_modified == 0) {
            printf("[CASE-1] PASS: Correctly aborted (ret -1) without writing to FIFO when self-test failed\n");
        } else {
            printf("[CASE-1] FAIL: Security check failure. Return: %d (expected -1), FIFO Modified: %s\n", 
                   result, fifo_modified ? "YES" : "NO");
        }
    }

    // Test Case 2: SELF_TEST_PASS bit (0x02) is SET
    // Security Requirement: Proceed with operation (Return 0)
    {
        volatile uint32_t status = 0x02; // Bit 1 is 1
        volatile uint32_t ctrl = 0x00;
        uint8_t fifo_buffer[32];
        uint8_t key[32];
        size_t key_len = 32;

        // Initialize buffers
        memset(fifo_buffer, 0xFF, sizeof(fifo_buffer));
        memset(key, 0xAA, sizeof(key));

        int result = module(&status, &ctrl, fifo_buffer, key, key_len);

        // We check for 0 to ensure the security check logic doesn't block valid states
        if (result == 0) {
            printf("[CASE-2] PASS: Function proceeded correctly when self-test passed\n");
        } else {
            printf("[CASE-2] FAIL: Function rejected valid state (Status=0x02). Return: %d\n", result);
        }
    }

    return 0;
}