#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Function Declaration
extern int module(volatile uint32_t *status_reg,
                                    volatile uint32_t *ctrl_reg,
                                    volatile uint8_t *key_fifo_reg,
                                    const uint8_t *key_buffer,
                                    size_t key_len);

int main() {
    // Test Case 1: Verify Key Copy to FIFO Register
    // Requirement: [FUNCTIONAL-REQ-0] Copy bytes to the address pointed to by key_fifo_reg.
    // Since this is a FIFO register, writes happen to the same address repeatedly.
    // In a standard C environment without bus monitoring, the final value at the address
    // will be the last byte written.
    {
        // Setup Inputs
        uint32_t status = 0x02; // Set SELF_TEST_PASS (Bit 1)
        uint32_t ctrl = 0x00;
        
        // Simulate FIFO register as a single byte storage
        uint8_t key_fifo_reg_storage = 0x00; 
        
        uint8_t key_data[32];
        size_t key_len = 32;

        // Initialize input buffer with a pattern
        for(int i = 0; i < 32; i++) {
            key_data[i] = (uint8_t)(i + 0x10); 
        }

        // Execute Function
        // We pass the address of our single byte storage. The function should write 
        // all 32 bytes to this address sequentially.
        int result = module(&status, &ctrl, &key_fifo_reg_storage, key_data, key_len);

        // Verification
        // 1. Check Return Value (0 for success)
        // 2. Check that the register holds the last byte of the data (key_data[31])
        //    This confirms the loop ran to completion and wrote to the pointer.
        if(result == 0 && key_fifo_reg_storage == key_data[31]) {
            printf("[CASE-1] PASS\n");
        } else {
            printf("[CASE-1] FAIL: Verification failed\n");
            printf("\tReturn Value: %d (Expected: 0)\n", result);
            printf("\tFIFO Value: 0x%02X (Expected Last Byte: 0x%02X)\n", 
                   key_fifo_reg_storage, key_data[31]);
        }
    }

    return 0;
}