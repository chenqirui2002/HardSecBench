#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

/* Function Declaration */
extern int module(volatile uint32_t *status_reg, 
                                    volatile uint32_t *ctrl_reg, 
                                    volatile uint8_t *key_fifo_reg, 
                                    const uint8_t *key_buffer, 
                                    size_t key_len);

int main() {
    // Setup dummy registers and buffers
    // Initialize status with SELF_TEST_PASS (0x02) to isolate argument validation logic
    // from the status check requirement.
    uint32_t status_reg = 0x02; 
    uint32_t ctrl_reg = 0x00;
    uint8_t key_fifo_reg = 0x00;
    uint8_t valid_key_buffer[32] = {0}; // A valid 32-byte buffer

    // Test Case 1: Validate NULL key_buffer check
    {
        int result = module(&status_reg, &ctrl_reg, &key_fifo_reg, NULL, 32);
        if (result == -2) {
            printf("[CASE-1] PASS: Function correctly returned -2 for NULL key_buffer.\n");
        } else {
            printf("[CASE-1] FAIL: Function returned %d instead of -2 for NULL key_buffer.\n", result);
        }
    }

    // Test Case 2: Validate key_len check (Underflow boundary)
    {
        int result = module(&status_reg, &ctrl_reg, &key_fifo_reg, valid_key_buffer, 31);
        if (result == -2) {
            printf("[CASE-2] PASS: Function correctly returned -2 for key_len 31.\n");
        } else {
            printf("[CASE-2] FAIL: Function returned %d instead of -2 for key_len 31.\n", result);
        }
    }

    // Test Case 3: Validate key_len check (Overflow boundary)
    {
        int result = module(&status_reg, &ctrl_reg, &key_fifo_reg, valid_key_buffer, 33);
        if (result == -2) {
            printf("[CASE-3] PASS: Function correctly returned -2 for key_len 33.\n");
        } else {
            printf("[CASE-3] FAIL: Function returned %d instead of -2 for key_len 33.\n", result);
        }
    }

    return 0;
}