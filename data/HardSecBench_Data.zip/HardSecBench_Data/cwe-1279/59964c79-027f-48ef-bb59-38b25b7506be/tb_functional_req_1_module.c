#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Extern declaration of the function under test
extern int module(
    volatile uint32_t *status_reg,
    volatile uint32_t *ctrl_reg,
    volatile uint8_t *key_fifo_reg,
    const uint8_t *key_buffer,
    size_t key_len
);

int main() {
    // Test Case 1: Verify ENABLE bit is set from a clear state
    {
        uint32_t status = 0x02; // Set SELF_TEST_PASS (Bit 1) to satisfy security check
        uint32_t ctrl = 0x00;   // Control register initially 0
        uint8_t fifo_sim[32];   // Buffer to simulate FIFO write address
        uint8_t key[32];
        memset(key, 0xAA, 32);  // Dummy key data

        // Execute function with valid inputs
        int res = module(&status, &ctrl, fifo_sim, key, 32);

        // Check: Return 0 (Success) and ENABLE bit (0x01) is set in ctrl_reg
        if (res == 0 && (ctrl & 0x01) == 0x01) {
            printf("[CASE-1] PASS: ENABLE bit set correctly.\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0, ctrl&1=1. Got ret=%d, ctrl=0x%08X\n", res, ctrl);
        }
    }

    // Test Case 2: Verify ENABLE bit is set when other bits are present
    {
        uint32_t status = 0x02; // Set SELF_TEST_PASS
        uint32_t ctrl = 0x10;   // Set Bit 4 initially to test bitwise operations
        uint8_t fifo_sim[32];
        uint8_t key[32];
        memset(key, 0xBB, 32);

        // Execute function
        int res = module(&status, &ctrl, fifo_sim, key, 32);

        // Check: Return 0 and ENABLE bit (0x01) is set.
        // We check (ctrl & 0x01) to verify the target bit is set regardless of whether 
        // the implementation preserves or clears the other bits (0x10).
        if (res == 0 && (ctrl & 0x01) == 0x01) {
            printf("[CASE-2] PASS: ENABLE bit set correctly with pre-existing bits.\n");
        } else {
            printf("[CASE-2] FAIL: Expected ret=0, ctrl&1=1. Got ret=%d, ctrl=0x%08X\n", res, ctrl);
        }
    }

    return 0;
}