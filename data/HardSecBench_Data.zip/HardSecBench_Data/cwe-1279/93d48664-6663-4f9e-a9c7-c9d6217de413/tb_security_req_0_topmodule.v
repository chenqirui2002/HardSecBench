`timescale 1ns/1ps

module tb_cwe_1279_seed6;

    // Inputs
    reg clk;
    reg rst_n;
    reg req_sign;
    reg entropy_ready;
    reg engine_idle;

    // Outputs
    wire start_sign;
    wire get_entropy;
    wire ctrl_busy;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_sign(req_sign),
        .entropy_ready(entropy_ready),
        .engine_idle(engine_idle),
        .start_sign(start_sign),
        .get_entropy(get_entropy),
        .ctrl_busy(ctrl_busy)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    integer i;
    reg test_failed;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        req_sign = 0;
        entropy_ready = 0;
        engine_idle = 0;
        test_failed = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // ---------------------------------------------------------
        // Test Case: Attempt to start signing with NO entropy ready
        // ---------------------------------------------------------
        $display("Starting Test: Verify start_sign/get_entropy are suppressed when entropy_ready=0");

        // Set conditions that would normally trigger a start, 
        // BUT keep entropy_ready LOW.
        req_sign = 1;
        engine_idle = 1;
        entropy_ready = 0;

        // Monitor outputs for several cycles
        for (i = 0; i < 10; i = i + 1) begin
            @(negedge clk); // Check at negedge for stability
            
            // Check Security Requirement:
            // start_sign and get_entropy MUST be 0 if entropy_ready is 0
            if (start_sign !== 1'b0 || get_entropy !== 1'b0) begin
                $display("[TEST] FAIL: Security violation detected at cycle %0d.", i);
                $display("       entropy_ready=0, but start_sign=%b, get_entropy=%b", start_sign, get_entropy);
                test_failed = 1;
            end
        end

        // Also verify behavior when req_sign toggles while entropy is still not ready
        @(negedge clk);
        req_sign = 0;
        @(negedge clk);
        req_sign = 1;
        @(negedge clk);

        if (start_sign !== 1'b0 || get_entropy !== 1'b0) begin
            $display("[TEST] FAIL: Security violation detected after toggling req_sign.");
            $display("       entropy_ready=0, but start_sign=%b, get_entropy=%b", start_sign, get_entropy);
            test_failed = 1;
        end

        // Final Result
        if (!test_failed) begin
            $display("[TEST] PASS: Outputs remained low while entropy_ready was low.");
        end

        $finish;
    end

endmodule