`timescale 1ns/1ps

module tb_task_cwe_1279_seed6;

    // Inputs to DUT
    reg clk;
    reg rst_n;
    reg req_sign;
    reg entropy_ready;
    reg engine_idle;

    // Outputs from DUT
    wire start_sign;
    wire get_entropy;
    wire ctrl_busy;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_sign(req_sign),
        .entropy_ready(entropy_ready),
        .engine_idle(engine_idle),
        .start_sign(start_sign),
        .get_entropy(get_entropy),
        .ctrl_busy(ctrl_busy)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer pass_count = 0;
    integer fail_count = 0;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        req_sign = 0;
        entropy_ready = 0;
        engine_idle = 0;

        // Wait 100 ns for global reset to finish
        #100;
        rst_n = 1;
        #20;

        // ---------------------------------------------------------------------
        // Test Case: Verify start_sign and get_entropy pulse for 1 cycle
        // Condition: req_sign=1, engine_idle=1, entropy_ready=1
        // ---------------------------------------------------------------------
        $display("Starting Test for FUNCTIONAL-REQ-1...");

        // Align to negative edge to change inputs safely
        @(negedge clk);
        req_sign = 1;
        engine_idle = 1;
        entropy_ready = 1; // "data is available"

        // Wait for the rising edge where the DUT samples inputs and asserts outputs
        @(posedge clk);
        #1; // Small delay for propagation

        // Check if outputs are asserted
        if (start_sign === 1'b1 && get_entropy === 1'b1) begin
            $display("[TEST] PASS: start_sign and get_entropy asserted high upon trigger condition.");
            pass_count = pass_count + 1;
        end else begin
            $display("[TEST] FAIL: Expected start_sign=1, get_entropy=1. Got start_sign=%b, get_entropy=%b", start_sign, get_entropy);
            fail_count = fail_count + 1;
        end

        // Wait for the next rising edge (end of the 1-cycle pulse)
        @(posedge clk);
        #1; // Small delay for propagation

        // Check if outputs are de-asserted (duration check)
        // Even if inputs remain high, the requirement specifies "exactly one clock cycle"
        if (start_sign === 1'b0 && get_entropy === 1'b0) begin
            $display("[TEST] PASS: start_sign and get_entropy de-asserted after exactly one cycle.");
            pass_count = pass_count + 1;
        end else begin
            $display("[TEST] FAIL: Outputs remained high longer than 1 cycle. start_sign=%b, get_entropy=%b", start_sign, get_entropy);
            fail_count = fail_count + 1;
        end

        // Clean up
        @(negedge clk);
        req_sign = 0;
        engine_idle = 0;
        entropy_ready = 0;
        #20;

        // Final Report
        if (fail_count == 0 && pass_count > 0) begin
            $display("[TEST] PASS: FUNCTIONAL-REQ-1 verified successfully.");
        end else begin
            $display("[TEST] FAIL: Errors detected in FUNCTIONAL-REQ-1 verification.");
        end

        $finish;
    end

endmodule