`timescale 1ns/1ps

module tb_task_cwe_1279_seed6;

    // Inputs
    reg clk;
    reg rst_n;
    reg req_sign;
    reg entropy_ready;
    reg engine_idle;

    // Outputs
    wire start_sign;
    wire get_entropy;
    wire ctrl_busy;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_sign(req_sign),
        .entropy_ready(entropy_ready),
        .engine_idle(engine_idle),
        .start_sign(start_sign),
        .get_entropy(get_entropy),
        .ctrl_busy(ctrl_busy)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        req_sign = 0;
        entropy_ready = 0;
        engine_idle = 0;

        // Reset sequence
        #20;
        rst_n = 1;
        #10;

        // Stimulus: Trigger start_sign
        // We assert all necessary conditions: request, engine idle, and entropy ready.
        @(posedge clk);
        req_sign <= 1;
        engine_idle <= 1;
        entropy_ready <= 1;

        // Wait for the DUT to process inputs (1 cycle)
        @(posedge clk);
        #1; // Wait for propagation delay

        // Verification Logic
        if (start_sign === 1'b1) begin
            // Target Requirement: ctrl_busy must be asserted if start_sign is active
            if (ctrl_busy === 1'b1) begin
                $display("[TEST] PASS: ctrl_busy is asserted during the cycle start_sign is active.");
            end else begin
                $display("[TEST] FAIL: ctrl_busy is logic low while start_sign is active.");
            end
        end else begin
            // If start_sign didn't assert immediately, give it one more cycle (pipeline/state delay)
            @(posedge clk);
            #1;
            if (start_sign === 1'b1) begin
                if (ctrl_busy === 1'b1) begin
                    $display("[TEST] PASS: ctrl_busy is asserted during the cycle start_sign is active (delayed).");
                end else begin
                    $display("[TEST] FAIL: ctrl_busy is logic low while start_sign is active (delayed).");
                end
            end else begin
                // If we cannot trigger start_sign, the test setup failed or REQ-1 is broken,
                // preventing verification of REQ-2.
                $display("[TEST] FAIL: start_sign did not assert, could not verify ctrl_busy relationship.");
            end
        end

        // Cleanup
        @(posedge clk);
        req_sign <= 0;
        
        $finish;
    end

endmodule