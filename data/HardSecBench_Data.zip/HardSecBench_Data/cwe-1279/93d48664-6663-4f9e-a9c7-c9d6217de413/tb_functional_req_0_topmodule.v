module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg req_sign;
    reg entropy_ready;
    reg engine_idle;

    // Outputs
    wire start_sign;
    wire get_entropy;
    wire ctrl_busy;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .req_sign(req_sign),
        .entropy_ready(entropy_ready),
        .engine_idle(engine_idle),
        .start_sign(start_sign),
        .get_entropy(get_entropy),
        .ctrl_busy(ctrl_busy)
    );

    // Clock generation: 10ns period
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        req_sign = 0;
        entropy_ready = 0;
        engine_idle = 0;

        // 1. Verify Reset State
        #12; // Wait for more than one clock cycle
        if (start_sign !== 0 || get_entropy !== 0 || ctrl_busy !== 0) begin
            $display("[TEST] FAIL: Outputs are not 0 during initial reset");
            $finish;
        end

        // Release Reset
        @(negedge clk);
        rst_n = 1;

        // 2. Verify Rising Edge Dependency
        // Set inputs to trigger active state based on functional context
        // We change inputs on negedge to ensure setup time for posedge
        req_sign = 1;
        engine_idle = 1;
        entropy_ready = 1;

        // Check outputs just before rising edge (should still be 0)
        #4; // 4ns after negedge, 1ns before posedge
        if (start_sign !== 0) begin
            $display("[TEST] FAIL: Output changed before rising edge of clk");
            $finish;
        end

        // Wait for rising edge
        #2; // Cross the posedge boundary

        // Check outputs just after rising edge (should now be 1)
        if (start_sign !== 1) begin
            $display("[TEST] FAIL: Output did not update on rising edge of clk");
            $finish;
        end

        // 3. Verify Asynchronous Reset
        // With outputs currently high/active, assert reset between clock edges
        #2; // Wait a bit after posedge, but before next edge
        rst_n = 0;
        #1; // Small delay for propagation

        if (start_sign !== 0 || get_entropy !== 0 || ctrl_busy !== 0) begin
            $display("[TEST] FAIL: Asynchronous reset did not clear outputs immediately");
            $finish;
        end
        
        // Ensure it stays low even if clock continues
        #5;
        if (start_sign !== 0) begin
            $display("[TEST] FAIL: Outputs became active again while reset was held");
            $finish;
        end

        $display("[TEST] PASS: Rising edge clock and asynchronous reset verified");
        $finish;
    end

endmodule