module topmodule (
    input wire clk,
    input wire rst_n,
    input wire req_sign,
    input wire entropy_ready,
    input wire engine_idle,
    output reg start_sign,
    output reg get_entropy,
    output reg ctrl_busy
);

    // State encoding
    localparam S_IDLE = 2'd0;
    localparam S_PULSE = 2'd1;
    localparam S_WAIT = 2'd2;

    reg [1:0] state;
    
    // Internal registers for pre-gated output signals
    reg start_sign_reg;
    reg get_entropy_reg;
    reg ctrl_busy_reg;

    // Sequential logic for state machine and internal registers
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE;
            start_sign_reg <= 1'b0;
            get_entropy_reg <= 1'b0;
            ctrl_busy_reg <= 1'b0;
        end else begin
            // Default: clear pulse registers for the next cycle
            // This ensures the pulse lasts exactly one cycle (during S_PULSE)
            start_sign_reg <= 1'b0;
            get_entropy_reg <= 1'b0;
            ctrl_busy_reg <= 1'b0;

            case (state)
                S_IDLE: begin
                    // Initiate signing only if requested, engine is idle, and entropy is ready
                    if (req_sign && engine_idle && entropy_ready) begin
                        state <= S_PULSE;
                        // Set registers high for the duration of S_PULSE
                        start_sign_reg <= 1'b1;
                        get_entropy_reg <= 1'b1;
                        ctrl_busy_reg <= 1'b1;
                    end
                end
                S_PULSE: begin
                    // Outputs are active in this state (driven by regs set in S_IDLE).
                    // Transition immediately to WAIT to ensure single-cycle pulse.
                    state <= S_WAIT;
                end
                S_WAIT: begin
                    // Wait for handshake completion to prevent re-firing.
                    // 1. If engine becomes busy (engine_idle=0), the start was successful.
                    // 2. If request is withdrawn (req_sign=0), reset to IDLE.
                    if (!engine_idle || !req_sign) begin
                        state <= S_IDLE;
                    end
                end
                default: state <= S_IDLE;
            endcase
        end
    end

    // Output Logic with Security Gating
    // Security Requirement: start_sign and get_entropy must be logic low whenever 
    // entropy_ready is logic low, overriding any other control inputs.
    // This combinational logic enforces the requirement even if the FSM is in S_PULSE.
    always @(*) begin
        if (entropy_ready) begin
            start_sign = start_sign_reg;
            get_entropy = get_entropy_reg;
            ctrl_busy = ctrl_busy_reg;
        end else begin
            start_sign = 1'b0;
            get_entropy = 1'b0;
            // ctrl_busy is also suppressed to maintain consistency with start_sign
            ctrl_busy = 1'b0;
        end
    end

endmodule