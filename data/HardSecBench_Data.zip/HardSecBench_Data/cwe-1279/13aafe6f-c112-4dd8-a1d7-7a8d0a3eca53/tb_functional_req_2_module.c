#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

// Global state for mock callback
static bool boot_called = false;

// Mock callback function
void mock_boot_sequence(void) {
    boot_called = true;
}

// External function declaration
extern void module(const volatile uint32_t *device_status, uint32_t ready_mask, uint32_t timeout_ticks, void (*boot_sequence)(void), uint32_t *error_log);

int main(void) {
    // Test Case 1: Verify error_log is 0 when boot_sequence is executed
    {
        uint32_t status = 0x0000000F;
        uint32_t mask = 0x0000000F;       // Matches status immediately
        uint32_t timeout = 100;
        uint32_t error_log = 0xFFFFFFFF;  // Initialize with garbage
        
        boot_called = false;
        
        module(&status, mask, timeout, mock_boot_sequence, &error_log);
        
        // We check boot_called to ensure the precondition "if boot_sequence was executed" was met
        if (boot_called && error_log == 0) {
            printf("[CASE-1] PASS: error_log set to 0 upon successful boot execution.\n");
        } else {
            printf("[CASE-1] FAIL: Expected error_log=0 and boot_called=1. Got error_log=%u, boot_called=%d.\n", error_log, boot_called);
        }
    }

    // Test Case 2: Verify error_log is 1 when timeout is reached
    {
        uint32_t status = 0x00000000;     // Does not match mask
        uint32_t mask = 0x0000000F;
        uint32_t timeout = 10;
        uint32_t error_log = 0xFFFFFFFF;  // Initialize with garbage
        
        boot_called = false;
        
        module(&status, mask, timeout, mock_boot_sequence, &error_log);
        
        // We check !boot_called to ensure the precondition "polling loop terminates due to timeout" was met
        if (!boot_called && error_log == 1) {
            printf("[CASE-2] PASS: error_log set to 1 upon timeout.\n");
        } else {
            printf("[CASE-2] FAIL: Expected error_log=1 and boot_called=0. Got error_log=%u, boot_called=%d.\n", error_log, boot_called);
        }
    }

    return 0;
}