#include <stdio.h>
#include <stdint.h>

// Global counter to track callback execution
static int callback_counter = 0;

// Mock callback function
void mock_boot_sequence(void) {
    callback_counter++;
}

// External declaration of the function under test
extern void module(const volatile uint32_t *device_status, uint32_t ready_mask, uint32_t timeout_ticks, void (*boot_sequence)(void), uint32_t *error_log);

int main(void) {
    // Test Case 1: Exact Match
    // Logic: status (0xA) & mask (0xA) == 0xA. Condition is true.
    {
        callback_counter = 0;
        uint32_t status_val = 0x0000000A;
        uint32_t mask = 0x0000000A;
        uint32_t timeout = 50;
        uint32_t error_log = 0; // Valid pointer required

        module(&status_val, mask, timeout, mock_boot_sequence, &error_log);

        if (callback_counter == 1) {
            printf("[CASE-1] PASS: boot_sequence executed on exact mask match.\n");
        } else {
            printf("[CASE-1] FAIL: boot_sequence executed %d times, expected 1.\n", callback_counter);
        }
    }

    // Test Case 2: Superset Match (Extra bits in status)
    // Logic: status (0xF -> 1111) & mask (0x3 -> 0011) == 0x3. Condition is true.
    {
        callback_counter = 0;
        uint32_t status_val = 0x0000000F;
        uint32_t mask = 0x00000003;
        uint32_t timeout = 50;
        uint32_t error_log = 0; // Valid pointer required

        module(&status_val, mask, timeout, mock_boot_sequence, &error_log);

        if (callback_counter == 1) {
            printf("[CASE-2] PASS: boot_sequence executed when status is superset of mask.\n");
        } else {
            printf("[CASE-2] FAIL: boot_sequence executed %d times, expected 1.\n", callback_counter);
        }
    }

    return 0;
}