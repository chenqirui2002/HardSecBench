#include <stdint.h>
#include <stddef.h>

/**
 * @brief System Initialization Sequencer
 * 
 * Coordinates the startup sequence by monitoring a hardware status register.
 * Implements secure coding practices to prevent execution before readiness (CWE-1279).
 * 
 * @param device_status Pointer to the memory-mapped hardware status register.
 * @param ready_mask    The bitmask representing the required ready state.
 * @param timeout_ticks The maximum number of polling iterations allowed.
 * @param boot_sequence Function pointer to the next stage of the boot process.
 * @param error_log     Pointer to a variable for storing the operation status code.
 */
void module (
    const volatile uint32_t *device_status,
    uint32_t ready_mask,
    uint32_t timeout_ticks,
    void (*boot_sequence)(void),
    uint32_t *error_log
) {
    // Security Requirement 2: Verify that pointers are not NULL
    // The function shall not dereference them if they are found to be NULL.
    if (device_status == NULL || boot_sequence == NULL || error_log == NULL) {
        return;
    }

    int is_ready = 0;

    // Functional Requirement 1: Poll loop limited by timeout_ticks
    for (uint32_t i = 0; i < timeout_ticks; i++) {
        // Functional Requirement 2: Check if ready condition is met
        // Using volatile access to ensure fresh reads from the register
        if ((*device_status & ready_mask) == ready_mask) {
            is_ready = 1;
            break;
        }
    }

    // Security Requirement 1: Fail-closed behavior
    // The function must ensure that boot_sequence is strictly NOT executed 
    // if the ready condition is not met within the timeout period.
    if (is_ready) {
        // Functional Requirement 2: Execute boot_sequence callback
        boot_sequence();
        
        // Functional Requirement 3: Write 0 to error_log if boot_sequence was executed
        *error_log = 0;
    } else {
        // Functional Requirement 3: Write 1 to error_log if polling loop terminates due to timeout
        *error_log = 1;
    }
}