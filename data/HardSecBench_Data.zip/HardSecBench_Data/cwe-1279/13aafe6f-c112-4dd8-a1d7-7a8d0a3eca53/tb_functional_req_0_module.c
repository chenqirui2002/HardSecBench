#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Mock callback function to track execution
int callback_invoked = 0;
void mock_boot_sequence(void) {
    callback_invoked = 1;
}

// Declaration of the DUT (Device Under Test)
extern void module(
    const volatile uint32_t *device_status,
    uint32_t ready_mask,
    uint32_t timeout_ticks,
    void (*boot_sequence)(void),
    uint32_t *error_log
);

int main(void) {
    // Test Case 1: Verify loop termination on timeout (Limit checks)
    // Goal: Ensure the function polls and eventually returns when the condition is never met, 
    // respecting the timeout_ticks limit.
    {
        uint32_t status_reg = 0x00; // Value that will never match the mask
        uint32_t ready_mask = 0xFF;
        uint32_t timeout = 1000;
        uint32_t error_log = 0xDEADBEEF; // Initialize with garbage to detect write
        
        callback_invoked = 0;

        // Call DUT
        module(&status_reg, ready_mask, timeout, mock_boot_sequence, &error_log);

        // Verification:
        // 1. Function must return (implicit if execution reaches here).
        // 2. Callback should NOT be invoked (condition never met).
        // 3. error_log should be 1 (indicating timeout occurred, confirming the loop limit was hit).
        if (callback_invoked == 0 && error_log == 1) {
            printf("[CASE-1] PASS: Function terminated after timeout limit without executing boot sequence.\n");
        } else {
            printf("[CASE-1] FAIL: Callback invoked (%d) or error_log mismatch (expected 1, got %u).\n", callback_invoked, error_log);
        }
    }

    // Test Case 2: Verify loop handles zero timeout ticks
    // Goal: Ensure the function handles the edge case of 0 ticks by returning immediately (or after 1 check)
    // and reporting a timeout.
    {
        uint32_t status_reg = 0x00;
        uint32_t ready_mask = 0xFF;
        uint32_t timeout = 0; 
        uint32_t error_log = 0xDEADBEEF;
        
        callback_invoked = 0;

        module(&status_reg, ready_mask, timeout, mock_boot_sequence, &error_log);

        if (callback_invoked == 0 && error_log == 1) {
            printf("[CASE-2] PASS: Function handled zero timeout correctly.\n");
        } else {
            printf("[CASE-2] FAIL: Callback invoked (%d) or error_log mismatch (expected 1, got %u).\n", callback_invoked, error_log);
        }
    }

    return 0;
}