`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs to UUT
    reg clk;
    reg rst_n;
    reg pll_lock;
    reg start_cmd;
    reg key_load;

    // Outputs from UUT
    wire rsa_rst_n;
    wire rsa_start;
    wire rsa_key_load;
    wire system_ready;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .pll_lock(pll_lock),
        .start_cmd(start_cmd),
        .key_load(key_load),
        .rsa_rst_n(rsa_rst_n),
        .rsa_start(rsa_start),
        .rsa_key_load(rsa_key_load),
        .system_ready(system_ready)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns period
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        pll_lock = 1; // Set valid lock to avoid interference from other logic
        start_cmd = 0;
        key_load = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // Test Case 1: Verify capture of start_cmd=1, key_load=0
        @(negedge clk); // Change inputs away from active edge
        start_cmd = 1;
        key_load = 0;
        
        @(posedge clk); // Wait for capture edge
        #1; // Small delay for propagation
        if (rsa_start !== 1'b1 || rsa_key_load !== 1'b0) begin
            $display("[TEST] FAIL: Failed to capture start_cmd=1, key_load=0 on rising edge.");
            $finish;
        end

        // Test Case 2: Verify capture of start_cmd=0, key_load=1
        // Also verify outputs don't change before the clock edge (Registered behavior check)
        @(negedge clk);
        start_cmd = 0;
        key_load = 1;
        
        #1; // Check immediately after input change (still low clock)
        if (rsa_start !== 1'b1 || rsa_key_load !== 1'b0) begin
            $display("[TEST] FAIL: Outputs changed asynchronously (combinational logic detected instead of registered).");
            $finish;
        end

        @(posedge clk);
        #1;
        if (rsa_start !== 1'b0 || rsa_key_load !== 1'b1) begin
            $display("[TEST] FAIL: Failed to capture start_cmd=0, key_load=1 on rising edge.");
            $finish;
        end

        // Test Case 3: Verify capture of start_cmd=1, key_load=1
        @(negedge clk);
        start_cmd = 1;
        key_load = 1;
        
        @(posedge clk);
        #1;
        if (rsa_start !== 1'b1 || rsa_key_load !== 1'b1) begin
            $display("[TEST] FAIL: Failed to capture start_cmd=1, key_load=1 on rising edge.");
            $finish;
        end

        // Test Case 4: Verify capture of start_cmd=0, key_load=0
        @(negedge clk);
        start_cmd = 0;
        key_load = 0;
        
        @(posedge clk);
        #1;
        if (rsa_start !== 1'b0 || rsa_key_load !== 1'b0) begin
            $display("[TEST] FAIL: Failed to capture start_cmd=0, key_load=0 on rising edge.");
            $finish;
        end

        $display("[TEST] PASS: rsa_start and rsa_key_load correctly registered inputs on rising edge.");
        $finish;
    end

endmodule