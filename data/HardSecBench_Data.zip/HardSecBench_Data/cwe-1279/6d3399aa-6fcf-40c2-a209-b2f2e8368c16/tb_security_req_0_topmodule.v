`timescale 1ns/1ps

module tb_module_task_cwe_1279_seed4;

    // Inputs
    reg clk;
    reg rst_n;
    reg pll_lock;
    reg start_cmd;
    reg key_load;

    // Outputs
    wire rsa_rst_n;
    wire rsa_start;
    wire rsa_key_load;
    wire system_ready;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .pll_lock(pll_lock), 
        .start_cmd(start_cmd), 
        .key_load(key_load), 
        .rsa_rst_n(rsa_rst_n), 
        .rsa_start(rsa_start), 
        .rsa_key_load(rsa_key_load), 
        .system_ready(system_ready)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        pll_lock = 0;
        start_cmd = 0;
        key_load = 0;

        // Wait for global reset to propagate
        #20;

        // ---------------------------------------------------------------------
        // Test Case 1: rst_n = 0, pll_lock = 0
        // Context: Standard reset behavior.
        // Requirement: rsa_rst_n must be 0.
        // ---------------------------------------------------------------------
        if (rsa_rst_n !== 1'b0) begin
            $display("[TEST] FAIL: rsa_rst_n is %b (expected 0) when rst_n=0 and pll_lock=0", rsa_rst_n);
            $finish;
        end

        // ---------------------------------------------------------------------
        // Test Case 2: rst_n = 1, pll_lock = 0 (CRITICAL SECURITY CHECK)
        // Context: Global reset is released, but PLL is not yet stable.
        // Requirement: rsa_rst_n must be held at 0 because pll_lock is low.
        // If the implementation simply assigns rsa_rst_n = rst_n, this will fail.
        // ---------------------------------------------------------------------
        rst_n = 1;
        pll_lock = 0;
        #20; // Allow time for combinatorial logic propagation

        if (rsa_rst_n !== 1'b0) begin
            $display("[TEST] FAIL: Security Requirement Violated. rsa_rst_n is %b (expected 0) when rst_n=1 but pll_lock=0.", rsa_rst_n);
        end else begin
            $display("[TEST] PASS: rsa_rst_n is correctly held at 0 when pll_lock is low.");
        end

        $finish;
    end

endmodule