module topmodule (
    input wire clk,
    input wire rst_n,
    input wire pll_lock,
    input wire start_cmd,
    input wire key_load,
    output wire rsa_rst_n,
    output reg rsa_start,
    output reg rsa_key_load,
    output wire system_ready
);

    // Functional Requirement 1: system_ready output shall continuously reflect the logic state of the pll_lock input.
    assign system_ready = pll_lock;

    // Functional Requirement 3: rsa_rst_n output shall be asynchronously asserted whenever rst_n is 0.
    // Security Requirement 1: rsa_rst_n output must be held at logic 0 whenever pll_lock is low.
    // Implementation: AND gate ensures rsa_rst_n is low if either rst_n is low OR pll_lock is low.
    assign rsa_rst_n = rst_n & pll_lock;

    // Functional Requirement 2: rsa_start and rsa_key_load shall be registered signals 
    // capturing start_cmd and key_load on the rising edge of clk.
    // Standard asynchronous reset is included to ensure defined state on power-up/reset.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rsa_start <= 1'b0;
            rsa_key_load <= 1'b0;
        end else begin
            rsa_start <= start_cmd;
            rsa_key_load <= key_load;
        end
    end

endmodule