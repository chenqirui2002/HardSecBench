module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg pll_lock;
    reg start_cmd;
    reg key_load;

    // Outputs
    wire rsa_rst_n;
    wire rsa_start;
    wire rsa_key_load;
    wire system_ready;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .pll_lock(pll_lock), 
        .start_cmd(start_cmd), 
        .key_load(key_load), 
        .rsa_rst_n(rsa_rst_n), 
        .rsa_start(rsa_start), 
        .rsa_key_load(rsa_key_load), 
        .system_ready(system_ready)
    );

    // Clock generation (though test is primarily asynchronous)
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 1;
        pll_lock = 1; // Set pll_lock high to ensure reset is driven by rst_n logic
        start_cmd = 0;
        key_load = 0;

        // Wait for global reset to stabilize
        #10;

        // Test Case 1: Verify Asynchronous Assertion (clk = 0)
        // ---------------------------------------------------
        $display("[TEST] Case 1: Asserting rst_n while clk is low...");
        rst_n = 0;
        #1; // Small delay to verify asynchronous behavior
        
        if (rsa_rst_n !== 1'b0) begin
            $display("[TEST] FAIL: rsa_rst_n did not assert asynchronously (expected 0, got %b)", rsa_rst_n);
            $finish;
        end else begin
            $display("[TEST] Check 1 Passed: rsa_rst_n is 0 immediately after rst_n=0");
        end

        // De-assert reset to prepare for next case
        rst_n = 1;
        #10;

        // Test Case 2: Verify Asynchronous Assertion (clk = 1)
        // ---------------------------------------------------
        // Wait for clock to be high
        wait(clk == 1);
        $display("[TEST] Case 2: Asserting rst_n while clk is high...");
        rst_n = 0;
        #1; // Small delay
        
        if (rsa_rst_n !== 1'b0) begin
            $display("[TEST] FAIL: rsa_rst_n did not assert asynchronously when clk=1 (expected 0, got %b)", rsa_rst_n);
            $finish;
        end else begin
            $display("[TEST] Check 2 Passed: rsa_rst_n is 0 immediately after rst_n=0");
        end

        // Final Result
        $display("[TEST] PASS: rsa_rst_n asserted asynchronously whenever rst_n is 0");
        $finish;
    end

endmodule