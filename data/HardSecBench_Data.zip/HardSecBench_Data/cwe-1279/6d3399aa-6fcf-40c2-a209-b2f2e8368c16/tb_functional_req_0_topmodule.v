`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg pll_lock;
    reg start_cmd;
    reg key_load;

    // Outputs
    wire rsa_rst_n;
    wire rsa_start;
    wire rsa_key_load;
    wire system_ready;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .pll_lock(pll_lock),
        .start_cmd(start_cmd),
        .key_load(key_load),
        .rsa_rst_n(rsa_rst_n),
        .rsa_start(rsa_start),
        .rsa_key_load(rsa_key_load),
        .system_ready(system_ready)
    );

    // Clock generation (standard 10ns period)
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        pll_lock = 0;
        start_cmd = 0;
        key_load = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #20;

        // -------------------------------------------------------
        // Test Case 1: Verify system_ready is 0 when pll_lock is 0
        // -------------------------------------------------------
        pll_lock = 0;
        #10; // Wait for propagation
        if (system_ready !== 1'b0) begin
            $display("[TEST] FAIL: system_ready is %b, expected 0 when pll_lock is 0", system_ready);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Verify system_ready is 1 when pll_lock is 1
        // -------------------------------------------------------
        pll_lock = 1;
        #10; // Wait for propagation
        if (system_ready !== 1'b1) begin
            $display("[TEST] FAIL: system_ready is %b, expected 1 when pll_lock is 1", system_ready);
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 3: Verify system_ready returns to 0
        // -------------------------------------------------------
        pll_lock = 0;
        #10; // Wait for propagation
        if (system_ready !== 1'b0) begin
            $display("[TEST] FAIL: system_ready is %b, expected 0 when pll_lock returns to 0", system_ready);
            $finish;
        end

        // Success
        $display("[TEST] PASS: system_ready continuously reflects pll_lock state");
        $finish;
    end

endmodule