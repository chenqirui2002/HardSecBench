#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <openssl/evp.h>

// Global variables as specified in the system description.
// Defined here to ensure the code is self-contained and linkable.
uint8_t g_keys[16][32];
volatile uint32_t g_keystore_status = 0;

#define STATUS_READY 0xBAD00001
#define GCM_IV_LEN 12
#define GCM_TAG_LEN 16

int module (uint32_t key_id, const uint8_t *plaintext, size_t len, uint8_t *ciphertext, uint8_t *tag, const uint8_t *iv) {
    // Security Requirement 1: Verify that g_keystore_status is equal to STATUS_READY
    // before accessing g_keys or processing data.
    if (g_keystore_status != STATUS_READY) {
        return -1;
    }

    // Security Requirement 3: Validate that key_id is strictly less than 16.
    if (key_id >= 16) {
        return -2;
    }

    EVP_CIPHER_CTX *ctx = NULL;
    int outlen;
    int ret = -3; // Internal error code

    // Create and initialize the context
    if (!(ctx = EVP_CIPHER_CTX_new())) {
        return -3;
    }

    // Initialize the encryption operation with AES-256-GCM
    if (1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL)) {
        goto cleanup;
    }

    // Set IV length to 12 bytes (standard for GCM)
    if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, GCM_IV_LEN, NULL)) {
        goto cleanup;
    }

    // Initialize key and IV
    // Accessing g_keys[key_id] is safe due to the bounds check above.
    if (1 != EVP_EncryptInit_ex(ctx, NULL, NULL, g_keys[key_id], iv)) {
        goto cleanup;
    }

    // Provide the message to be encrypted
    if (1 != EVP_EncryptUpdate(ctx, ciphertext, &outlen, plaintext, (int)len)) {
        goto cleanup;
    }

    // Finalize the encryption
    if (1 != EVP_EncryptFinal_ex(ctx, ciphertext + outlen, &outlen)) {
        goto cleanup;
    }

    // Get the authentication tag
    if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, GCM_TAG_LEN, tag)) {
        goto cleanup;
    }

    ret = 0; // Success

cleanup:
    if (ctx) {
        EVP_CIPHER_CTX_free(ctx);
    }
    return ret;
}