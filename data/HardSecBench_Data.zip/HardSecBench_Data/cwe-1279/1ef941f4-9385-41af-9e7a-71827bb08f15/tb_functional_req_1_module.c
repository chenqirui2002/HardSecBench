#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// --- OpenSSL Mocks ---
// Mocks are required because the build environment does not link -lcrypto.
// These mocks simulate the behavior of AES-GCM for functional verification.

typedef struct evp_cipher_ctx_st EVP_CIPHER_CTX;
typedef struct evp_cipher_st EVP_CIPHER;
typedef struct engine_st ENGINE;

// Mock constants matching OpenSSL headers
#define EVP_CTRL_GCM_SET_IVLEN 0x9
#define EVP_CTRL_GCM_GET_TAG   0x10

// Mock implementation
EVP_CIPHER_CTX *EVP_CIPHER_CTX_new(void) {
    // Return a dummy pointer
    return (EVP_CIPHER_CTX *)malloc(1);
}

void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *ctx) {
    free(ctx);
}

const EVP_CIPHER *EVP_aes_256_gcm(void) {
    return (const EVP_CIPHER *)0xDEADBEEF;
}

int EVP_EncryptInit_ex(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *cipher, ENGINE *impl, const unsigned char *key, const unsigned char *iv) {
    return 1; // Success
}

int EVP_EncryptUpdate(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl, const unsigned char *in, int inl) {
    // Simulate encryption by bit-inverting the input
    // This allows us to verify data flow from plaintext -> ciphertext
    for (int i = 0; i < inl; i++) {
        out[i] = ~in[i];
    }
    *outl = inl;
    return 1; // Success
}

int EVP_EncryptFinal_ex(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl) {
    // GCM normally outputs 0 bytes in Final
    *outl = 0;
    return 1; // Success
}

int EVP_CIPHER_CTX_ctrl(EVP_CIPHER_CTX *ctx, int type, int arg, void *ptr) {
    if (type == EVP_CTRL_GCM_SET_IVLEN) {
        return 1; // Success
    }
    if (type == EVP_CTRL_GCM_GET_TAG) {
        // Write a specific pattern (0x77) to the tag buffer
        // This allows us to verify the function retrieved the tag
        memset(ptr, 0x77, arg); 
        return 1; // Success
    }
    return 0;
}
// --- End OpenSSL Mocks ---

// Global variables defined in the implementation file
extern uint8_t g_keys[16][32];
extern volatile uint32_t g_keystore_status;

// Function prototype
extern int module(uint32_t key_id, const uint8_t *plaintext, size_t len, uint8_t *ciphertext, uint8_t *tag, const uint8_t *iv);

#define STATUS_READY 0xBAD00001

int main() {
    // Test Case 1: Verify ciphertext and tag generation
    {
        // 1. Setup Environment
        // Initialize globals (accessing the extern variables)
        memset(g_keys, 0, 16 * 32);
        
        // Set status to READY to allow function execution
        g_keystore_status = STATUS_READY;

        // 2. Prepare Inputs
        uint32_t key_id = 0;
        const char *msg = "TestPayload";
        size_t len = strlen(msg);
        
        uint8_t plaintext[64];
        memset(plaintext, 0, sizeof(plaintext));
        memcpy(plaintext, msg, len);

        uint8_t iv[12] = {0};

        // 3. Prepare Outputs with guard values
        uint8_t ciphertext[64];
        uint8_t tag[16];
        
        // Initialize with 0x00 to detect writes
        memset(ciphertext, 0x00, sizeof(ciphertext));
        memset(tag, 0x00, sizeof(tag));

        // 4. Execute Function
        int result = module(key_id, plaintext, len, ciphertext, tag, iv);

        // 5. Verify Results
        int fail = 0;
        
        // Check Return Value
        if (result != 0) {
            printf("[CASE-1] FAIL: Function returned %d, expected 0\n", result);
            fail = 1;
        }

        // Check Ciphertext
        // Our mock inverts bits (~). 'T' (0x54) -> 0xAB.
        // If ciphertext[0] is ~plaintext[0], the function correctly passed data to EncryptUpdate
        if (ciphertext[0] != (uint8_t)(~msg[0])) {
            printf("[CASE-1] FAIL: Ciphertext incorrect. Expected ~Input, got %02X\n", ciphertext[0]);
            fail = 1;
        }

        // Check Tag
        // Our mock writes 0x77 to the tag buffer.
        // If tag[0] is 0x77, the function correctly called CTRL_GCM_GET_TAG
        if (tag[0] != 0x77) {
            printf("[CASE-1] FAIL: Tag incorrect. Expected 0x77, got %02X\n", tag[0]);
            fail = 1;
        }

        if (!fail) {
            printf("[CASE-1] PASS: Ciphertext and Tag were populated correctly\n");
        }
    }

    return 0;
}