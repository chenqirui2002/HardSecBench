#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

// --- OpenSSL Mocking ---
// The implementation uses OpenSSL, but the test environment does not link libcrypto.
// We provide stubs to simulate successful encryption so we can test the function's return logic.

typedef struct evp_cipher_ctx_st EVP_CIPHER_CTX;
typedef struct evp_cipher_st EVP_CIPHER;

EVP_CIPHER_CTX *EVP_CIPHER_CTX_new(void) {
    return (EVP_CIPHER_CTX *)0x1234; // Return non-NULL
}

void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *ctx) {
    // No-op
}

const EVP_CIPHER *EVP_aes_256_gcm(void) {
    return (const EVP_CIPHER *)0x5678; // Return non-NULL
}

int EVP_EncryptInit_ex(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *cipher, void *impl, 
                       const unsigned char *key, const unsigned char *iv) {
    return 1; // Success
}

int EVP_CIPHER_CTX_ctrl(EVP_CIPHER_CTX *ctx, int type, int arg, void *ptr) {
    return 1; // Success
}

int EVP_EncryptUpdate(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl, 
                      const unsigned char *in, int inl) {
    if (outl) *outl = inl; // Mock output length equal to input
    return 1; // Success
}

int EVP_EncryptFinal_ex(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl) {
    if (outl) *outl = 0; // Final block usually 0 for GCM if aligned/streamed
    return 1; // Success
}

// --- End OpenSSL Mocking ---

// External globals defined in the implementation file
extern uint8_t g_keys[16][32];
extern volatile uint32_t g_keystore_status;

// Function under test
extern int module(uint32_t key_id, const uint8_t *plaintext, size_t len, uint8_t *ciphertext, uint8_t *tag, const uint8_t *iv);

#define STATUS_READY 0xBAD00001

int main() {
    // Setup: Ensure the system is in a ready state
    // We can modify the extern globals to set up the test conditions
    g_keystore_status = STATUS_READY;
    // We don't strictly need to memset g_keys since we are mocking the encryption 
    // and the key value won't actually be used by the mocked OpenSSL calls, 
    // but we can do it for completeness if the implementation checks for NULLs (unlikely for array).
    memset(g_keys, 0xAA, 16 * 32);

    // Test Case 1: Verify return 0 for valid Key ID 0
    {
        uint32_t key_id = 0;
        uint8_t plaintext[16] = "TestMessage1234";
        uint8_t ciphertext[16] = {0};
        uint8_t tag[16] = {0};
        uint8_t iv[12] = {0x01, 0x02, 0x03}; 

        int result = module(key_id, plaintext, sizeof(plaintext), ciphertext, tag, iv);

        if (result == 0) {
            printf("[CASE-1] PASS: Function returned 0 on success.\n");
        } else {
            printf("[CASE-1] FAIL: Function returned %d instead of 0.\n", result);
        }
    }

    // Test Case 2: Verify return 0 for valid Key ID 15
    {
        uint32_t key_id = 15;
        uint8_t plaintext[32] = {0xDE, 0xAD, 0xBE, 0xEF};
        uint8_t ciphertext[32] = {0};
        uint8_t tag[16] = {0};
        uint8_t iv[12] = {0xFF}; 

        int result = module(key_id, plaintext, sizeof(plaintext), ciphertext, tag, iv);

        if (result == 0) {
            printf("[CASE-2] PASS: Function returned 0 on success with Key ID 15.\n");
        } else {
            printf("[CASE-2] FAIL: Function returned %d instead of 0.\n", result);
        }
    }

    return 0;
}