#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// --- MOCKING OPENSSL DEFINITIONS ---
// Since the environment lacks the OpenSSL library, we mock the necessary types and functions
// to verify the logic of the function under test (key retrieval and data flow).

typedef struct {
    int dummy;
} EVP_CIPHER_CTX;

typedef struct {
    int dummy;
} EVP_CIPHER;

#define EVP_CTRL_GCM_SET_IVLEN 0x9
#define EVP_CTRL_GCM_GET_TAG   0x10
#define EVP_CTRL_GCM_SET_TAG   0x11

// Test instrumentation variables
uint8_t mock_captured_key[32];
int mock_key_captured = 0;

// Mock functions
EVP_CIPHER_CTX *EVP_CIPHER_CTX_new(void) {
    return (EVP_CIPHER_CTX *)malloc(sizeof(EVP_CIPHER_CTX));
}

void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *ctx) {
    free(ctx);
}

const EVP_CIPHER *EVP_aes_256_gcm(void) {
    static EVP_CIPHER cipher;
    return &cipher;
}

int EVP_EncryptInit_ex(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *cipher, void *impl,
                       const unsigned char *key, const unsigned char *iv) {
    if (key != NULL) {
        memcpy(mock_captured_key, key, 32);
        mock_key_captured = 1;
    }
    return 1; // Success
}

int EVP_CIPHER_CTX_ctrl(EVP_CIPHER_CTX *ctx, int type, int arg, void *ptr) {
    if (type == EVP_CTRL_GCM_GET_TAG) {
        // Write a dummy tag
        memset(ptr, 0xAA, arg); 
    }
    return 1; // Success
}

int EVP_EncryptUpdate(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl,
                      const unsigned char *in, int inl) {
    // Simulate encryption by copying input to output (Identity transform)
    if (in != NULL && out != NULL) {
        memcpy(out, in, inl);
    }
    *outl = inl;
    return 1; // Success
}

int EVP_EncryptFinal_ex(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl) {
    *outl = 0;
    return 1; // Success
}

// --- END MOCKS ---

// External Globals (Defined in the implementation file)
extern uint8_t g_keys[16][32];
extern volatile uint32_t g_keystore_status;

// Function under test
extern int module(uint32_t key_id, const uint8_t *plaintext, size_t len, uint8_t *ciphertext, uint8_t *tag, const uint8_t *iv);

#define STATUS_READY 0xBAD00001

int main(void) {
    // Test Data
    const uint8_t test_key_1[32] = {
        0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 
        0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00,
        0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 
        0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00
    };
    
    const uint8_t test_iv[12] = {0};
    const uint8_t test_pt[] = "Hello World Data";
    uint8_t ciphertext[64];
    uint8_t tag[16];

    // Case 1: Verify Key Retrieval
    // Requirement: The function shall retrieve the 32-byte key from g_keys at index key_id
    {
        uint32_t target_id = 2;
        
        // Reset state
        memset(g_keys, 0, sizeof(g_keys));
        memcpy(g_keys[target_id], test_key_1, 32);
        g_keystore_status = STATUS_READY;
        
        memset(mock_captured_key, 0, 32);
        mock_key_captured = 0;
        memset(ciphertext, 0, sizeof(ciphertext));

        // Execute
        int ret = module(target_id, test_pt, sizeof(test_pt), ciphertext, tag, test_iv);

        // Verify Return Code
        if (ret != 0) {
            printf("[CASE-1] FAIL: Function returned %d, expected 0\n", ret);
        } else {
            // Verify Key Usage
            if (mock_key_captured && memcmp(mock_captured_key, test_key_1, 32) == 0) {
                // Verify Data Flow (Mock copies PT to CT)
                if (memcmp(ciphertext, test_pt, sizeof(test_pt)) == 0) {
                    printf("[CASE-1] PASS: Correct key retrieved from index %u and used for processing\n", target_id);
                } else {
                    printf("[CASE-1] FAIL: Key correct, but data processing failed (Ciphertext != Plaintext in mock)\n");
                }
            } else {
                printf("[CASE-1] FAIL: Incorrect key used. Captured: %02x, Expected: %02x\n", mock_captured_key[0], test_key_1[0]);
            }
        }
    }

    // Case 2: Verify Index Sensitivity
    // Requirement: Ensure changing the index changes the retrieved key
    {
        uint32_t target_id = 5;
        uint8_t other_key[32];
        memset(other_key, 0xEE, 32);

        // Reset state
        memset(g_keys, 0, sizeof(g_keys));
        memcpy(g_keys[target_id], other_key, 32);
        g_keystore_status = STATUS_READY;
        
        memset(mock_captured_key, 0, 32);
        mock_key_captured = 0;

        // Execute
        module(target_id, test_pt, sizeof(test_pt), ciphertext, tag, test_iv);

        // Verify
        if (mock_key_captured && memcmp(mock_captured_key, other_key, 32) == 0) {
            printf("[CASE-2] PASS: Key retrieval respects key_id parameter\n");
        } else {
            printf("[CASE-2] FAIL: Key mismatch for index %u\n", target_id);
        }
    }

    return 0;
}