#include <stdio.h>
#include <stdint.h>
#include <string.h>

/* 
 * External globals defined in the DUT (Device Under Test).
 * We declare them extern to avoid multiple definition errors while
 * still being able to manipulate the state (g_keystore_status).
 */
extern uint8_t g_keys[16][32];
extern volatile uint32_t g_keystore_status;

/* Function declaration */
extern int module(uint32_t key_id, const uint8_t *plaintext, size_t len, uint8_t *ciphertext, uint8_t *tag, const uint8_t *iv);

/* 
 * OpenSSL Stubs 
 * The DUT links against OpenSSL functions. Since we are testing bounds checks
 * that happen BEFORE encryption, we provide dummy implementations to satisfy 
 * the linker.
 */

// Opaque pointer types for stubs
typedef void EVP_CIPHER_CTX;
typedef void EVP_CIPHER;

EVP_CIPHER_CTX *EVP_CIPHER_CTX_new(void) {
    static int dummy = 0;
    return (EVP_CIPHER_CTX*)&dummy; // Return non-NULL
}

const EVP_CIPHER *EVP_aes_256_gcm(void) {
    static int dummy = 0;
    return (const EVP_CIPHER*)&dummy; // Return non-NULL
}

int EVP_EncryptInit_ex(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *cipher, void *impl, const unsigned char *key, const unsigned char *iv) {
    return 1; // Success
}

int EVP_CIPHER_CTX_ctrl(EVP_CIPHER_CTX *ctx, int type, int arg, void *ptr) {
    return 1; // Success
}

int EVP_EncryptUpdate(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl, const unsigned char *in, int inl) {
    *outl = inl; // Pretend we encrypted everything
    return 1; // Success
}

int EVP_EncryptFinal_ex(EVP_CIPHER_CTX *ctx, unsigned char *out, int *outl) {
    *outl = 0;
    return 1; // Success
}

void EVP_CIPHER_CTX_free(EVP_CIPHER_CTX *ctx) {
    // No-op
}

int main() {
    // Setup dummy buffers
    uint8_t plaintext[16] = {0};
    uint8_t ciphertext[16] = {0};
    uint8_t tag[16] = {0};
    uint8_t iv[12] = {0};
    size_t len = 16;

    // PRECONDITION: Set keystore status to READY (0xBAD00001)
    // This allows us to bypass the first check and reach the key_id check.
    g_keystore_status = 0xBAD00001;

    // Test Case 1: Boundary Condition (key_id = 16)
    // The array size is 16, so indices 0-15 are valid. 16 must be rejected.
    {
        int ret = module(16, plaintext, len, ciphertext, tag, iv);
        if (ret == -2) {
            printf("[CASE-1] PASS: key_id 16 correctly rejected with -2\n");
        } else {
            printf("[CASE-1] FAIL: key_id 16 returned %d, expected -2\n", ret);
        }
    }

    // Test Case 2: Large Out-of-Bounds (key_id = 100)
    // Ensures that values significantly outside the range are also caught.
    {
        int ret = module(100, plaintext, len, ciphertext, tag, iv);
        if (ret == -2) {
            printf("[CASE-2] PASS: key_id 100 correctly rejected with -2\n");
        } else {
            printf("[CASE-2] FAIL: key_id 100 returned %d, expected -2\n", ret);
        }
    }

    // Test Case 3: Valid ID (key_id = 0)
    // Ensures valid inputs are processed (returns 0 via stubs).
    {
        int ret = module(0, plaintext, len, ciphertext, tag, iv);
        if (ret == 0) {
            printf("[CASE-3] PASS: key_id 0 accepted\n");
        } else {
            printf("[CASE-3] FAIL: key_id 0 returned %d, expected 0\n", ret);
        }
    }

    return 0;
}