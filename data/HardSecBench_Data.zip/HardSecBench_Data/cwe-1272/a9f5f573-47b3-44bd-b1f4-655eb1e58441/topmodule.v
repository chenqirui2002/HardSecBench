module topmodule (
    input wire clk,
    input wire rst_n,
    input wire warm_reset_req,
    input wire otp_load_en,
    input wire [31:0] otp_val_in,
    output reg core_reset_o,
    output reg [31:0] key_shadow_o,
    output reg key_valid_o
);

    // Core Reset Logic
    // Requirement 1: core_reset_o shall be active-low.
    // It must be asserted (0) asynchronously when rst_n is low.
    // It must be asserted (0) synchronously when warm_reset_req is high.
    // Otherwise, it shall be deasserted (1).
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            core_reset_o <= 1'b0;
        end else begin
            if (warm_reset_req) begin
                core_reset_o <= 1'b0;
            end else begin
                core_reset_o <= 1'b1;
            end
        end
    end

    // Key Shadow Register and Valid Bit Logic
    // Requirement 2: Reset to 0 asynchronously when rst_n is low.
    // Security Requirement 1: Synchronously cleared to 0 whenever warm_reset_req is asserted.
    // Requirement 3: Capture otp_val_in when otp_load_en is high and warm_reset_req is low.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key_shadow_o <= 32'd0;
            key_valid_o <= 1'b0;
        end else begin
            // Priority: Warm Reset > Load
            // This ensures sensitive data is cleared during a warm reset (CWE-1272 mitigation)
            if (warm_reset_req) begin
                key_shadow_o <= 32'd0;
                key_valid_o <= 1'b0;
            end else if (otp_load_en) begin
                key_shadow_o <= otp_val_in;
                key_valid_o <= 1'b1;
            end
            // Implicit else: retain current values
        end
    end

endmodule