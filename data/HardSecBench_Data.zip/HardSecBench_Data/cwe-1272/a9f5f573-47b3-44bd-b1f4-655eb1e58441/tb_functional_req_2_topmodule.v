module tb_task_cwe_1272_seed6;

    // Inputs
    reg clk;
    reg rst_n;
    reg warm_reset_req;
    reg otp_load_en;
    reg [31:0] otp_val_in;

    // Outputs
    wire core_reset_o;
    wire [31:0] key_shadow_o;
    wire key_valid_o;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .warm_reset_req(warm_reset_req),
        .otp_load_en(otp_load_en),
        .otp_val_in(otp_val_in),
        .core_reset_o(core_reset_o),
        .key_shadow_o(key_shadow_o),
        .key_valid_o(key_valid_o)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;
    reg [31:0] test_val;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        warm_reset_req = 0;
        otp_load_en = 0;
        otp_val_in = 0;

        // Apply cold reset
        #20;
        rst_n = 1;
        #20;

        // Test Loop for Requirement [FUNCTIONAL-REQ-2]
        // Condition: otp_load_en == 1 && warm_reset_req == 0
        for (i = 0; i < 5; i = i + 1) begin
            // Setup inputs on negative edge to ensure stability at positive edge
            @(negedge clk);
            warm_reset_req = 0;
            otp_load_en = 1;
            test_val = $random;
            otp_val_in = test_val;

            // Wait for rising edge where capture happens
            @(posedge clk);
            #1; // Allow for propagation delay

            // Check key_shadow_o
            if (key_shadow_o !== test_val) begin
                $display("[TEST] FAIL: key_shadow_o mismatch at iter %0d. Expected: %h, Got: %h", i, test_val, key_shadow_o);
                $finish;
            end

            // Check key_valid_o
            if (key_valid_o !== 1'b1) begin
                $display("[TEST] FAIL: key_valid_o not asserted at iter %0d. Expected: 1, Got: %b", i, key_valid_o);
                $finish;
            end
        end

        // If we complete the loop without failure
        $display("[TEST] PASS: key_shadow_o captured otp_val_in and key_valid_o asserted when enabled.");
        $finish;
    end

endmodule