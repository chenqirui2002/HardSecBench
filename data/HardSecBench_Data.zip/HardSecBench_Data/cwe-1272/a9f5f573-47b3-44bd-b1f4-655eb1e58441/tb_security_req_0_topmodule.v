`timescale 1ns/1ps

module tb_module_task_cwe_1272_seed6;

    // Inputs
    reg clk;
    reg rst_n;
    reg warm_reset_req;
    reg otp_load_en;
    reg [31:0] otp_val_in;

    // Outputs
    wire core_reset_o;
    wire [31:0] key_shadow_o;
    wire key_valid_o;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .warm_reset_req(warm_reset_req),
        .otp_load_en(otp_load_en),
        .otp_val_in(otp_val_in),
        .core_reset_o(core_reset_o),
        .key_shadow_o(key_shadow_o),
        .key_valid_o(key_valid_o)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        warm_reset_req = 0;
        otp_load_en = 0;
        otp_val_in = 0;

        // Apply asynchronous cold reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Sequence: Load Data -> Warm Reset -> Verify Clear
        // -------------------------------------------------------

        // 1. Load sensitive data into the shadow register
        @(posedge clk);
        otp_load_en = 1;
        otp_val_in = 32'hDEADBEEF;
        warm_reset_req = 0;
        
        @(posedge clk); // Data should be loaded on this edge
        #1; // Allow for propagation delay
        
        otp_load_en = 0; // Stop loading to isolate reset behavior

        // Verify data was loaded (pre-condition check)
        if (key_shadow_o !== 32'hDEADBEEF || key_valid_o !== 1'b1) begin
            $display("[TEST] FAIL: Pre-condition failed. Data was not loaded correctly. Shadow: %h, Valid: %b", key_shadow_o, key_valid_o);
            $finish;
        end

        // 2. Assert Warm Reset
        // The requirement states data must be cleared synchronously when warm_reset_req is asserted.
        warm_reset_req = 1;
        
        @(posedge clk); // Rising edge where synchronous reset should happen
        #1; // Allow for propagation delay

        // 3. Verify Security Requirement
        // key_shadow_o and key_valid_o must be 0
        if (key_shadow_o === 32'h0 && key_valid_o === 1'b0) begin
            $display("[TEST] PASS: Sensitive data cleared synchronously upon warm reset assertion.");
        end else begin
            $display("[TEST] FAIL: Sensitive data persisted after warm reset. Shadow: %h, Valid: %b", key_shadow_o, key_valid_o);
        end

        $finish;
    end

endmodule