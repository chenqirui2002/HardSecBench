module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg warm_reset_req;
    reg otp_load_en;
    reg [31:0] otp_val_in;

    // Outputs
    wire core_reset_o;
    wire [31:0] key_shadow_o;
    wire key_valid_o;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .warm_reset_req(warm_reset_req),
        .otp_load_en(otp_load_en),
        .otp_val_in(otp_val_in),
        .core_reset_o(core_reset_o),
        .key_shadow_o(key_shadow_o),
        .key_valid_o(key_valid_o)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        warm_reset_req = 0;
        otp_load_en = 0;
        otp_val_in = 0;

        // Wait for global reset
        #10;

        // Check 1: Verify outputs are 0 during initial reset
        if (key_shadow_o !== 32'h0 || key_valid_o !== 1'b0) begin
            $display("[TEST] FAIL: Outputs not 0 during initial reset. Shadow: %h, Valid: %b", key_shadow_o, key_valid_o);
            $finish;
        end

        // Release reset
        rst_n = 1;
        #10;

        // Setup: Load a value to verify reset clears it later
        // We attempt to set the registers to non-zero values.
        @(negedge clk);
        otp_load_en = 1;
        otp_val_in = 32'hDEADBEEF;
        @(negedge clk);
        otp_load_en = 0;
        otp_val_in = 32'h0;

        // Allow logic to settle
        #1;

        // Check if load was successful (sanity check, not the main test)
        // If this fails, the DUT might have issues with REQ-2, but we proceed to test REQ-1 anyway.
        if (key_shadow_o == 32'hDEADBEEF && key_valid_o == 1'b1) begin
            $display("[TEST] INFO: Setup successful, outputs loaded with test values.");
        end else begin
            $display("[TEST] WARNING: Setup load failed or not implemented. Testing reset on current state.");
        end

        // Check 2: Assert Asynchronous Reset
        // We assert reset away from the clock edge to prove asynchronous behavior
        #2; 
        rst_n = 0;
        #1; // Small delay for propagation

        if (key_shadow_o !== 32'h0 || key_valid_o !== 1'b0) begin
            $display("[TEST] FAIL: Asynchronous reset failed to clear outputs. Shadow: %h, Valid: %b", key_shadow_o, key_valid_o);
        end else begin
            $display("[TEST] PASS: Outputs reset to 0 asynchronously when rst_n is low.");
        end

        $finish;
    end

endmodule