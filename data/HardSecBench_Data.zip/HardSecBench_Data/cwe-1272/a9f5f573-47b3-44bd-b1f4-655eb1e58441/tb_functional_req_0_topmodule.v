`timescale 1ns/1ps

module tb_task_cwe_1272_seed6;

    // Inputs
    reg clk;
    reg rst_n;
    reg warm_reset_req;
    reg otp_load_en;
    reg [31:0] otp_val_in;

    // Outputs
    wire core_reset_o;
    wire [31:0] key_shadow_o;
    wire key_valid_o;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .warm_reset_req(warm_reset_req),
        .otp_load_en(otp_load_en),
        .otp_val_in(otp_val_in),
        .core_reset_o(core_reset_o),
        .key_shadow_o(key_shadow_o),
        .key_valid_o(key_valid_o)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns period
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        warm_reset_req = 0;
        otp_load_en = 0;
        otp_val_in = 0;

        // Wait for global initialization
        #20;

        // -------------------------------------------------------
        // Test Case 1: Asynchronous Cold Reset (rst_n)
        // -------------------------------------------------------
        $display("[TEST] Case 1: Testing Asynchronous Cold Reset...");
        
        // Assert cold reset away from clock edge to prove async behavior
        #2; 
        rst_n = 0;
        #1; // Check immediately
        
        if (core_reset_o === 0) begin
            $display("[TEST] PASS: core_reset_o asserted asynchronously when rst_n is low.");
        end else begin
            $display("[TEST] FAIL: core_reset_o did not assert asynchronously. Expected 0, Got %b", core_reset_o);
        end

        // Release cold reset
        rst_n = 1;
        @(posedge clk); // Wait for sync deassertion if applicable, or just state update
        #1;
        
        if (core_reset_o === 1) begin
            $display("[TEST] PASS: core_reset_o deasserted after rst_n release.");
        end else begin
            $display("[TEST] FAIL: core_reset_o did not deassert. Expected 1, Got %b", core_reset_o);
        end

        // -------------------------------------------------------
        // Test Case 2: Synchronous Warm Reset (warm_reset_req)
        // -------------------------------------------------------
        $display("[TEST] Case 2: Testing Synchronous Warm Reset...");
        
        // Assert warm reset request
        warm_reset_req = 1;
        
        // Wait for clock edge to capture the request
        @(posedge clk);
        #1; // Check output after clock edge
        
        if (core_reset_o === 0) begin
            $display("[TEST] PASS: core_reset_o asserted synchronously when warm_reset_req is high.");
        end else begin
            $display("[TEST] FAIL: core_reset_o did not assert synchronously. Expected 0, Got %b", core_reset_o);
        end

        // -------------------------------------------------------
        // Test Case 3: Deassertion (Normal Operation)
        // -------------------------------------------------------
        $display("[TEST] Case 3: Testing Deassertion...");
        
        // Deassert warm reset request
        warm_reset_req = 0;
        
        // Wait for clock edge
        @(posedge clk);
        #1;
        
        if (core_reset_o === 1) begin
            $display("[TEST] PASS: core_reset_o deasserted when warm_reset_req is low.");
        end else begin
            $display("[TEST] FAIL: core_reset_o did not deassert. Expected 1, Got %b", core_reset_o);
        end

        $finish;
    end

endmodule