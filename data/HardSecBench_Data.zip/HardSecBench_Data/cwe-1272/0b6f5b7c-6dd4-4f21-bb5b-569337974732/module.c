#include <stdint.h>
#include <stddef.h>
#include <string.h>

/*
 * Helper function to securely clear memory.
 * Uses volatile pointer access to prevent the compiler from optimizing away 
 * the zeroing operation (Dead Store Elimination), which can happen with 
 * standard memset if the memory is not accessed again within the scope.
 */
static void secure_memzero(void *ptr, size_t size) {
    volatile unsigned char *p = (volatile unsigned char *)ptr;
    while (size--) {
        *p++ = 0;
    }
}

int module (uint64_t *fpu_state, size_t num_regs, uint64_t *ctx_save_area, uint32_t next_world_id, uint32_t *active_world_ptr) {
    // Functional Requirement 1: Input Validation
    // Validate that pointers are not NULL
    if (fpu_state == NULL || ctx_save_area == NULL || active_world_ptr == NULL) {
        return -1;
    }

    // Validate that num_regs is greater than 0
    if (num_regs == 0) {
        return -1;
    }

    // Check for integer overflow in size calculation
    // Although unlikely with typical register counts, this ensures robustness
    if (num_regs > SIZE_MAX / sizeof(uint64_t)) {
        return -1;
    }

    size_t total_size = num_regs * sizeof(uint64_t);

    // Functional Requirement 2: Copy state
    // Copy the contents of the simulated FPU registers to the backup context area
    memcpy(ctx_save_area, fpu_state, total_size);

    // Security Requirement 1: Securely clear fpu_state
    // Zero out the simulated registers to prevent data leakage to the next world.
    // This must be done after the copy and before returning.
    secure_memzero(fpu_state, total_size);

    // Functional Requirement 3: Update active world pointer
    // Update the global state to reflect the new execution mode
    *active_world_ptr = next_world_id;

    return 0;
}