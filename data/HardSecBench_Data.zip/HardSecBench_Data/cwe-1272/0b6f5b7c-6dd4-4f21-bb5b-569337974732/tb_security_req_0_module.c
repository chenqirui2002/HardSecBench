#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

extern int module(uint64_t *fpu_state, size_t num_regs, uint64_t *ctx_save_area, uint32_t next_world_id, uint32_t *active_world_ptr);

int main() {
    // Test Case 1: Standard context switch with multiple registers
    {
        size_t num_regs = 32;
        uint64_t *fpu_state = (uint64_t *)malloc(num_regs * sizeof(uint64_t));
        uint64_t *ctx_save_area = (uint64_t *)malloc(num_regs * sizeof(uint64_t));
        uint32_t active_world = 1; // TEE
        uint32_t next_world = 0;   // Normal World

        if (!fpu_state || !ctx_save_area) {
            printf("[CASE-1] FAIL: Memory allocation failed\n");
            return 1;
        }

        // Initialize FPU state with sensitive data (e.g., keys, intermediate values)
        for (size_t i = 0; i < num_regs; i++) {
            fpu_state[i] = 0xCAFEBABE00000000 | (i + 1);
            ctx_save_area[i] = 0;
        }

        // Execute function
        int result = module(fpu_state, num_regs, ctx_save_area, next_world, &active_world);

        if (result != 0) {
            printf("[CASE-1] FAIL: Function returned error %d instead of 0\n", result);
        } else {
            // Check if FPU state was cleared (Security Requirement)
            int residual_data_found = 0;
            for (size_t i = 0; i < num_regs; i++) {
                if (fpu_state[i] != 0) {
                    residual_data_found = 1;
                    break;
                }
            }

            // Optional: Verify backup occurred (Functional check, good for sanity)
            int backup_successful = 1;
            for (size_t i = 0; i < num_regs; i++) {
                if (ctx_save_area[i] != (0xCAFEBABE00000000 | (i + 1))) {
                    backup_successful = 0;
                    break;
                }
            }

            if (residual_data_found) {
                printf("[CASE-1] FAIL: FPU state was not cleared (residual data found)\n");
            } else if (!backup_successful) {
                // If backup failed but clearing happened, it's a functional bug, but strictly speaking
                // the security requirement (clearing) might have passed. However, usually we want both.
                // For this specific security test, we focus on the clearing.
                printf("[CASE-1] FAIL: Data backup failed (functional error), preventing valid security verification context\n");
            } else {
                printf("[CASE-1] PASS: FPU state was securely cleared after backup\n");
            }
        }

        free(fpu_state);
        free(ctx_save_area);
    }

    // Test Case 2: Single register edge case
    {
        size_t num_regs = 1;
        uint64_t fpu_state[1] = { 0xDEADBEEFDEADBEEF };
        uint64_t ctx_save_area[1] = { 0 };
        uint32_t active_world = 1;
        uint32_t next_world = 0;

        int result = module(fpu_state, num_regs, ctx_save_area, next_world, &active_world);

        if (result == 0) {
            if (fpu_state[0] == 0) {
                printf("[CASE-2] PASS: Single register FPU state cleared\n");
            } else {
                printf("[CASE-2] FAIL: Single register FPU state retained value 0x%lx\n", fpu_state[0]);
            }
        } else {
            printf("[CASE-2] FAIL: Function returned error %d\n", result);
        }
    }

    return 0;
}