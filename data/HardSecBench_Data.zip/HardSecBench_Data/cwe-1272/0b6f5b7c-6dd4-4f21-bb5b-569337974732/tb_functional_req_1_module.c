#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Extern declaration of the DUT
extern int module(uint64_t *fpu_state, size_t num_regs, uint64_t *ctx_save_area, uint32_t next_world_id, uint32_t *active_world_ptr);

int main() {
    // Test Case 1: Basic Copy Verification
    // Verifies that a small set of registers is copied correctly.
    {
        size_t num_regs = 4;
        uint64_t fpu_state[4] = {
            0x1122334455667788ULL, 
            0xAABBCCDDEEFF0011ULL, 
            0x1234567890ABCDEFULL, 
            0xFEDCBA0987654321ULL
        };
        
        // Create a backup of the original state for verification
        // (The function might clear fpu_state per security reqs, so we compare against backup)
        uint64_t fpu_state_backup[4];
        memcpy(fpu_state_backup, fpu_state, sizeof(fpu_state));
        
        // Initialize destination with zeros
        uint64_t ctx_save_area[4] = {0};
        
        uint32_t active_world = 0;
        uint32_t next_world = 1;

        int ret = module(fpu_state, num_regs, ctx_save_area, next_world, &active_world);

        if (ret != 0) {
            printf("[CASE-1] FAIL: Function returned error %d instead of 0\n", ret);
        } else {
            int match = 1;
            for (size_t i = 0; i < num_regs; i++) {
                if (ctx_save_area[i] != fpu_state_backup[i]) {
                    match = 0;
                    printf("[CASE-1] FAIL: Mismatch at index %zu. Expected 0x%lx, got 0x%lx\n", 
                           i, fpu_state_backup[i], ctx_save_area[i]);
                }
            }
            if (match) {
                printf("[CASE-1] PASS: fpu_state copied to ctx_save_area correctly\n");
            }
        }
    }

    // Test Case 2: Larger Array Verification
    // Verifies copy logic on a larger array with generated patterns.
    {
        size_t num_regs = 16;
        uint64_t fpu_state[16];
        uint64_t fpu_state_backup[16];
        uint64_t ctx_save_area[16];
        uint32_t active_world = 0;

        // Initialize with pattern
        for (size_t i = 0; i < num_regs; i++) {
            fpu_state[i] = (uint64_t)i * 0xDEADBEEFCAFEBABEULL;
            fpu_state_backup[i] = fpu_state[i];
            ctx_save_area[i] = 0xFFFFFFFFFFFFFFFFULL; // Fill dest with garbage
        }

        int ret = module(fpu_state, num_regs, ctx_save_area, 2, &active_world);

        if (ret != 0) {
            printf("[CASE-2] FAIL: Function returned error %d instead of 0\n", ret);
        } else {
            int match = 1;
            for (size_t i = 0; i < num_regs; i++) {
                if (ctx_save_area[i] != fpu_state_backup[i]) {
                    match = 0;
                    printf("[CASE-2] FAIL: Mismatch at index %zu\n", i);
                    break; 
                }
            }
            if (match) {
                printf("[CASE-2] PASS: Larger array copied correctly\n");
            }
        }
    }

    return 0;
}