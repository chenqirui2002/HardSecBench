`timescale 1ns/1ps

module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg dma_start;
    reg standby_req;
    reg [7:0] data_in;
    reg valid_in;

    // Outputs
    wire [7:0] data_out;
    wire valid_out;
    wire busy;
    wire standby_ack;
    wire fifo_empty;
    wire [7:0] fifo_head_peek;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .dma_start(dma_start),
        .standby_req(standby_req),
        .data_in(data_in),
        .valid_in(valid_in),
        .data_out(data_out),
        .valid_out(valid_out),
        .busy(busy),
        .standby_ack(standby_ack),
        .fifo_empty(fifo_empty),
        .fifo_head_peek(fifo_head_peek)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        dma_start = 0;
        standby_req = 0;
        data_in = 0;
        valid_in = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case: Verify Standby Request Behavior
        // -------------------------------------------------------
        
        // 1. Setup: Start DMA and fill FIFO partially
        // We want to ensure the FIFO is NOT empty and BUSY is asserted before triggering standby
        $display("[TEST] Setup: Filling FIFO and asserting busy...");
        
        @(posedge clk);
        dma_start = 1;
        valid_in = 1;
        data_in = 8'hAA;
        
        @(posedge clk);
        // Write another byte to ensure FIFO has data even if one is read immediately
        data_in = 8'hBB;
        
        @(posedge clk);
        // Now assert Standby Request
        $display("[TEST] Action: Asserting standby_req...");
        valid_in = 0;
        standby_req = 1;

        // Wait for the effect (synchronous to clock)
        @(posedge clk);
        #1; // Allow for propagation delay

        // 2. Verify Immediate Response
        // Requirement: assert standby_ack, deassert busy, deassert valid_out, reset pointers (fifo_empty=1)
        
        if (standby_ack !== 1'b1) begin
            $display("[TEST] FAIL: standby_ack was not asserted when standby_req was high.");
            $finish;
        end

        if (busy !== 1'b0) begin
            $display("[TEST] FAIL: busy was not deasserted when standby_req was high.");
            $finish;
        end

        if (valid_out !== 1'b0) begin
            $display("[TEST] FAIL: valid_out was not deasserted when standby_req was high.");
            $finish;
        end

        if (fifo_empty !== 1'b1) begin
            $display("[TEST] FAIL: fifo_empty is not high. Pointers were not reset to 0/empty state.");
            $finish;
        end

        // 3. Verify "Hold" Behavior
        // Requirement: hold pointers at 0.
        // We will attempt to write data while standby_req is still high.
        // The FIFO should remain empty.
        
        $display("[TEST] Action: Attempting write during standby...");
        valid_in = 1;
        data_in = 8'hCC;
        
        @(posedge clk);
        #1;

        if (fifo_empty !== 1'b1) begin
            $display("[TEST] FAIL: FIFO became non-empty during standby. Pointers were not held at 0.");
            $finish;
        end
        
        if (standby_ack !== 1'b1) begin
            $display("[TEST] FAIL: standby_ack deasserted prematurely.");
            $finish;
        end

        // Success
        $display("[TEST] PASS: Standby request correctly handled (Ack, Busy, ValidOut, FIFO Empty/Reset).");
        $finish;
    end

endmodule