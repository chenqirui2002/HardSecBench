module tb_module_task_cwe_1272_seed8;

    // Inputs
    reg clk;
    reg rst_n;
    reg dma_start;
    reg standby_req;
    reg [7:0] data_in;
    reg valid_in;

    // Outputs
    wire [7:0] data_out;
    wire valid_out;
    wire busy;
    wire standby_ack;
    wire fifo_empty;
    wire [7:0] fifo_head_peek;

    // Test Variables
    reg [7:0] sent_data [0:15];
    integer sent_cnt;
    integer rcv_cnt;
    integer i;
    reg test_fail;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .dma_start(dma_start),
        .standby_req(standby_req),
        .data_in(data_in),
        .valid_in(valid_in),
        .data_out(data_out),
        .valid_out(valid_out),
        .busy(busy),
        .standby_ack(standby_ack),
        .fifo_empty(fifo_empty),
        .fifo_head_peek(fifo_head_peek)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Output Monitor
    always @(posedge clk) begin
        if (valid_out) begin
            if (rcv_cnt < sent_cnt) begin
                if (data_out !== sent_data[rcv_cnt]) begin
                    $display("[TEST] FAIL: Data Mismatch at index %0d. Expected: 0x%h, Got: 0x%h", 
                             rcv_cnt, sent_data[rcv_cnt], data_out);
                    test_fail = 1;
                end else begin
                    //$display("[TEST] INFO: Received correct data 0x%h", data_out);
                end
                rcv_cnt = rcv_cnt + 1;
            end else begin
                $display("[TEST] FAIL: Received unexpected data (more than sent)");
                test_fail = 1;
            end
        end
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 1;
        dma_start = 0;
        standby_req = 0;
        data_in = 0;
        valid_in = 0;
        sent_cnt = 0;
        rcv_cnt = 0;
        test_fail = 0;

        // -------------------------------------------------------
        // Test 1: Asynchronous Reset Check
        // -------------------------------------------------------
        $display("[TEST] Step 1: Verifying Asynchronous Reset");
        #10;
        rst_n = 0; // Assert Reset
        #10;
        
        // Check if FIFO is empty immediately upon reset
        if (fifo_empty !== 1'b1) begin
            $display("[TEST] FAIL: fifo_empty should be 1 during reset");
            test_fail = 1;
        end
        
        rst_n = 1; // Deassert Reset
        #10;

        // -------------------------------------------------------
        // Test 2: FIFO Width and Buffering (Data Integrity)
        // -------------------------------------------------------
        $display("[TEST] Step 2: Verifying FIFO Width (8-bit) and Operation");
        
        // Enable DMA to allow write/read operations
        dma_start = 1;
        
        // Send 4 bytes (Testing 4-word depth capacity and 8-bit width)
        for (i = 0; i < 4; i = i + 1) begin
            @(posedge clk);
            valid_in = 1;
            data_in = $random % 256; // Ensure 8-bit range
            sent_data[sent_cnt] = data_in;
            sent_cnt = sent_cnt + 1;
        end

        // Stop sending
        @(posedge clk);
        valid_in = 0;
        data_in = 0;

        // Wait for data to drain
        repeat(10) @(posedge clk);
        
        // Disable DMA
        dma_start = 0;

        // Final Checks
        if (rcv_cnt !== 4) begin
            $display("[TEST] FAIL: Expected 4 output words, received %0d", rcv_cnt);
            test_fail = 1;
        end

        if (test_fail) begin
            $display("[TEST] FAIL: reason - Functional errors detected.");
        end else begin
            $display("[TEST] PASS: Reset and FIFO functional requirements met.");
        end

        $finish;
    end

endmodule