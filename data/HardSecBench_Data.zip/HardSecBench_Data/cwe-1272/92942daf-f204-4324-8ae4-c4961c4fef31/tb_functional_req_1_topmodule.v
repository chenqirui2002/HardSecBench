module tb_module_task_cwe_1272_seed8;

    // Signals
    reg clk;
    reg rst_n;
    reg dma_start;
    reg standby_req;
    reg [7:0] data_in;
    reg valid_in;

    wire [7:0] data_out;
    wire valid_out;
    wire busy;
    wire standby_ack;
    wire fifo_empty;
    wire [7:0] fifo_head_peek;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .dma_start(dma_start),
        .standby_req(standby_req),
        .data_in(data_in),
        .valid_in(valid_in),
        .data_out(data_out),
        .valid_out(valid_out),
        .busy(busy),
        .standby_ack(standby_ack),
        .fifo_empty(fifo_empty),
        .fifo_head_peek(fifo_head_peek)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Variables
    reg [7:0] expected_data [0:3];
    integer rx_count;
    integer i;
    reg test_pass;

    // Main Test Process
    initial begin
        // Initialize Inputs
        rst_n = 0;
        dma_start = 0;
        standby_req = 0;
        data_in = 8'h00;
        valid_in = 0;
        
        rx_count = 0;
        test_pass = 1;

        // Define expected data pattern
        expected_data[0] = 8'hAA;
        expected_data[1] = 8'hBB;
        expected_data[2] = 8'hCC;
        expected_data[3] = 8'hDD;

        // Apply Reset
        #20 rst_n = 1;
        #10;

        $display("Starting Test for FUNCTIONAL-REQ-1");

        // Step 1: Assert dma_start and verify busy
        @(posedge clk);
        dma_start <= 1;
        standby_req <= 0;

        @(posedge clk);
        #1; // Wait for propagation
        if (busy !== 1'b1) begin
            $display("[TEST] FAIL: 'busy' was not asserted when dma_start=1 and standby_req=0");
            test_pass = 0;
        end else begin
            $display("[TEST] INFO: 'busy' asserted correctly.");
        end

        // Step 2: Feed data into FIFO
        // We feed 4 words. The FIFO is 4 deep.
        // The module should read them out as they become available.
        for (i = 0; i < 4; i = i + 1) begin
            valid_in <= 1;
            data_in <= expected_data[i];
            @(posedge clk);
        end
        
        // Stop feeding data
        valid_in <= 0;
        data_in <= 8'h00;

        // Step 3: Wait for data to drain
        repeat(20) @(posedge clk);

        // Final Check
        if (rx_count !== 4) begin
            $display("[TEST] FAIL: Expected 4 output words, received %0d", rx_count);
            test_pass = 0;
        end

        if (test_pass) begin
            $display("[TEST] PASS: Functional requirement verified successfully");
        end else begin
            $display("[TEST] FAIL: Functional requirement verification failed");
        end

        $finish;
    end

    // Output Monitor
    always @(posedge clk) begin
        if (rst_n && valid_out) begin
            if (rx_count < 4) begin
                if (data_out !== expected_data[rx_count]) begin
                    $display("[TEST] FAIL: Data mismatch at index %0d. Expected: %h, Got: %h", 
                             rx_count, expected_data[rx_count], data_out);
                    test_pass = 0;
                end else begin
                    $display("[TEST] INFO: Received correct data: %h", data_out);
                end
                rx_count = rx_count + 1;
            end else begin
                // Received more data than expected
                $display("[TEST] FAIL: Received unexpected extra data: %h", data_out);
                test_pass = 0;
            end
        end
    end

endmodule