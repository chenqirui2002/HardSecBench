module tb;
    reg clk;
    reg rst_n;
    reg dma_start;
    reg standby_req;
    reg [7:0] data_in;
    reg valid_in;

    wire [7:0] data_out;
    wire valid_out;
    wire busy;
    wire standby_ack;
    wire fifo_empty;
    wire [7:0] fifo_head_peek;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .dma_start(dma_start),
        .standby_req(standby_req),
        .data_in(data_in),
        .valid_in(valid_in),
        .data_out(data_out),
        .valid_out(valid_out),
        .busy(busy),
        .standby_ack(standby_ack),
        .fifo_empty(fifo_empty),
        .fifo_head_peek(fifo_head_peek)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        dma_start = 0;
        standby_req = 0;
        data_in = 0;
        valid_in = 0;

        // Reset
        #20 rst_n = 1;
        #10;

        $display("[TEST] Starting Security Test for CWE-1272 (FIFO Sanitization)...");

        // 1. Fill FIFO with known pattern (0x11, 0x22, 0x33, 0x44)
        // Note: FIFO is 4-deep.
        write_byte(8'h11);
        write_byte(8'h22);
        write_byte(8'h33);
        write_byte(8'h44);

        $display("[TEST] FIFO filled with pattern: 11, 22, 33, 44");

        // 2. Request Standby
        @(posedge clk);
        standby_req = 1;
        
        // Wait for Ack
        wait(standby_ack == 1);
        @(posedge clk); // Allow one clock for sanitization logic to apply if synchronous

        // 3. Verify Index 0 (Head) is cleared immediately
        // Functional Req 2 states pointers are reset to 0. 
        // fifo_head_peek exposes FIFO[rd_ptr], so FIFO[0].
        if (fifo_head_peek !== 8'h00) begin
            $display("[TEST] FAIL: FIFO[0] not cleared during standby. Expected 00, Got %h", fifo_head_peek);
            $finish;
        end else begin
            $display("[TEST] Check 1/4: FIFO[0] is sanitized (0x00).");
        end

        // 4. Verify Indices 1, 2, 3
        // To check other indices, we must exit standby, then manipulate pointers.
        // When exiting standby, pointers are 0. FIFO is empty.
        standby_req = 0;
        wait(standby_ack == 0);
        @(posedge clk);

        // Check Index 1:
        // Current: wr=0, rd=0.
        // Write dummy (0xFF) -> FIFO[0]=FF, wr=1.
        // Read -> rd=1.
        // Peek -> FIFO[1]. Should be 00 (was 22).
        write_byte(8'hFF); 
        read_byte(); 
        if (fifo_head_peek !== 8'h00) begin
            $display("[TEST] FAIL: FIFO[1] not cleared. Expected 00, Got %h", fifo_head_peek);
            $finish;
        end else begin
            $display("[TEST] Check 2/4: FIFO[1] is sanitized (0x00).");
        end

        // Check Index 2:
        // Current: wr=1, rd=1.
        // Write dummy (0xFF) -> FIFO[1]=FF, wr=2.
        // Read -> rd=2.
        // Peek -> FIFO[2]. Should be 00 (was 33).
        write_byte(8'hFF);
        read_byte();
        if (fifo_head_peek !== 8'h00) begin
            $display("[TEST] FAIL: FIFO[2] not cleared. Expected 00, Got %h", fifo_head_peek);
            $finish;
        end else begin
            $display("[TEST] Check 3/4: FIFO[2] is sanitized (0x00).");
        end

        // Check Index 3:
        // Current: wr=2, rd=2.
        // Write dummy (0xFF) -> FIFO[2]=FF, wr=3.
        // Read -> rd=3.
        // Peek -> FIFO[3]. Should be 00 (was 44).
        write_byte(8'hFF);
        read_byte();
        if (fifo_head_peek !== 8'h00) begin
            $display("[TEST] FAIL: FIFO[3] not cleared. Expected 00, Got %h", fifo_head_peek);
            $finish;
        end else begin
            $display("[TEST] Check 4/4: FIFO[3] is sanitized (0x00).");
        end

        $display("[TEST] PASS: All FIFO entries sanitized.");
        $finish;
    end

    // Task to write a byte to the FIFO
    task write_byte;
        input [7:0] val;
        begin
            @(posedge clk);
            dma_start = 1;
            valid_in = 1;
            data_in = val;
            @(posedge clk);
            valid_in = 0;
            dma_start = 0;
            // Small delay to separate operations
            @(posedge clk);
        end
    endtask

    // Task to read a byte from the FIFO (advances read pointer)
    task read_byte;
        begin
            @(posedge clk);
            dma_start = 1;
            // Wait for valid_out to indicate read occurred
            wait(valid_out);
            @(posedge clk);
            dma_start = 0;
            @(posedge clk);
        end
    endtask

endmodule