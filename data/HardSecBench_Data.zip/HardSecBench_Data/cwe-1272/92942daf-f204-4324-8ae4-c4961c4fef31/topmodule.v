module topmodule (
    input wire clk,
    input wire rst_n,
    input wire dma_start,
    input wire standby_req,
    input wire [7:0] data_in,
    input wire valid_in,
    output reg [7:0] data_out,
    output reg valid_out,
    output reg busy,
    output reg standby_ack,
    output wire fifo_empty,
    output wire [7:0] fifo_head_peek
);

    // Internal FIFO Memory and Pointers
    reg [7:0] fifo_mem [0:3];
    reg [1:0] wr_ptr;
    reg [1:0] rd_ptr;
    reg [2:0] count; // Tracks number of elements (0 to 4)

    // Status Signals
    assign fifo_empty = (count == 3'd0);
    wire fifo_full = (count == 3'd4);

    // Debug Output: Expose value at FIFO head
    // This exposes the data at the read pointer. 
    // Security: During standby, memory is cleared, so this will safely show 0x00.
    assign fifo_head_peek = fifo_mem[rd_ptr];

    integer i;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Asynchronous Reset
            wr_ptr <= 2'd0;
            rd_ptr <= 2'd0;
            count <= 3'd0;
            busy <= 1'b0;
            standby_ack <= 1'b0;
            valid_out <= 1'b0;
            data_out <= 8'd0;
            
            // Securely clear memory on reset
            for (i = 0; i < 4; i = i + 1) begin
                fifo_mem[i] <= 8'd0;
            end
        end else begin
            // Priority: Standby Request overrides DMA operation
            if (standby_req) begin
                // Standby Mode
                standby_ack <= 1'b1;
                busy <= 1'b0;
                valid_out <= 1'b0;
                
                // Synchronously reset pointers and count to 0 and hold them
                wr_ptr <= 2'd0;
                rd_ptr <= 2'd0;
                count <= 3'd0;
                
                // Security Requirement: Sanitize FIFO memory
                // Overwrite all entries with 0x00 on every clock edge while in standby
                for (i = 0; i < 4; i = i + 1) begin
                    fifo_mem[i] <= 8'd0;
                end
            end else begin
                // Normal Operation
                standby_ack <= 1'b0;
                
                if (dma_start) begin
                    busy <= 1'b1;
                    
                    // FIFO Write Logic
                    if (valid_in && !fifo_full) begin
                        fifo_mem[wr_ptr] <= data_in;
                        wr_ptr <= wr_ptr + 1'b1;
                    end
                    
                    // FIFO Read Logic
                    if (!fifo_empty) begin
                        data_out <= fifo_mem[rd_ptr];
                        valid_out <= 1'b1;
                        rd_ptr <= rd_ptr + 1'b1;
                    end else begin
                        valid_out <= 1'b0;
                    end
                    
                    // FIFO Count Update
                    if (valid_in && !fifo_full && !fifo_empty) begin
                        // Simultaneous Read and Write: Count unchanged
                        count <= count;
                    end else if (valid_in && !fifo_full) begin
                        // Write only
                        count <= count + 1'b1;
                    end else if (!fifo_empty) begin
                        // Read only
                        count <= count - 1'b1;
                    end
                    
                end else begin
                    // DMA Idle (dma_start is low, standby_req is low)
                    busy <= 1'b0;
                    valid_out <= 1'b0;
                    // FIFO state (pointers and memory) is preserved
                end
            end
        end
    end

endmodule