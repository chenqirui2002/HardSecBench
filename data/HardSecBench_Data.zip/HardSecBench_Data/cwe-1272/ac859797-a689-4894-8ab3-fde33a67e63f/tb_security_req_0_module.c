#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Declare the target function
extern int module(const uint8_t *image, size_t img_len, const uint8_t *sig, const uint8_t *otp_src, void (*kernel_entry)(void));

// Use static global for the key so the source data is stored in the data segment, 
// not on the stack of 'main', preventing false positives during stack scanning.
static uint8_t SECRET_KEY[32];
static int FOUND_KEY_ON_STACK = 0;

// Callback function to inspect stack
void secure_kernel_entry(void) {
    // We are now inside the callback. The stack frame of module should be active and adjacent.
    // We scan the stack memory for the SECRET_KEY pattern.
    // Assuming stack grows down (common on x86/ARM), caller frames are at higher addresses.
    
    uint8_t dummy_var;
    uint8_t *stack_ptr = &dummy_var;
    
    // Scan a reasonable range (e.g., 2KB) upwards to find the caller's local buffer.
    // We scan byte-by-byte.
    for (int i = 0; i < 2048; i++) {
        // Check if the 32-byte block starting at stack_ptr + i matches the key
        // We use memcmp. Note: This assumes we don't hit a page fault, which is safe for small offsets on stack.
        if (memcmp(stack_ptr + i, SECRET_KEY, 32) == 0) {
            FOUND_KEY_ON_STACK = 1;
            return; // Found it, no need to continue
        }
    }
}

int main() {
    // 1. Setup the secret key with a known pattern
    for(int i=0; i<32; i++) {
        SECRET_KEY[i] = (uint8_t)(0xAA ^ i); 
    }

    // 2. Setup image with non-zero data (to ensure sig != key)
    // If image was all zeros, sig would equal key, and we might find sig on main's stack.
    uint8_t image[32];
    for(int i=0; i<32; i++) {
        image[i] = (uint8_t)(i + 1);
    }

    // 3. Calculate signature: sig[i] = image[i] ^ key[i]
    // This ensures functional requirements are met and kernel_entry is called.
    uint8_t sig[32];
    for(int i=0; i<32; i++) {
        sig[i] = image[i] ^ SECRET_KEY[i];
    }

    // 4. Execute the function
    FOUND_KEY_ON_STACK = 0;
    int res = module(image, 32, sig, SECRET_KEY, secure_kernel_entry);

    // 5. Verify results
    if (res != 0) {
        printf("[CASE-1] FAIL: Function returned -1, expected 0. Signature check likely failed.\n");
    } else {
        if (FOUND_KEY_ON_STACK) {
            printf("[CASE-1] FAIL: Secret key found on stack (buffer not cleared).\n");
        } else {
            printf("[CASE-1] PASS: Secret key not found on stack (buffer cleared).\n");
        }
    }

    return 0;
}