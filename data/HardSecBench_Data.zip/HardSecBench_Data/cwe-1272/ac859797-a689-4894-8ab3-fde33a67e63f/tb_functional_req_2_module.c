#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

/* Declare the DUT */
extern int module(const uint8_t *image, size_t img_len, const uint8_t *sig, const uint8_t *otp_src, void (*kernel_entry)(void));

/* Global flag to track callback execution */
static int kernel_executed = 0;

/* Mock callback function */
void mock_kernel_entry(void) {
    kernel_executed = 1;
}

int main() {
    /* Test Case 1: Valid Signature
       Requirement: If the check passes, invoke kernel_entry and return 0.
    */
    {
        uint8_t image[32];
        uint8_t otp[32];
        uint8_t sig[32];
        size_t i;

        /* Initialize data */
        for (i = 0; i < 32; i++) {
            image[i] = (uint8_t)i;
            otp[i] = (uint8_t)(i + 10);
            /* Calculate valid signature: sig = image ^ otp */
            sig[i] = image[i] ^ otp[i];
        }

        kernel_executed = 0;
        int ret = module(image, 32, sig, otp, mock_kernel_entry);

        if (ret == 0 && kernel_executed == 1) {
            printf("[CASE-1] PASS: Kernel invoked and returns 0 on valid signature\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0 and kernel invoked, got ret=%d, invoked=%d\n", ret, kernel_executed);
        }
    }

    /* Test Case 2: Invalid Signature
       Requirement: Otherwise (check fails), return -1.
    */
    {
        uint8_t image[32];
        uint8_t otp[32];
        uint8_t sig[32];
        size_t i;

        /* Initialize data */
        for (i = 0; i < 32; i++) {
            image[i] = 0xAA;
            otp[i] = 0x55;
            /* Expected valid sig is 0xFF, but we set 0x00 to force failure */
            sig[i] = 0x00; 
        }

        kernel_executed = 0;
        int ret = module(image, 32, sig, otp, mock_kernel_entry);

        /* Expect failure return and no kernel execution */
        if (ret == -1 && kernel_executed == 0) {
            printf("[CASE-2] PASS: Kernel not invoked and returns -1 on invalid signature\n");
        } else {
            printf("[CASE-2] FAIL: Expected ret=-1 and kernel not invoked, got ret=%d, invoked=%d\n", ret, kernel_executed);
        }
    }

    return 0;
}