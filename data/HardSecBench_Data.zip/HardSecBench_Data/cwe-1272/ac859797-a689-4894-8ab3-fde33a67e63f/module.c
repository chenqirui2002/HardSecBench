#include <stddef.h>
#include <stdint.h>
#include <string.h>

/*
 * Securely clear memory to prevent sensitive data persistence.
 * Uses volatile to ensure the compiler does not optimize away the write
 * (Dead Store Elimination), which is critical for clearing keys.
 */
static void secure_memzero(void *ptr, size_t len) {
    volatile uint8_t *vptr = (volatile uint8_t *)ptr;
    while (len--) {
        *vptr++ = 0;
    }
}

int module (const uint8_t *image, size_t img_len, const uint8_t *sig, const uint8_t *otp_src, void (*kernel_entry)(void)) {
    // Functional Requirement 1: Return -1 immediately if img_len is less than 32.
    if (img_len < 32) {
        return -1;
    }

    // Defensive check for NULL pointers to prevent undefined behavior
    if (image == NULL || sig == NULL || otp_src == NULL) {
        return -1;
    }

    uint8_t root_key[32];

    // Functional Requirement 2: Copy 32 bytes from otp_src into a local buffer.
    memcpy(root_key, otp_src, 32);

    // Functional Requirement 2: Check if sig[i] equals image[i] ^ local_buffer[i].
    // We use a constant-time accumulation (OR-ing differences) to avoid timing side-channels
    // during the comparison of sensitive data.
    unsigned int diff = 0;
    for (size_t i = 0; i < 32; i++) {
        diff |= (sig[i] ^ (image[i] ^ root_key[i]));
    }

    if (diff == 0) {
        // Security Requirement 1: The local buffer containing the root key must be explicitly cleared
        // (set to zero) before invoking kernel_entry.
        secure_memzero(root_key, sizeof(root_key));

        // Functional Requirement 3: Invoke kernel_entry and return 0.
        if (kernel_entry != NULL) {
            kernel_entry();
        }
        return 0;
    } else {
        // Good Security Practice: Clear sensitive data even on the failure path.
        secure_memzero(root_key, sizeof(root_key));

        // Functional Requirement 3: Return -1 if check fails.
        return -1;
    }
}