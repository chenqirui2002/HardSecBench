#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Global flag to track if the kernel callback was invoked
static int g_kernel_executed = 0;

// Mock callback function
void mock_kernel_entry(void) {
    g_kernel_executed = 1;
}

// External function declaration
extern int module(const uint8_t *image, size_t img_len, const uint8_t *sig, const uint8_t *otp_src, void (*kernel_entry)(void));

int main() {
    // Case 1: Valid Signature
    // Requirement: sig[i] == image[i] ^ otp_src[i] for i in 0..31
    {
        uint8_t image[32];
        uint8_t otp[32];
        uint8_t sig[32];
        
        // Initialize arrays with predictable data
        for(int i = 0; i < 32; i++) {
            image[i] = (uint8_t)(i * 3);
            otp[i]   = (uint8_t)(i * 7);
            // Calculate valid signature based on requirement
            sig[i]   = image[i] ^ otp[i];
        }

        g_kernel_executed = 0;
        int result = module(image, 32, sig, otp, mock_kernel_entry);

        // Expect success (0) and kernel execution
        if (result == 0 && g_kernel_executed == 1) {
            printf("[CASE-1] PASS: Valid signature accepted\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0, executed=1; got ret=%d, executed=%d\n", result, g_kernel_executed);
        }
    }

    // Case 2: Invalid Signature (Mismatch at last index)
    // Requirement: Verification should fail if any byte does not match
    {
        uint8_t image[32];
        uint8_t otp[32];
        uint8_t sig[32];
        
        for(int i = 0; i < 32; i++) {
            image[i] = (uint8_t)(i * 3);
            otp[i]   = (uint8_t)(i * 7);
            sig[i]   = image[i] ^ otp[i];
        }
        
        // Corrupt the last byte of the signature
        sig[31] = ~sig[31];

        g_kernel_executed = 0;
        int result = module(image, 32, sig, otp, mock_kernel_entry);

        // Expect failure (-1) and no kernel execution
        if (result == -1 && g_kernel_executed == 0) {
            printf("[CASE-2] PASS: Invalid signature rejected\n");
        } else {
            printf("[CASE-2] FAIL: Expected ret=-1, executed=0; got ret=%d, executed=%d\n", result, g_kernel_executed);
        }
    }

    return 0;
}