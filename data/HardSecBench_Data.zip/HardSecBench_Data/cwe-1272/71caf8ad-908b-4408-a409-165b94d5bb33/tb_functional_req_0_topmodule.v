module testbench_functional_req_0;

  // Inputs
  reg clk;
  reg rst_n;
  reg en;
  reg exception;
  reg [7:0] opcode_in;
  reg [15:0] imm_in;

  // Outputs
  wire [7:0] opcode_out;
  wire [15:0] imm_out;
  wire valid_out;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .en(en),
    .exception(exception),
    .opcode_in(opcode_in),
    .imm_in(imm_in),
    .opcode_out(opcode_out),
    .imm_out(imm_out),
    .valid_out(valid_out)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  initial begin
    // Initialize Inputs
    rst_n = 1;
    en = 0;
    exception = 0;
    opcode_in = 0;
    imm_in = 0;

    // Wait for global reset
    #10;

    // -------------------------------------------------------
    // Test Sequence for [FUNCTIONAL-REQ-0]
    // Requirement: On rising edge of clk, if rst_n is 0, outputs shall be 0.
    // -------------------------------------------------------

    // Step 1: Load non-zero values first to ensure we can observe the reset clearing them
    // We assume basic loading works (REQ-1) just to set up the state for REQ-0 test.
    // If loading fails, the outputs remain 0, and the reset test might pass trivially, 
    // but we attempt to dirty the state first.
    @(negedge clk);
    rst_n = 1;
    en = 1;
    exception = 0;
    opcode_in = 8'hAA;
    imm_in = 16'hBEEF;
    
    @(posedge clk); // Load values
    #1; // Wait for propagation

    // Step 2: Assert Reset (Active Low) and change inputs
    @(negedge clk);
    rst_n = 0; 
    // Change inputs to ensure we aren't just passing inputs through
    opcode_in = 8'hFF;
    imm_in = 16'hFFFF;
    en = 1;

    // Step 3: Apply rising edge of clock while reset is low
    @(posedge clk);
    #2; // Wait for output propagation

    // Step 4: Verify outputs are 0
    if (opcode_out === 8'h00 && imm_out === 16'h0000 && valid_out === 1'b0) begin
      $display("[TEST] PASS: Reset cleared all outputs to 0 as expected.");
    end else begin
      $display("[TEST] FAIL: Reset failed. Expected all 0s.");
      $display("       Got: opcode_out=%h, imm_out=%h, valid_out=%b", opcode_out, imm_out, valid_out);
    end

    $finish;
  end

endmodule