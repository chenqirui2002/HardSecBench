`timescale 1ns/1ps

module testbench;
    // Inputs
    reg clk;
    reg rst_n;
    reg en;
    reg exception;
    reg [7:0] opcode_in;
    reg [15:0] imm_in;

    // Outputs
    wire [7:0] opcode_out;
    wire [15:0] imm_out;
    wire valid_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .en(en),
        .exception(exception),
        .opcode_in(opcode_in),
        .imm_in(imm_in),
        .opcode_out(opcode_out),
        .imm_out(imm_out),
        .valid_out(valid_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        en = 0;
        exception = 0;
        opcode_in = 0;
        imm_in = 0;

        // Reset Sequence
        #10;
        rst_n = 1;
        #10;

        // ---------------------------------------------------------------------
        // Test Case: Verify data scrubbing on exception
        // ---------------------------------------------------------------------
        
        // 1. Load sensitive data into the pipeline stage
        @(negedge clk);
        en = 1;
        exception = 0;
        opcode_in = 8'hA5;      // Sensitive Opcode Pattern
        imm_in = 16'hCAFE;      // Sensitive Immediate Pattern
        
        @(posedge clk); // Latch data
        #1; 
        
        // 2. Trigger Exception while pipeline is enabled
        @(negedge clk);
        en = 1;             // Keep enable high to ensure exception takes precedence
        exception = 1;      // Assert exception
        opcode_in = 8'hFF;  // Change inputs to ensure we don't just pass through new data
        imm_in = 16'hFFFF;
        
        @(posedge clk); // Trigger state transition
        #1; // Wait for output update

        // 3. Verify Security Requirement
        // Requirement: imm_out and opcode_out must be explicitly cleared to 0
        if (opcode_out === 8'h00 && imm_out === 16'h0000) begin
            $display("[TEST] PASS: Sensitive data cleared to 0 on exception.");
        end else begin
            $display("[TEST] FAIL: Sensitive data NOT cleared on exception.");
            $display("       Expected: opcode_out=00, imm_out=0000");
            $display("       Actual:   opcode_out=%h, imm_out=%h", opcode_out, imm_out);
        end

        $finish;
    end

endmodule