`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg en;
    reg exception;
    reg [7:0] opcode_in;
    reg [15:0] imm_in;

    // Outputs
    wire [7:0] opcode_out;
    wire [15:0] imm_out;
    wire valid_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .en(en),
        .exception(exception),
        .opcode_in(opcode_in),
        .imm_in(imm_in),
        .opcode_out(opcode_out),
        .imm_out(imm_out),
        .valid_out(valid_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        en = 0;
        exception = 0;
        opcode_in = 0;
        imm_in = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // Test Case 1: Normal operation with en=1, exception=0
        // Apply inputs on negative edge to ensure stability before posedge
        @(negedge clk);
        en = 1;
        exception = 0;
        opcode_in = 8'hA5;
        imm_in = 16'h1234;

        // Wait for clock edge to capture data
        @(posedge clk);
        #1; // Allow for propagation delay

        // Check results
        if (opcode_out !== 8'hA5 || imm_out !== 16'h1234 || valid_out !== 1'b1) begin
            $display("[TEST] FAIL: Iteration 1 - Expected opcode=A5, imm=1234, valid=1. Got opcode=%h, imm=%h, valid=%b", opcode_out, imm_out, valid_out);
            $finish;
        end

        // Test Case 2: Change data values
        @(negedge clk);
        opcode_in = 8'hC3;
        imm_in = 16'hDEAD;

        // Wait for clock edge
        @(posedge clk);
        #1; // Allow for propagation delay

        // Check results
        if (opcode_out !== 8'hC3 || imm_out !== 16'hDEAD || valid_out !== 1'b1) begin
            $display("[TEST] FAIL: Iteration 2 - Expected opcode=C3, imm=DEAD, valid=1. Got opcode=%h, imm=%h, valid=%b", opcode_out, imm_out, valid_out);
            $finish;
        end

        // Test Case 3: Boundary values
        @(negedge clk);
        opcode_in = 8'hFF;
        imm_in = 16'hFFFF;

        // Wait for clock edge
        @(posedge clk);
        #1; // Allow for propagation delay

        // Check results
        if (opcode_out !== 8'hFF || imm_out !== 16'hFFFF || valid_out !== 1'b1) begin
            $display("[TEST] FAIL: Iteration 3 - Expected opcode=FF, imm=FFFF, valid=1. Got opcode=%h, imm=%h, valid=%b", opcode_out, imm_out, valid_out);
            $finish;
        end

        $display("[TEST] PASS: Pipeline registers update correctly when enabled and no exception.");
        $finish;
    end

endmodule