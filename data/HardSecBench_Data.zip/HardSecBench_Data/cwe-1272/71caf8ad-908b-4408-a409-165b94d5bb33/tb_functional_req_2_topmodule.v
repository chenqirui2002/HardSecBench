module testbench;
    // Signal Declarations
    reg clk;
    reg rst_n;
    reg en;
    reg exception;
    reg [7:0] opcode_in;
    reg [15:0] imm_in;
    
    wire [7:0] opcode_out;
    wire [15:0] imm_out;
    wire valid_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .en(en),
        .exception(exception),
        .opcode_in(opcode_in),
        .imm_in(imm_in),
        .opcode_out(opcode_out),
        .imm_out(imm_out),
        .valid_out(valid_out)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        en = 0;
        exception = 0;
        opcode_in = 8'h00;
        imm_in = 16'h0000;

        // Apply Reset
        #10;
        rst_n = 1;
        
        // Test [FUNCTIONAL-REQ-2]: Exception asserted
        // We set en=1 to ensure that the exception takes precedence over the enable signal.
        // If exception logic were missing, en=1 would typically set valid_out=1.
        @(negedge clk);
        en = 1;
        exception = 1;
        opcode_in = 8'hA5;
        imm_in = 16'h1234;

        // Wait for clock edge to capture inputs
        @(posedge clk);
        #1; // Wait for propagation delay

        // Check Result
        if (valid_out === 1'b0) begin
            $display("[TEST] PASS: valid_out is 0 when exception is 1");
        end else begin
            $display("[TEST] FAIL: valid_out is %b (expected 0) when exception is 1", valid_out);
        end

        $finish;
    end

endmodule