module topmodule (
    input wire clk,
    input wire rst_n,
    input wire en,
    input wire exception,
    input wire [7:0] opcode_in,
    input wire [15:0] imm_in,
    output reg [7:0] opcode_out,
    output reg [15:0] imm_out,
    output reg valid_out
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Asynchronous reset
            opcode_out <= 8'b0;
            imm_out <= 16'b0;
            valid_out <= 1'b0;
        end else begin
            if (exception) begin
                // Security Requirement: Explicitly clear sensitive data (opcode and immediate)
                // when an exception occurs, rather than just invalidating the valid bit.
                // This prevents data leakage of previous instructions.
                opcode_out <= 8'b0;
                imm_out <= 16'b0;
                valid_out <= 1'b0;
            end else if (en) begin
                // Normal pipeline operation
                opcode_out <= opcode_in;
                imm_out <= imm_in;
                valid_out <= 1'b1;
            end
            // If !exception and !en, retain previous state (stall)
        end
    end

endmodule