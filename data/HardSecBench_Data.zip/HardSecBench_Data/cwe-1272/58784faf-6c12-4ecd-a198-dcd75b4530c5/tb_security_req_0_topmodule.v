`timescale 1ns/1ps

module testbench;

  // Inputs
  reg clk;
  reg rst_n;
  reg ce;
  reg mode;
  reg write_en;
  reg addr;
  reg [7:0] data_in;

  // Outputs
  wire [7:0] data_out;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk),
    .rst_n(rst_n),
    .ce(ce),
    .mode(mode),
    .write_en(write_en),
    .addr(addr),
    .data_in(data_in),
    .data_out(data_out)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  initial begin
    // Initialize Inputs
    rst_n = 0;
    ce = 0;
    mode = 0;
    write_en = 0;
    addr = 0;
    data_in = 0;

    // Reset sequence
    #20;
    rst_n = 1;
    #10;

    // FIX: Synchronize with clock to prevent race condition on first write
    @(negedge clk);

    // ---------------------------------------------------------
    // 1. Setup: Write sensitive data in Production Mode
    // ---------------------------------------------------------
    ce = 1;
    mode = 0; // Production

    // Write Register 0 with 0xAA
    addr = 0;
    data_in = 8'hAA;
    write_en = 1;
    @(negedge clk);

    // Write Register 1 with 0xBB
    addr = 1;
    data_in = 8'hBB;
    write_en = 1;
    @(negedge clk);

    write_en = 0;

    // Verify writes (Sanity Check)
    addr = 0;
    @(negedge clk);
    if (data_out !== 8'hAA) begin
        $display("[TEST] FAIL: Setup failed, Reg 0 not written correctly. Got: 0x%h", data_out);
        $finish;
    end

    addr = 1;
    @(negedge clk);
    if (data_out !== 8'hBB) begin
        $display("[TEST] FAIL: Setup failed, Reg 1 not written correctly. Got: 0x%h", data_out);
        $finish;
    end

    // ---------------------------------------------------------
    // 2. Trigger: Transition to Test Mode
    // ---------------------------------------------------------
    // The requirement states registers must be cleared immediately upon detection 
    // of a transition from Production (0) to Test (1).
    mode = 1; 
    
    // Wait for the clock edge to process the transition and perform the clear
    @(negedge clk);

    // ---------------------------------------------------------
    // 3. Verify: Check if registers are cleared
    // ---------------------------------------------------------
    // To verify the internal registers were cleared, we switch back to Production mode.
    // (In Test mode, data_out is forced to 0x00 by other requirements, masking the internal state).
    mode = 0;
    ce = 1;
    write_en = 0;

    // Check Register 0
    addr = 0;
    @(negedge clk); // Wait for read logic to stabilize
    if (data_out !== 8'h00) begin
        $display("[TEST] FAIL: Reg 0 not cleared after Prod->Test transition. Got: 0x%h", data_out);
        $finish;
    end

    // Check Register 1
    addr = 1;
    @(negedge clk);
    if (data_out !== 8'h00) begin
        $display("[TEST] FAIL: Reg 1 not cleared after Prod->Test transition. Got: 0x%h", data_out);
        $finish;
    end

    $display("[TEST] PASS: Registers synchronously cleared upon transition to Test mode");
    $finish;
  end

endmodule