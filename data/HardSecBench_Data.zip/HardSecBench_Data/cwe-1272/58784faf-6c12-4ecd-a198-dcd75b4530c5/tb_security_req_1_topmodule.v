`timescale 1ns/1ps

module testbench;

    // Inputs
    reg clk;
    reg rst_n;
    reg ce;
    reg mode;
    reg write_en;
    reg addr;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .ce(ce),
        .mode(mode),
        .write_en(write_en),
        .addr(addr),
        .data_in(data_in),
        .data_out(data_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        ce = 0;
        mode = 0;
        write_en = 0;
        addr = 0;
        data_in = 0;

        // Apply Reset
        #10 rst_n = 1;
        #10;

        // ---------------------------------------------------------------------
        // TEST CASE: Write Priority and Read Masking
        // ---------------------------------------------------------------------
        // Objective: 
        // 1. Verify that transitioning to Test Mode (mode 0->1) clears registers
        //    EVEN IF a write is attempted simultaneously (Priority Check).
        // 2. Verify that data_out is masked (0x00) while in Test Mode.
        
        // Step 1: Pre-load Register 0 with known data (0xAA) in Production Mode
        @(negedge clk);
        mode = 0;
        ce = 1;
        write_en = 1;
        addr = 0;
        data_in = 8'hAA;
        
        @(posedge clk); // Write 0xAA occurs here
        
        // Step 2: Trigger Transition (0->1) AND Attempt Write (0xFF)
        // If secure: Register becomes 0x00 (Clear > Write).
        // If insecure: Register becomes 0xFF (Write > Clear) or stays 0xAA (No Clear).
        @(negedge clk);
        mode = 1;         // Transition to Test
        write_en = 1;     // Attempt Write simultaneously
        data_in = 8'hFF;  // Malicious/New Data
        addr = 0;
        
        @(posedge clk);   // Active edge for transition and write attempt
        #1; // Allow propagation

        // Step 3: Verify Read Masking in Test Mode
        // Requirement: data_out driven to 0x00 in Test Mode
        if (data_out !== 8'h00) begin
            $display("[TEST] FAIL: data_out was not masked in Test Mode. Expected 0x00, Got 0x%h", data_out);
            $finish;
        end

        // Step 4: Verify Register Content (Check Priority)
        // We must switch back to Production Mode to read the actual register value,
        // because Test Mode masks the output (verified in Step 3).
        @(negedge clk);
        mode = 0;       // Back to Production
        write_en = 0;   // Read only
        addr = 0;
        
        @(posedge clk); // Latch mode change / read address
        #1;

        if (data_out === 8'h00) begin
            $display("[TEST] PASS: Priority verified. Register cleared to 0x00 despite write attempt.");
        end else if (data_out === 8'hFF) begin
            $display("[TEST] FAIL: Write Priority Violation. Write (0xFF) overrode Security Clear.");
        end else if (data_out === 8'hAA) begin
            $display("[TEST] FAIL: Security Clear Missing. Register retained old value (0xAA).");
        end else begin
            $display("[TEST] FAIL: Unexpected register value 0x%h", data_out);
        end

        $finish;
    end

endmodule