module tb_task_cwe_1272_seed12;

    // Inputs
    reg clk;
    reg rst_n;
    reg ce;
    reg mode;
    reg write_en;
    reg addr;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .ce(ce),
        .mode(mode),
        .write_en(write_en),
        .addr(addr),
        .data_in(data_in),
        .data_out(data_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer fail_count = 0;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        ce = 0;
        mode = 0;
        write_en = 0;
        addr = 0;
        data_in = 0;

        // Apply Reset
        #10 rst_n = 1;
        #10;

        // ----------------------------------------------------------------
        // Pre-requisite: Write data to registers to allow verification of read
        // ----------------------------------------------------------------
        
        // Write 0xAA to Register 0
        @(negedge clk);
        ce = 1; mode = 0; write_en = 1; addr = 0; data_in = 8'hAA;
        @(negedge clk);

        // Write 0xBB to Register 1
        ce = 1; mode = 0; write_en = 1; addr = 1; data_in = 8'hBB;
        @(negedge clk);

        // Disable write
        write_en = 0;
        ce = 0;
        
        // ----------------------------------------------------------------
        // Test [FUNCTIONAL-REQ-2]: Read Operations
        // ----------------------------------------------------------------
        
        // Case 1: Read Register 0 (ce=1, mode=0, addr=0)
        @(negedge clk);
        ce = 1; mode = 0; addr = 0;
        #1; // Wait for combinational logic
        if (data_out !== 8'hAA) begin
            $display("[TEST] FAIL: Read Reg 0 (ce=1, mode=0). Expected 0xAA, got 0x%h", data_out);
            fail_count = fail_count + 1;
        end

        // Case 2: Read Register 1 (ce=1, mode=0, addr=1)
        @(negedge clk);
        ce = 1; mode = 0; addr = 1;
        #1;
        if (data_out !== 8'hBB) begin
            $display("[TEST] FAIL: Read Reg 1 (ce=1, mode=0). Expected 0xBB, got 0x%h", data_out);
            fail_count = fail_count + 1;
        end

        // ----------------------------------------------------------------
        // Test [FUNCTIONAL-REQ-2]: "Otherwise" conditions (data_out == 0)
        // ----------------------------------------------------------------

        // Case 3: ce = 0 (mode = 0)
        @(negedge clk);
        ce = 0; mode = 0; addr = 0;
        #1;
        if (data_out !== 8'h00) begin
            $display("[TEST] FAIL: Output check (ce=0, mode=0). Expected 0x00, got 0x%h", data_out);
            fail_count = fail_count + 1;
        end

        // Case 4: mode = 1 (ce = 1) -> Test Mode
        @(negedge clk);
        ce = 1; mode = 1; addr = 0;
        #1;
        if (data_out !== 8'h00) begin
            $display("[TEST] FAIL: Output check (ce=1, mode=1). Expected 0x00, got 0x%h", data_out);
            fail_count = fail_count + 1;
        end

        // Case 5: ce = 0 and mode = 1
        @(negedge clk);
        ce = 0; mode = 1; addr = 0;
        #1;
        if (data_out !== 8'h00) begin
            $display("[TEST] FAIL: Output check (ce=0, mode=1). Expected 0x00, got 0x%h", data_out);
            fail_count = fail_count + 1;
        end

        // Summary
        if (fail_count == 0) begin
            $display("[TEST] PASS: Functional Requirement 2 verified.");
        end else begin
            $display("[TEST] FAIL: %0d checks failed.", fail_count);
        end

        $finish;
    end

endmodule