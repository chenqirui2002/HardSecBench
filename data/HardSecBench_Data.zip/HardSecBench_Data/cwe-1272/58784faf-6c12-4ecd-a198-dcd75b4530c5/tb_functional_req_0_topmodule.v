`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg ce;
    reg mode;
    reg write_en;
    reg addr;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .ce(ce),
        .mode(mode),
        .write_en(write_en),
        .addr(addr),
        .data_in(data_in),
        .data_out(data_out)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 1;
        ce = 0;
        mode = 0;
        write_en = 0;
        addr = 0;
        data_in = 0;

        // Wait for global reset stabilization
        #20;

        // ---------------------------------------------------------------------
        // Step 1: Setup - Write non-zero values to registers
        // ---------------------------------------------------------------------
        $display("[TEST] Writing initial values 0xAA and 0xBB...");
        
        // Write 0xAA to Register 0
        @(negedge clk);
        ce = 1;
        mode = 0; // Production mode
        write_en = 1;
        addr = 0;
        data_in = 8'hAA;
        
        // Write 0xBB to Register 1
        @(negedge clk);
        addr = 1;
        data_in = 8'hBB;

        @(negedge clk);
        write_en = 0; // Disable write

        // ---------------------------------------------------------------------
        // Step 2: Sanity Check - Verify writes succeeded
        // ---------------------------------------------------------------------
        // Read Reg 0
        addr = 0;
        @(negedge clk);
        if (data_out !== 8'hAA) begin
            $display("[TEST] FAIL: Setup write to Reg 0 failed. Expected 0xAA, got 0x%h", data_out);
            $finish;
        end

        // Read Reg 1
        addr = 1;
        @(negedge clk);
        if (data_out !== 8'hBB) begin
            $display("[TEST] FAIL: Setup write to Reg 1 failed. Expected 0xBB, got 0x%h", data_out);
            $finish;
        end

        // ---------------------------------------------------------------------
        // Step 3: Test Reset
        // ---------------------------------------------------------------------
        $display("[TEST] Asserting Reset...");
        
        // Assert asynchronous reset
        #2; 
        rst_n = 0;
        #20; 
        rst_n = 1; // Release reset
        #10;

        // ---------------------------------------------------------------------
        // Step 4: Verify Registers are cleared to 0
        // ---------------------------------------------------------------------
        // Ensure we are in Production mode to read the actual register values
        // (Test mode might force output to 0 regardless of register content)
        ce = 1;
        mode = 0; 
        write_en = 0;

        // Verify Reg 0
        addr = 0;
        @(negedge clk);
        if (data_out !== 8'h00) begin
            $display("[TEST] FAIL: Reset did not clear Reg 0. Expected 0x00, got 0x%h", data_out);
            $finish;
        end

        // Verify Reg 1
        addr = 1;
        @(negedge clk);
        if (data_out !== 8'h00) begin
            $display("[TEST] FAIL: Reset did not clear Reg 1. Expected 0x00, got 0x%h", data_out);
            $finish;
        end

        $display("[TEST] PASS: Reset correctly initialized registers to 0.");
        $finish;
    end

endmodule