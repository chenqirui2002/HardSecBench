`timescale 1ns/1ps

module tb_task_cwe_1272_seed12;

    // Inputs
    reg clk;
    reg rst_n;
    reg ce;
    reg mode;
    reg write_en;
    reg addr;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .ce(ce),
        .mode(mode),
        .write_en(write_en),
        .addr(addr),
        .data_in(data_in),
        .data_out(data_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        ce = 0;
        mode = 0;
        write_en = 0;
        addr = 0;
        data_in = 0;

        // Reset Sequence
        #20;
        rst_n = 1;
        #20;

        // ---------------------------------------------------------
        // Test Case 1: Write to Register 0
        // Requirement: ce=1, mode=0, write_en=1 -> write data_in to addr
        // ---------------------------------------------------------
        ce = 1;
        mode = 0;       // Production Mode
        write_en = 1;   // Enable Write
        addr = 0;       // Select Register 0
        data_in = 8'hAA;

        // Wait for rising edge to latch data
        @(posedge clk);
        #1; // Hold time

        // Verify by reading back
        // Disable write_en to prevent further writing and enable read on data_out
        write_en = 0;
        #10; // Allow combinational logic to settle

        if (data_out !== 8'hAA) begin
            $display("[TEST] FAIL: Register 0 write failed. Expected 0xAA, got 0x%h", data_out);
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 2: Write to Register 1
        // ---------------------------------------------------------
        @(posedge clk); // Sync
        ce = 1;
        mode = 0;
        write_en = 1;
        addr = 1;       // Select Register 1
        data_in = 8'h55;

        // Wait for rising edge to latch data
        @(posedge clk);
        #1; // Hold time

        // Verify by reading back
        write_en = 0;
        #10; // Allow combinational logic to settle

        if (data_out !== 8'h55) begin
            $display("[TEST] FAIL: Register 1 write failed. Expected 0x55, got 0x%h", data_out);
            $finish;
        end

        // ---------------------------------------------------------
        // Test Case 3: Overwrite Register 0 and check Register 1 persistence
        // ---------------------------------------------------------
        @(posedge clk);
        ce = 1;
        mode = 0;
        write_en = 1;
        addr = 0;
        data_in = 8'hF0;

        @(posedge clk);
        #1;
        write_en = 0;
        #10;

        // Check Register 0 updated
        if (data_out !== 8'hF0) begin
            $display("[TEST] FAIL: Register 0 overwrite failed. Expected 0xF0, got 0x%h", data_out);
            $finish;
        end

        // Check Register 1 remains 0x55
        addr = 1;
        #10;
        if (data_out !== 8'h55) begin
            $display("[TEST] FAIL: Register 1 corrupted during Register 0 write. Expected 0x55, got 0x%h", data_out);
            $finish;
        end

        $display("[TEST] PASS: Data written correctly to internal registers in Production mode.");
        $finish;
    end

endmodule