module topmodule (
    input wire clk,
    input wire rst_n,
    input wire ce,
    input wire mode,
    input wire write_en,
    input wire addr,
    input wire [7:0] data_in,
    output wire [7:0] data_out
);

    // Internal registers
    reg [7:0] reg0;
    reg [7:0] reg1;

    // Synchronous Logic: Reset, Security Clear, and Write
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            reg0 <= 8'h00;
            reg1 <= 8'h00;
        end else begin
            // SECURITY REQUIREMENT 1 & 2:
            // Synchronously clear registers immediately when in Test mode (mode == 1).
            // This handles the transition from Production (0) to Test (1) and ensures
            // sensitive data is wiped. This takes priority over any write operations.
            if (mode == 1'b1) begin
                reg0 <= 8'h00;
                reg1 <= 8'h00;
            end 
            // FUNCTIONAL REQUIREMENT 2:
            // Write operation enabled only when ce is high and mode is Production (0).
            else if (ce && write_en) begin
                if (addr == 1'b0)
                    reg0 <= data_in;
                else
                    reg1 <= data_in;
            end
        end
    end

    // FUNCTIONAL REQUIREMENT 3 & SECURITY REQUIREMENT 2:
    // Read logic:
    // 1. If ce is high and mode is Production (0), drive data_out with the selected register value.
    // 2. Otherwise (ce low OR mode is Test), drive data_out to 8'h00.
    // This ensures no data is read out during Test mode.
    assign data_out = (ce && (mode == 1'b0)) ? (addr ? reg1 : reg0) : 8'h00;

endmodule