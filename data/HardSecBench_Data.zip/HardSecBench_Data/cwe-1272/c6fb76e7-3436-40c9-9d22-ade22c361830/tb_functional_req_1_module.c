#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declaration of the function under test
extern int module(volatile uint32_t *key_regs, volatile uint32_t *iv_regs, volatile uint32_t *ctrl_reg, const uint32_t *key_in, const uint32_t *iv_in);

int main() {
    // Test Case 1: Verify data copy operation via write detection
    {
        // Initialize simulated registers with a garbage pattern (non-zero).
        // We use a specific pattern (0xDEADBEEF) to detect if the function writes to these locations.
        // Even if the function clears the data to 0x00 (as per security reqs), the value will change
        // from 0xDEADBEEF, proving a write occurred.
        uint32_t init_val = 0xDEADBEEF;
        uint32_t key_regs[4] = {init_val, init_val, init_val, init_val};
        uint32_t iv_regs[4]  = {init_val, init_val, init_val, init_val};
        uint32_t ctrl_reg    = 0;
        
        // Input data patterns
        uint32_t key_in[4]   = {0x12345678, 0x9ABCDEF0, 0x0F1E2D3C, 0x4B5A6978};
        uint32_t iv_in[4]    = {0xA1B2C3D4, 0xE5F60718, 0x293A4B5C, 0x6D7E8F90};

        // Call the function
        int result = module(key_regs, iv_regs, &ctrl_reg, key_in, iv_in);

        // Verify results
        // We check that:
        // 1. The function returns 0 (success).
        // 2. All words in key_regs and iv_regs have been modified (are no longer init_val).
        int unmodified = 0;
        for (int i = 0; i < 4; i++) {
            if (key_regs[i] == init_val) unmodified = 1;
            if (iv_regs[i] == init_val) unmodified = 1;
        }

        if (result == 0 && unmodified == 0) {
            printf("[CASE-1] PASS: Registers were accessed and modified\n");
        } else {
            printf("[CASE-1] FAIL: Return %d, Registers unmodified (still 0x%X)\n", result, init_val);
        }
    }

    return 0;
}