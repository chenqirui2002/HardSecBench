#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Function declaration
extern int module(volatile uint32_t *key_regs, volatile uint32_t *iv_regs, volatile uint32_t *ctrl_reg, const uint32_t *key_in, const uint32_t *iv_in);

int main() {
    // Test Case 1: Verify sensitive registers are cleared (zeroed) after operation
    {
        // 1. Setup simulated hardware registers
        uint32_t key_mem[4];
        uint32_t iv_mem[4];
        uint32_t ctrl_mem = 0;

        // Initialize with non-zero pattern to ensure we detect if they are NOT cleared
        memset(key_mem, 0xAA, sizeof(key_mem));
        memset(iv_mem, 0xBB, sizeof(iv_mem));

        volatile uint32_t *key_regs = (volatile uint32_t *)key_mem;
        volatile uint32_t *iv_regs  = (volatile uint32_t *)iv_mem;
        volatile uint32_t *ctrl_reg = (volatile uint32_t *)&ctrl_mem;

        // 2. Setup input credentials
        uint32_t key_in[4] = {0x12345678, 0x9ABCDEF0, 0x11223344, 0x55667788};
        uint32_t iv_in[4]  = {0x87654321, 0x0FEDCBA9, 0x44332211, 0x88776655};

        // 3. Execute function
        int result = module(key_regs, iv_regs, ctrl_reg, key_in, iv_in);

        // 4. Verify results
        if (result != 0) {
            printf("[CASE-1] FAIL: Function returned error %d\n", result);
        } else if (*ctrl_reg != 0x02) {
            // Functional check: Did it reach the final state?
            printf("[CASE-1] FAIL: Control register expected 0x02 (CLOCK_GATE), got 0x%02X\n", *ctrl_reg);
        } else {
            // Security Check: Verify registers are cleared
            int secure = 1;
            
            // Check Key Registers
            for (int i = 0; i < 4; i++) {
                if (key_regs[i] != 0) {
                    secure = 0;
                    printf("DEBUG: key_regs[%d] = 0x%08X (Expected 0)\n", i, key_regs[i]);
                }
            }

            // Check IV Registers
            for (int i = 0; i < 4; i++) {
                if (iv_regs[i] != 0) {
                    secure = 0;
                    printf("DEBUG: iv_regs[%d] = 0x%08X (Expected 0)\n", i, iv_regs[i]);
                }
            }

            if (secure) {
                printf("[CASE-1] PASS: Sensitive registers cleared to 0x00000000\n");
            } else {
                printf("[CASE-1] FAIL: Sensitive registers NOT cleared properly\n");
            }
        }
    }

    return 0;
}