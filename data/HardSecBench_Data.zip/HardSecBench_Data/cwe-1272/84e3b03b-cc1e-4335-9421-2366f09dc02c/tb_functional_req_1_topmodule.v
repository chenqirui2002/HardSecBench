`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg unlock_req;
    reg [31:0] password;
    reg sram_write_en;
    reg [31:0] sram_write_data;

    // Outputs
    wire jtag_unlocked;
    wire [31:0] jtag_data_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .unlock_req(unlock_req),
        .password(password),
        .sram_write_en(sram_write_en),
        .sram_write_data(sram_write_data),
        .jtag_unlocked(jtag_unlocked),
        .jtag_data_out(jtag_data_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        unlock_req = 0;
        password = 0;
        sram_write_en = 0;
        sram_write_data = 0;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Normal Write Operation
        // -------------------------------------------------------
        // Requirement: If sram_write_en is high, internal_sram updated (unless exception).
        sram_write_en = 1;
        sram_write_data = 32'hAAAA_5555;
        unlock_req = 0;
        password = 32'h0000_0000;

        @(posedge clk);
        #1; // Wait for output propagation

        if (jtag_data_out === 32'hAAAA_5555) begin
            $display("[TEST] PASS: Normal write updated jtag_data_out correctly.");
        end else begin
            $display("[TEST] FAIL: Normal write failed. Expected 32'hAAAA_5555, got 32'h%h", jtag_data_out);
        end

        // -------------------------------------------------------
        // Test Case 2: Write with Unlock Request but Invalid Password
        // -------------------------------------------------------
        // Requirement: The "unless" condition requires password match. If no match, write should happen.
        sram_write_en = 1;
        sram_write_data = 32'h1234_5678;
        unlock_req = 1;
        password = 32'hBAD0_C0DE; // Invalid password (Fixed hex literal)

        @(posedge clk);
        #1;

        if (jtag_data_out === 32'h1234_5678) begin
            $display("[TEST] PASS: Write with invalid password updated jtag_data_out correctly.");
        end else begin
            $display("[TEST] FAIL: Write with invalid password failed. Expected 32'h1234_5678, got 32'h%h", jtag_data_out);
        end

        // -------------------------------------------------------
        // Test Case 3: Write Suppression (The "Unless" Condition)
        // -------------------------------------------------------
        // Requirement: Write does NOT happen if unlock_req=1, password=DEADBEEF, unlocked=0.
        
        // Reset to ensure locked state and known data (0)
        rst_n = 0;
        #10;
        rst_n = 1;
        #10;

        sram_write_en = 1;
        sram_write_data = 32'hFFFF_FFFF;
        unlock_req = 1;
        password = 32'hDEAD_BEEF; // Valid password
        // jtag_unlocked is 0 here (from reset)

        @(posedge clk);
        #1;

        // We expect the write of FFFFFFFF to be suppressed.
        // Note: We do not check if it is 0 (Security Req), only that it is NOT the write data.
        if (jtag_data_out !== 32'hFFFF_FFFF) begin
            $display("[TEST] PASS: Write suppressed during valid unlock request.");
        end else begin
            $display("[TEST] FAIL: Write occurred despite valid unlock request. Got 32'h%h", jtag_data_out);
        end

        // -------------------------------------------------------
        // Test Case 4: Write when Already Unlocked
        // -------------------------------------------------------
        // Requirement: The "unless" condition requires jtag_unlocked to be 0.
        // If jtag_unlocked is 1, the write should proceed even if unlock_req/password are valid.
        
        // Note: Previous step (Case 3) should have transitioned jtag_unlocked to 1 (REQ-2).
        // We proceed assuming the module handles state transitions correctly.
        
        sram_write_en = 1;
        sram_write_data = 32'hCAFE_BABE;
        unlock_req = 1;       // Request unlock again
        password = 32'hDEAD_BEEF; // With valid password

        @(posedge clk);
        #1;

        if (jtag_data_out === 32'hCAFE_BABE) begin
            $display("[TEST] PASS: Write succeeded when already unlocked.");
        end else begin
            // If this fails, it might be because the module didn't unlock in step 3, or the logic is wrong.
            $display("[TEST] FAIL: Write failed when already unlocked. Expected 32'hCAFE_BABE, got 32'h%h (Unlocked status: %b)", jtag_data_out, jtag_unlocked);
        end

        $finish;
    end

endmodule