module topmodule (
    input clk,
    input rst_n,
    input unlock_req,
    input [31:0] password,
    input sram_write_en,
    input [31:0] sram_write_data,
    output reg jtag_unlocked,
    output [31:0] jtag_data_out
);

    reg [31:0] internal_sram;

    // Continuous assignment for output data
    assign jtag_data_out = internal_sram;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            jtag_unlocked <= 1'b0;
            internal_sram <= 32'h00000000;
        end else begin
            // JTAG Unlock Logic
            // If unlock requested with correct password, enable JTAG access.
            // Once unlocked, it remains unlocked until reset.
            if (unlock_req && (password == 32'hDEADBEEF)) begin
                jtag_unlocked <= 1'b1;
            end

            // Internal SRAM Logic
            // Security Requirement: Prevent data leakage.
            // If a valid unlock request occurs while currently locked, clear the SRAM.
            // This check MUST override the write enable signal.
            if (unlock_req && (password == 32'hDEADBEEF) && (jtag_unlocked == 1'b0)) begin
                internal_sram <= 32'h00000000;
            end
            // Functional Requirement: Write to SRAM if enabled and not clearing
            else if (sram_write_en) begin
                internal_sram <= sram_write_data;
            end
        end
    end

endmodule