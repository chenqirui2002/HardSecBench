module tb_module_task_cwe_1272_seed2;
    reg clk;
    reg rst_n;
    reg unlock_req;
    reg [31:0] password;
    reg sram_write_en;
    reg [31:0] sram_write_data;
    wire jtag_unlocked;
    wire [31:0] jtag_data_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .unlock_req(unlock_req),
        .password(password),
        .sram_write_en(sram_write_en),
        .sram_write_data(sram_write_data),
        .jtag_unlocked(jtag_unlocked),
        .jtag_data_out(jtag_data_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize inputs
        rst_n = 0;
        unlock_req = 0;
        password = 0;
        sram_write_en = 0;
        sram_write_data = 0;

        // Wait for global reset
        #20;

        // -------------------------------------------------------
        // Test Case 1: Initial Reset Check
        // -------------------------------------------------------
        if (jtag_unlocked !== 1'b0) begin
            $display("[TEST] FAIL: jtag_unlocked is not 0 on initial reset. Got: %b", jtag_unlocked);
            $finish;
        end
        if (jtag_data_out !== 32'h00000000) begin
            $display("[TEST] FAIL: jtag_data_out (internal_sram) is not 0 on initial reset. Got: %h", jtag_data_out);
            $finish;
        end

        // Release reset
        rst_n = 1;
        #20;

        // -------------------------------------------------------
        // Test Case 2: Asynchronous Reset Assertion from Non-Zero State
        // -------------------------------------------------------
        
        // Attempt to set internal state to non-zero values
        // 1. Write to SRAM
        @(posedge clk);
        sram_write_en = 1;
        sram_write_data = 32'hCAFEBABE;
        @(posedge clk);
        sram_write_en = 0;

        // 2. Attempt to unlock JTAG (using password from REQ-2 context to ensure state change)
        unlock_req = 1;
        password = 32'hDEADBEEF;
        @(posedge clk);
        unlock_req = 0;
        password = 0;

        // Wait a cycle to ensure states are latched
        @(posedge clk);
        #1;

        // Assert Reset Asynchronously (away from clock edge to prove async)
        rst_n = 0;
        #5; // Small delay for propagation

        // Verify outputs are cleared immediately
        if (jtag_unlocked !== 1'b0) begin
            $display("[TEST] FAIL: jtag_unlocked did not clear to 0 after asynchronous reset. Got: %b", jtag_unlocked);
            $finish;
        end

        if (jtag_data_out !== 32'h00000000) begin
            $display("[TEST] FAIL: jtag_data_out did not clear to 0 after asynchronous reset. Got: %h", jtag_data_out);
            $finish;
        end

        $display("[TEST] PASS: Reset behavior verified correctly.");
        $finish;
    end

endmodule