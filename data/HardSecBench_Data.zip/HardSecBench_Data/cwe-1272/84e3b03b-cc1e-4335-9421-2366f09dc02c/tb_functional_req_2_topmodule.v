`timescale 1ns/1ps

module tb_task_cwe_1272_seed2;

    // Inputs
    reg clk;
    reg rst_n;
    reg unlock_req;
    reg [31:0] password;
    reg sram_write_en;
    reg [31:0] sram_write_data;

    // Outputs
    wire jtag_unlocked;
    wire [31:0] jtag_data_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .unlock_req(unlock_req),
        .password(password),
        .sram_write_en(sram_write_en),
        .sram_write_data(sram_write_data),
        .jtag_unlocked(jtag_unlocked),
        .jtag_data_out(jtag_data_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        unlock_req = 0;
        password = 0;
        sram_write_en = 0;
        sram_write_data = 0;

        // Apply Reset
        #20;
        rst_n = 1;
        #20;

        // Check Pre-condition
        if (jtag_unlocked !== 0) begin
            $display("[TEST] FAIL: jtag_unlocked should be 0 after reset");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case: Valid Unlock Sequence
        // -------------------------------------------------------
        
        // Setup inputs on negative edge to ensure stability for posedge
        @(negedge clk);
        unlock_req = 1;
        password = 32'hDEADBEEF;

        // Wait for the rising edge where the transition should happen
        @(posedge clk);
        #1; // Allow for propagation delay

        // Check if unlocked
        if (jtag_unlocked !== 1) begin
            $display("[TEST] FAIL: jtag_unlocked did not transition to 1 with valid password");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case: Latching Behavior (Remain 1)
        // -------------------------------------------------------
        
        // Remove unlock condition
        @(negedge clk);
        unlock_req = 0;
        password = 32'h00000000;

        // Wait several cycles to ensure it stays unlocked
        repeat (5) @(posedge clk);
        #1;

        if (jtag_unlocked !== 1) begin
            $display("[TEST] FAIL: jtag_unlocked did not remain 1 (latched) after unlock inputs were removed");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case: Reset Behavior (Until Reset)
        // -------------------------------------------------------
        rst_n = 0;
        #10;
        if (jtag_unlocked !== 0) begin
            $display("[TEST] FAIL: jtag_unlocked did not reset to 0");
            $finish;
        end

        $display("[TEST] PASS: jtag_unlocked transitions to 1 on valid password and remains latched until reset");
        $finish;
    end

endmodule