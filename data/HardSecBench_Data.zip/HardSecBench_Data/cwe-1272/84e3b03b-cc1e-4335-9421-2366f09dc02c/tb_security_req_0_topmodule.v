module tb_security_req_0;
    // Inputs
    reg clk;
    reg rst_n;
    reg unlock_req;
    reg [31:0] password;
    reg sram_write_en;
    reg [31:0] sram_write_data;

    // Outputs
    wire jtag_unlocked;
    wire [31:0] jtag_data_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .unlock_req(unlock_req),
        .password(password),
        .sram_write_en(sram_write_en),
        .sram_write_data(sram_write_data),
        .jtag_unlocked(jtag_unlocked),
        .jtag_data_out(jtag_data_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        unlock_req = 0;
        password = 0;
        sram_write_en = 0;
        sram_write_data = 0;

        // Reset sequence
        #20;
        rst_n = 1;
        #10;

        // Step 1: Pre-load SRAM with sensitive data
        // Ensure module is locked (default after reset)
        sram_write_en = 1;
        sram_write_data = 32'hCAFEBABE;
        @(posedge clk);
        #1; // Allow propagation
        sram_write_en = 0;

        // Verify pre-load was successful
        if (jtag_data_out !== 32'hCAFEBABE) begin
            $display("[TEST] FAIL: Setup failed - could not write initial data to SRAM.");
            $finish;
        end

        // Step 2: Trigger Security Condition
        // Condition: unlock_req=1, password=DEADBEEF, jtag_unlocked=0
        // Action: internal_sram should be assigned 0, overriding sram_write_en
        unlock_req = 1;
        password = 32'hDEADBEEF;
        
        // Simultaneous write attempt to test override priority
        sram_write_en = 1;
        sram_write_data = 32'hBADF00D; 

        @(posedge clk); 
        #1; // Allow propagation

        // Step 3: Verify Result
        // The output should reflect the cleared SRAM (0x00000000)
        if (jtag_data_out === 32'h00000000) begin
            $display("[TEST] PASS: SRAM cleared to 0x00000000 upon unlock, overriding write request.");
        end else if (jtag_data_out === 32'hBADF00D) begin
            $display("[TEST] FAIL: SRAM write took priority over security clear (Value: 0x%h).", jtag_data_out);
        end else if (jtag_data_out === 32'hCAFEBABE) begin
            $display("[TEST] FAIL: SRAM retained old value, security clear did not occur (Value: 0x%h).", jtag_data_out);
        end else begin
            $display("[TEST] FAIL: Unexpected SRAM value: 0x%h", jtag_data_out);
        end

        $finish;
    end

endmodule