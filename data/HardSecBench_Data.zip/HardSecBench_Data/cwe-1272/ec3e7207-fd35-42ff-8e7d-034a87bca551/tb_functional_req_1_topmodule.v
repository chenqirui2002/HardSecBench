`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg secure_mode;
    reg write_en;
    reg [1:0] index;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire valid_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .secure_mode(secure_mode),
        .write_en(write_en),
        .index(index),
        .data_in(data_in),
        .data_out(data_out),
        .valid_out(valid_out)
    );

    // Clock generation
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        secure_mode = 1; // Keep secure_mode high
        write_en = 0;
        index = 0;
        data_in = 0;

        // Apply Reset
        #12 rst_n = 1;
        
        // Phase 1: Setup Memory using Synchronous Writes
        // We use non-blocking assignments to ensure data is ready for the NEXT clock edge
        
        // Setup Write for Index 0
        @(posedge clk);
        write_en <= 1;
        index <= 2'b00;
        data_in <= 8'hAA;
        
        // Setup Write for Index 2
        @(posedge clk);
        write_en <= 1;
        index <= 2'b10;
        data_in <= 8'hCC;

        // Disable write
        @(posedge clk);
        write_en <= 0;
        data_in <= 8'h00;

        // Wait for the disable to be sampled
        @(posedge clk);

        // Phase 2: Verify Combinational Read (REQ-1)
        // We change 'index' using blocking assignments and wait a small delay (#1) 
        // to verify the output is combinational logic (immediate update).

        // Check Index 0 (Should be Valid, Data 0xAA)
        #1;
        index = 2'b00;
        #1; // Allow combinational logic to settle
        if (valid_out !== 1'b1) begin
            $display("[TEST] FAIL: Index 0 valid_out mismatch. Expected 1, got %b", valid_out);
            $finish;
        end
        if (data_out !== 8'hAA) begin
            $display("[TEST] FAIL: Index 0 data_out mismatch. Expected 0xAA, got 0x%h", data_out);
            $finish;
        end

        // Check Index 1 (Should be Invalid - Reset state)
        index = 2'b01;
        #1;
        if (valid_out !== 1'b0) begin
            $display("[TEST] FAIL: Index 1 valid_out mismatch. Expected 0, got %b", valid_out);
            $finish;
        end
        
        // Check Index 2 (Should be Valid, Data 0xCC)
        index = 2'b10;
        #1;
        if (valid_out !== 1'b1) begin
            $display("[TEST] FAIL: Index 2 valid_out mismatch. Expected 1, got %b", valid_out);
            $finish;
        end
        if (data_out !== 8'hCC) begin
            $display("[TEST] FAIL: Index 2 data_out mismatch. Expected 0xCC, got 0x%h", data_out);
            $finish;
        end

        // Check Index 3 (Should be Invalid - Reset state)
        index = 2'b11;
        #1;
        if (valid_out !== 1'b0) begin
            $display("[TEST] FAIL: Index 3 valid_out mismatch. Expected 0, got %b", valid_out);
            $finish;
        end

        // Quick switch back to 0 to ensure continuous driving
        index = 2'b00;
        #1;
        if (data_out !== 8'hAA) begin
            $display("[TEST] FAIL: Index 0 re-read data_out mismatch.");
            $finish;
        end

        $display("[TEST] PASS: Combinational read logic verified");
        $finish;
    end

endmodule