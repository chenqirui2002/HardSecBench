`timescale 1ns/1ps

module tb_functional_req_0;

    // Testbench signals
    reg clk;
    reg rst_n;
    reg secure_mode;
    reg write_en;
    reg [1:0] index;
    reg [7:0] data_in;
    wire [7:0] data_out;
    wire valid_out;

    // Instantiate the DUT
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .secure_mode(secure_mode),
        .write_en(write_en),
        .index(index),
        .data_in(data_in),
        .data_out(data_out),
        .valid_out(valid_out)
    );

    // Clock generation
    initial clk = 0;
    always #5 clk = ~clk;

    // Test variables
    integer i;
    reg [7:0] test_patterns [0:3];
    reg test_pass;

    initial begin
        // 1. Initialize Inputs
        rst_n = 0;
        secure_mode = 1; // Keep secure_mode high to avoid security logic interference
        write_en = 0;
        index = 0;
        data_in = 0;
        test_pass = 1;

        // Define distinct patterns to verify independence of slots
        test_patterns[0] = 8'hAA;
        test_patterns[1] = 8'hBB;
        test_patterns[2] = 8'hCC;
        test_patterns[3] = 8'hDD;

        // 2. Reset Sequence
        #20 rst_n = 1;
        #10;

        // 3. Write Phase: Write distinct data to all 4 slots
        // This exercises the existence of the data register and valid register for each slot
        for (i = 0; i < 4; i = i + 1) begin
            @(posedge clk);
            index = i[1:0];
            data_in = test_patterns[i];
            write_en = 1;
            @(posedge clk); // Allow write to happen on this edge
            write_en = 0;
            #1; // Hold time
        end

        // 4. Read Phase: Verify data and valid bit for all 4 slots
        for (i = 0; i < 4; i = i + 1) begin
            @(posedge clk);
            index = i[1:0];
            write_en = 0;
            #2; // Allow combinational read logic to settle

            // Verify Data
            if (data_out !== test_patterns[i]) begin
                $display("[TEST] FAIL: Data mismatch at index %0d. Expected 0x%h, Got 0x%h", i, test_patterns[i], data_out);
                test_pass = 0;
            end

            // Verify Valid Bit
            if (valid_out !== 1'b1) begin
                $display("[TEST] FAIL: Valid bit not set at index %0d", i);
                test_pass = 0;
            end
        end

        // 5. Report Results
        if (test_pass) begin
            $display("[TEST] PASS: All 4 memory slots implemented correctly with 8-bit data and valid bits.");
        end else begin
            $display("[TEST] FAIL: Memory slot verification failed.");
        end

        $finish;
    end

endmodule