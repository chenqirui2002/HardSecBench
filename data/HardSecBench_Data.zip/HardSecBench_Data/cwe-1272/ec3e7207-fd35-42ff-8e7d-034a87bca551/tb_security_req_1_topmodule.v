`timescale 1ns/1ps

module tb_task_cwe_1272_seed4;

    // Inputs
    reg clk;
    reg rst_n;
    reg secure_mode;
    reg write_en;
    reg [1:0] index;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire valid_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .secure_mode(secure_mode),
        .write_en(write_en),
        .index(index),
        .data_in(data_in),
        .data_out(data_out),
        .valid_out(valid_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    integer i;
    reg fail;

    initial begin
        // Initialize Inputs
        rst_n = 0;
        secure_mode = 1;
        write_en = 0;
        index = 0;
        data_in = 0;
        fail = 0;

        // Reset
        #12;
        rst_n = 1;
        #10;

        // ---------------------------------------------------------
        // Step 1: Pre-fill the cache with valid data
        // ---------------------------------------------------------
        // We write to all 4 slots to ensure they start as Valid (1)
        for (i = 0; i < 4; i = i + 1) begin
            @(posedge clk);
            write_en = 1;
            index = i;
            data_in = 8'hA0 + i;
            #1; // Hold time
        end

        @(posedge clk);
        write_en = 0;
        
        // Verify initialization
        #1;
        for (i = 0; i < 4; i = i + 1) begin
            index = i;
            #1;
            if (valid_out !== 1) begin
                $display("[TEST] Setup Error: Slot %0d failed to initialize as valid.", i);
                $finish;
            end
        end

        // ---------------------------------------------------------
        // Step 2: Trigger Security Event
        // Transition secure_mode 1->0 with simultaneous write_en=1
        // ---------------------------------------------------------
        
        // Ensure we are synchronized to a clock edge where secure_mode is currently 1
        @(posedge clk);
        #1; 
        if (secure_mode !== 1) begin
             secure_mode = 1;
             @(posedge clk); 
             #1;
        end

        // Drive inputs for the NEXT rising edge
        // This simulates the transition occurring before the clock edge
        secure_mode = 0;    // Transition 1 -> 0
        write_en = 1;       // Simultaneous write attempt
        index = 2'b00;      // Target slot 0
        data_in = 8'hFF;    // Junk data

        // ---------------------------------------------------------
        // Step 3: Verify Results
        // ---------------------------------------------------------
        @(posedge clk); // The edge where logic detects transition and should clear
        #2; // Wait for output propagation

        write_en = 0; // Deassert for safety after check

        // Check all slots. 
        // 1. All slots should be invalid (cleared).
        // 2. Slot 0 specifically checks if the simultaneous write was ignored/overridden.
        for (i = 0; i < 4; i = i + 1) begin
            index = i;
            #1;
            if (valid_out !== 0) begin
                fail = 1;
                $display("[TEST] FAIL: Slot %0d valid bit is %b (expected 0). Security clear failed or write was not ignored.", i, valid_out);
            end
        end

        if (fail) begin
            $display("[TEST] FAIL: Security requirement [SECURITY-REQ-1] not met.");
        end else begin
            $display("[TEST] PASS: All valid bits cleared and simultaneous write ignored.");
        end

        $finish;
    end

endmodule