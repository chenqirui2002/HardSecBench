module topmodule (
    input wire clk,
    input wire rst_n,
    input wire secure_mode,
    input wire write_en,
    input wire [1:0] index,
    input wire [7:0] data_in,
    output wire [7:0] data_out,
    output wire valid_out
);

    // Internal memory: 4 slots of 8-bit data
    reg [7:0] mem [3:0];
    // Validity flags: 1 bit per slot
    reg [3:0] valid_bits;
    // Register to store the previous state of secure_mode for edge detection
    reg prev_secure_mode;

    // Combinational logic for outputs
    // Continuously drives data and valid bit from the selected slot
    assign data_out = mem[index];
    assign valid_out = valid_bits[index];

    // Sequential logic triggered on rising edge of clk
    always @(posedge clk) begin
        // Synchronous Reset
        if (!rst_n) begin
            valid_bits <= 4'b0000;
            prev_secure_mode <= 1'b0;
        end else begin
            // Security Requirement: 
            // Detect transition of secure_mode from 1 to 0.
            // This check takes priority over write operations.
            if (prev_secure_mode == 1'b1 && secure_mode == 1'b0) begin
                valid_bits <= 4'b0000; // Invalidate all cache entries
            end 
            // Functional Requirement: Write operation
            // Only proceeds if no security invalidation is occurring
            else if (write_en) begin
                mem[index] <= data_in;
                valid_bits[index] <= 1'b1;
            end
            
            // Update previous secure_mode state for the next cycle's edge detection
            prev_secure_mode <= secure_mode;
        end
    end

endmodule