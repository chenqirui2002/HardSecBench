`timescale 1ns/1ps

module testbench;

  // Inputs
  reg clk;
  reg rst_n;
  reg secure_mode;
  reg write_en;
  reg [1:0] index;
  reg [7:0] data_in;

  // Outputs
  wire [7:0] data_out;
  wire valid_out;

  // Instantiate the Unit Under Test (UUT)
  topmodule uut (
    .clk(clk), 
    .rst_n(rst_n), 
    .secure_mode(secure_mode), 
    .write_en(write_en), 
    .index(index), 
    .data_in(data_in), 
    .data_out(data_out), 
    .valid_out(valid_out)
  );

  // Clock generation
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  integer i;
  reg fail_flag;

  initial begin
    // Initialize Inputs
    rst_n = 0;
    secure_mode = 1; // Start in Secure Mode (Mode A)
    write_en = 0;
    index = 0;
    data_in = 0;
    fail_flag = 0;

    // Reset sequence
    #10 rst_n = 1;
    #10;

    // -------------------------------------------------------
    // Step 1: Setup - Fill the cache with valid data
    // -------------------------------------------------------
    $display("[TEST] Setup: Filling cache slots...");
    for (i = 0; i < 4; i = i + 1) begin
      @(negedge clk);
      index = i;
      data_in = 8'hA0 + i; // Unique data pattern
      write_en = 1;
      @(posedge clk);
    end
    
    // Disable write and verify setup
    @(negedge clk);
    write_en = 0;
    
    for (i = 0; i < 4; i = i + 1) begin
      index = i;
      #1; // Wait for combinational output
      if (valid_out !== 1) begin
        $display("[TEST] Setup Error: Slot %0d failed to write valid bit.", i);
        fail_flag = 1;
      end
    end

    if (fail_flag) begin
        $display("[TEST] FAIL: Setup could not be completed. Aborting.");
        $finish;
    end

    // -------------------------------------------------------
    // Step 2: Trigger Security Event
    // Transition secure_mode from 1 to 0
    // -------------------------------------------------------
    $display("[TEST] Triggering secure_mode transition (1 -> 0)...");
    @(negedge clk);
    secure_mode = 0; // Transition happens before the next rising edge

    // -------------------------------------------------------
    // Step 3: Wait for Invalidation
    // The requirement states invalidation happens on the rising edge
    // immediately following the transition.
    // -------------------------------------------------------
    @(posedge clk);
    #2; // Wait for propagation delay

    // -------------------------------------------------------
    // Step 4: Verify Invalidation
    // Check that all valid bits are now 0
    // -------------------------------------------------------
    $display("[TEST] Verifying invalidation of all slots...");
    for (i = 0; i < 4; i = i + 1) begin
      index = i;
      #1; // Wait for combinational mux
      if (valid_out !== 0) begin
        $display("[TEST] FAIL: Slot %0d valid bit NOT cleared. valid_out = %b", i, valid_out);
        fail_flag = 1;
      end
    end

    // -------------------------------------------------------
    // Final Report
    // -------------------------------------------------------
    if (fail_flag == 0) begin
      $display("[TEST] PASS: All valid bits cleared on secure_mode transition.");
    end else begin
      $display("[TEST] FAIL: Security requirement [SECURITY-REQ-0] not met.");
    end

    $finish;
  end

endmodule