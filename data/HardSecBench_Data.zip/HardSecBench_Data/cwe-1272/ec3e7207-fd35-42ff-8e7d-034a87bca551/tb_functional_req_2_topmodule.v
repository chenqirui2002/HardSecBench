`timescale 1ns/1ps

module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg secure_mode;
    reg write_en;
    reg [1:0] index;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire valid_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .secure_mode(secure_mode), 
        .write_en(write_en), 
        .index(index), 
        .data_in(data_in), 
        .data_out(data_out), 
        .valid_out(valid_out)
    );

    // Clock generation
    initial clk = 0;
    always #5 clk = ~clk;

    integer i;
    integer errors = 0;

    initial begin
        // Initialize Inputs
        rst_n = 1;
        secure_mode = 1; // Keep high to avoid security triggers
        write_en = 0;
        index = 0;
        data_in = 0;

        // Wait for initial stabilization
        #20;

        // -------------------------------------------------------
        // Setup Phase: Populate the cache so valid bits are 1
        // -------------------------------------------------------
        $display("Setup: Writing valid entries to all slots...");
        for (i = 0; i < 4; i = i + 1) begin
            @(negedge clk); // Setup inputs on negedge
            rst_n = 1;
            write_en = 1;
            index = i;
            data_in = 8'hAA + i;
            @(posedge clk); // Write happens on posedge
        end

        // Verify setup was successful (sanity check)
        write_en = 0;
        #1; // Wait for write_en to propagate if needed (though write happens on edge)
        
        for (i = 0; i < 4; i = i + 1) begin
            index = i;
            #2; // Allow combinational mux to update
            if (valid_out !== 1'b1) begin
                $display("Setup Warning: Slot %0d valid bit not set (read %b). Test may be inconclusive.", i, valid_out);
            end
        end

        // -------------------------------------------------------
        // Test Phase: Assert Synchronous Reset
        // -------------------------------------------------------
        $display("Test: Asserting synchronous reset (rst_n=0)...");
        
        @(negedge clk);
        rst_n = 0;       // Assert reset
        write_en = 0;    // Ensure no write
        
        @(posedge clk);  // Active clock edge for reset
        
        @(negedge clk);
        rst_n = 1;       // Deassert reset

        // -------------------------------------------------------
        // Verification Phase: Check all valid bits are 0
        // -------------------------------------------------------
        for (i = 0; i < 4; i = i + 1) begin
            index = i;
            #5; // Allow combinational logic to settle
            
            if (valid_out !== 1'b0) begin
                $display("[TEST] FAIL: Slot %0d valid_out is %b (expected 0) after reset.", i, valid_out);
                errors = errors + 1;
            end else begin
                // $display("Info: Slot %0d cleared successfully.", i);
            end
        end

        if (errors == 0) begin
            $display("[TEST] PASS: All valid registers cleared to 0 upon synchronous reset.");
        end else begin
            $display("[TEST] FAIL: %0d slots failed to clear.", errors);
        end

        $finish;
    end

endmodule