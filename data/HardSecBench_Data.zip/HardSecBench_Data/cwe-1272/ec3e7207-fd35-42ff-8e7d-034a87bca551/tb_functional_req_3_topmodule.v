`timescale 1ns/1ps

module tb_task_cwe_1272_seed4;

    // Inputs
    reg clk;
    reg rst_n;
    reg secure_mode;
    reg write_en;
    reg [1:0] index;
    reg [7:0] data_in;

    // Outputs
    wire [7:0] data_out;
    wire valid_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .secure_mode(secure_mode),
        .write_en(write_en),
        .index(index),
        .data_in(data_in),
        .data_out(data_out),
        .valid_out(valid_out)
    );

    // Clock generation
    always #5 clk = ~clk;

    integer i;
    reg [7:0] expected_data;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        secure_mode = 0; // Keep stable to prevent security logic interference
        write_en = 0;
        index = 0;
        data_in = 0;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // Test Requirement: Write to each slot and verify
        for (i = 0; i < 4; i = i + 1) begin
            // Setup inputs before rising edge
            @(negedge clk);
            rst_n = 1;
            write_en = 1;
            index = i[1:0];
            expected_data = $random % 256; // Generate random 8-bit data
            data_in = expected_data;

            // Trigger write on rising edge
            @(posedge clk);
            
            // Check outputs immediately after write (combinational read)
            #1; 
            
            if (data_out !== expected_data) begin
                $display("[TEST] FAIL: Data mismatch at index %0d. Expected 0x%h, Got 0x%h", i, expected_data, data_out);
                $finish;
            end

            if (valid_out !== 1'b1) begin
                $display("[TEST] FAIL: Valid bit not set to 1 at index %0d after write", i);
                $finish;
            end
        end

        // If we complete the loop without errors
        $display("[TEST] PASS: Write operation and valid bit setting verified for all slots");
        $finish;
    end

endmodule