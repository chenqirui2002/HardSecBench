`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg ps_req;
    reg data_we;
    reg [31:0] data_in;

    // Outputs
    wire ps_ack;
    wire [1:0] status_led;
    wire [31:0] data_out;
    wire [7:0] device_id;

    // Test Control
    reg test_pass;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk), 
        .rst_n(rst_n), 
        .ps_req(ps_req), 
        .data_we(data_we), 
        .data_in(data_in), 
        .ps_ack(ps_ack), 
        .status_led(status_led), 
        .data_out(data_out), 
        .device_id(device_id)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        ps_req = 0;
        data_we = 0;
        data_in = 0;
        test_pass = 1;

        // Apply Reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Transition ACTIVE -> POWER_SAVE
        // -------------------------------------------------------
        $display("[TEST] Case 1: Transition to POWER_SAVE (ps_req=1)");
        
        // Stimulus
        ps_req = 1;
        
        // Wait for next clock edge and propagation delay
        @(posedge clk);
        #1; 

        // Check outputs
        if (ps_ack !== 1'b1) begin
            $display("[TEST] FAIL: ps_ack should be 1 in POWER_SAVE mode, got %b", ps_ack);
            test_pass = 0;
        end
        if (status_led !== 2'b10) begin
            $display("[TEST] FAIL: status_led should be 2'b10 in POWER_SAVE mode, got %b", status_led);
            test_pass = 0;
        end

        // -------------------------------------------------------
        // Test Case 2: Transition POWER_SAVE -> ACTIVE
        // -------------------------------------------------------
        $display("[TEST] Case 2: Transition to ACTIVE (ps_req=0)");
        
        // Stimulus
        ps_req = 0;
        
        // Wait for next clock edge and propagation delay
        @(posedge clk);
        #1;

        // Check outputs
        if (ps_ack !== 1'b0) begin
            $display("[TEST] FAIL: ps_ack should be 0 in ACTIVE mode, got %b", ps_ack);
            test_pass = 0;
        end
        if (status_led !== 2'b01) begin
            $display("[TEST] FAIL: status_led should be 2'b01 in ACTIVE mode, got %b", status_led);
            test_pass = 0;
        end

        // -------------------------------------------------------
        // Test Case 3: Verify Stability/Re-entry
        // -------------------------------------------------------
        $display("[TEST] Case 3: Re-enter POWER_SAVE");
        
        ps_req = 1;
        @(posedge clk);
        #1;
        
        if (ps_ack !== 1'b1 || status_led !== 2'b10) begin
            $display("[TEST] FAIL: Failed to re-enter POWER_SAVE mode correctly.");
            test_pass = 0;
        end

        // Final Result Reporting
        if (test_pass) begin
            $display("[TEST] PASS: State transitions verified successfully.");
        end else begin
            $display("[TEST] FAIL: State transitions incorrect.");
        end
        
        $finish;
    end

endmodule