module testbench;
    // Signal declarations
    reg clk;
    reg rst_n;
    reg ps_req;
    reg data_we;
    reg [31:0] data_in;
    
    wire ps_ack;
    wire [1:0] status_led;
    wire [31:0] data_out;
    wire [7:0] device_id;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .ps_req(ps_req),
        .data_we(data_we),
        .data_in(data_in),
        .ps_ack(ps_ack),
        .status_led(status_led),
        .data_out(data_out),
        .device_id(device_id)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test sequence
    initial begin
        // Initialize inputs
        rst_n = 0;
        ps_req = 0;
        data_we = 0;
        data_in = 0;

        // Wait for reset
        #15;
        rst_n = 1;
        #10;

        // Step 1: Ensure we are in ACTIVE state (ps_ack should be 0)
        // Functional requirements state reset initializes to ACTIVE.
        if (ps_ack !== 1'b0) begin
            $display("[TEST] FAIL: System did not initialize to ACTIVE state (ps_ack is %b).", ps_ack);
            $finish;
        end

        // Step 2: Write sensitive data (0xDEADBEEF) into the register
        // Functional Req 2: In ACTIVE, if ps_req=0 and data_we=1, update internal_data.
        data_in = 32'hDEADBEEF;
        data_we = 1;
        @(posedge clk); // Write occurs on this edge
        #1; // Allow propagation
        data_we = 0;

        // Verify write was successful
        if (data_out !== 32'hDEADBEEF) begin
            $display("[TEST] FAIL: Setup failed - could not write initial data. data_out = %h", data_out);
            $finish;
        end

        // Step 3: Trigger Power Save Request
        // Security Req 0: If in ACTIVE and ps_req is high, internal_data shall be assigned 0.
        ps_req = 1;
        
        // Wait for the synchronous transition/clear
        @(posedge clk); 
        #1; // Allow propagation

        // Step 4: Verify Security Requirement
        // The data should be cleared immediately on the transition edge.
        if (data_out === 32'h00000000) begin
            $display("[TEST] PASS: internal_data cleared to 0 upon ps_req assertion.");
        end else begin
            $display("[TEST] FAIL: internal_data was NOT cleared. Sensitive data remains: %h", data_out);
        end

        $finish;
    end

endmodule