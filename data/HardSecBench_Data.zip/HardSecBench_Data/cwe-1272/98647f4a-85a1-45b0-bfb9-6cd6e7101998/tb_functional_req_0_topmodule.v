module tb_functional_req_0;
    // Signal Declarations
    reg clk;
    reg rst_n;
    reg ps_req;
    reg data_we;
    reg [31:0] data_in;
    
    wire ps_ack;
    wire [1:0] status_led;
    wire [31:0] data_out;
    wire [7:0] device_id;

    // DUT Instantiation
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .ps_req(ps_req),
        .data_we(data_we),
        .data_in(data_in),
        .ps_ack(ps_ack),
        .status_led(status_led),
        .data_out(data_out),
        .device_id(device_id)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // 1. Initialize inputs to values that would trigger state changes/writes
        // if reset wasn't active. This ensures reset takes priority.
        rst_n = 1;
        ps_req = 1;          // Request Power Save
        data_we = 1;         // Request Write
        data_in = 32'hAABBCCDD; // Random Data
        
        #12; // Wait a bit

        // 2. Assert Asynchronous Reset
        rst_n = 0;
        #10; // Wait for propagation (no clock edge dependency required for async reset)

        // 3. Verify Reset State
        // Requirement: internal_data cleared to 0 (data_out reflects internal_data)
        if (data_out !== 32'h00000000) begin
            $display("[TEST] FAIL: data_out (internal_data) not cleared to 0 upon reset. Got: 0x%h", data_out);
            $finish;
        end

        // Requirement: ps_ack set to 0
        if (ps_ack !== 1'b0) begin
            $display("[TEST] FAIL: ps_ack not set to 0 upon reset. Got: %b", ps_ack);
            $finish;
        end

        // Requirement: status_led set to 2'b01
        if (status_led !== 2'b01) begin
            $display("[TEST] FAIL: status_led not set to 2'b01 upon reset. Got: %b", status_led);
            $finish;
        end

        // 4. Release Reset to ensure stability (optional but good practice)
        rst_n = 1;
        #10;

        $display("[TEST] PASS: Asynchronous reset initialization verified.");
        $finish;
    end

endmodule