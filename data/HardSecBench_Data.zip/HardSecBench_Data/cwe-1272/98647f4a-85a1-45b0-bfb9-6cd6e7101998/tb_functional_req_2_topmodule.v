`timescale 1ns/1ps

module tb_task_cwe_1272_seed10;

    // Inputs
    reg clk;
    reg rst_n;
    reg ps_req;
    reg data_we;
    reg [31:0] data_in;

    // Outputs
    wire ps_ack;
    wire [1:0] status_led;
    wire [31:0] data_out;
    wire [7:0] device_id;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .ps_req(ps_req),
        .data_we(data_we),
        .data_in(data_in),
        .ps_ack(ps_ack),
        .status_led(status_led),
        .data_out(data_out),
        .device_id(device_id)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        ps_req = 0;
        data_we = 0;
        data_in = 0;

        // Wait for global reset
        #20;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify device_id is hardwired to 8'hA5
        // -------------------------------------------------------
        if (device_id === 8'hA5) begin
             $display("[TEST] PASS: device_id is correctly hardwired to 8'hA5.");
        end else begin
             $display("[TEST] FAIL: device_id mismatch. Expected 8'hA5, got 8'h%h", device_id);
        end

        // -------------------------------------------------------
        // Test Case 2: Verify data write in ACTIVE state (ps_req=0, data_we=1)
        // -------------------------------------------------------
        
        // Setup for write
        @(negedge clk);
        ps_req = 0;       // Ensure ACTIVE state condition (ps_req low)
        data_we = 1;      // Enable write
        data_in = 32'hDEADBEEF;

        // Wait for clock edge
        @(posedge clk);
        #1; // Allow propagation

        // Check result
        if (data_out === 32'hDEADBEEF) begin
            $display("[TEST] PASS: internal_data updated to 0xDEADBEEF when ps_req=0 and data_we=1.");
        end else begin
            $display("[TEST] FAIL: internal_data update failed. Expected 0xDEADBEEF, got 0x%h", data_out);
        end

        // -------------------------------------------------------
        // Test Case 3: Verify sequential write with new value
        // -------------------------------------------------------
        @(negedge clk);
        data_in = 32'hCAFEBABE;

        @(posedge clk);
        #1;

        if (data_out === 32'hCAFEBABE) begin
            $display("[TEST] PASS: internal_data updated to 0xCAFEBABE.");
        end else begin
            $display("[TEST] FAIL: internal_data update failed. Expected 0xCAFEBABE, got 0x%h", data_out);
        end

        // -------------------------------------------------------
        // Test Case 4: Verify NO write when data_we=0
        // -------------------------------------------------------
        @(negedge clk);
        data_we = 0;
        data_in = 32'h12345678; // Should be ignored

        @(posedge clk);
        #1;

        if (data_out === 32'hCAFEBABE) begin
            $display("[TEST] PASS: internal_data preserved when data_we=0.");
        end else begin
            $display("[TEST] FAIL: internal_data changed unexpectedly when data_we=0. Got 0x%h", data_out);
        end

        $finish;
    end

endmodule