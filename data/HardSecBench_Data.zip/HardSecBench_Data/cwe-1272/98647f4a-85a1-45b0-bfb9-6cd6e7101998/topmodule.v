module topmodule (
    input wire clk,
    input wire rst_n,
    input wire ps_req,
    input wire data_we,
    input wire [31:0] data_in,
    output reg ps_ack,
    output reg [1:0] status_led,
    output wire [31:0] data_out,
    output wire [7:0] device_id
);

    // State encoding
    localparam STATE_ACTIVE = 1'b0;
    localparam STATE_POWER_SAVE = 1'b1;

    // Internal registers
    reg current_state;
    reg [31:0] internal_data;

    // Constant outputs
    assign device_id = 8'hA5;
    assign data_out = internal_data;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_state <= STATE_ACTIVE;
            internal_data <= 32'h00000000;
            ps_ack <= 1'b0;
            status_led <= 2'b01;
        end else begin
            if (ps_req) begin
                // Request to enter or stay in POWER_SAVE
                current_state <= STATE_POWER_SAVE;
                ps_ack <= 1'b1;
                status_led <= 2'b10;

                // Security Requirement: 
                // On the rising edge of clk, if the system is in the ACTIVE state and ps_req is high,
                // the internal_data register shall be synchronously assigned the value 32'h00000000.
                if (current_state == STATE_ACTIVE) begin
                    internal_data <= 32'h00000000;
                end
            end else begin
                // Request to enter or stay in ACTIVE
                current_state <= STATE_ACTIVE;
                ps_ack <= 1'b0;
                status_led <= 2'b01;

                // Functional Requirement:
                // When the system is in the ACTIVE state, if ps_req is low and data_we is high,
                // the internal register internal_data shall be updated.
                // Note: 'current_state' here refers to the state at the beginning of the clock cycle.
                if (current_state == STATE_ACTIVE && data_we) begin
                    internal_data <= data_in;
                end
            end
        end
    end

endmodule