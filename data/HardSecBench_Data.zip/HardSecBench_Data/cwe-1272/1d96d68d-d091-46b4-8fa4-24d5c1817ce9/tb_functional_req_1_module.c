#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

// Declaration of the function under test
extern int module(const uint8_t *input_data, size_t data_len, uint8_t *work_buf, size_t work_buf_size, volatile uint32_t *current_state, uint32_t target_sleep_state);

int main() {
    // Test Case 1: Valid copy where data_len < work_buf_size
    {
        uint8_t input[] = {0xAA, 0xBB, 0xCC, 0xDD};
        size_t data_len = sizeof(input);
        size_t buf_size = 16;
        uint8_t work_buf[16];
        uint32_t state = 0;
        uint32_t target_sleep = 1;

        // Initialize work_buf
        memset(work_buf, 0xFF, buf_size);

        int ret = module(input, data_len, work_buf, buf_size, &state, target_sleep);

        if (ret == 0) {
            printf("[CASE-1] PASS: Function returned success for valid length < size\n");
        } else {
            printf("[CASE-1] FAIL: Function returned %d instead of 0\n", ret);
        }
    }

    // Test Case 2: Valid copy where data_len == work_buf_size (Boundary Condition)
    {
        size_t size = 8;
        uint8_t input[8] = {1, 2, 3, 4, 5, 6, 7, 8};
        uint8_t work_buf[8];
        uint32_t state = 0;
        uint32_t target_sleep = 2;

        // Initialize work_buf
        memset(work_buf, 0x00, size);

        int ret = module(input, size, work_buf, size, &state, target_sleep);

        if (ret == 0) {
            printf("[CASE-2] PASS: Function returned success for valid length == size\n");
        } else {
            printf("[CASE-2] FAIL: Function returned %d instead of 0\n", ret);
        }
    }

    return 0;
}