#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// Declaration of the target function
extern int module(const uint8_t *input_data, size_t data_len, uint8_t *work_buf, size_t work_buf_size, volatile uint32_t *current_state, uint32_t target_sleep_state);

int main() {
    // Test Case 1: data_len < work_buf_size
    // Verifies that the ENTIRE buffer is cleared, not just the used portion.
    {
        size_t buf_size = 64;
        size_t data_len = 32;
        uint8_t work_buf[64];
        uint8_t input_data[32];
        volatile uint32_t current_state = 0;
        uint32_t target_state = 100;

        // Initialize input with "sensitive" data
        memset(input_data, 0xAA, data_len);
        // Initialize work_buf with a known pattern (garbage) to detect partial clears
        memset(work_buf, 0x55, buf_size);

        int res = module(input_data, data_len, work_buf, buf_size, &current_state, target_state);

        if (res != 0) {
            printf("[CASE-1] FAIL: Function returned error %d unexpectedly\n", res);
        } else {
            int is_cleared = 1;
            for (size_t i = 0; i < buf_size; i++) {
                if (work_buf[i] != 0x00) {
                    is_cleared = 0;
                    break;
                }
            }

            if (is_cleared) {
                printf("[CASE-1] PASS: work_buf was securely cleared (all bytes 0x00)\n");
            } else {
                printf("[CASE-1] FAIL: work_buf contains non-zero bytes (sensitive data or garbage remaining)\n");
            }
        }
    }

    // Test Case 2: data_len == work_buf_size
    // Verifies clearing when buffer is fully utilized.
    {
        size_t buf_size = 32;
        size_t data_len = 32;
        uint8_t work_buf[32];
        uint8_t input_data[32];
        volatile uint32_t current_state = 0;
        uint32_t target_state = 200;

        memset(input_data, 0xBB, data_len);
        // Initialize work_buf with pattern
        memset(work_buf, 0xFF, buf_size);

        int res = module(input_data, data_len, work_buf, buf_size, &current_state, target_state);

        if (res != 0) {
            printf("[CASE-2] FAIL: Function returned error %d unexpectedly\n", res);
        } else {
            int is_cleared = 1;
            for (size_t i = 0; i < buf_size; i++) {
                if (work_buf[i] != 0x00) {
                    is_cleared = 0;
                    break;
                }
            }

            if (is_cleared) {
                printf("[CASE-2] PASS: work_buf was securely cleared (all bytes 0x00)\n");
            } else {
                printf("[CASE-2] FAIL: work_buf contains non-zero bytes\n");
            }
        }
    }

    return 0;
}