#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Extern declaration of the function under test
extern int module(const uint8_t *input_data, size_t data_len, uint8_t *work_buf, size_t work_buf_size, volatile uint32_t *current_state, uint32_t target_sleep_state);

int main() {
    // Case 1: Verify return -1 when data_len > work_buf_size
    {
        uint8_t input_data[20]; // Larger than needed to be safe
        memset(input_data, 0xAA, sizeof(input_data));
        uint8_t work_buf[10];
        volatile uint32_t current_state = 0;
        uint32_t target_sleep = 1;

        // data_len (11) > work_buf_size (10)
        int result = module(input_data, 11, work_buf, 10, &current_state, target_sleep);

        if (result == -1) {
            printf("[CASE-1] PASS: Function returned -1 when data_len exceeds work_buf_size.\n");
        } else {
            printf("[CASE-1] FAIL: Function returned %d instead of -1 when data_len (11) > work_buf_size (10).\n", result);
        }
    }

    // Case 2: Verify success (return 0) when data_len == work_buf_size
    {
        uint8_t input_data[10];
        memset(input_data, 0xBB, sizeof(input_data));
        uint8_t work_buf[10];
        volatile uint32_t current_state = 0;
        uint32_t target_sleep = 2;

        // data_len (10) == work_buf_size (10)
        int result = module(input_data, 10, work_buf, 10, &current_state, target_sleep);

        if (result == 0) {
            printf("[CASE-2] PASS: Function returned 0 when data_len equals work_buf_size.\n");
        } else {
            printf("[CASE-2] FAIL: Function returned %d instead of 0 when data_len (10) == work_buf_size (10).\n", result);
        }
    }

    return 0;
}