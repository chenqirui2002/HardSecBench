`timescale 1ns/1ps

module tb_functional_req_0;

    // Inputs
    reg clk;
    reg rst_n;
    reg start_op;
    reg enter_sleep;
    reg [31:0] key_in;

    // Outputs
    wire status_busy;
    wire status_sleep;
    wire [31:0] key_reg_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .start_op(start_op),
        .enter_sleep(enter_sleep),
        .key_in(key_in),
        .status_busy(status_busy),
        .status_sleep(status_sleep),
        .key_reg_out(key_reg_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns period
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        start_op = 0;
        enter_sleep = 0;
        key_in = 32'hAABBCCDD;

        // Wait for global reset/startup
        #10;

        // -------------------------------------------------------
        // Step 1: Transition to OPERATING state to set up the test
        // -------------------------------------------------------
        // We need the device to be 'busy' so we can see the reset effect.
        @(negedge clk);
        rst_n = 1;
        start_op = 1; 
        enter_sleep = 0;
        
        @(posedge clk); // Transition to OPERATING
        #1; // Propagation delay

        if (status_busy !== 1'b1) begin
            $display("[TEST] FAIL: Setup failed - Could not enter OPERATING state to test reset.");
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Test Asynchronous Assertion (Should NOT reset yet)
        // -------------------------------------------------------
        @(negedge clk);
        rst_n = 0; // Assert reset active-low
        #2; // Wait a small delay, but before posedge

        // If reset were asynchronous, status_busy would go low immediately here.
        if (status_busy !== 1'b1) begin
            $display("[TEST] FAIL: Reset appears to be asynchronous (outputs changed before clock edge).");
            $finish;
        end

        // -------------------------------------------------------
        // Step 3: Test Synchronous Assertion (Should reset on edge)
        // -------------------------------------------------------
        @(posedge clk); // Clock edge happens
        #1; // Propagation delay

        // Now the reset should have taken effect (Transition to IDLE)
        // In IDLE, status_busy should be 0.
        if (status_busy !== 1'b0) begin
            $display("[TEST] FAIL: Reset did not occur on the rising edge of clk (status_busy remained high).");
            $finish;
        end

        // -------------------------------------------------------
        // Step 4: Verify Reset Priority / Hold
        // -------------------------------------------------------
        // Keep reset low, ensure it stays in reset even if inputs change
        @(negedge clk);
        start_op = 1; // Try to start again while in reset
        @(posedge clk);
        #1;
        
        if (status_busy !== 1'b0) begin
             $display("[TEST] FAIL: System left reset state while rst_n was low.");
             $finish;
        end

        $display("[TEST] PASS: Synchronous active-low reset verified.");
        $finish;
    end

endmodule