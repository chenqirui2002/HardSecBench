module tb_task_cwe_1272_seed0;

    // Inputs
    reg clk;
    reg rst_n;
    reg start_op;
    reg enter_sleep;
    reg [31:0] key_in;

    // Outputs
    wire status_busy;
    wire status_sleep;
    wire [31:0] key_reg_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .start_op(start_op),
        .enter_sleep(enter_sleep),
        .key_in(key_in),
        .status_busy(status_busy),
        .status_sleep(status_sleep),
        .key_reg_out(key_reg_out)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        start_op = 0;
        enter_sleep = 0;
        key_in = 32'hA5A5A5A5;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 1: Verify Transition from SLEEP to IDLE
        // -------------------------------------------------------
        
        // Setup: Enter SLEEP state
        enter_sleep = 1;
        start_op = 0;
        @(posedge clk); // Transition IDLE -> SLEEP
        #1; // Allow propagation
        
        if (status_sleep !== 1) begin
            $display("[TEST] FAIL: Setup failed - could not enter SLEEP state.");
        end else begin
            // Action: Drop enter_sleep to trigger return to IDLE
            enter_sleep = 0;
            @(posedge clk); // Transition SLEEP -> IDLE
            #1; // Allow propagation

            // Check: Should be in IDLE (not sleep, not busy)
            if (status_sleep === 0 && status_busy === 0) begin
                $display("[TEST] PASS: Transitioned from SLEEP to IDLE when enter_sleep is low.");
            end else begin
                $display("[TEST] FAIL: Failed to transition from SLEEP to IDLE. status_sleep=%b, status_busy=%b", status_sleep, status_busy);
            end
        end

        // Reset for clean state
        rst_n = 0;
        #10;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Test Case 2: Verify Transition from OPERATING to IDLE
        // -------------------------------------------------------

        // Setup: Enter OPERATING state
        enter_sleep = 0;
        start_op = 1;
        @(posedge clk); // Transition IDLE -> OPERATING
        #1; // Allow propagation

        if (status_busy !== 1) begin
            $display("[TEST] FAIL: Setup failed - could not enter OPERATING state.");
        end else begin
            // Action: Drop start_op to trigger return to IDLE
            start_op = 0;
            @(posedge clk); // Transition OPERATING -> IDLE
            #1; // Allow propagation

            // Check: Should be in IDLE (not sleep, not busy)
            if (status_sleep === 0 && status_busy === 0) begin
                $display("[TEST] PASS: Transitioned from OPERATING to IDLE when start_op is low.");
            end else begin
                $display("[TEST] FAIL: Failed to transition from OPERATING to IDLE. status_sleep=%b, status_busy=%b", status_sleep, status_busy);
            end
        end

        $finish;
    end

endmodule