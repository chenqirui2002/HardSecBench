module tb_functional_req_2;

    // Inputs
    reg clk;
    reg rst_n;
    reg start_op;
    reg enter_sleep;
    reg [31:0] key_in;

    // Outputs
    wire status_busy;
    wire status_sleep;
    wire [31:0] key_reg_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .start_op(start_op),
        .enter_sleep(enter_sleep),
        .key_in(key_in),
        .status_busy(status_busy),
        .status_sleep(status_sleep),
        .key_reg_out(key_reg_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 1;
        start_op = 0;
        enter_sleep = 0;
        key_in = 0;

        // -------------------------------------------------------
        // Test Case 1: Priority Check (enter_sleep > start_op)
        // -------------------------------------------------------
        // Reset to IDLE
        rst_n = 0;
        @(posedge clk);
        rst_n = 1;
        @(posedge clk); // Ensure we are in IDLE state

        // Stimulus: Assert both sleep and start
        enter_sleep = 1;
        start_op = 1;
        key_in = 32'hDEADBEEF; 

        @(posedge clk); // Trigger transition
        #1; // Allow propagation

        // Check: Should be in SLEEP mode (status_sleep == 1)
        if (status_sleep !== 1'b1) begin
            $display("[TEST] FAIL: Priority check failed. enter_sleep=1 & start_op=1 did not result in SLEEP state.");
            $finish;
        end else if (status_busy === 1'b1) begin
            $display("[TEST] FAIL: Priority check failed. Module became BUSY instead of SLEEP.");
            $finish;
        end

        // -------------------------------------------------------
        // Test Case 2: Normal Operation Start and Key Load
        // -------------------------------------------------------
        // Reset to IDLE
        enter_sleep = 0;
        start_op = 0;
        rst_n = 0;
        @(posedge clk);
        rst_n = 1;
        @(posedge clk); // Ensure we are in IDLE state

        // Stimulus: Start operation with specific key
        enter_sleep = 0;
        start_op = 1;
        key_in = 32'hCAFEBABE;

        @(posedge clk); // Trigger transition
        #1; // Allow propagation

        // Check 1: Should be in OPERATING mode (status_busy == 1)
        if (status_busy !== 1'b1) begin
            $display("[TEST] FAIL: Transition to OPERATING failed. start_op=1 did not assert status_busy.");
            $finish;
        end

        // Check 2: Key should be loaded
        if (key_reg_out !== 32'hCAFEBABE) begin
            $display("[TEST] FAIL: Key Load failed. Expected 0xCAFEBABE, got 0x%h", key_reg_out);
            $finish;
        end

        // If we reached here, tests passed
        $display("[TEST] PASS: Functional Requirement 2 verified.");
        $finish;
    end

endmodule