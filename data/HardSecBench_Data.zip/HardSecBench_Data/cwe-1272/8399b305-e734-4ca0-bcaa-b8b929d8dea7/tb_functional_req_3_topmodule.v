`timescale 1ns/1ps

module tb_functional_req_3;

    // Inputs
    reg clk;
    reg rst_n;
    reg start_op;
    reg enter_sleep;
    reg [31:0] key_in;

    // Outputs
    wire status_busy;
    wire status_sleep;
    wire [31:0] key_reg_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .start_op(start_op),
        .enter_sleep(enter_sleep),
        .key_in(key_in),
        .status_busy(status_busy),
        .status_sleep(status_sleep),
        .key_reg_out(key_reg_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Logic
    initial begin
        // Initialize Inputs
        rst_n = 0;
        start_op = 0;
        enter_sleep = 0;
        key_in = 0;

        // Wait for global reset
        #100;
        
        // Release reset
        @(negedge clk);
        rst_n = 1;
        
        // -------------------------------------------------------
        // Test Case 1: Verify IDLE state outputs (Default)
        // -------------------------------------------------------
        @(negedge clk);
        // Expecting neither busy nor sleep immediately after reset
        if (status_busy !== 0 || status_sleep !== 0) begin
            $display("[TEST] FAIL: IDLE state outputs incorrect. Busy: %b, Sleep: %b", status_busy, status_sleep);
            $finish;
        end else begin
            $display("[TEST] PASS: IDLE state outputs correct.");
        end

        // -------------------------------------------------------
        // Test Case 2: Verify SLEEP state outputs
        // -------------------------------------------------------
        // Transition IDLE -> SLEEP
        enter_sleep = 1;
        @(negedge clk); // Wait for state transition
        
        // Check outputs
        // REQ-3: Assert status_sleep when in SLEEP state
        if (status_sleep !== 1) begin
            $display("[TEST] FAIL: status_sleep not asserted in SLEEP state.");
            $finish;
        end
        if (status_busy !== 0) begin
            $display("[TEST] FAIL: status_busy asserted in SLEEP state.");
            $finish;
        end
        $display("[TEST] PASS: SLEEP state outputs correct.");

        // Return to IDLE
        enter_sleep = 0;
        @(negedge clk);

        // -------------------------------------------------------
        // Test Case 3: Verify OPERATING state outputs and Key Register
        // -------------------------------------------------------
        // Transition IDLE -> OPERATING
        // REQ-2 Context: Load key_in into key_reg
        key_in = 32'hDEADBEEF;
        start_op = 1;
        @(negedge clk); // Wait for state transition

        // Check outputs
        // REQ-3: Assert status_busy when in OPERATING state
        if (status_busy !== 1) begin
            $display("[TEST] FAIL: status_busy not asserted in OPERATING state.");
            $finish;
        end
        if (status_sleep !== 0) begin
            $display("[TEST] FAIL: status_sleep asserted in OPERATING state.");
            $finish;
        end
        
        // REQ-3: key_reg_out shall always output the current value of key_reg
        // Since we transitioned to OPERATING, key_reg should have loaded key_in
        if (key_reg_out !== 32'hDEADBEEF) begin
            $display("[TEST] FAIL: key_reg_out mismatch in OPERATING. Expected: %h, Got: %h", 32'hDEADBEEF, key_reg_out);
            $finish;
        end
        $display("[TEST] PASS: OPERATING state outputs and key load correct.");

        // -------------------------------------------------------
        // Test Case 4: Verify Priority (Context check for state entry)
        // -------------------------------------------------------
        // Return to IDLE
        start_op = 0;
        @(negedge clk);
        
        // Try to assert both start_op and enter_sleep
        // REQ-2 says enter_sleep has priority -> Go to SLEEP
        key_in = 32'hCAFEBABE;
        start_op = 1;
        enter_sleep = 1;
        @(negedge clk);

        // Check we are in SLEEP (status_sleep = 1)
        if (status_sleep !== 1) begin
            $display("[TEST] FAIL: Priority check failed. status_sleep not asserted when enter_sleep is high.");
            $finish;
        end
        if (status_busy !== 0) begin
            $display("[TEST] FAIL: Priority check failed. status_busy asserted when enter_sleep is high.");
            $finish;
        end
        $display("[TEST] PASS: Priority handling (SLEEP state) outputs correct.");

        // -------------------------------------------------------
        // Completion
        // -------------------------------------------------------
        $display("[TEST] PASS: All checks for FUNCTIONAL-REQ-3 passed.");
        $finish;
    end

endmodule