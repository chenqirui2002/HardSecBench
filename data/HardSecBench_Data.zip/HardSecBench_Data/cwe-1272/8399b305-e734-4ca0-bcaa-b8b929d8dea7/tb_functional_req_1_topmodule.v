`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs
    reg clk;
    reg rst_n;
    reg start_op;
    reg enter_sleep;
    reg [31:0] key_in;

    // Outputs
    wire status_busy;
    wire status_sleep;
    wire [31:0] key_reg_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .start_op(start_op),
        .enter_sleep(enter_sleep),
        .key_in(key_in),
        .status_busy(status_busy),
        .status_sleep(status_sleep),
        .key_reg_out(key_reg_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Test Sequence
    initial begin
        // Initialize Inputs
        rst_n = 0;
        start_op = 0;
        enter_sleep = 0;
        key_in = 32'h0;

        // 1. Verify IDLE State (Reset State)
        // Assert Synchronous Reset
        @(posedge clk);
        rst_n = 0;
        @(posedge clk);
        rst_n = 1;
        
        // Wait for output propagation
        #1; 
        
        // Expectation: In IDLE, both status flags should be low
        if (status_busy === 0 && status_sleep === 0) begin
            $display("[TEST] PASS: IDLE state verified after reset.");
        end else begin
            $display("[TEST] FAIL: IDLE state incorrect. Busy: %b, Sleep: %b", status_busy, status_sleep);
            $finish;
        end

        // 2. Verify SLEEP State
        // Transition: IDLE -> SLEEP (requires enter_sleep=1)
        enter_sleep = 1;
        @(posedge clk); // Clock the transition
        #1; // Wait for propagation

        if (status_sleep === 1) begin
            $display("[TEST] PASS: SLEEP state verified.");
        end else begin
            $display("[TEST] FAIL: Failed to enter SLEEP state. Sleep: %b", status_sleep);
            $finish;
        end

        // Return to IDLE to prepare for next state check
        enter_sleep = 0;
        @(posedge clk);
        #1;

        // 3. Verify OPERATING State
        // Transition: IDLE -> OPERATING (requires start_op=1)
        start_op = 1;
        @(posedge clk); // Clock the transition
        #1; // Wait for propagation

        if (status_busy === 1) begin
            $display("[TEST] PASS: OPERATING state verified.");
        end else begin
            $display("[TEST] FAIL: Failed to enter OPERATING state. Busy: %b", status_busy);
            $finish;
        end

        $display("[TEST] PASS: All three states (IDLE, SLEEP, OPERATING) confirmed.");
        $finish;
    end

endmodule