module testbench;
    // Inputs
    reg clk;
    reg rst_n;
    reg start_op;
    reg enter_sleep;
    reg [31:0] key_in;

    // Outputs
    wire status_busy;
    wire status_sleep;
    wire [31:0] key_reg_out;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .start_op(start_op),
        .enter_sleep(enter_sleep),
        .key_in(key_in),
        .status_busy(status_busy),
        .status_sleep(status_sleep),
        .key_reg_out(key_reg_out)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        // Initialize Inputs
        rst_n = 0;
        start_op = 0;
        enter_sleep = 0;
        key_in = 0;

        // Reset sequence
        repeat(2) @(negedge clk);
        rst_n = 1;

        // -------------------------------------------------------
        // Step 1: Load a sensitive key in OPERATING mode
        // -------------------------------------------------------
        @(negedge clk);
        key_in = 32'hDEADBEEF; // Sensitive Data
        start_op = 1;
        enter_sleep = 0;

        @(posedge clk); // Transition IDLE -> OPERATING
        #1; // Allow output propagation

        // Verify setup
        if (key_reg_out !== 32'hDEADBEEF) begin
            $display("[TEST] FAIL: Setup failed - Key was not loaded in OPERATING mode. Got: %h", key_reg_out);
            $finish;
        end

        // -------------------------------------------------------
        // Step 2: Return to IDLE mode
        // -------------------------------------------------------
        @(negedge clk);
        start_op = 0; // Request return to IDLE

        @(posedge clk); // Transition OPERATING -> IDLE
        #1;

        // -------------------------------------------------------
        // Step 3: Enter SLEEP mode
        // -------------------------------------------------------
        @(negedge clk);
        enter_sleep = 1; // Request SLEEP mode

        @(posedge clk); // Transition IDLE -> SLEEP
        #1; // Allow output propagation

        // -------------------------------------------------------
        // Step 4: Verify Security Requirement
        // -------------------------------------------------------
        // Check if we are actually in SLEEP
        if (status_sleep !== 1) begin
             $display("[TEST] FAIL: Setup failed - Did not enter SLEEP mode.");
             $finish;
        end

        // Check if key_reg was cleared
        if (key_reg_out === 32'h00000000) begin
            $display("[TEST] PASS: Key register cleared upon entering SLEEP mode.");
        end else begin
            $display("[TEST] FAIL: Key register NOT cleared in SLEEP mode. Retained value: %h", key_reg_out);
        end

        $finish;
    end

endmodule