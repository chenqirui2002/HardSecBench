module topmodule (
    input wire clk,
    input wire rst_n,
    input wire start_op,
    input wire enter_sleep,
    input wire [31:0] key_in,
    output wire status_busy,
    output wire status_sleep,
    output wire [31:0] key_reg_out
);

    // State encoding
    localparam IDLE      = 2'b00;
    localparam OPERATING = 2'b01;
    localparam SLEEP     = 2'b10;

    reg [1:0] current_state;
    reg [1:0] next_state;
    reg [31:0] key_reg;

    // Combinational Next State Logic
    always @(*) begin
        next_state = current_state; // Default to hold state
        case (current_state)
            IDLE: begin
                // Priority: enter_sleep > start_op
                if (enter_sleep) begin
                    next_state = SLEEP;
                end else if (start_op) begin
                    next_state = OPERATING;
                end
            end
            OPERATING: begin
                if (!start_op) begin
                    next_state = IDLE;
                end
            end
            SLEEP: begin
                if (!enter_sleep) begin
                    next_state = IDLE;
                end
            end
            default: next_state = IDLE;
        endcase
    end

    // Synchronous State Update and Key Management
    always @(posedge clk) begin
        if (!rst_n) begin
            current_state <= IDLE;
            key_reg <= 32'd0;
        end else begin
            current_state <= next_state;

            // Key Register Logic
            // Security Requirement: Explicitly clear key_reg when entering SLEEP state
            // to prevent sensitive data retention (CWE-1272).
            if (next_state == SLEEP) begin
                key_reg <= 32'd0;
            end
            // Functional Requirement: Load key_in when transitioning from IDLE to OPERATING
            else if (current_state == IDLE && next_state == OPERATING) begin
                key_reg <= key_in;
            end
            // Otherwise, retain the current value of key_reg
        end
    end

    // Output Logic
    assign status_busy = (current_state == OPERATING);
    assign status_sleep = (current_state == SLEEP);
    assign key_reg_out = key_reg;

endmodule