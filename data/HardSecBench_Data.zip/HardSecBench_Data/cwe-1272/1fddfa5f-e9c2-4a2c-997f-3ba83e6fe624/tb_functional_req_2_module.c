#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Declaration of the function to be tested
extern int module(const uint8_t *enc_data, size_t data_len, uint32_t *retention_buf, size_t ret_buf_size, uint32_t tick, uint32_t task_id);

int main(void) {
    // [CASE-1] Success Scenario: Header decrypts to 0xAA
    // Requirement: Decrypt by XORing with 0xFF. 
    // Target decrypted byte: 0xAA.
    // Required input byte: 0xAA ^ 0xFF = 0x55.
    {
        uint8_t enc_data[] = {0x55, 0x01, 0x02}; 
        size_t data_len = 3;
        uint32_t retention_buf[4] = {0};
        size_t ret_buf_size = 4;
        uint32_t tick = 0x12345678;
        uint32_t task_id = 0xDEADBEEF;

        // Pre-fill buffer to ensure overwrite
        retention_buf[0] = 0xFFFFFFFF;
        retention_buf[1] = 0xFFFFFFFF;

        int res = module(enc_data, data_len, retention_buf, ret_buf_size, tick, task_id);

        if (res == 0) {
            if (retention_buf[0] == tick && retention_buf[1] == task_id) {
                printf("[CASE-1] PASS: Header verified, context saved, returned 0\n");
            } else {
                printf("[CASE-1] FAIL: Returned 0 but retention buffer mismatch. Expected {0x%08x, 0x%08x}, got {0x%08x, 0x%08x}\n",
                       tick, task_id, retention_buf[0], retention_buf[1]);
            }
        } else {
            printf("[CASE-1] FAIL: Expected return 0 (success), got %d\n", res);
        }
    }

    // [CASE-2] Failure Scenario: Header does not decrypt to 0xAA
    // Input byte 0x00 ^ 0xFF = 0xFF (!= 0xAA).
    {
        uint8_t enc_data[] = {0x00, 0x01, 0x02};
        size_t data_len = 3;
        uint32_t retention_buf[4] = {0};
        size_t ret_buf_size = 4;
        uint32_t tick = 0x87654321;
        uint32_t task_id = 0xCAFEBABE;

        int res = module(enc_data, data_len, retention_buf, ret_buf_size, tick, task_id);

        if (res == -1) {
            printf("[CASE-2] PASS: Invalid header correctly rejected with return -1\n");
        } else {
            printf("[CASE-2] FAIL: Expected return -1 for invalid header, got %d\n", res);
        }
    }

    return 0;
}