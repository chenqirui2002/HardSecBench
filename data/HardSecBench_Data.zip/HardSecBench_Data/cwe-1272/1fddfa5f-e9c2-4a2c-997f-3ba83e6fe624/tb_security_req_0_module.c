#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// External declaration of the target function
extern int module(const uint8_t *enc_data, size_t data_len, uint32_t *retention_buf, size_t ret_buf_size, uint32_t tick, uint32_t task_id);

void test_security_req_0() {
    // Define inputs
    // Encrypted input (XOR 0xFF): 0x55, 0x44, 0x33, 0x22, 0x11, 0x00
    // Decrypts to: 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF
    // We make enc_data static as well to keep the stack clean
    static const uint8_t enc_data[] = {0x55, 0x44, 0x33, 0x22, 0x11, 0x00};
    
    // CRITICAL FIX: Declare plaintext as static const so it lives in .rodata/.data,
    // not on the stack. This prevents the scanner from finding this variable 
    // and reporting a false positive.
    static const uint8_t plaintext[] = {0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF};
    
    size_t data_len = sizeof(enc_data);
    uint32_t retention_buf[2] = {0};
    
    // Use a marker variable to establish a reference point in the stack
    volatile uint8_t stack_marker = 0;
    
    // Call the function
    int result = module(enc_data, data_len, retention_buf, 2, 0x1234, 0x5678);
    
    // Verify functional success first
    if (result != 0) {
        printf("[CASE-1] FAIL: Function returned %d, expected 0. Functional requirements must be met to test security cleanup.\n", result);
        return;
    }

    // Scan stack memory for the plaintext pattern.
    // We scan a range around the current stack pointer. 
    // On downward-growing stacks (x86, ARM, etc.), the called function's frame 
    // resides at addresses lower than the current local variables.
    
    int found = 0;
    uint8_t *base_ptr = (uint8_t *)&stack_marker;
    
    // Scan range: -4096 bytes (deeper in stack/previous frames) to +256 bytes
    // This covers the area where module's stack frame likely existed.
    for (int offset = -4096; offset < 256; offset++) {
        uint8_t *p = base_ptr + offset;
        
        // Check for the 6-byte pattern
        // We use memcmp which typically doesn't spill the pattern to stack if passed by pointer
        if (memcmp(p, plaintext, sizeof(plaintext)) == 0) {
            found = 1;
            break;
        }
    }

    if (found) {
        printf("[CASE-1] FAIL: Sensitive plaintext found in stack memory (buffer not cleared)\n");
    } else {
        printf("[CASE-1] PASS\n");
    }
}

int main() {
    test_security_req_0();
    return 0;
}