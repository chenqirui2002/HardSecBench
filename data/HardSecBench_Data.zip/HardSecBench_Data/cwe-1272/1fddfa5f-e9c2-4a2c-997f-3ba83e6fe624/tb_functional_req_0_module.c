#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

// Declare the target function
extern int module(const uint8_t *enc_data, size_t data_len, uint32_t *retention_buf, size_t ret_buf_size, uint32_t tick, uint32_t task_id);

int main() {
    // Valid dummy data for non-NULL arguments
    uint8_t valid_enc_data[] = {0x00, 0x01};
    uint32_t valid_ret_buf[2] = {0};
    size_t valid_data_len = 2;
    size_t valid_ret_size = 2;

    // Test Case 1: Verify validation of NULL pointers
    {
        // Check NULL enc_data
        int res1 = module(NULL, valid_data_len, valid_ret_buf, valid_ret_size, 0, 0);
        
        // Check NULL retention_buf
        int res2 = module(valid_enc_data, valid_data_len, NULL, valid_ret_size, 0, 0);

        if (res1 == -2 && res2 == -2) {
            printf("[CASE-1] PASS: Function correctly returns -2 for NULL pointers\n");
        } else {
            printf("[CASE-1] FAIL: NULL pointer checks failed. enc_data_res=%d, ret_buf_res=%d\n", res1, res2);
        }
    }

    // Test Case 2: Verify validation of ret_buf_size < 2
    {
        size_t invalid_ret_size = 1;
        int res = module(valid_enc_data, valid_data_len, valid_ret_buf, invalid_ret_size, 0, 0);
        
        if (res == -2) {
            printf("[CASE-2] PASS: Function correctly returns -2 when ret_buf_size < 2\n");
        } else {
            printf("[CASE-2] FAIL: Expected -2 for ret_buf_size=1, got %d\n", res);
        }
    }

    // Test Case 3: Verify validation of data_len < 1
    {
        size_t invalid_data_len = 0;
        int res = module(valid_enc_data, invalid_data_len, valid_ret_buf, valid_ret_size, 0, 0);
        
        if (res == -2) {
            printf("[CASE-3] PASS: Function correctly returns -2 when data_len < 1\n");
        } else {
            printf("[CASE-3] FAIL: Expected -2 for data_len=0, got %d\n", res);
        }
    }

    return 0;
}