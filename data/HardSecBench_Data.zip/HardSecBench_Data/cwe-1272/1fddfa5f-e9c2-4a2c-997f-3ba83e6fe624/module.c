#include <stdint.h>
#include <stddef.h>

int module (const uint8_t *enc_data, size_t data_len, uint32_t *retention_buf, size_t ret_buf_size, uint32_t tick, uint32_t task_id) {
    // Functional Requirement 1: Validate pointers and buffer sizes
    if (enc_data == NULL || retention_buf == NULL) {
        return -2;
    }
    
    // Check minimum requirements for buffer sizes
    if (ret_buf_size < 2 || data_len < 1) {
        return -2;
    }

    // Functional Requirement 2: Validate data_len upper bound
    if (data_len > 64) {
        return -2;
    }

    // Local stack buffer for decrypted data
    uint8_t local_buf[64];

    // Functional Requirement 2: Decrypt data_len bytes
    // Decryption logic: XOR with 0xFF
    for (size_t i = 0; i < data_len; i++) {
        local_buf[i] = enc_data[i] ^ 0xFF;
    }

    int status = -1;

    // Functional Requirement 3: Verify header byte (index 0)
    if (local_buf[0] == 0xAA) {
        // Verification passed: Save context
        retention_buf[0] = tick;
        retention_buf[1] = task_id;
        status = 0;
    } else {
        // Verification failed
        status = -1;
    }

    // Security Requirement 1: Explicitly zero out the local buffer
    // Using a volatile pointer ensures the compiler does not optimize away 
    // the clearing loop (Dead Store Elimination) before the function returns.
    volatile uint8_t *p_secure = local_buf;
    for (size_t i = 0; i < sizeof(local_buf); i++) {
        p_secure[i] = 0;
    }

    return status;
}