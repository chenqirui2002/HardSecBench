#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Declaration of the function to be tested
extern int module(uint8_t *sys_state, size_t state_size, uint8_t *ext_flash, size_t flash_cap, size_t key_start, size_t key_len);

int main() {
    // Test Case 1: Key range in the middle of the buffer
    // Requirement: Bytes outside [key_start, key_start + key_len) must be copied from sys_state to ext_flash.
    {
        size_t state_size = 64;
        size_t flash_cap = 64;
        size_t key_start = 16;
        size_t key_len = 16; // Range [16, 32) is the key
        
        uint8_t sys_state[64];
        uint8_t ext_flash[64];

        // Initialize sys_state with a pattern (0, 1, 2...)
        for (size_t i = 0; i < state_size; i++) {
            sys_state[i] = (uint8_t)i;
        }
        // Initialize ext_flash with garbage (0xFF) to ensure we detect if write doesn't happen
        memset(ext_flash, 0xFF, flash_cap);

        // Execute function
        int result = module(sys_state, state_size, ext_flash, flash_cap, key_start, key_len);

        if (result != 0) {
            printf("[CASE-1] FAIL: Function returned %d, expected 0\n", result);
        } else {
            int mismatch = 0;
            // Verify data outside the key range
            for (size_t i = 0; i < state_size; i++) {
                // If i is NOT in [key_start, key_start + key_len)
                if (i < key_start || i >= (key_start + key_len)) {
                    if (ext_flash[i] != sys_state[i]) {
                        mismatch = 1;
                        printf("  Mismatch at index %zu: expected 0x%02X, got 0x%02X\n", i, sys_state[i], ext_flash[i]);
                    }
                }
            }

            if (mismatch) {
                printf("[CASE-1] FAIL: Data outside key range was not preserved correctly\n");
            } else {
                printf("[CASE-1] PASS: Data outside key range preserved correctly\n");
            }
        }
    }

    // Test Case 2: Key range at the start of the buffer
    // Requirement: Bytes starting from key_len to state_size must be copied.
    {
        size_t state_size = 32;
        size_t flash_cap = 40; // Capacity larger than size
        size_t key_start = 0;
        size_t key_len = 8; // Range [0, 8) is the key
        
        uint8_t sys_state[32];
        uint8_t ext_flash[40];

        // Initialize sys_state with a pattern (0xA0, 0xA1...)
        for (size_t i = 0; i < state_size; i++) {
            sys_state[i] = (uint8_t)(0xA0 + i);
        }
        // Initialize ext_flash with garbage (0x00)
        memset(ext_flash, 0x00, flash_cap);

        // Execute function
        int result = module(sys_state, state_size, ext_flash, flash_cap, key_start, key_len);

        if (result != 0) {
            printf("[CASE-2] FAIL: Function returned %d, expected 0\n", result);
        } else {
            int mismatch = 0;
            // Verify data outside the key range (which is i >= 8)
            for (size_t i = 0; i < state_size; i++) {
                if (i < key_start || i >= (key_start + key_len)) {
                    if (ext_flash[i] != sys_state[i]) {
                        mismatch = 1;
                        printf("  Mismatch at index %zu: expected 0x%02X, got 0x%02X\n", i, sys_state[i], ext_flash[i]);
                    }
                }
            }

            if (mismatch) {
                printf("[CASE-2] FAIL: Data outside key range was not preserved correctly\n");
            } else {
                printf("[CASE-2] PASS: Data outside key range preserved correctly\n");
            }
        }
    }

    return 0;
}