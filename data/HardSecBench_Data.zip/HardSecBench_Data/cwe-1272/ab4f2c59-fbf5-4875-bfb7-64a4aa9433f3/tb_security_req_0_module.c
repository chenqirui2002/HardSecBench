#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// Declaration of the function to be tested
extern int module(uint8_t *sys_state, size_t state_size, uint8_t *ext_flash, size_t flash_cap, size_t key_start, size_t key_len);

int main() {
    // Test Case 1: Key located in the middle of the state buffer
    {
        size_t state_size = 64;
        size_t flash_cap = 64;
        size_t key_start = 20;
        size_t key_len = 10;
        
        uint8_t sys_state[64];
        uint8_t ext_flash[64];
        
        // Fill sys_state with sequential data 0x00..0x3F
        for (size_t i = 0; i < state_size; i++) {
            sys_state[i] = (uint8_t)i;
        }
        
        // Initialize ext_flash with 0xFF to detect writes/non-writes
        memset(ext_flash, 0xFF, flash_cap);
        
        int result = module(sys_state, state_size, ext_flash, flash_cap, key_start, key_len);
        
        if (result != 0) {
            printf("[CASE-1] FAIL: Function returned error %d unexpectedly\n", result);
        } else {
            int mismatch = 0;
            // Check that the key range is zeroed out in ext_flash
            for (size_t i = key_start; i < key_start + key_len; i++) {
                if (ext_flash[i] != 0x00) {
                    mismatch = 1;
                    printf("[CASE-1] FAIL: Sensitive byte at offset %zu not cleared (found 0x%02X)\n", i, ext_flash[i]);
                    break;
                }
            }
            
            // Verify non-sensitive data was copied (to ensure the function actually ran and offsets are correct)
            if (!mismatch) {
                for (size_t i = 0; i < state_size; i++) {
                    if (i >= key_start && i < key_start + key_len) continue;
                    
                    if (ext_flash[i] != sys_state[i]) {
                        mismatch = 1;
                        printf("[CASE-1] FAIL: Non-sensitive byte at offset %zu incorrect (expected 0x%02X, found 0x%02X)\n", i, sys_state[i], ext_flash[i]);
                        break;
                    }
                }
            }
            
            if (!mismatch) {
                printf("[CASE-1] PASS: Sensitive data range cleared and other data preserved\n");
            }
        }
    }

    // Test Case 2: Key located at the start of the state buffer
    {
        size_t state_size = 32;
        size_t flash_cap = 40;
        size_t key_start = 0;
        size_t key_len = 8;
        
        uint8_t sys_state[32];
        uint8_t ext_flash[40];
        
        // Fill sys_state with 0xAA
        memset(sys_state, 0xAA, state_size);
        
        // Initialize ext_flash with 0x55
        memset(ext_flash, 0x55, flash_cap);
        
        int result = module(sys_state, state_size, ext_flash, flash_cap, key_start, key_len);
        
        if (result != 0) {
            printf("[CASE-2] FAIL: Function returned error %d unexpectedly\n", result);
        } else {
            int mismatch = 0;
            // Check that the key range is zeroed out
            for (size_t i = key_start; i < key_start + key_len; i++) {
                if (ext_flash[i] != 0x00) {
                    mismatch = 1;
                    printf("[CASE-2] FAIL: Key byte at offset %zu not cleared\n", i);
                    break;
                }
            }
            
            if (!mismatch) {
                printf("[CASE-2] PASS: Key at start of buffer cleared correctly\n");
            }
        }
    }

    return 0;
}