#include <stddef.h>
#include <stdint.h>
#include <string.h>

int module (uint8_t *sys_state, size_t state_size, uint8_t *ext_flash, size_t flash_cap, size_t key_start, size_t key_len) {
    /* Validate input pointers */
    if (sys_state == NULL || ext_flash == NULL) {
        return -1;
    }

    /* Validate that state size fits in flash capacity */
    if (state_size > flash_cap) {
        return -1;
    }

    /* Check for integer overflow in key range calculation */
    if (key_len > SIZE_MAX - key_start) {
        return -1;
    }
    size_t key_end = key_start + key_len;

    /* Validate that the key range is fully contained within the state data */
    if (key_end > state_size) {
        return -1;
    }

    /* 
     * Copy data to external flash buffer, redacting the key.
     * The operation is split into three parts to ensure the key data 
     * from sys_state is never read or written to ext_flash.
     */

    /* Part 1: Copy data before the key */
    if (key_start > 0) {
        memcpy(ext_flash, sys_state, key_start);
    }

    /* Part 2: Redact key (Security Requirement) - Set destination range to 0x00 */
    if (key_len > 0) {
        memset(ext_flash + key_start, 0x00, key_len);
    }

    /* Part 3: Copy data after the key */
    size_t remaining = state_size - key_end;
    if (remaining > 0) {
        memcpy(ext_flash + key_end, sys_state + key_end, remaining);
    }

    return 0;
}