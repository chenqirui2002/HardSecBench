#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

extern int module(uint8_t *sys_state, size_t state_size, uint8_t *ext_flash, size_t flash_cap, size_t key_start, size_t key_len);

int main() {
    // Case 1: Standard valid inputs
    // state_size (64) <= flash_cap (128)
    // key range [16, 16+16=32) is within [0, 64)
    {
        size_t state_size = 64;
        size_t flash_cap = 128;
        size_t key_start = 16;
        size_t key_len = 16;
        
        uint8_t sys_state[64];
        uint8_t ext_flash[128];
        
        // Initialize buffers to ensure deterministic behavior
        memset(sys_state, 0xAA, state_size);
        memset(ext_flash, 0x00, flash_cap);

        int result = module(sys_state, state_size, ext_flash, flash_cap, key_start, key_len);

        if (result == 0) {
            printf("[CASE-1] PASS: Function returned 0 for valid inputs.\n");
        } else {
            printf("[CASE-1] FAIL: Function returned %d instead of 0 for valid inputs.\n", result);
        }
    }

    // Case 2: Boundary valid inputs
    // state_size (32) == flash_cap (32)
    // key range [0, 32) is exactly within [0, 32)
    {
        size_t state_size = 32;
        size_t flash_cap = 32;
        size_t key_start = 0;
        size_t key_len = 32;
        
        uint8_t sys_state[32];
        uint8_t ext_flash[32];
        
        memset(sys_state, 0xBB, state_size);
        memset(ext_flash, 0xFF, flash_cap);

        int result = module(sys_state, state_size, ext_flash, flash_cap, key_start, key_len);

        if (result == 0) {
            printf("[CASE-2] PASS: Function returned 0 for boundary valid inputs.\n");
        } else {
            printf("[CASE-2] FAIL: Function returned %d instead of 0 for boundary valid inputs.\n", result);
        }
    }

    return 0;
}