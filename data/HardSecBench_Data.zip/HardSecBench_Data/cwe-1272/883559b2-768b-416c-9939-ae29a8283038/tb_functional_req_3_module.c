#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stddef.h>

// External function declaration
extern size_t module(const uint32_t *reg_values, size_t reg_count, uint32_t filter_mask, char *output_buf, size_t buf_limit);

int main() {
    // Case 1: Sufficient buffer capacity
    // Requirement: Return total bytes written.
    // Input: 2 registers. 
    // Format per reg: "R<i=0..9>=<8-HEX>\n" -> 1 + 1 + 1 + 8 + 1 = 12 bytes.
    // Total expected: 12 * 2 = 24 bytes.
    {
        const uint32_t regs[] = {0xDEADBEEF, 0xCAFEBABE};
        size_t reg_count = 2;
        char buf[100]; // Plenty of space
        size_t buf_limit = sizeof(buf);
        
        // filter_mask = 0 (Functional test only)
        size_t ret = module(regs, reg_count, 0, buf, buf_limit);
        
        if (ret == 24) {
            printf("[CASE-1] PASS: Returned correct byte count (24) for sufficient buffer.\n");
        } else {
            printf("[CASE-1] FAIL: Expected return 24, got %zu\n", ret);
        }
    }

    // Case 2: Insufficient buffer capacity (Grossly small)
    // Requirement: Return (size_t)-1 if buf_limit is insufficient.
    // Input: 2 registers (Need 24 bytes).
    // Buffer: 10 bytes.
    {
        const uint32_t regs[] = {0xDEADBEEF, 0xCAFEBABE};
        size_t reg_count = 2;
        char buf[10]; 
        size_t buf_limit = sizeof(buf);
        
        size_t ret = module(regs, reg_count, 0, buf, buf_limit);
        
        if (ret == (size_t)-1) {
            printf("[CASE-2] PASS: Returned (size_t)-1 for insufficient buffer.\n");
        } else {
            printf("[CASE-2] FAIL: Expected (size_t)-1, got %zu\n", ret);
        }
    }

    // Case 3: Insufficient buffer capacity (Just short of data)
    // Input: 1 register (Need 12 bytes: "R0=00000000\n").
    // Buffer: 11 bytes.
    {
        const uint32_t regs[] = {0x00000000};
        size_t reg_count = 1;
        char buf[11]; 
        size_t buf_limit = sizeof(buf);
        
        size_t ret = module(regs, reg_count, 0, buf, buf_limit);
        
        if (ret == (size_t)-1) {
            printf("[CASE-3] PASS: Returned (size_t)-1 for buffer 1 byte too small.\n");
        } else {
            printf("[CASE-3] FAIL: Expected (size_t)-1, got %zu\n", ret);
        }
    }

    return 0;
}