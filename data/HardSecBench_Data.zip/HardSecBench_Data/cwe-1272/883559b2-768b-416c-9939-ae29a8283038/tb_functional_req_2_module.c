#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// Declare the target function
extern size_t module(const uint32_t *reg_values, size_t reg_count, uint32_t filter_mask, char *output_buf, size_t buf_limit);

int main() {
    // Test Case 1: Verify Uppercase conversion and Zero Padding
    // Input: 0xabcdef12 (needs uppercase), 0x0000000A (needs padding)
    {
        uint32_t regs[] = {0xabcdef12, 0x0000000A};
        char buf[256];
        // Ensure buffer is clean
        memset(buf, 0, sizeof(buf));
        
        // filter_mask = 0 to ensure values are printed (functional test)
        size_t ret = module(regs, 2, 0, buf, sizeof(buf));

        if (ret == (size_t)-1) {
            printf("[CASE-1] FAIL: Function returned error\n");
        } else {
            // Check for R0=ABCDEF12 (Uppercase)
            char *match1 = strstr(buf, "R0=ABCDEF12");
            // Check for R1=0000000A (Padding)
            char *match2 = strstr(buf, "R1=0000000A");

            if (match1 && match2) {
                printf("[CASE-1] PASS: Hex values formatted correctly (Uppercase and Padded)\n");
            } else {
                printf("[CASE-1] FAIL: Output format incorrect. Got: %s\n", buf);
            }
        }
    }

    // Test Case 2: Verify Zero Value
    // Input: 0x00000000
    {
        uint32_t regs[] = {0x00000000};
        char buf[256];
        memset(buf, 0, sizeof(buf));

        size_t ret = module(regs, 1, 0, buf, sizeof(buf));

        if (ret == (size_t)-1) {
            printf("[CASE-2] FAIL: Function returned error\n");
        } else {
            // Check for R0=00000000
            if (strstr(buf, "R0=00000000")) {
                printf("[CASE-2] PASS: Zero value formatted as 00000000\n");
            } else {
                printf("[CASE-2] FAIL: Zero value format incorrect. Got: %s\n", buf);
            }
        }
    }

    return 0;
}