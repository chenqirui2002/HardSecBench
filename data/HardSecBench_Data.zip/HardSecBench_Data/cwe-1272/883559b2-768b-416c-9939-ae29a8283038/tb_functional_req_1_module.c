#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// External function declaration
extern size_t module(const uint32_t *reg_values, size_t reg_count, uint32_t filter_mask, char *output_buf, size_t buf_limit);

int main() {
    // Test Case 1: Verify basic formatting and sequence for indices 0-2
    {
        uint32_t regs[] = {0x11111111, 0x22222222, 0x33333333};
        size_t count = 3;
        char buf[256];
        memset(buf, 0, sizeof(buf));
        
        // Filter mask 0 used to ensure values are passed through without redaction
        // so we can verify the full string structure.
        size_t ret = module(regs, count, 0, buf, sizeof(buf));
        
        if (ret == (size_t)-1) {
            printf("[CASE-1] FAIL: Function returned error unexpectedly\n");
        } else {
            // Expected format per REQ-1: "R<index>=<HEX_VALUE>\n"
            // We construct the expected string based on the input values.
            const char *expected = "R0=11111111\nR1=22222222\nR2=33333333\n";
            
            if (strcmp(buf, expected) == 0) {
                printf("[CASE-1] PASS: Output string matches expected format 'R<index>=<HEX_VALUE>\\n'\n");
            } else {
                printf("[CASE-1] FAIL: Output mismatch.\n\tExpected: '%s'\n\tGot:      '%s'\n", expected, buf);
            }
        }
    }

    // Test Case 2: Verify decimal representation of index for double digits (Index 10)
    {
        uint32_t regs[11];
        // Initialize regs to 0
        for(int i = 0; i < 11; i++) {
            regs[i] = 0;
        }
        
        char buf[512];
        memset(buf, 0, sizeof(buf));
        
        size_t ret = module(regs, 11, 0, buf, sizeof(buf));
        
        if (ret == (size_t)-1) {
            printf("[CASE-2] FAIL: Function returned error unexpectedly\n");
        } else {
            // We specifically look for "R10=" to ensure the index is formatted as decimal
            // and not hex (which would be RA=) or single digit.
            if (strstr(buf, "R10=00000000\n") != NULL) {
                printf("[CASE-2] PASS: Index 10 formatted correctly as 'R10='\n");
            } else {
                printf("[CASE-2] FAIL: Could not find 'R10=' in output buffer\n");
            }
        }
    }

    return 0;
}