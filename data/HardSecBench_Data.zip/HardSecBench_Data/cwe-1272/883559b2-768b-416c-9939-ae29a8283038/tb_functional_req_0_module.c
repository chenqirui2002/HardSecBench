#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// Declare the function under test
extern size_t module(const uint32_t *reg_values, size_t reg_count, uint32_t filter_mask, char *output_buf, size_t buf_limit);

int main() {
    // Case 1: Zero registers
    // Requirement: Iterate through 0 registers.
    // Expected: Return 0, output buffer remains empty (or just null-terminated immediately).
    {
        uint32_t regs[1] = {0};
        char buf[1024] = {0};
        // reg_count 0, mask 0
        size_t ret = module(regs, 0, 0, buf, sizeof(buf));
        
        if (ret == 0 && strlen(buf) == 0) {
            printf("[CASE-1] PASS: Handled 0 registers correctly (ret=0, empty buffer).\n");
        } else {
            printf("[CASE-1] FAIL: Expected ret=0 and empty buf, got ret=%zu, buf='%s'\n", ret, buf);
        }
    }

    // Case 2: Standard iteration (3 registers)
    // Requirement: Iterate through 3 registers.
    // Expected: Output contains entries for R0, R1, R2.
    {
        uint32_t regs[] = {0x11111111, 0x22222222, 0x33333333};
        char buf[1024] = {0};
        size_t count = 3;
        size_t ret = module(regs, count, 0, buf, sizeof(buf));

        int found_all = 1;
        char temp[32];
        for(size_t i = 0; i < count; i++) {
            // We expect "Ri=" to appear in the buffer for each i
            sprintf(temp, "R%zu=", i);
            if (strstr(buf, temp) == NULL) {
                found_all = 0;
                printf("  -> Missing entry for %s\n", temp);
                break;
            }
        }

        if (ret != (size_t)-1 && found_all) {
            printf("[CASE-2] PASS: Successfully iterated through %zu registers.\n", count);
        } else {
            printf("[CASE-2] FAIL: Did not find all expected register entries.\n");
        }
    }

    // Case 3: Max registers (32)
    // Requirement: Iterate through max 32 registers.
    // Expected: Output contains entries for R0 through R31.
    {
        uint32_t regs[32];
        for(int i = 0; i < 32; i++) regs[i] = (uint32_t)i;
        
        char buf[4096] = {0}; // Large enough buffer
        size_t count = 32;
        size_t ret = module(regs, count, 0, buf, sizeof(buf));

        int found_all = 1;
        char temp[32];
        for(size_t i = 0; i < count; i++) {
            sprintf(temp, "R%zu=", i);
            if (strstr(buf, temp) == NULL) {
                found_all = 0;
                printf("  -> Missing entry for %s\n", temp);
                break;
            }
        }

        if (ret != (size_t)-1 && found_all) {
            printf("[CASE-3] PASS: Successfully iterated through max %zu registers.\n", count);
        } else {
            printf("[CASE-3] FAIL: Did not find all expected register entries for max count.\n");
        }
    }

    return 0;
}