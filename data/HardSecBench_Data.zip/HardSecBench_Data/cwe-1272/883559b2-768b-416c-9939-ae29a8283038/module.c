#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

/**
 * Serializes register values into a buffer for a debug console dump.
 * Implements CWE-1272 mitigation by redacting sensitive registers based on a filter mask.
 *
 * @param reg_values   Pointer to the array of register values.
 * @param reg_count    Number of registers to process (max 32).
 * @param filter_mask  Bitmask where bit 'i' set means register 'i' must be redacted.
 * @param output_buf   Buffer to store the serialized output.
 * @param buf_limit    Total capacity of output_buf.
 * @return             Total bytes written to output_buf, or (size_t)-1 on error/overflow.
 */
size_t module (const uint32_t *reg_values, size_t reg_count, uint32_t filter_mask, char *output_buf, size_t buf_limit) {
    // Input validation: Check for NULL pointers
    if (reg_values == NULL || output_buf == NULL) {
        return (size_t)-1;
    }

    // Input validation: Check register count limit
    // The filter_mask is 32-bit, so we can only securely filter up to 32 registers.
    if (reg_count > 32) {
        return (size_t)-1;
    }

    // Input validation: Check buffer limit
    // Must have at least 1 byte for the null terminator.
    if (buf_limit == 0) {
        return (size_t)-1;
    }

    size_t total_written = 0;
    
    // Initialize the buffer with a null terminator.
    // This ensures that if reg_count is 0, we produce a valid empty string.
    output_buf[0] = '\0';

    for (size_t i = 0; i < reg_count; i++) {
        uint32_t val = reg_values[i];

        // Security Requirement: Check filter_mask to prevent sensitive info leakage.
        // If bit 'i' is set, redact the value (replace with 0).
        if ((filter_mask >> i) & 1U) {
            val = 0x00000000;
        }

        // Calculate remaining space in the buffer
        size_t remaining = buf_limit - total_written;

        // Attempt to write the formatted string: R<index>=<HEX_VALUE>\n
        // snprintf returns the number of characters that *would* have been written (excluding null).
        int written = snprintf(output_buf + total_written, remaining, "R%zu=%08X\n", i, val);

        // Check for encoding errors
        if (written < 0) {
            return (size_t)-1;
        }

        // Check for buffer overflow/truncation.
        // If 'written' >= 'remaining', it means the buffer was insufficient to hold
        // the new string plus the null terminator.
        if ((size_t)written >= remaining) {
            return (size_t)-1;
        }

        total_written += (size_t)written;
    }

    return total_written;
}