`timescale 1ns/1ps

module tb_functional_req_1;

    // Inputs to UUT
    reg clk;
    reg rst_n;
    reg [3:0] sid_in;
    reg sid_load;
    reg start;
    reg [7:0] data_in;

    // Outputs from UUT
    wire bus_req;
    wire [3:0] bus_sid;
    wire [7:0] bus_data;

    // Instantiate the Unit Under Test (UUT)
    topmodule uut (
        .clk(clk),
        .rst_n(rst_n),
        .sid_in(sid_in),
        .sid_load(sid_load),
        .start(start),
        .data_in(data_in),
        .bus_req(bus_req),
        .bus_sid(bus_sid),
        .bus_data(bus_data)
    );

    // Clock generation
    always #5 clk = ~clk;

    // Test Variables
    integer i;
    reg [3:0] test_sid;
    reg [7:0] test_data;

    initial begin
        // Initialize Inputs
        clk = 0;
        rst_n = 0;
        sid_in = 4'b0;
        sid_load = 0;
        start = 0;
        data_in = 8'b0;

        // Apply Reset
        #10;
        rst_n = 1;
        #10;

        // -------------------------------------------------------
        // Check 1: Reset State
        // Internal register clears to 0 on reset, so bus_sid should be 0
        // -------------------------------------------------------
        if (bus_sid !== 4'b0000) begin
            $display("[TEST] FAIL: bus_sid is not 0 after reset. Got: %b", bus_sid);
            $finish;
        end

        // -------------------------------------------------------
        // Check 2: Data Pass-through (Combinational)
        // bus_data should continuously drive data_in
        // -------------------------------------------------------
        test_data = 8'hA5;
        data_in = test_data;
        #1; // Allow for combinational propagation
        if (bus_data !== test_data) begin
            $display("[TEST] FAIL: bus_data did not propagate data_in immediately. Expected: %h, Got: %h", test_data, bus_data);
            $finish;
        end

        // -------------------------------------------------------
        // Check 3: SID Loading and Data Updates
        // Verify bus_sid updates on clock when load is high
        // Verify bus_data updates with data_in
        // -------------------------------------------------------
        for (i = 0; i < 5; i = i + 1) begin
            test_sid = $random % 16;
            test_data = $random % 256;

            // Setup inputs
            sid_in = test_sid;
            sid_load = 1;
            data_in = test_data;

            // Check data_in propagation before clock (combinational)
            #1;
            if (bus_data !== test_data) begin
                $display("[TEST] FAIL: bus_data mismatch before clock. Expected: %h, Got: %h", test_data, bus_data);
                $finish;
            end

            // Clock the SID load
            @(posedge clk);
            #1; // Hold time

            // Verify SID updated
            if (bus_sid !== test_sid) begin
                $display("[TEST] FAIL: bus_sid did not update after load. Expected: %h, Got: %h", test_sid, bus_sid);
                $finish;
            end
        end

        // -------------------------------------------------------
        // Check 4: SID Stability (No Load)
        // Verify bus_sid holds value when sid_load is low
        // -------------------------------------------------------
        sid_load = 0;
        test_sid = bus_sid; // Current value
        sid_in = ~test_sid; // Change input to something else
        
        @(posedge clk);
        #1;

        if (bus_sid !== test_sid) begin
            $display("[TEST] FAIL: bus_sid changed when sid_load was low. Expected: %h, Got: %h", test_sid, bus_sid);
            $finish;
        end

        // Verify data_in still propagates even if sid_load is low
        data_in = 8'hFF;
        #1;
        if (bus_data !== 8'hFF) begin
            $display("[TEST] FAIL: bus_data stopped propagating when sid_load low. Expected: FF, Got: %h", bus_data);
            $finish;
        end

        $display("[TEST] PASS: bus_sid reflects register and bus_data reflects data_in");
        $finish;
    end

endmodule